import React, { useState } from 'react';
import {
  Alert, Platform, Pressable, ScrollView, StyleSheet, Text, TouchableOpacity, View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/context/AuthContext';

interface Plan {
  id: string;
  name: string;
  price: string;
  duration: string;
  gradient: [string, string];
  icon: string;
  features: string[];
  badge?: string;
}

const PLANS: Plan[] = [
  {
    id: 'temel',
    name: 'Temel',
    price: '₺29',
    duration: '/ay',
    gradient: ['#4A3F70', '#3D3468'],
    icon: 'star-outline',
    features: ['Sınırsız okuma', 'Reklamsız deneyim', 'Temel rozet'],
  },
  {
    id: 'standart',
    name: 'Standart',
    price: '₺59',
    duration: '/ay',
    gradient: ['#1E3A5F', '#0E4D6B'],
    icon: 'star-half-outline',
    features: ['Temel özellikleri + ...', 'Dergi yazarlığı', 'Kitap indirme', 'Özel bölüme erişim'],
    badge: 'Popüler',
  },
  {
    id: 'premium',
    name: 'Premium',
    price: '₺99',
    duration: '/ay',
    gradient: ['#78350F', '#92400E'],
    icon: 'star',
    features: ['Standart + ...', 'Altın rozet', 'Vitrin öne çıkarma', 'Discord topluluğu', 'Erken erişim'],
    badge: 'En İyi Değer',
  },
  {
    id: 'vip',
    name: 'VIP',
    price: '₺199',
    duration: '/ay',
    gradient: ['#6B21A8', '#7C3AED'],
    icon: 'diamond',
    features: ['Premium + ...', 'VIP rozeti', 'Admin ile direkt iletişim', 'Özel içerik oluşturma', 'Tüm içeriklere sınırsız erişim'],
    badge: '👑 VIP',
  },
];

export default function PremiumScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const [selected, setSelected] = useState<string | null>(null);
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const handleRequest = () => {
    if (!selected) { Alert.alert('Plan Seç', 'Lütfen bir abonelik planı seçin.'); return; }
    const plan = PLANS.find(p => p.id === selected)!;
    Alert.alert(
      'Talep Gönderildi 🎉',
      `${plan.name} abonelik talebiniz alındı. Admin onayından sonra aktif edilecek.`,
      [{ text: 'Tamam', onPress: () => router.back() }]
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <LinearGradient colors={[colors.primary, colors.accent]} style={[styles.hero, { paddingTop: topPad }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color="#fff" />
        </Pressable>
        <View style={styles.heroContent}>
          <Ionicons name="diamond" size={40} color="#FFD700" />
          <Text style={styles.heroTitle}>Premium Üyelik</Text>
          <Text style={styles.heroSub}>Sınırsız okuma, özel içerikler ve daha fazlası</Text>
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {user?.isPremium && (
          <View style={[styles.activeBanner, { backgroundColor: colors.success + '22', borderColor: colors.success }]}>
            <Ionicons name="checkmark-circle" size={20} color={colors.success} />
            <Text style={[styles.activeBannerText, { color: colors.success }]}>Aktif Premium Üyeliğin Var</Text>
          </View>
        )}

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Plan Seç</Text>

        {PLANS.map(plan => (
          <Pressable key={plan.id} onPress={() => setSelected(plan.id)}>
            <LinearGradient
              colors={plan.gradient}
              style={[
                styles.planCard,
                selected === plan.id && styles.planCardSelected,
                selected === plan.id && { borderColor: colors.primary, borderWidth: 2 },
              ]}
            >
              {plan.badge && (
                <View style={styles.badgeWrap}>
                  <Text style={styles.badgeText}>{plan.badge}</Text>
                </View>
              )}
              <View style={styles.planHeader}>
                <Ionicons name={plan.icon as any} size={26} color="#FFD700" />
                <Text style={styles.planName}>{plan.name}</Text>
                <View style={{ flex: 1 }} />
                <Text style={styles.planPrice}>{plan.price}</Text>
                <Text style={styles.planDuration}>{plan.duration}</Text>
                {selected === plan.id && (
                  <Ionicons name="checkmark-circle" size={22} color="#22C55E" style={{ marginLeft: 8 }} />
                )}
              </View>
              <View style={styles.featureList}>
                {plan.features.map((f, i) => (
                  <View key={i} style={styles.featureRow}>
                    <Ionicons name="checkmark" size={14} color="#22C55E" />
                    <Text style={styles.featureText}>{f}</Text>
                  </View>
                ))}
              </View>
            </LinearGradient>
          </Pressable>
        ))}

        <TouchableOpacity onPress={handleRequest} style={[styles.requestBtn, { backgroundColor: colors.primary }]}>
          <Ionicons name="diamond-outline" size={18} color={colors.primaryForeground} />
          <Text style={[styles.requestBtnText, { color: colors.primaryForeground }]}>
            {selected ? `${PLANS.find(p => p.id === selected)?.name} Planını İste` : 'Talep Gönder'}
          </Text>
        </TouchableOpacity>

        <Text style={[styles.note, { color: colors.mutedForeground }]}>
          * Abonelikler admin onayıyla aktive edilir. Ödeme yöntemleri yakında ekleniyor.
        </Text>

        <View style={{ height: insets.bottom + 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  hero: { paddingBottom: 28 },
  backBtn: { padding: 16 },
  heroContent: { alignItems: 'center', gap: 8, paddingBottom: 8 },
  heroTitle: { fontSize: 24, fontFamily: 'Poppins_700Bold', color: '#fff' },
  heroSub: { fontSize: 13, fontFamily: 'Poppins_400Regular', color: 'rgba(255,255,255,0.8)', textAlign: 'center', paddingHorizontal: 32 },
  content: { padding: 16 },
  activeBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 12, padding: 12, borderWidth: 1, marginBottom: 16 },
  activeBannerText: { fontSize: 14, fontFamily: 'Poppins_600SemiBold' },
  sectionTitle: { fontSize: 16, fontFamily: 'Poppins_600SemiBold', marginBottom: 12 },
  planCard: { borderRadius: 16, padding: 16, marginBottom: 12 },
  planCardSelected: { shadowColor: '#9B59F5', shadowOpacity: 0.4, shadowRadius: 12, elevation: 6 },
  badgeWrap: { alignSelf: 'flex-start', backgroundColor: '#FFD700', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, marginBottom: 8 },
  badgeText: { fontSize: 11, fontFamily: 'Poppins_700Bold', color: '#000' },
  planHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  planName: { fontSize: 18, fontFamily: 'Poppins_700Bold', color: '#fff' },
  planPrice: { fontSize: 22, fontFamily: 'Poppins_700Bold', color: '#FFD700' },
  planDuration: { fontSize: 13, color: 'rgba(255,255,255,0.7)', fontFamily: 'Poppins_400Regular', alignSelf: 'flex-end', marginBottom: 2 },
  featureList: { gap: 6 },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  featureText: { fontSize: 13, color: 'rgba(255,255,255,0.9)', fontFamily: 'Poppins_400Regular' },
  requestBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 14, paddingVertical: 16, marginTop: 8 },
  requestBtnText: { fontSize: 16, fontFamily: 'Poppins_600SemiBold' },
  note: { fontSize: 11, fontFamily: 'Poppins_400Regular', textAlign: 'center', marginTop: 16, lineHeight: 18 },
});
