import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AdminLog, Book, Bookmark, Chapter, Comment, ContactMessage, Conversation, DergiPost, Message, Notification, OzelPost, Poem, Post, PostComment, PostReply, ReadingList, Story, SupportTicket, TicketStatus } from '@/data/types';
import { SAMPLE_USERS } from '@/data/sampleData';
import { DEFAULT_BANNED_WORDS, FilterLevel, filterContent } from '@/utils/contentFilter';
import {
  MESSAGES_BY_CONV,
  SAMPLE_BOOKS,
  SAMPLE_COMMENTS,
  SAMPLE_CONVERSATIONS,
  SAMPLE_NOTIFICATIONS,
  SAMPLE_POEMS,
  SAMPLE_POSTS,
  SAMPLE_STORIES,
} from '@/data/sampleData';

const SAMPLE_POST_COMMENTS: PostComment[] = [
  {
    id: 'pc1',
    postId: 'post0',
    authorId: 'u2',
    authorName: 'Mehmet Derin',
    authorAvatarColor: '#EC4899',
    content: 'Harika bir hikaye, okudum ve çok etkilendim!',
    likesCount: 12,
    reactions: { '❤️': 8, '🔥': 3 },
    replies: [
      {
        id: 'pr1',
        commentId: 'pc1',
        authorId: 'u1',
        authorName: 'Ayşe Kalem',
        authorAvatarColor: '#9B59F5',
        content: 'Teşekkür ederim, çok mutlu oldum! 🙏',
        likesCount: 5,
        createdAt: '2024-07-25T10:00:00Z',
      },
    ],
    createdAt: '2024-07-25T09:00:00Z',
  },
  {
    id: 'pc2',
    postId: 'post1',
    authorId: 'u5',
    authorName: 'Zeynep Masalcı',
    authorAvatarColor: '#3B82F6',
    content: 'Bu duygu herkese tanıdık geliyor... Yazarlık bazen öyle bir sessizlik ki...',
    likesCount: 24,
    reactions: { '😢': 15, '❤️': 9 },
    replies: [],
    createdAt: '2024-07-23T19:00:00Z',
  },
];

interface DataContextType {
  books: Book[];
  stories: Story[];
  poems: Poem[];
  posts: Post[];
  comments: Comment[];
  postComments: PostComment[];
  notifications: Notification[];
  conversations: Conversation[];
  messagesByConv: Record<string, Message[]>;
  lists: ReadingList[];
  likedIds: Set<string>;
  savedIds: Set<string>;
  followedIds: Set<string>;
  postLikedIds: Set<string>;
  postSavedIds: Set<string>;
  postCommentLikedIds: Set<string>;
  userRatings: Record<string, number>;
  readProgress: Record<string, number>;
  unreadNotifCount: number;
  // Support & Contact
  supportTickets: SupportTicket[];
  contactMessages: ContactMessage[];
  adminLogs: AdminLog[];
  // Admin user management (local state)
  adminUsers: typeof SAMPLE_USERS;
  // Dergi & Özel
  dergiPosts: DergiPost[];
  ozelPosts: OzelPost[];
  dergiLikedIds: Set<string>;
  ozelLikedIds: Set<string>;
  addDergiPost: (post: DergiPost) => void;
  addOzelPost: (post: OzelPost) => void;
  toggleDergiLike: (id: string) => void;
  toggleOzelLike: (id: string) => void;
  // Admin permission management
  adminGrantPermission: (userId: string, perm: 'canMagazineWrite' | 'canPostVideo' | 'canPostPhoto') => void;
  adminRevokePermission: (userId: string, perm: 'canMagazineWrite' | 'canPostVideo' | 'canPostPhoto') => void;
  adminBanUser: (userId: string, until?: string) => void;
  adminUnbanUser: (userId: string) => void;
  // Bookmarks
  bookmarks: Bookmark[];
  addBookmark: (bm: Bookmark) => void;
  removeBookmark: (id: string) => void;
  // Draft & chapter actions
  publishDraft: (id: string, type: 'book' | 'story' | 'poem') => void;
  addChapterToBook: (bookId: string, chapter: Chapter) => void;
  // Haftanın kitabı
  weeklyBookId: string | null;
  setWeeklyBookId: (id: string | null) => void;
  // İçerik filtresi
  bannedWords: string[];
  filterLevel: FilterLevel;
  addBannedWord: (word: string) => void;
  removeBannedWord: (word: string) => void;
  setFilterLevelAdmin: (level: FilterLevel) => void;
  checkContent: (text: string) => { ok: boolean; message?: string };
  toggleLike: (id: string) => void;
  toggleSave: (id: string) => void;
  toggleFollow: (userId: string) => void;
  togglePostLike: (id: string) => void;
  togglePostSave: (id: string) => void;
  rateContent: (id: string, rating: number) => void;
  setReadProgress: (bookId: string, percent: number) => void;
  addBook: (book: Book) => void;
  addStory: (story: Story) => void;
  addPoem: (poem: Poem) => void;
  addPost: (post: Post) => void;
  addComment: (comment: Comment) => void;
  addReply: (commentId: string, reply: import('@/data/types').Reply) => void;
  addPostComment: (comment: PostComment) => void;
  addPostCommentReply: (commentId: string, reply: PostReply) => void;
  togglePostCommentLike: (commentId: string) => void;
  addReactionToPostComment: (commentId: string, emoji: string) => void;
  sendMessage: (convId: string, senderId: string, content: string) => void;
  markNotifsRead: () => void;
  addList: (list: ReadingList) => void;
  removeList: (id: string) => void;
  addToList: (listId: string, bookId: string) => void;
  removeFromList: (listId: string, bookId: string) => void;
  // Support / Contact
  addSupportTicket: (ticket: SupportTicket) => void;
  addContactMessage: (msg: ContactMessage) => void;
  updateTicketStatus: (id: string, status: TicketStatus, reply?: string) => void;
  updateContactStatus: (id: string, status: TicketStatus, reply?: string) => void;
  // Admin actions
  adminSuspendUser: (userId: string) => void;
  adminActivateUser: (userId: string) => void;
  adminDeleteUser: (userId: string) => void;
  adminRemovePost: (postId: string) => void;
  adminRemoveComment: (commentId: string) => void;
  addAdminLog: (log: AdminLog) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [books, setBooks] = useState<Book[]>(SAMPLE_BOOKS);
  const [stories, setStories] = useState<Story[]>(SAMPLE_STORIES);
  const [poems, setPoems] = useState<Poem[]>(SAMPLE_POEMS);
  const [posts, setPosts] = useState<Post[]>(SAMPLE_POSTS);
  const [comments, setComments] = useState<Comment[]>(SAMPLE_COMMENTS);
  const [postComments, setPostComments] = useState<PostComment[]>(SAMPLE_POST_COMMENTS);
  const [notifications, setNotifications] = useState<Notification[]>(SAMPLE_NOTIFICATIONS);
  const [conversations, setConversations] = useState<Conversation[]>(SAMPLE_CONVERSATIONS);
  const [messagesByConv, setMessagesByConv] = useState<Record<string, Message[]>>(MESSAGES_BY_CONV);
  const [lists, setLists] = useState<ReadingList[]>([]);
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [followedIds, setFollowedIds] = useState<Set<string>>(new Set());
  const [postLikedIds, setPostLikedIds] = useState<Set<string>>(new Set());
  const [postSavedIds, setPostSavedIds] = useState<Set<string>>(new Set());
  const [postCommentLikedIds, setPostCommentLikedIds] = useState<Set<string>>(new Set());
  const [userRatings, setUserRatings] = useState<Record<string, number>>({});
  const [readProgress, setReadProgressState] = useState<Record<string, number>>({});
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>([]);
  const [adminLogs, setAdminLogs] = useState<AdminLog[]>([]);
  const [adminUsers, setAdminUsers] = useState(SAMPLE_USERS);
  const [dergiPosts, setDergiPosts] = useState<DergiPost[]>([]);
  const [ozelPosts, setOzelPosts] = useState<OzelPost[]>([]);
  const [dergiLikedIds, setDergiLikedIds] = useState<Set<string>>(new Set());
  const [ozelLikedIds, setOzelLikedIds] = useState<Set<string>>(new Set());
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [weeklyBookId, setWeeklyBookId] = useState<string | null>(null);
  const [bannedWords, setBannedWords] = useState<string[]>(DEFAULT_BANNED_WORDS);
  const [filterLevel, setFilterLevel] = useState<FilterLevel>('orta');

  const addBannedWord = (word: string) => {
    const w = word.trim().toLowerCase();
    if (!w || bannedWords.includes(w)) return;
    setBannedWords(prev => [...prev, w]);
  };
  const removeBannedWord = (word: string) => setBannedWords(prev => prev.filter(w => w !== word));
  const setFilterLevelAdmin = (level: FilterLevel) => setFilterLevel(level);
  const checkContent = (text: string) => filterContent(text, bannedWords, filterLevel);

  useEffect(() => {
    AsyncStorage.getItem('lazlani_likes').then(v => v && setLikedIds(new Set(JSON.parse(v))));
    AsyncStorage.getItem('lazlani_saves').then(v => v && setSavedIds(new Set(JSON.parse(v))));
    AsyncStorage.getItem('lazlani_follows').then(v => v && setFollowedIds(new Set(JSON.parse(v))));
    AsyncStorage.getItem('lazlani_post_likes').then(v => v && setPostLikedIds(new Set(JSON.parse(v))));
    AsyncStorage.getItem('lazlani_post_saves').then(v => v && setPostSavedIds(new Set(JSON.parse(v))));
    AsyncStorage.getItem('lazlani_post_comment_likes').then(v => v && setPostCommentLikedIds(new Set(JSON.parse(v))));
    AsyncStorage.getItem('lazlani_lists').then(v => v && setLists(JSON.parse(v)));
    AsyncStorage.getItem('lazlani_ratings').then(v => v && setUserRatings(JSON.parse(v)));
    AsyncStorage.getItem('lazlani_progress').then(v => v && setReadProgressState(JSON.parse(v)));
    AsyncStorage.getItem('lazlani_bookmarks').then(v => v && setBookmarks(JSON.parse(v)));
  }, []);

  const toggleLike = (id: string) => {
    setLikedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      AsyncStorage.setItem('lazlani_likes', JSON.stringify([...next]));
      return next;
    });
  };

  const toggleSave = (id: string) => {
    setSavedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      AsyncStorage.setItem('lazlani_saves', JSON.stringify([...next]));
      return next;
    });
  };

  const toggleFollow = (userId: string) => {
    setFollowedIds(prev => {
      const next = new Set(prev);
      next.has(userId) ? next.delete(userId) : next.add(userId);
      AsyncStorage.setItem('lazlani_follows', JSON.stringify([...next]));
      return next;
    });
  };

  const togglePostLike = (id: string) => {
    setPostLikedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      AsyncStorage.setItem('lazlani_post_likes', JSON.stringify([...next]));
      return next;
    });
    setPosts(prev => prev.map(p => p.id === id ? { ...p, likesCount: p.likesCount + (postLikedIds.has(id) ? -1 : 1) } : p));
  };

  const togglePostSave = (id: string) => {
    setPostSavedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      AsyncStorage.setItem('lazlani_post_saves', JSON.stringify([...next]));
      return next;
    });
  };

  const togglePostCommentLike = (commentId: string) => {
    setPostCommentLikedIds(prev => {
      const next = new Set(prev);
      const wasLiked = next.has(commentId);
      wasLiked ? next.delete(commentId) : next.add(commentId);
      AsyncStorage.setItem('lazlani_post_comment_likes', JSON.stringify([...next]));
      setPostComments(c => c.map(cm => cm.id === commentId
        ? { ...cm, likesCount: cm.likesCount + (wasLiked ? -1 : 1) }
        : cm
      ));
      return next;
    });
  };

  const addReactionToPostComment = (commentId: string, emoji: string) => {
    setPostComments(prev => prev.map(c => {
      if (c.id !== commentId) return c;
      const reactions = { ...c.reactions };
      reactions[emoji] = (reactions[emoji] ?? 0) + 1;
      return { ...c, reactions };
    }));
  };

  const rateContent = (id: string, rating: number) => {
    setUserRatings(prev => {
      const next = { ...prev, [id]: rating };
      AsyncStorage.setItem('lazlani_ratings', JSON.stringify(next));
      return next;
    });
  };

  const setReadProgress = (bookId: string, percent: number) => {
    setReadProgressState(prev => {
      const next = { ...prev, [bookId]: percent };
      AsyncStorage.setItem('lazlani_progress', JSON.stringify(next));
      return next;
    });
  };

  const addBook = (book: Book) => setBooks(prev => [book, ...prev]);
  const addStory = (story: Story) => setStories(prev => [story, ...prev]);
  const addPoem = (poem: Poem) => setPoems(prev => [poem, ...prev]);
  const addPost = (post: Post) => setPosts(prev => [post, ...prev]);
  const addComment = (comment: Comment) => setComments(prev => [comment, ...prev]);

  const addPostComment = (comment: PostComment) => {
    setPostComments(prev => [comment, ...prev]);
    setPosts(prev => prev.map(p => p.id === comment.postId ? { ...p, commentsCount: p.commentsCount + 1 } : p));
  };

  const addPostCommentReply = (commentId: string, reply: PostReply) => {
    setPostComments(prev => prev.map(c =>
      c.id === commentId ? { ...c, replies: [...c.replies, reply] } : c
    ));
  };

  const addReply = (commentId: string, reply: import('@/data/types').Reply) => {
    setComments(prev =>
      prev.map(c =>
        c.id === commentId ? { ...c, replies: [...c.replies, reply] } : c
      )
    );
  };

  const sendMessage = (convId: string, senderId: string, content: string) => {
    const msg: Message = {
      id: Date.now().toString(),
      conversationId: convId,
      senderId,
      content,
      type: 'text',
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setMessagesByConv(prev => ({ ...prev, [convId]: [...(prev[convId] ?? []), msg] }));
    setConversations(prev =>
      prev.map(c =>
        c.id === convId ? { ...c, lastMessage: content, lastMessageTime: msg.createdAt } : c
      )
    );
  };

  const markNotifsRead = () =>
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));

  const addList = (list: ReadingList) => {
    setLists(prev => {
      const next = [list, ...prev];
      AsyncStorage.setItem('lazlani_lists', JSON.stringify(next));
      return next;
    });
  };

  const removeList = (id: string) => {
    setLists(prev => {
      const next = prev.filter(l => l.id !== id);
      AsyncStorage.setItem('lazlani_lists', JSON.stringify(next));
      return next;
    });
  };

  const addToList = (listId: string, bookId: string) => {
    setLists(prev => {
      const next = prev.map(l =>
        l.id === listId && !l.bookIds.includes(bookId)
          ? { ...l, bookIds: [...l.bookIds, bookId] }
          : l
      );
      AsyncStorage.setItem('lazlani_lists', JSON.stringify(next));
      return next;
    });
  };

  const removeFromList = (listId: string, bookId: string) => {
    setLists(prev => {
      const next = prev.map(l =>
        l.id === listId ? { ...l, bookIds: l.bookIds.filter(b => b !== bookId) } : l
      );
      AsyncStorage.setItem('lazlani_lists', JSON.stringify(next));
      return next;
    });
  };

  const unreadNotifCount = notifications.filter(n => !n.isRead).length;

  const addSupportTicket = (ticket: SupportTicket) =>
    setSupportTickets(prev => [ticket, ...prev]);

  const addContactMessage = (msg: ContactMessage) =>
    setContactMessages(prev => [msg, ...prev]);

  const updateTicketStatus = (id: string, status: TicketStatus, reply?: string) =>
    setSupportTickets(prev => prev.map(t =>
      t.id === id ? { ...t, status, ...(reply ? { adminReply: reply } : {}) } : t
    ));

  const updateContactStatus = (id: string, status: TicketStatus, reply?: string) =>
    setContactMessages(prev => prev.map(m =>
      m.id === id ? { ...m, status, ...(reply ? { adminReply: reply } : {}) } : m
    ));

  const addAdminLog = (log: AdminLog) =>
    setAdminLogs(prev => [log, ...prev]);

  const adminSuspendUser = (userId: string) =>
    setAdminUsers(prev => prev.map(u => u.id === userId ? { ...u, isSuspended: true } : u));

  const adminActivateUser = (userId: string) =>
    setAdminUsers(prev => prev.map(u => u.id === userId ? { ...u, isSuspended: false } : u));

  const adminDeleteUser = (userId: string) =>
    setAdminUsers(prev => prev.filter(u => u.id !== userId));

  const adminRemovePost = (postId: string) =>
    setPosts(prev => prev.filter(p => p.id !== postId));

  const adminRemoveComment = (commentId: string) =>
    setPostComments(prev => prev.filter(c => c.id !== commentId));

  const addBookmark = (bm: Bookmark) => {
    setBookmarks(prev => {
      const next = [bm, ...prev.filter(b => !(b.targetId === bm.targetId && b.targetType === bm.targetType && b.userId === bm.userId))];
      AsyncStorage.setItem('lazlani_bookmarks', JSON.stringify(next));
      return next;
    });
  };

  const removeBookmark = (id: string) => {
    setBookmarks(prev => {
      const next = prev.filter(b => b.id !== id);
      AsyncStorage.setItem('lazlani_bookmarks', JSON.stringify(next));
      return next;
    });
  };

  const publishDraft = (id: string, type: 'book' | 'story' | 'poem') => {
    if (type === 'book') setBooks(prev => prev.map(b => b.id === id ? { ...b, isDraft: false } : b));
    else if (type === 'story') setStories(prev => prev.map(s => s.id === id ? { ...s, isDraft: false } : s));
    else setPoems(prev => prev.map(p => p.id === id ? { ...p, isDraft: false } : p));
  };

  const addChapterToBook = (bookId: string, chapter: Chapter) => {
    setBooks(prev => prev.map(b =>
      b.id === bookId ? { ...b, chapters: [...(b.chapters ?? []), chapter] } : b
    ));
  };

  const addDergiPost = (post: DergiPost) => setDergiPosts(prev => [post, ...prev]);
  const addOzelPost  = (post: OzelPost)  => setOzelPosts(prev => [post, ...prev]);

  const toggleDergiLike = (id: string) => {
    setDergiLikedIds(prev => {
      const next = new Set(prev);
      const wasLiked = next.has(id);
      wasLiked ? next.delete(id) : next.add(id);
      setDergiPosts(p => p.map(d => d.id === id ? { ...d, likesCount: d.likesCount + (wasLiked ? -1 : 1) } : d));
      return next;
    });
  };

  const toggleOzelLike = (id: string) => {
    setOzelLikedIds(prev => {
      const next = new Set(prev);
      const wasLiked = next.has(id);
      wasLiked ? next.delete(id) : next.add(id);
      setOzelPosts(p => p.map(o => o.id === id ? { ...o, likesCount: o.likesCount + (wasLiked ? -1 : 1) } : o));
      return next;
    });
  };

  type UserPerm = 'canMagazineWrite' | 'canPostVideo' | 'canPostPhoto';
  const adminGrantPermission = (userId: string, perm: UserPerm) =>
    setAdminUsers(prev => prev.map(u => u.id === userId ? { ...u, [perm]: true } : u));
  const adminRevokePermission = (userId: string, perm: UserPerm) =>
    setAdminUsers(prev => prev.map(u => u.id === userId ? { ...u, [perm]: false } : u));
  const adminBanUser = (userId: string, until?: string) =>
    setAdminUsers(prev => prev.map(u => u.id === userId ? { ...u, isBanned: true, bannedUntil: until ?? null } : u));
  const adminUnbanUser = (userId: string) =>
    setAdminUsers(prev => prev.map(u => u.id === userId ? { ...u, isBanned: false, bannedUntil: undefined } : u));

  return (
    <DataContext.Provider
      value={{
        books, stories, poems, posts, comments, postComments, notifications, conversations, messagesByConv, lists,
        likedIds, savedIds, followedIds, postLikedIds, postSavedIds, postCommentLikedIds, userRatings, readProgress,
        unreadNotifCount,
        supportTickets, contactMessages, adminLogs, adminUsers,
        toggleLike, toggleSave, toggleFollow, togglePostLike, togglePostSave,
        rateContent, setReadProgress,
        addBook, addStory, addPoem, addPost, addComment, addReply,
        addPostComment, addPostCommentReply, togglePostCommentLike, addReactionToPostComment,
        sendMessage, markNotifsRead,
        addList, removeList, addToList, removeFromList,
        addSupportTicket, addContactMessage, updateTicketStatus, updateContactStatus,
        adminSuspendUser, adminActivateUser, adminDeleteUser, adminRemovePost, adminRemoveComment, addAdminLog,
        dergiPosts, ozelPosts, dergiLikedIds, ozelLikedIds,
        addDergiPost, addOzelPost, toggleDergiLike, toggleOzelLike,
        adminGrantPermission, adminRevokePermission, adminBanUser, adminUnbanUser,
        bookmarks, addBookmark, removeBookmark,
        publishDraft, addChapterToBook,
        weeklyBookId, setWeeklyBookId,
        bannedWords, filterLevel, addBannedWord, removeBannedWord, setFilterLevelAdmin, checkContent,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be inside DataProvider');
  return ctx;
}
