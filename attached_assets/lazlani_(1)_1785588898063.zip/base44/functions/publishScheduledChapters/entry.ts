import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const now = new Date().toISOString();

    // Get all scheduled chapters whose date has passed
    const scheduled = await base44.asServiceRole.entities.Chapter.filter(
      { status: "zamanlanmis" },
      "scheduled_date",
      200
    );

    const toPublish = scheduled.filter(ch => ch.scheduled_date && ch.scheduled_date <= now);

    if (toPublish.length === 0) {
      return Response.json({ published: 0, message: "No chapters to publish" });
    }

    // Publish each chapter and send notifications
    for (const chapter of toPublish) {
      await base44.asServiceRole.entities.Chapter.update(chapter.id, {
        status: "yayinda",
      });

      // Get book info for notification
      const books = await base44.asServiceRole.entities.Book.filter(
        { id: chapter.book_id },
        "-created_date",
        1
      );
      const book = books[0];
      if (!book) continue;

      // Get followers + saved book users
      const [follows, savedBooks] = await Promise.all([
        base44.asServiceRole.entities.Follow.filter(
          { following_email: book.author_email },
          "-created_date",
          500
        ),
        base44.asServiceRole.entities.SavedBook.filter(
          { book_id: chapter.book_id },
          "-created_date",
          500
        ),
      ]);

      const recipientSet = new Set();
      [...follows.map(f => f.follower_email), ...savedBooks.map(s => s.user_email)]
        .filter(email => email !== book.author_email)
        .forEach(email => recipientSet.add(email));

      // Send notifications
      for (const email of recipientSet) {
        await base44.asServiceRole.entities.Notification.create({
          receiver_email: email,
          sender_name: book.author_name,
          sender_email: book.author_email,
          type: "new_chapter",
          message: `"${book.title}" adlı kitaba yeni bölüm eklendi: "${chapter.title}"`,
          book_id: chapter.book_id,
          is_read: false,
        });
      }
    }

    return Response.json({
      published: toPublish.length,
      chapters: toPublish.map(c => ({ id: c.id, title: c.title })),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});