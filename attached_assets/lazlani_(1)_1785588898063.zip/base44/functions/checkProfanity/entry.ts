import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const PROFANITY_LIST = [
  "orospu", "piç", "siktir", "siktirgit", "sikeyim", "sikerim", "sikik",
  "amk", "amına", "amını", "ananı", "ananızı",
  "fahişe", "sürtük", "kaltak", "kahpe",
  "göt", "götünü", "götün",
  "yarrak", "yarrağ", "yarak",
  "dalyarak", "dallama",
  "pezevenk", "gavat", "ibne",
  "gerizekalı", "mal", "salak", "aptal", "dangalak", "gerzek",
  "haysiyetsiz", "şerefsiz", "namussuz",
  "bok", "boktan", "pislik",
  "puşt", "köpek herif",
  "aq", "mk", "mq", "amq",
  "s2m", "s2k", "s1k",
];

const normalize = (text) =>
  text.toLowerCase()
    .replace(/ı/g, "i").replace(/ö/g, "o").replace(/ü/g, "u")
    .replace(/ş/g, "s").replace(/ç/g, "c").replace(/ğ/g, "g")
    .replace(/1/g, "i").replace(/3/g, "e").replace(/0/g, "o")
    .replace(/4/g, "a").replace(/\$/g, "s").replace(/[_.!@#*\-]/g, "");

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { content, type, userName } = await req.json();
    if (!content) return Response.json({ error: 'Content required' }, { status: 400 });

    // Fetch dynamic banned words from BannedWord entity
    const bannedWords = await base44.asServiceRole.entities.BannedWord.list("-created_date", 500);
    const dynamicWords = bannedWords.map(b => b.word).filter(Boolean);
    const allWords = [...PROFANITY_LIST, ...dynamicWords];

    const normalizedContent = normalize(content);
    const hasProfanity = allWords.some(word => normalizedContent.includes(normalize(word)));
    
    if (!hasProfanity) return Response.json({ blocked: false, message: "İçerik temiz" });

    // Get or create violation record
    const violations = await base44.asServiceRole.entities.ProfanityViolation.filter(
      { user_email: user.email }, "-created_date", 1
    );

    const now = new Date();
    const violation = violations[0];
    const prevCount = violation ? violation.violation_count : 0;
    const newCount = prevCount + 1;

    // Gezep bot warning messages
    const botMessages = {
      1: `⚠️ Sayın ${userName || user.full_name || "kullanıcı"}, lütfen topluluk kurallarına uygun bir dil kullanınız. Bu ilk uyarınızdır.`,
      2: `⚠️ İkinci uyarınızı aldınız, ${userName || user.full_name || "kullanıcı"}. Bir sonraki ihlalde topluluk odasında mesaj gönderme hakkınız geçici olarak durdurulacaktır.`,
      3: `🚫 ${userName || user.full_name || "kullanıcı"}, tekrarlanan ihlaller nedeniyle topluluk odasında mesaj gönderme yetkiniz geçici olarak devre dışı bırakılmıştır. Lütfen bir yöneticiyle iletişime geçin.`,
    };

    const botWarning = botMessages[Math.min(newCount, 3)];

    if (!violation) {
      // 1st violation: warning
      await base44.asServiceRole.entities.ProfanityViolation.create({
        user_email: user.email,
        violation_count: 1,
        last_violation_date: now.toISOString(),
        status: "warning",
      });
      // Create Gezep bot warning message
      await base44.asServiceRole.entities.CommunityMessage.create({
        user_email: "gezep@lazlani.com",
        user_name: "Gezep",
        user_avatar: "",
        user_role: "admin",
        content: botWarning,
        type: "text",
        like_count: 0,
      });
      return Response.json({ blocked: true, warning: true, message: botWarning, violationCount: 1 });
    }

    if (newCount === 2) {
      // 2nd violation: warning + mute upcoming
      await base44.asServiceRole.entities.ProfanityViolation.update(violation.id, {
        violation_count: newCount, last_violation_date: now.toISOString(), status: "warning",
      });
      await base44.asServiceRole.entities.CommunityMessage.create({
        user_email: "gezep@lazlani.com",
        user_name: "Gezep",
        user_avatar: "",
        user_role: "admin",
        content: botWarning,
        type: "text",
        like_count: 0,
      });
      return Response.json({ blocked: true, warning: true, message: botWarning, violationCount: newCount });
    }

    if (newCount >= 3) {
      // 3rd+ violation: mute the user
      const muteUntil = new Date(now.getTime() + 24 * 60 * 60 * 1000);
      await base44.asServiceRole.entities.ProfanityViolation.update(violation.id, {
        violation_count: newCount, last_violation_date: now.toISOString(),
        is_muted: true, muted_until: muteUntil.toISOString(), status: "muted",
      });
      await base44.asServiceRole.entities.CommunityChatBan.create({
        user_email: user.email,
        user_name: userName || user.full_name || user.email.split("@")[0],
        banned_by_email: "gezep@lazlani.com",
        banned_by_name: "Gezep (Otomatik)",
        reason: `Küfür/hakaret - ${newCount}. ihlal (otomatik)`,
        ban_type: "mute",
        duration_label: "24 saat",
        expires_at: muteUntil.toISOString(),
        is_active: true,
        issued_by_role: "admin",
      });
      await base44.asServiceRole.entities.CommunityMessage.create({
        user_email: "gezep@lazlani.com",
        user_name: "Gezep",
        user_avatar: "",
        user_role: "admin",
        content: botWarning,
        type: "text",
        like_count: 0,
      });
      return Response.json({ blocked: true, muted: true, message: botWarning, violationCount: newCount, mutedUntil: muteUntil.toISOString() });
    }

    // Fallback
    await base44.asServiceRole.entities.ProfanityViolation.update(violation.id, {
      violation_count: newCount, last_violation_date: now.toISOString(),
    });
    return Response.json({ blocked: true, warning: true, message: "Uyarı", violationCount: newCount });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});