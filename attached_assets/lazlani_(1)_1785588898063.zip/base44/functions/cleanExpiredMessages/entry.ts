import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Get all messages with expiration
    const allMessages = await base44.asServiceRole.entities.LazlanMessage.filter({}, "-created_date", 500);
    const now = new Date();
    let deleted = 0;

    for (const msg of allMessages) {
      if (msg.expires_at && new Date(msg.expires_at) < now) {
        await base44.asServiceRole.entities.LazlanMessage.delete(msg.id);
        deleted++;
      }
    }

    return Response.json({ success: true, deleted });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});