import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { event } = body;

    // Security: require valid automation event — prevents direct external calls
    if (!event?.entity_id || event?.entity_name !== 'BultenPost') {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Security: fetch actual record from DB instead of trusting request body
    const posts = await base44.asServiceRole.entities.BultenPost.filter({ id: event.entity_id }, '-created_date', 1);
    const data = posts[0];
    if (!data) {
      return Response.json({ skipped: true, reason: 'Post not found' });
    }

    const authorEmail = data.user_email;

    const authorName = escapeHtml(data.user_name || authorEmail);
    const rawPreview = (data.content || '').replace(/<[^>]*>/g, '').substring(0, 150);
    const contentPreview = escapeHtml(rawPreview);

    // Get followers of the author
    const followers = await base44.asServiceRole.entities.Follow.filter(
      { following_email: authorEmail },
      '-created_date',
      200
    );

    if (followers.length === 0) {
      return Response.json({ message: 'No followers to notify', count: 0 });
    }

    // Send email to each follower
    const results = await Promise.allSettled(
      followers.map((f) =>
        base44.asServiceRole.integrations.Core.SendEmail({
          to: f.follower_email,
          subject: `📰 ${authorName} yeni bir bülten paylaştı!`,
          body: `
            <div style="font-family:sans-serif;max-width:500px;margin:0 auto;padding:20px;">
              <h2 style="color:#2d6a4f;">${authorName} yeni bir yazı paylaştı</h2>
              <p style="color:#555;line-height:1.6;">${contentPreview}${contentPreview.length >= 150 ? '...' : ''}</p>
              <hr style="border:none;border-top:1px solid #eee;margin:16px 0;" />
              <p style="color:#888;font-size:13px;">Lazlani Bülten Bildirimi</p>
            </div>
          `,
          from_name: 'Lazlani',
        })
      )
    );

    const sent = results.filter((r) => r.status === 'fulfilled').length;
    console.log(`Sent ${sent}/${followers.length} emails for bulten by ${authorEmail}`);

    return Response.json({ message: 'Notifications sent', sent, total: followers.length });
  } catch (error) {
    console.error('notifyFollowersOnBulten error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});