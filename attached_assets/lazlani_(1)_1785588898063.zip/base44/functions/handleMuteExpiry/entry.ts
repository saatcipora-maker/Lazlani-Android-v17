import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Sessiz moddan çıkması gereken tüm kullanıcıları getir
    const violations = await base44.asServiceRole.entities.ProfanityViolation.filter(
      { is_muted: true },
      "-created_date",
      500
    );

    const now = new Date();
    const released = [];

    for (const v of violations) {
      if (v.muted_until && new Date(v.muted_until) <= now) {
        await base44.asServiceRole.entities.ProfanityViolation.update(v.id, {
          is_muted: false,
          muted_until: null,
          status: "warning"
        });
        released.push(v.user_email);
      }
    }

    return Response.json({ 
      success: true, 
      released_count: released.length,
      released_users: released 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});