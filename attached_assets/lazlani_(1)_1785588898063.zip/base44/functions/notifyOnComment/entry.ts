import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Verify caller is authenticated (automation service or admin)
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { data, event } = body;

    if (!data || event?.type !== "create") {
      return Response.json({ ok: true, skipped: true });
    }

    const chapterId = data.chapter_id;
    const commenterEmail = data.user_email;
    const commenterName = data.user_name || commenterEmail;

    if (!chapterId || !commenterEmail) {
      return Response.json({ ok: true, skipped: true });
    }

    // Determine if this is a book-level comment (chapter_id starts with "book_") or chapter comment
    let bookId = null;
    let bookTitle = "kitabınız";

    if (chapterId.startsWith("book_")) {
      bookId = chapterId.replace("book_", "");
    } else {
      // It's a chapter comment — find the chapter to get book_id
      const chapters = await base44.asServiceRole.entities.Chapter.filter({ id: chapterId }, "-created_date", 1);
      if (chapters.length > 0) {
        bookId = chapters[0].book_id;
      }
    }

    if (!bookId) {
      return Response.json({ ok: true, skipped: true, reason: "no_book_id" });
    }

    // Get the book to find the author
    const books = await base44.asServiceRole.entities.Book.filter({ id: bookId }, "-created_date", 1);
    if (books.length === 0) {
      return Response.json({ ok: true, skipped: true, reason: "book_not_found" });
    }

    const book = books[0];
    const authorEmail = book.author_email;
    bookTitle = book.title || "kitabınız";

    // Don't notify the author about their own comments
    if (authorEmail === commenterEmail) {
      return Response.json({ ok: true, skipped: true, reason: "self_comment" });
    }

    // Create notification for the book author
    await base44.asServiceRole.entities.Notification.create({
      receiver_email: authorEmail,
      sender_name: commenterName,
      sender_email: commenterEmail,
      type: "comment_reply",
      message: `${commenterName} "${bookTitle}" kitabınıza yorum yaptı.`,
      book_id: bookId,
      is_read: false,
    });

    return Response.json({ ok: true, notified: authorEmail });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});