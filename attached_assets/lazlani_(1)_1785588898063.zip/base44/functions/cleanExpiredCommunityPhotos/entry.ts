import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const now = new Date().toISOString();
    
    // Find expired image messages
    const expired = await base44.asServiceRole.entities.CommunityMessage.filter(
      { type: "image" },
      "-created_date",
      200
    );
    
    const toDelete = expired.filter(m => m.expires_at && new Date(m.expires_at) < new Date(now));
    
    let deleted = 0;
    for (const msg of toDelete) {
      await base44.asServiceRole.entities.CommunityMessage.delete(msg.id);
      deleted++;
    }
    
    return Response.json({ success: true, deleted, checked: expired.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});