import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const now = new Date().toISOString();
    const allVideos = await base44.asServiceRole.entities.ExclusiveVideo.filter({}, "-created_date", 200);
    
    const expired = allVideos.filter(v => v.expires_at && v.expires_at < now);
    
    let deleted = 0;
    for (const video of expired) {
      // Delete associated likes
      const likes = await base44.asServiceRole.entities.ExclusiveVideoLike.filter({ video_id: video.id });
      for (const like of likes) {
        await base44.asServiceRole.entities.ExclusiveVideoLike.delete(like.id);
      }
      // Delete associated comments
      const comments = await base44.asServiceRole.entities.ExclusiveVideoComment.filter({ video_id: video.id });
      for (const comment of comments) {
        await base44.asServiceRole.entities.ExclusiveVideoComment.delete(comment.id);
      }
      // Delete the video
      await base44.asServiceRole.entities.ExclusiveVideo.delete(video.id);
      deleted++;
    }

    return Response.json({ success: true, deleted, checked: allVideos.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});