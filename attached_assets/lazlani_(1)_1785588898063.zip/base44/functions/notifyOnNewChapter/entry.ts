import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { event } = body;

    // Security: require valid automation event — prevents direct external calls
    if (!event?.entity_id || event?.entity_name !== 'Chapter') {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Security: fetch actual chapter record from DB instead of trusting request body
    const chapters = await base44.asServiceRole.entities.Chapter.filter({ id: event.entity_id }, '-created_date', 1);
    const data = chapters[0];
    if (!data || data.status !== 'yayinda') {
      return Response.json({ skipped: true, reason: 'Not a published chapter' });
    }

    const bookId = data.book_id;
    if (!bookId) {
      return Response.json({ skipped: true, reason: 'No book_id' });
    }

    // Get the book details
    const books = await base44.asServiceRole.entities.Book.filter({ id: bookId });
    const book = books[0];
    if (!book) {
      return Response.json({ skipped: true, reason: 'Book not found' });
    }

    // Get all users who saved this book to their library
    const savedBooks = await base44.asServiceRole.entities.SavedBook.filter(
      { book_id: bookId }, '-created_date', 500
    );

    // Also get followers of the author
    const followers = await base44.asServiceRole.entities.Follow.filter(
      { following_email: book.author_email }, '-created_date', 500
    );

    // Combine unique emails from saved books + followers
    const emailSet = new Set();
    savedBooks.forEach(s => emailSet.add(s.user_email));
    followers.forEach(f => emailSet.add(f.follower_email));

    // Remove the author themselves
    emailSet.delete(book.author_email);

    if (emailSet.size === 0) {
      return Response.json({ skipped: true, reason: 'No users to notify' });
    }

    const chapterTitle = data.title || 'Yeni bölüm';
    const authorName = book.author_name || 'Bir yazar';

    // Create notifications for all unique users
    const notifications = [...emailSet].map(email => ({
      receiver_email: email,
      sender_name: authorName,
      sender_email: book.author_email,
      type: 'new_chapter',
      message: `✍️ ${authorName}, "${book.title}" kitabına yeni bölüm ekledi: "${chapterTitle}"`,
      book_id: bookId,
      is_read: false,
    }));

    // Bulk create in batches of 50
    for (let i = 0; i < notifications.length; i += 50) {
      const batch = notifications.slice(i, i + 50);
      await base44.asServiceRole.entities.Notification.bulkCreate(batch);
    }

    return Response.json({
      success: true,
      notified: notifications.length,
      chapter: chapterTitle,
      book: book.title,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});