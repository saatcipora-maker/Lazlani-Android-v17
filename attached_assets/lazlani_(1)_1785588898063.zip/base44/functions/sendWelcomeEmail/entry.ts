import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// Strip dangerous characters from user-supplied names to prevent injection
function sanitizeName(name) {
  if (typeof name !== 'string') return '';
  return name
    .replace(/[<>]/g, '')      // remove angle brackets (HTML injection)
    .replace(/https?:\/\//gi, '') // remove URLs (phishing links)
    .replace(/[\r\n\t]/g, ' ')  // collapse newlines
    .trim()
    .slice(0, 100);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { data } = body;

    if (!data?.follower_email) {
      return Response.json({ error: 'Missing follower_email' }, { status: 400 });
    }

    // Verify a genuine Follow record exists — the authenticated user must be the follower
    const follows = await base44.asServiceRole.entities.Follow.filter({
      follower_email: user.email,
      following_email: data.follower_email
    });
    const follow = follows[0];
    if (!follow) {
      return Response.json({ error: 'Follow record not found' }, { status: 403 });
    }

    // Use names from the verified DB record, not the request body
    const followerName = sanitizeName(follow.follower_name) || 'Okuyucu';
    const followingName = sanitizeName(follow.following_name) || 'Yazar';

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: follow.follower_email,
      subject: "Lazlani'ye Hoş Geldiniz! 🎉",
      body: `Merhaba ${followerName},

${followingName} adlı yazarı takip etmeye başladınız. Tebrikler!

Artık bu yazarın yeni kitap ve bölümlerinden haberdar olacaksınız.

Keyifli okumalar dileriz 📚
— Lazlani Ekibi

https://lazlani.com`
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});