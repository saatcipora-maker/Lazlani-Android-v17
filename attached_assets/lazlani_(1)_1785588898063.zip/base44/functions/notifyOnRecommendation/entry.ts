import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Verify caller is authenticated (automation service or admin)
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { data, old_data, event } = body;

    if (!data || event?.type !== "update") {
      return Response.json({ ok: true, skipped: true });
    }

    // Check if recommendation_status just changed to "approved"
    const wasApproved = old_data?.recommendation_status !== "approved" && data.recommendation_status === "approved";
    
    if (!wasApproved) {
      return Response.json({ ok: true, skipped: true, reason: "not_recommendation_approval" });
    }

    const authorEmail = data.author_email;
    const bookTitle = data.title || "Kitabınız";
    const bookId = event.entity_id;

    if (!authorEmail) {
      return Response.json({ ok: true, skipped: true, reason: "no_author" });
    }

    // Create notification for the book author
    await base44.asServiceRole.entities.Notification.create({
      receiver_email: authorEmail,
      sender_name: "Lazlani",
      sender_email: "system",
      type: "system",
      message: `🎉 "${bookTitle}" kitabınız önerilenlere eklendi!`,
      book_id: bookId,
      is_read: false,
    });

    return Response.json({ ok: true, notified: authorEmail });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});