import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const email = user.email;
    const userId = user.id;
    const sr = base44.asServiceRole;

    // Helper to delete all records matching a filter
    const deleteAll = async (entityName, query) => {
      const records = await sr.entities[entityName].filter(query, '-created_date', 500);
      for (const r of records) {
        await sr.entities[entityName].delete(r.id);
      }
    };

    // 1. Comments
    await deleteAll('ChapterComment', { user_email: email });
    await deleteAll('BultenComment', { user_email: email });
    await deleteAll('MagazinComment', { user_email: email });

    // 2. Likes
    await deleteAll('ChapterLike', { user_email: email });
    await deleteAll('BultenLike', { user_email: email });
    await deleteAll('MagazinLike', { user_email: email });
    await deleteAll('ExclusiveVideoLike', { user_email: email });

    // 3. Reading data
    await deleteAll('Bookmark', { user_email: email });
    await deleteAll('Highlight', { user_email: email });
    await deleteAll('ReadHistory', { user_email: email });
    await deleteAll('SavedBook', { user_email: email });
    await deleteAll('FavoriteBook', { user_email: email });

    // 4. Social
    await deleteAll('Follow', { follower_email: email });
    await deleteAll('Follow', { following_email: email });

    // 5. Notifications
    await deleteAll('Notification', { receiver_email: email });

    // 6. Commerce & requests
    await deleteAll('BadgeRequest', { user_email: email });
    await deleteAll('CartItem', { user_email: email });

    // 7. Messages
    await deleteAll('Message', { sender_email: email });
    await deleteAll('Message', { receiver_email: email });
    await deleteAll('LazlanMessage', { user_email: email });

    // 8. Reviews & lists
    await deleteAll('BookReview', { user_email: email });
    await deleteAll('ReadingList', { user_email: email });

    // 9. Game & tournament
    await deleteAll('TournamentScore', { user_email: email });
    await deleteAll('GameProfile', { user_email: email });

    // 10. Exclusive videos
    await deleteAll('ExclusiveVideo', { user_email: email });
    await deleteAll('ExclusiveVideoComment', { user_email: email });

    // 11. User's books — first delete chapters, then books
    const userBooks = await sr.entities.Book.filter({ author_email: email }, '-created_date', 500);
    for (const book of userBooks) {
      const chapters = await sr.entities.Chapter.filter({ book_id: book.id }, 'order', 500);
      for (const ch of chapters) {
        await sr.entities.Chapter.delete(ch.id);
      }
      await sr.entities.Book.delete(book.id);
    }

    // 12. Delete the User record
    await sr.entities.User.delete(userId);

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});