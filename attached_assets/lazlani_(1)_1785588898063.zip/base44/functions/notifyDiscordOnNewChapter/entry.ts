import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { event, old_data } = body;

    // Require valid automation event — only Chapter entity triggers are allowed
    if (!event?.entity_id || event?.entity_name !== 'Chapter') {
      return Response.json({ skipped: true, reason: 'Invalid event source' });
    }

    // Fetch the verified chapter record from the database (don't trust request body)
    const chapters = await base44.asServiceRole.entities.Chapter.filter({ id: event.entity_id });
    const chapter = chapters[0];
    if (!chapter) {
      return Response.json({ skipped: true, reason: 'Chapter not found' });
    }

    // Only process chapters that just became "yayinda"
    if (chapter.status !== 'yayinda') {
      return Response.json({ skipped: true, reason: 'Not published' });
    }

    // For updates, only fire if status changed to yayinda
    if (event?.type === 'update' && old_data?.status === 'yayinda') {
      return Response.json({ skipped: true, reason: 'Already published' });
    }

    const bookId = chapter.book_id;
    if (!bookId) {
      return Response.json({ skipped: true, reason: 'No book_id' });
    }

    // Get book details using service role
    const books = await base44.asServiceRole.entities.Book.filter({ id: bookId });
    const book = books[0];
    if (!book) {
      return Response.json({ skipped: true, reason: 'Book not found' });
    }

    const webhookUrl = Deno.env.get('DISCORD_WEBHOOK_URL');
    if (!webhookUrl) {
      return Response.json({ error: 'Discord webhook URL not configured' }, { status: 500 });
    }

    const chapterTitle = chapter.title || 'Yeni bölüm';
    const authorName = book.author_name || 'Anonim';

    const discordEmbed = {
      title: `✍️ ${chapterTitle}`,
      description: `**${book.title}** kitabına yeni bölüm eklendi!`,
      color: 15105570,
      author: {
        name: authorName,
      },
      fields: [
        { name: 'Kitap', value: book.title, inline: true },
        { name: 'Bölüm', value: chapterTitle, inline: true },
      ],
      image: book.cover_image ? { url: book.cover_image } : undefined,
      timestamp: new Date().toISOString(),
    };

    const payload = {
      content: `✍️ **Yeni bölüm yayınlandı!**\n📖 **${book.title}** — ${chapterTitle}`,
      embeds: [discordEmbed],
    };

    const discordResponse = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!discordResponse.ok) {
      const errText = await discordResponse.text();
      return Response.json({ error: 'Discord failed', detail: errText }, { status: 500 });
    }

    return Response.json({ success: true, book: book.title, chapter: chapterTitle });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});