import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { jsPDF } from 'npm:jspdf@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { book_id } = await req.json();
    if (!book_id) {
      return Response.json({ error: 'book_id is required' }, { status: 400 });
    }

    // Fetch book and chapters
    const books = await base44.entities.Book.filter({ id: book_id });
    if (!books || books.length === 0) {
      return Response.json({ error: 'Book not found' }, { status: 404 });
    }
    const book = books[0];

    const chapters = await base44.entities.Chapter.filter(
      { book_id: book_id, status: 'yayinda' },
      'order',
      200
    );

    // Create PDF
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 20;
    const maxWidth = pageWidth - margin * 2;

    // Title page
    doc.setFontSize(28);
    const titleLines = doc.splitTextToSize(book.title || 'Kitap', maxWidth);
    const titleY = pageHeight / 3;
    doc.text(titleLines, pageWidth / 2, titleY, { align: 'center' });

    doc.setFontSize(16);
    doc.text(book.author_name || 'Yazar', pageWidth / 2, titleY + titleLines.length * 12 + 10, { align: 'center' });

    if (book.category) {
      doc.setFontSize(11);
      doc.text(book.category, pageWidth / 2, titleY + titleLines.length * 12 + 22, { align: 'center' });
    }

    doc.setFontSize(9);
    doc.text('Lazlani', pageWidth / 2, pageHeight - 30, { align: 'center' });

    // Chapters
    for (let i = 0; i < chapters.length; i++) {
      const chapter = chapters[i];
      doc.addPage();

      // Chapter title
      doc.setFontSize(18);
      const chapterTitle = `${i + 1}. ${chapter.title}`;
      const chTitleLines = doc.splitTextToSize(chapterTitle, maxWidth);
      doc.text(chTitleLines, margin, 30);

      // Separator line
      const afterTitle = 30 + chTitleLines.length * 8 + 4;
      doc.setDrawColor(200);
      doc.setLineWidth(0.3);
      doc.line(margin, afterTitle, pageWidth - margin, afterTitle);

      // Content
      doc.setFontSize(11);
      const content = (chapter.content || '').replace(/\r\n/g, '\n');
      const lines = doc.splitTextToSize(content, maxWidth);
      
      let y = afterTitle + 8;
      const lineHeight = 5.5;

      for (let j = 0; j < lines.length; j++) {
        if (y + lineHeight > pageHeight - 25) {
          // Footer
          doc.setFontSize(8);
          doc.setTextColor(150);
          doc.text(`${chapter.title}`, margin, pageHeight - 12);
          doc.text(`${doc.internal.getNumberOfPages()}`, pageWidth - margin, pageHeight - 12, { align: 'right' });
          doc.setTextColor(0);
          
          doc.addPage();
          y = 25;
          doc.setFontSize(11);
        }
        doc.text(lines[j], margin, y);
        y += lineHeight;
      }

      // Footer on last page of chapter
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.text(`${chapter.title}`, margin, pageHeight - 12);
      doc.text(`${doc.internal.getNumberOfPages()}`, pageWidth - margin, pageHeight - 12, { align: 'right' });
      doc.setTextColor(0);
    }

    const pdfBytes = doc.output('arraybuffer');

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${encodeURIComponent(book.title || 'kitap')}.pdf"`,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});