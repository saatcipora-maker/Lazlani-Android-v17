import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { triggerMessage, recentMessages } = await req.json();
    if (!triggerMessage) return Response.json({ error: 'triggerMessage required' }, { status: 400 });

    // Build context from recent messages
    const context = (recentMessages || [])
      .slice(-8)
      .map(m => `${m.user_name}: ${m.content}`)
      .join("\n");

    const prompt = `Sen "Gezep" adında bir topluluk sohbet botusun. Lazlani adlı bir kitap okuma ve yazma platformunun topluluk odasındasın.

Kuralların:
- Türkçeyi doğal ve samimi kullan, resmi olma
- Kısa ve öz cevaplar ver (1-3 cümle)
- Sohbetin bağlamına uygun cevap ver
- Aynı cevabı tekrarlama, yaratıcı ol
- Kullanıcılara yardımcı ol
- Kitaplar, edebiyat, yazarlık hakkında bilgili ol
- Espritüel ve sevecen ol
- Emojileri ölçülü kullan

Son sohbet:
${context}

Sana seslenen mesaj: "${triggerMessage}"

Gezep olarak doğal bir cevap ver:`;

    const response = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      model: "gpt_5_mini"
    });

    return Response.json({ reply: response });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});