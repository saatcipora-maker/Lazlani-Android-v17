import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { event } = body;

    // Security: require valid automation event — prevents direct external calls
    if (!event?.entity_id || event?.entity_name !== 'Book') {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Security: fetch actual book record from DB instead of trusting request body
    const books = await base44.asServiceRole.entities.Book.filter({ id: event.entity_id }, '-created_date', 1);
    const data = books[0];
    if (!data || data.status !== 'yayinda') {
      return Response.json({ success: true, skipped: true, reason: 'Not published' });
    }

    // For updates, only fire if status actually changed to yayinda
    if (event?.type === 'update' && body.old_data?.status === 'yayinda') {
      return Response.json({ success: true, skipped: true, reason: 'Already published' });
    }

    const webhookUrl = Deno.env.get('DISCORD_WEBHOOK_URL');
    if (!webhookUrl) {
      return Response.json({ error: 'Discord webhook URL not configured' }, { status: 500 });
    }

    const discordEmbed = {
      title: `📚 ${data.title || 'Yeni Kitap'}`,
      description: (data.description || 'Yeni bir kitap yayınlandı!').substring(0, 300),
      color: 3066993,
      author: {
        name: data.author_name || 'Anonim',
      },
      fields: [
        { name: 'Kategori', value: data.category || 'Genel', inline: true },
      ],
      image: data.cover_image ? { url: data.cover_image } : undefined,
      timestamp: new Date().toISOString(),
    };

    const payload = {
      content: `🎉 **Yeni kitap yayınlandı!**\n📖 **${data.title}** — ${data.author_name || 'Anonim'}`,
      embeds: [discordEmbed],
    };

    const discordResponse = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!discordResponse.ok) {
      const errText = await discordResponse.text();
      return Response.json({ error: 'Discord failed', detail: errText }, { status: 500 });
    }

    return Response.json({ success: true, notified: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});