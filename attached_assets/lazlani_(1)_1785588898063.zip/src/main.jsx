import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'

// Fix: Radix UI dismissable layer calls e.target.closest() on text nodes
// which don't have that method. Patch the prototype if missing.
if (typeof Node !== 'undefined' && !Node.prototype.closest) {
  Node.prototype.closest = function(selector) {
    let el = this.nodeType === 1 ? this : this.parentElement;
    return el ? el.closest(selector) : null;
  };
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)