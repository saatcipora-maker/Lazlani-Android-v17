import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Plus, Loader2, Video, X, HelpCircle } from "lucide-react";
import OzelVideoCard from "./OzelVideoCard";
import OzelCommentSheet from "./OzelCommentSheet";
import OzelHelpSheet from "./OzelHelpSheet";
import { toast } from "sonner";

export default function OzelTab() {
  const [currentUser, setCurrentUser] = useState(null);
  const [showUpload, setShowUpload] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [caption, setCaption] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [commentVideo, setCommentVideo] = useState(null);
  const [showHelp, setShowHelp] = useState(false);
  const fileRef = useRef(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const hasOzelBadge = currentUser?.has_ozel_badge === true;

  const { data: videos = [], isLoading } = useQuery({
    queryKey: ["exclusive-videos"],
    queryFn: () => base44.entities.ExclusiveVideo.list("-created_date", 50),
  });

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!selectedFile) return;

      // Validate duration
      const videoEl = document.createElement("video");
      videoEl.preload = "metadata";
      const duration = await new Promise((resolve) => {
        videoEl.onloadedmetadata = () => resolve(videoEl.duration);
        videoEl.src = URL.createObjectURL(selectedFile);
      });

      if (duration > 40) {
        throw new Error("Video süresi maksimum 40 saniye olabilir.");
      }

      setUploading(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedFile });
      const expiresAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();

      await base44.entities.ExclusiveVideo.create({
        user_email: currentUser.email,
        user_name: currentUser.display_name || currentUser.full_name,
        video_url: file_url,
        caption: caption.trim(),
        expires_at: expiresAt,
      });
    },
    onSuccess: () => {
      setShowUpload(false);
      setCaption("");
      setSelectedFile(null);
      setUploading(false);
      queryClient.invalidateQueries({ queryKey: ["exclusive-videos"] });
      toast.success("Video paylaşıldı!");
    },
    onError: (err) => {
      setUploading(false);
      toast.error(err.message || "Video yüklenemedi");
    },
  });

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("video/")) {
      toast.error("Lütfen bir video dosyası seçin");
      return;
    }
    setSelectedFile(file);
    setShowUpload(true);
  };

  return (
    <div className="relative" style={{ height: "calc(100vh - 130px)" }}>
      {/* Top buttons */}
      <div className="absolute top-3 right-3 z-30 flex gap-2">
        <button
          onClick={() => setShowHelp(true)}
          className="w-10 h-10 rounded-full bg-black/30 backdrop-blur-md flex items-center justify-center active:scale-95 transition-transform border border-white/10"
          aria-label="Yardım"
        >
          <HelpCircle className="w-5 h-5 text-white" />
        </button>
        {hasOzelBadge ? (
          <button
            onClick={() => fileRef.current?.click()}
            className="w-11 h-11 rounded-full bg-primary shadow-lg shadow-primary/30 flex items-center justify-center active:scale-95 transition-transform"
            aria-label="Video paylaş"
          >
            <Plus className="w-5 h-5 text-primary-foreground" />
          </button>
        ) : currentUser && (
          <button
            onClick={() => toast("Bu özellik yalnızca Özel Rozet sahiplerine açıktır.", { duration: 3000 })}
            className="w-11 h-11 rounded-full bg-muted/80 backdrop-blur-md flex items-center justify-center border border-white/10 opacity-60"
            aria-label="Video paylaş (kilitli)"
          >
            <Plus className="w-5 h-5 text-muted-foreground" />
          </button>
        )}
      </div>
      <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={handleFileSelect} />

      {/* Upload modal */}
      {showUpload && (
        <div className="absolute inset-0 z-40 bg-background flex flex-col">
          <div className="flex items-center justify-between p-4 border-b border-border">
            <h3 className="font-heading text-lg font-bold">Video Paylaş</h3>
            <button onClick={() => { setShowUpload(false); setSelectedFile(null); }} aria-label="Kapat">
              <X className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>
          <div className="flex-1 p-4 space-y-4">
            {selectedFile && (
              <div className="rounded-2xl overflow-hidden bg-black aspect-[9/16] max-h-[40vh] mx-auto">
                <video src={URL.createObjectURL(selectedFile)} className="w-full h-full object-contain" controls />
              </div>
            )}
            <input
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Açıklama ekle..."
              maxLength={200}
              className="w-full h-11 rounded-xl bg-muted px-4 text-sm outline-none border-0"
              style={{ fontSize: "16px" }}
            />
            <p className="text-[10px] text-muted-foreground">Maks. 40 saniye • 14 gün yayında kalır</p>
            <button
              onClick={() => uploadMutation.mutate()}
              disabled={!selectedFile || uploading}
              className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-semibold flex items-center justify-center gap-2 disabled:opacity-50 active:scale-[0.98] transition-transform"
            >
              {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Video className="w-4 h-4" /> Paylaş</>}
            </button>
          </div>
        </div>
      )}

      {/* Video feed */}
      {isLoading ? (
        <div className="flex items-center justify-center h-full">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full gap-3">
          <Video className="w-12 h-12 text-muted-foreground/30" />
          <p className="text-sm text-muted-foreground">Henüz özel video yok</p>
        </div>
      ) : (
        <div className="h-full overflow-y-auto snap-y snap-mandatory scrollbar-hide">
          {videos.map((video) => (
            <div key={video.id} className="h-full">
              <OzelVideoCard
                video={video}
                currentUser={currentUser}
                onCommentClick={(v) => setCommentVideo(v)}
              />
            </div>
          ))}
        </div>
      )}

      {/* Help sheet */}
      <OzelHelpSheet isOpen={showHelp} onClose={() => setShowHelp(false)} />

      {/* Comment sheet */}
      <OzelCommentSheet
        video={commentVideo}
        isOpen={!!commentVideo}
        onClose={() => setCommentVideo(null)}
        currentUser={currentUser}
      />
    </div>
  );
}