import { Shield, Upload, Clock, Ban, Sparkles, Award, X } from "lucide-react";
import { BottomSheet } from "@/components/ui/bottom-sheet";

const RULES = [
  { icon: Upload, title: "Nasıl Yüklenir?", text: "Sağ üstteki + butonuna basın, galeriden videonuzu seçin ve açıklama ekleyip paylaşın." },
  { icon: Clock, title: "Süre & Yayın", text: "Videolar en fazla 40 saniye olabilir ve yayınlandıktan 14 gün sonra otomatik olarak silinir." },
  { icon: Award, title: "Rozet Gerekli", text: "Video paylaşabilmek için Özel rozetine sahip olmanız gerekir. Rozeti Mağaza'dan edinebilirsiniz." },
  { icon: Sparkles, title: "İçerik Kalitesi", text: "Orijinal, yaratıcı ve kaliteli içerikler paylaşın. Topluluk kurallarına uygun içerikler yayında kalır." },
  { icon: Ban, title: "Yasak İçerikler", text: "Hakaret, şiddet, müstehcen, telif haklı veya spam içerikler kesinlikle yasaktır ve kaldırılır." },
  { icon: Shield, title: "Topluluk Güvenliği", text: "Kurallara uymayan içerikler yöneticiler tarafından kaldırılabilir. Tekrarlayan ihlallerde hesap kısıtlanır." },
];

export default function OzelHelpSheet({ isOpen, onClose }) {
  return (
    <BottomSheet isOpen={isOpen} onClose={onClose} title="Özel Videolar Rehberi">
      <div className="px-4 pb-6 space-y-3">
        <p className="text-xs text-muted-foreground leading-relaxed">
          Özel videolar, rozet sahibi üyelerin kısa videolarını toplulukla paylaştığı özel bir alandır.
        </p>

        {RULES.map((rule, i) => (
          <div key={i} className="flex gap-3 p-3 rounded-xl bg-muted/50">
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <rule.icon className="w-4 h-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground">{rule.title}</p>
              <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{rule.text}</p>
            </div>
          </div>
        ))}
      </div>
    </BottomSheet>
  );
}