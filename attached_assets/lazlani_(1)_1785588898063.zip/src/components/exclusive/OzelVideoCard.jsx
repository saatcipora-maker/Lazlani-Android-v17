import { useState, useRef, useEffect } from "react";
import { Heart, MessageCircle, Eye, Play, Pause } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";

export default function OzelVideoCard({ video, currentUser, onCommentClick }) {
  const videoRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [viewed, setViewed] = useState(false);
  const queryClient = useQueryClient();

  const { data: likes = [] } = useQuery({
    queryKey: ["exclusive-likes", video.id],
    queryFn: () => base44.entities.ExclusiveVideoLike.filter({ video_id: video.id }),
  });

  const isLiked = likes.some((l) => l.user_email === currentUser?.email);

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (isLiked) {
        const myLike = likes.find((l) => l.user_email === currentUser?.email);
        if (myLike) await base44.entities.ExclusiveVideoLike.delete(myLike.id);
        await base44.entities.ExclusiveVideo.update(video.id, { like_count: Math.max(0, (video.like_count || 0) - 1) });
      } else {
        await base44.entities.ExclusiveVideoLike.create({ video_id: video.id, user_email: currentUser.email });
        await base44.entities.ExclusiveVideo.update(video.id, { like_count: (video.like_count || 0) + 1 });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["exclusive-likes", video.id] });
      queryClient.invalidateQueries({ queryKey: ["exclusive-videos"] });
    },
  });

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (playing) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setPlaying(!playing);
  };

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.play().catch(() => {});
          setPlaying(true);
          if (!viewed && currentUser) {
            setViewed(true);
            base44.entities.ExclusiveVideo.update(video.id, { view_count: (video.view_count || 0) + 1 }).catch(() => {});
          }
        } else {
          el.pause();
          setPlaying(false);
        }
      },
      { threshold: 0.6 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [video.id, viewed, currentUser]);

  return (
    <div className="relative w-full h-full snap-start snap-always flex-shrink-0 bg-black">
      <video
        ref={videoRef}
        src={video.video_url}
        className="w-full h-full object-cover"
        loop
        muted={false}
        playsInline
        preload="metadata"
        onClick={togglePlay}
      />

      {/* Play/pause overlay */}
      {!playing && (
        <button onClick={togglePlay} className="absolute inset-0 flex items-center justify-center bg-black/20" aria-label="Oynat">
          <Play className="w-16 h-16 text-white/80" fill="white" />
        </button>
      )}

      {/* Right side actions */}
      <div className="absolute right-3 bottom-28 flex flex-col items-center gap-5">
        <button onClick={() => currentUser && likeMutation.mutate()} className="flex flex-col items-center gap-1" aria-label="Beğen">
          <div className={`w-11 h-11 rounded-full flex items-center justify-center ${isLiked ? "bg-red-500" : "bg-white/20 backdrop-blur-sm"}`}>
            <Heart className={`w-5 h-5 ${isLiked ? "text-white fill-white" : "text-white"}`} />
          </div>
          <span className="text-[11px] text-white font-semibold drop-shadow">{video.like_count || 0}</span>
        </button>

        <button onClick={() => onCommentClick?.(video)} className="flex flex-col items-center gap-1" aria-label="Yorum yap">
          <div className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <MessageCircle className="w-5 h-5 text-white" />
          </div>
          <span className="text-[11px] text-white font-semibold drop-shadow">{video.comment_count || 0}</span>
        </button>

        <div className="flex flex-col items-center gap-1">
          <div className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Eye className="w-5 h-5 text-white" />
          </div>
          <span className="text-[11px] text-white font-semibold drop-shadow">{video.view_count || 0}</span>
        </div>
      </div>

      {/* Bottom user info */}
      <div className="absolute left-3 bottom-8 right-20">
        <Link to={`/user/${encodeURIComponent(video.user_email)}`} className="flex items-center gap-2 mb-2">
          <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
            <span className="text-sm font-bold text-white">{video.user_name?.[0]?.toUpperCase() || "?"}</span>
          </div>
          <span className="text-sm font-semibold text-white drop-shadow">{video.user_name || "Kullanıcı"}</span>
        </Link>
        {video.caption && <p className="text-xs text-white/90 drop-shadow line-clamp-2">{video.caption}</p>}
        <p className="text-[10px] text-white/60 mt-1">{formatDistanceToNow(new Date(video.created_date), { addSuffix: true, locale: tr })}</p>
      </div>
    </div>
  );
}