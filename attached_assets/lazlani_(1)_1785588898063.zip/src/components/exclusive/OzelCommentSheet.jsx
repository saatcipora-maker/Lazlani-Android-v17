import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { BottomSheet } from "@/components/ui/bottom-sheet";
import { Send, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";

export default function OzelCommentSheet({ video, isOpen, onClose, currentUser }) {
  const [text, setText] = useState("");
  const queryClient = useQueryClient();

  const { data: comments = [], isLoading } = useQuery({
    queryKey: ["exclusive-comments", video?.id],
    queryFn: () => base44.entities.ExclusiveVideoComment.filter({ video_id: video.id }, "-created_date", 50),
    enabled: !!video?.id && isOpen,
  });

  const addComment = useMutation({
    mutationFn: async () => {
      await base44.entities.ExclusiveVideoComment.create({
        video_id: video.id,
        user_email: currentUser.email,
        user_name: currentUser.display_name || currentUser.full_name,
        content: text.trim(),
      });
      await base44.entities.ExclusiveVideo.update(video.id, { comment_count: (video.comment_count || 0) + 1 });
    },
    onSuccess: () => {
      setText("");
      queryClient.invalidateQueries({ queryKey: ["exclusive-comments", video?.id] });
      queryClient.invalidateQueries({ queryKey: ["exclusive-videos"] });
    },
  });

  return (
    <BottomSheet isOpen={isOpen} onClose={onClose} title={`Yorumlar (${comments.length})`}>
      <div className="space-y-3 max-h-[50vh] overflow-y-auto mb-4">
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
        ) : comments.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-8">Henüz yorum yok</p>
        ) : comments.map((c) => (
          <div key={c.id} className="flex gap-2.5">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-xs font-bold text-primary">{c.user_name?.[0]?.toUpperCase() || "?"}</span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="bg-white rounded-2xl px-3.5 py-2.5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.08)" }}>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-foreground">{c.user_name}</span>
                  <span className="text-[10px] text-muted-foreground">{formatDistanceToNow(new Date(c.created_date), { addSuffix: true, locale: tr })}</span>
                </div>
                <p className="text-[13px] mt-0.5 leading-relaxed whitespace-pre-wrap break-words" style={{ color: "#111111" }}>{c.content}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="flex gap-2 pt-2 border-t border-border">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Yorum yaz..."
          className="flex-1 h-10 rounded-full bg-muted px-4 text-sm outline-none border-0"
          style={{ fontSize: "16px" }}
          onKeyDown={(e) => { if (e.key === "Enter" && text.trim()) addComment.mutate(); }}
        />
        <button
          onClick={() => text.trim() && addComment.mutate()}
          disabled={!text.trim() || addComment.isPending}
          className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground disabled:opacity-50"
          aria-label="Gönder"
        >
          {addComment.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </button>
      </div>
    </BottomSheet>
  );
}