import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, MessageSquare } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";

const AVATAR_COLORS = [
  "#4CAF50", "#2196F3", "#FF9800", "#9C27B0", "#E91E63",
  "#00BCD4", "#FF5722", "#795548", "#607D8B", "#F44336",
];

function getAvatarColor(email) {
  if (!email) return AVATAR_COLORS[0];
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = email.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

export default function DMConversationList({ currentUser, onSelectConversation, onClose }) {
  // Fetch all messages involving the current user
  const { data: sentMessages = [] } = useQuery({
    queryKey: ["dm-sent", currentUser?.email],
    queryFn: () => base44.entities.Message.filter({ sender_email: currentUser.email }, "-created_date", 200),
    enabled: !!currentUser?.email,
  });

  const { data: receivedMessages = [] } = useQuery({
    queryKey: ["dm-received", currentUser?.email],
    queryFn: () => base44.entities.Message.filter({ receiver_email: currentUser.email }, "-created_date", 200),
    enabled: !!currentUser?.email,
  });

  // Build conversation list
  const allMessages = [...sentMessages, ...receivedMessages].sort(
    (a, b) => new Date(b.created_date) - new Date(a.created_date)
  );

  const conversationsMap = {};
  allMessages.forEach((msg) => {
    const otherEmail = msg.sender_email === currentUser.email ? msg.receiver_email : msg.sender_email;
    const otherName = msg.sender_email === currentUser.email ? msg.receiver_name : msg.sender_name;
    if (!conversationsMap[otherEmail]) {
      conversationsMap[otherEmail] = {
        email: otherEmail,
        name: otherName || otherEmail?.split("@")[0],
        lastMessage: msg.content || "",
        lastDate: msg.created_date,
        unread: msg.receiver_email === currentUser.email && !msg.is_read ? 1 : 0,
      };
    } else {
      if (msg.receiver_email === currentUser.email && !msg.is_read) {
        conversationsMap[otherEmail].unread++;
      }
    }
  });

  const conversations = Object.values(conversationsMap);

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-[#f0f0f5]">
      {/* Header */}
      <div className="flex items-center gap-3 px-3 py-2.5 bg-[#f0f0f5] border-b border-[#d0d0d8] flex-shrink-0">
        <button
          onClick={onClose}
          className="w-9 h-9 flex items-center justify-center text-[#555]"
          style={{ minWidth: "36px" }}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <MessageSquare className="w-5 h-5 text-[#4A90D9]" />
        <p className="text-sm font-bold text-[#333]">Özel Mesajlar</p>
      </div>

      {/* List */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        {conversations.length === 0 && (
          <p className="text-center text-[#999] text-xs py-12">Henüz özel mesajınız yok</p>
        )}
        {conversations.map((conv) => {
          const avatarColor = getAvatarColor(conv.email);
          const initial = (conv.name || "?")?.[0]?.toUpperCase();
          return (
            <button
              key={conv.email}
              onClick={() => onSelectConversation(conv.email, conv.name)}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/60 transition-colors border-b border-[#e0e0e8] text-left"
            >
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: avatarColor }}
              >
                <span className="text-white text-sm font-bold">{initial}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-[#333] truncate">{conv.name}</p>
                  {conv.lastDate && (
                    <span className="text-[10px] text-[#999] flex-shrink-0 ml-2">
                      {formatDistanceToNow(new Date(conv.lastDate), { addSuffix: true, locale: tr })}
                    </span>
                  )}
                </div>
                <p className="text-xs text-[#777] truncate mt-0.5">{conv.lastMessage}</p>
              </div>
              {conv.unread > 0 && (
                <span className="w-5 h-5 rounded-full bg-[#4A90D9] text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0">
                  {conv.unread > 9 ? "9+" : conv.unread}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}