import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { X, Pencil, Image, UserPlus, UserMinus, Upload, Palette, Clock, Mic, ScrollText, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const THEME_COLORS = [
  "", "#e8e8f0", "#1a1a2e", "#0f172a", "#1e293b",
  "#fef3c7", "#dcfce7", "#dbeafe", "#fce7f3", "#ede9fe",
  "#fee2e2", "#f0fdf4", "#ecfdf5", "#fdf4ff", "#fff7ed",
];

const SLOW_MODE_OPTIONS = [
  { value: 0, label: "Kapalı" },
  { value: 5, label: "5 sn" },
  { value: 10, label: "10 sn" },
  { value: 30, label: "30 sn" },
  { value: 60, label: "1 dk" },
  { value: 300, label: "5 dk" },
];

export default function RoomAdminPanel({ room, onClose }) {
  const [roomName, setRoomName] = useState(room?.name || "");
  const [modEmail, setModEmail] = useState("");
  const [rules, setRules] = useState(room?.rules || "");
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const updateRoom = useMutation({
    mutationFn: (data) => base44.entities.ChatRoom.update(room.id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["chat-rooms"] }),
  });

  const handleRename = () => {
    if (!roomName.trim() || roomName === room.name) return;
    updateRoom.mutate({ name: roomName.trim() });
  };

  const handleToggle = (field) => {
    updateRoom.mutate({ [field]: !room[field] });
  };

  const handleAddMod = () => {
    if (!modEmail.trim()) return;
    const current = room.moderator_emails || [];
    if (current.includes(modEmail.trim())) return;
    updateRoom.mutate({ moderator_emails: [...current, modEmail.trim()] });
    setModEmail("");
  };

  const handleRemoveMod = (email) => {
    const current = room.moderator_emails || [];
    updateRoom.mutate({ moderator_emails: current.filter((e) => e !== email) });
  };

  const handleSaveRules = () => {
    updateRoom.mutate({ rules });
  };

  const handleBgUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    updateRoom.mutate({ background_image: file_url });
    setUploading(false);
    e.target.value = "";
  };

  const handleRemoveBg = () => {
    updateRoom.mutate({ background_image: "" });
  };

  const handleThemeColor = (color) => {
    updateRoom.mutate({ theme_color: color });
  };

  const handleSlowMode = (seconds) => {
    updateRoom.mutate({ slow_mode_seconds: seconds });
  };

  const mods = room?.moderator_emails || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        className="relative bg-[#1e1e30] rounded-2xl w-80 max-h-[85vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 pt-4 pb-2 sticky top-0 bg-[#1e1e30] z-10">
          <h3 className="text-white font-bold text-sm">Oda Yönetimi — #{room?.name}</h3>
          <button onClick={onClose} className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-white rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Rename */}
        <Section title="Oda Adı">
          <div className="flex gap-2">
            <Input
              value={roomName}
              onChange={(e) => setRoomName(e.target.value)}
              className="h-8 text-sm bg-white/10 border-white/20 text-white placeholder:text-gray-500"
              onKeyDown={(e) => e.key === "Enter" && handleRename()}
            />
            <Button size="sm" className="h-8 flex-shrink-0" onClick={handleRename} disabled={!roomName.trim() || roomName === room?.name}>
              <Pencil className="w-3 h-3" />
            </Button>
          </div>
        </Section>

        {/* Rules */}
        <Section title="Oda Kuralları">
          <Textarea
            value={rules}
            onChange={(e) => setRules(e.target.value)}
            placeholder="Bu odanın kurallarını yazın..."
            className="text-sm bg-white/10 border-white/20 text-white placeholder:text-gray-500 min-h-[80px] resize-none"
          />
          <Button
            size="sm"
            className="h-7 mt-2 w-full"
            onClick={handleSaveRules}
            disabled={rules === (room?.rules || "")}
          >
            <ScrollText className="w-3 h-3 mr-1" />
            Kuralları Kaydet
          </Button>
        </Section>

        {/* Background Image */}
        <Section title="Arka Plan Resmi">
          {room?.background_image ? (
            <div className="space-y-2">
              <div className="relative rounded-lg overflow-hidden h-24">
                <img src={room.background_image} alt="bg" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/30" />
              </div>
              <div className="flex gap-2">
                <label className="flex-1 flex items-center justify-center gap-1 h-8 rounded-lg bg-white/10 text-white text-xs font-medium cursor-pointer hover:bg-white/20 transition-colors">
                  <Upload className="w-3 h-3" />
                  Değiştir
                  <input type="file" accept="image/*" className="hidden" onChange={handleBgUpload} disabled={uploading} />
                </label>
                <Button size="sm" variant="destructive" className="h-8" onClick={handleRemoveBg}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ) : (
            <label className="flex items-center justify-center gap-2 h-20 rounded-lg border-2 border-dashed border-white/20 text-gray-400 text-xs cursor-pointer hover:border-white/40 hover:text-gray-300 transition-colors">
              {uploading ? (
                <span>Yükleniyor...</span>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Arka plan resmi yükle</span>
                </>
              )}
              <input type="file" accept="image/*" className="hidden" onChange={handleBgUpload} disabled={uploading} />
            </label>
          )}
        </Section>

        {/* Theme Color */}
        <Section title="Tema Rengi">
          <div className="flex flex-wrap gap-2">
            {THEME_COLORS.map((color) => (
              <button
                key={color || "default"}
                onClick={() => handleThemeColor(color)}
                className={`w-10 h-10 rounded-full border-2 transition-transform hover:scale-110 ${
                  (room?.theme_color || "") === color ? "ring-2 ring-offset-2 ring-offset-[#1e1e30] ring-blue-500" : "border-white/20"
                }`}
                style={{ backgroundColor: color || "#e8e8f0" }}
              >
                {!color && <X className="w-3 h-3 text-gray-500 mx-auto" />}
              </button>
            ))}
          </div>
          <p className="text-[10px] text-gray-500 mt-1.5">Boş = varsayılan renk</p>
        </Section>

        {/* Slow Mode */}
        <Section title="Yavaş Mod">
          <div className="flex flex-wrap gap-1.5">
            {SLOW_MODE_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => handleSlowMode(opt.value)}
                className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                  (room?.slow_mode_seconds || 0) === opt.value
                    ? "bg-blue-500 text-white"
                    : "bg-white/10 text-gray-300 hover:bg-white/20"
                }`}
              >
                {opt.value === 0 ? <Clock className="w-3 h-3 inline mr-1" /> : null}
                {opt.label}
              </button>
            ))}
          </div>
        </Section>

        {/* Toggle switches */}
        <Section title="Özellikler">
          <div className="space-y-2">
            <ToggleRow
              label="GIF Gönderimi"
              icon={<Image className="w-4 h-4" />}
              enabled={room?.gif_enabled !== false}
              onToggle={() => handleToggle("gif_enabled")}
            />
            <ToggleRow
              label="Ses Kaydı"
              icon={<Mic className="w-4 h-4" />}
              enabled={room?.voice_enabled !== false}
              onToggle={() => handleToggle("voice_enabled")}
            />
          </div>
        </Section>

        {/* Moderators */}
        <Section title="Oda Görevlileri">
          <div className="space-y-1.5 mb-2">
            {mods.length === 0 && <p className="text-gray-500 text-xs">Henüz görevli yok</p>}
            {mods.map((email) => (
              <div key={email} className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
                <span className="text-white text-xs truncate">{email}</span>
                <button
                  onClick={() => handleRemoveMod(email)}
                  className="w-8 h-8 flex items-center justify-center text-red-400 hover:text-red-300 flex-shrink-0 rounded-lg"
                >
                  <UserMinus className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              value={modEmail}
              onChange={(e) => setModEmail(e.target.value)}
              placeholder="Email ekle..."
              className="h-8 text-sm bg-white/10 border-white/20 text-white placeholder:text-gray-500"
              onKeyDown={(e) => e.key === "Enter" && handleAddMod()}
            />
            <Button size="sm" className="h-8 flex-shrink-0" onClick={handleAddMod} disabled={!modEmail.trim()}>
              <UserPlus className="w-3 h-3" />
            </Button>
          </div>
        </Section>

        <div className="h-4" />
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="px-4 py-3 border-t border-white/10">
      <p className="text-[10px] text-gray-500 uppercase font-bold tracking-wider mb-2">{title}</p>
      {children}
    </div>
  );
}

function ToggleRow({ label, icon, enabled, onToggle }) {
  return (
    <button
      onClick={onToggle}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
        enabled ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
      }`}
    >
      {icon}
      <span className="text-sm font-semibold flex-1 text-left">{label}</span>
      <span className="text-xs font-bold">{enabled ? "Açık ✓" : "Kapalı ✗"}</span>
    </button>
  );
}