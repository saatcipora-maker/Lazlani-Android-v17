import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { BookOpen, Mic, Reply, ScrollText, X } from "lucide-react";
import { format } from "date-fns";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useBadgeContext } from "@/lib/BadgeContext";
import UserBadges from "@/components/badges/UserBadges";
import UserProfilePopup from "@/components/lazlande/UserProfilePopup";
import MessageReactions from "@/components/lazlande/MessageReactions";



const AVATAR_COLORS = [
  "#4CAF50", "#2196F3", "#FF9800", "#9C27B0", "#E91E63",
  "#00BCD4", "#FF5722", "#795548", "#607D8B", "#F44336",
  "#8BC34A", "#3F51B5", "#FFEB3B", "#009688", "#673AB7",
];

function getAvatarColor(email) {
  if (!email) return AVATAR_COLORS[0];
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = email.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function getIndicatorColor(email, badges) {
  if (badges?.role === "admin") return "#eab308"; // altın/sarı - yönetici
  if (badges?.has_vip) return "#a855f7"; // mor - VIP
  if (badges?.has_author_badge) return "#10b981"; // yeşil - onaylı yazar
  if (badges?.has_magazin_badge) return "#f43f5e"; // pembe - magazin
  return "#3b82f6"; // mavi - standart
}

export default function ChatMessageList({ messages, currentUser, onlineUsers = [], activeRoom, activeRoomData, onOpenDM, onReply }) {
  const [showRules, setShowRules] = useState(false);
  const bottomRef = useRef(null);
  const containerRef = useRef(null);
  const { badgeMap, autoBadgeMap } = useBadgeContext();
  const [selectedUser, setSelectedUser] = useState(null);
  const [tappedMsgId, setTappedMsgId] = useState(null);
  const queryClient = useQueryClient();

  // Fetch all reactions for visible messages
  const messageIds = messages.map((m) => m.id);
  const { data: allReactions = [] } = useQuery({
    queryKey: ["message-reactions", activeRoom],
    queryFn: () => base44.entities.MessageReaction.list("-created_date", 500),
    refetchInterval: 10000,
  });

  // Subscribe to real-time reaction changes
  useEffect(() => {
    const unsub = base44.entities.MessageReaction.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["message-reactions"] });
    });
    return unsub;
  }, []);

  // Group reactions by message_id
  const reactionsByMsg = {};
  allReactions.forEach((r) => {
    if (!reactionsByMsg[r.message_id]) reactionsByMsg[r.message_id] = [];
    reactionsByMsg[r.message_id].push(r);
  });

  const addReaction = useMutation({
    mutationFn: ({ messageId, emoji }) =>
      base44.entities.MessageReaction.create({ message_id: messageId, user_email: currentUser.email, emoji }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["message-reactions"] }),
  });

  const removeReaction = useMutation({
    mutationFn: (reactionId) => base44.entities.MessageReaction.delete(reactionId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["message-reactions"] }),
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const renderContent = (msg) => {
    if (msg.type === "voice" && msg.media_url) {
      return (
        <div className="flex items-center gap-2 mt-1">
          <Mic className="w-3.5 h-3.5 flex-shrink-0" />
          <audio controls src={msg.media_url} className="h-8 max-w-[180px]" />
        </div>
      );
    }

    if (msg.type === "gif" && msg.media_url) {
      return (
        <img
          src={msg.media_url}
          alt="gif"
          className="mt-1 max-w-[200px] max-h-[160px] rounded-lg object-cover"
        />
      );
    }

    if (msg.type === "book" && msg.book_id) {
      return (
        <Link
          to={`/book/${msg.book_id}`}
          className="flex items-center gap-2 mt-1 p-2 bg-gray-50 rounded-lg border border-gray-200 hover:bg-gray-100 transition-colors"
        >
          {msg.media_url ? (
            <img src={msg.media_url} alt={msg.book_title} className="w-10 h-14 object-cover rounded flex-shrink-0" />
          ) : (
            <div className="w-10 h-14 bg-gray-200 rounded flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-4 h-4 text-gray-400" />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold truncate" style={{ color: "#111111" }}>{msg.book_title || "Kitap"}</p>
            <p className="text-[10px] text-gray-500">Okumak için tıkla</p>
          </div>
        </Link>
      );
    }

    return (
      <p className="text-[14px] leading-relaxed break-words" style={{ color: msg.text_color || "#111111" }}>
        {msg.content || ""}
      </p>
    );
  };

  const renderReplyPreview = (msg) => {
    if (!msg.reply_to_id || !msg.reply_to_content) return null;
    return (
      <div className="mb-1 px-2.5 py-1.5 rounded-lg bg-black/5 border-l-2 border-[#4A90D9]">
        <p className="text-[10px] font-semibold text-[#4A90D9]">{msg.reply_to_name || "Kullanıcı"}</p>
        <p className="text-[11px] text-[#666] truncate">{msg.reply_to_content}</p>
      </div>
    );
  };

  const handleReply = (msg) => {
    if (!onReply || !currentUser) return;
    const name = msg.user_name || msg.user_email?.split("@")[0] || "?";
    const preview = msg.type === "gif" ? "GIF" : msg.type === "voice" ? "Ses kaydı" : msg.type === "book" ? msg.book_title : msg.content;
    onReply({ id: msg.id, name, content: (preview || "").slice(0, 80) });
  };

  const formatTime = (dateStr) => {
    if (!dateStr) return "";
    return format(new Date(dateStr), "HH:mm");
  };

  return (
    <div
      ref={containerRef}
      className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-3 py-3 space-y-3 relative"
      style={{
        backgroundColor: activeRoomData?.theme_color || "#e8e8f0",
        backgroundImage: activeRoomData?.background_image ? `url(${activeRoomData.background_image})` : undefined,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Overlay for readability when background image is set */}
      {activeRoomData?.background_image && (
        <div className="absolute inset-0 bg-black/20 pointer-events-none" />
      )}

      {/* Room rules banner */}
      {activeRoomData?.rules && !showRules && (
        <div className="relative z-10">
          <button
            onClick={() => setShowRules(true)}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl bg-blue-500/15 backdrop-blur-sm border border-blue-400/30 text-blue-600 text-xs font-medium hover:bg-blue-500/25 transition-colors"
            style={{ minHeight: "auto" }}
          >
            <ScrollText className="w-3.5 h-3.5 flex-shrink-0" />
            <span>Oda kurallarını görüntüle</span>
          </button>
        </div>
      )}

      {showRules && activeRoomData?.rules && (
        <div className="relative z-10 bg-white/90 backdrop-blur-sm rounded-xl p-3 border border-blue-200 shadow-sm">
          <div className="flex items-start justify-between gap-2 mb-1.5">
            <p className="text-xs font-bold text-blue-600 flex items-center gap-1">
              <ScrollText className="w-3.5 h-3.5" />
              Oda Kuralları
            </p>
            <button
              onClick={() => setShowRules(false)}
              className="text-gray-400 hover:text-gray-600"
              style={{ minHeight: "auto", minWidth: "auto" }}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-gray-700 whitespace-pre-wrap leading-relaxed">{activeRoomData.rules}</p>
        </div>
      )}

      {messages.map((msg) => {
        const isOwn = msg.user_email === currentUser?.email;
        const avatarColor = getAvatarColor(msg.user_email);
        const displayName = msg.user_name || msg.user_email?.split("@")[0] || "?";
        const initial = displayName[0]?.toUpperCase() || "?";
        const indicatorColor = getIndicatorColor(msg.user_email, badgeMap[msg.user_email]);
        const bgColor = activeRoomData?.theme_color || "#e8e8f0";

        if (isOwn) {
          return (
            <div key={msg.id} className="flex items-end gap-2 justify-end">
              <div className="flex flex-col items-end max-w-[75%]">
                <div className="flex items-center gap-1.5 mb-0.5 mr-1">
                  <span className="text-[11px] font-semibold text-[#555]">{displayName}</span>
                  <span className="text-[10px] text-[#999]">{formatTime(msg.created_date)}</span>
                </div>
                <div
                  className="rounded-2xl rounded-br-sm px-3.5 py-2 shadow-sm cursor-pointer"
                  style={{ backgroundColor: "#FFFFFF", border: "1px solid rgba(0,0,0,0.08)" }}
                  onClick={() => setTappedMsgId(tappedMsgId === msg.id ? null : msg.id)}
                >
                  {renderReplyPreview(msg)}
                  {renderContent(msg)}
                </div>
                <div className="flex items-center gap-1 mt-0.5">
                  {tappedMsgId === msg.id && currentUser && (
                    <button
                      onClick={() => { handleReply(msg); setTappedMsgId(null); }}
                      className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] text-[#888] hover:text-[#4A90D9] hover:bg-[#4A90D9]/10 transition-colors"
                      style={{ minHeight: "auto", minWidth: "auto" }}
                    >
                      <Reply className="w-3 h-3" />
                      Yanıtla
                    </button>
                  )}
                  <MessageReactions
                    messageId={msg.id}
                    reactions={reactionsByMsg[msg.id] || []}
                    currentUser={currentUser}
                    onAddReaction={(msgId, emoji) => addReaction.mutate({ messageId: msgId, emoji })}
                    onRemoveReaction={(id) => removeReaction.mutate(id)}
                  />
                </div>
              </div>
              <button
                className="flex-shrink-0 relative"
                onClick={() => setSelectedUser({ email: msg.user_email, name: displayName })}
                style={{ minHeight: "auto", minWidth: "auto" }}
              >
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shadow-sm"
                  style={{ backgroundColor: avatarColor }}
                >
                  <span className="text-white text-sm font-bold">{initial}</span>
                </div>
                <div className="absolute -bottom-0.5 -left-0.5 w-3.5 h-3.5 rounded-full border-2" style={{ backgroundColor: indicatorColor, borderColor: bgColor }} />
              </button>
            </div>
          );
        }

        return (
          <div key={msg.id} className="flex items-end gap-2">
            <button
              className="flex-shrink-0 relative"
              onClick={() => setSelectedUser({ email: msg.user_email, name: displayName })}
              style={{ minHeight: "auto", minWidth: "auto" }}
            >
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center shadow-sm"
                style={{ backgroundColor: avatarColor }}
              >
                <span className="text-white text-sm font-bold">{initial}</span>
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2" style={{ backgroundColor: indicatorColor, borderColor: bgColor }} />
            </button>

            <div className="flex flex-col max-w-[75%]">
              <div className="flex items-center gap-1.5 mb-0.5 ml-1 flex-wrap">
                <span
                  className="text-[11px] font-semibold"
                  style={{ color: msg.text_color || "#333" }}
                >
                  {displayName}
                </span>
                <UserBadges
                  size="xs"
                  manualBadges={badgeMap[msg.user_email] || {}}
                  autoBadges={autoBadgeMap[msg.user_email] || {}}
                />
                <span className="text-[10px] text-[#999]">{formatTime(msg.created_date)}</span>
              </div>
              <div className="bg-white rounded-2xl rounded-bl-sm px-3.5 py-2 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.08)" }}>
                {renderReplyPreview(msg)}
                {renderContent(msg)}
              </div>
              <div className="flex items-center gap-1 mt-0.5">
                {currentUser && (
                  <button
                    onClick={() => handleReply(msg)}
                    className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] text-[#888] hover:text-[#4A90D9] hover:bg-[#4A90D9]/10 transition-colors"
                    style={{ minHeight: "auto", minWidth: "auto" }}
                  >
                    <Reply className="w-3 h-3" />
                    Yanıtla
                  </button>
                )}
                <MessageReactions
                  messageId={msg.id}
                  reactions={reactionsByMsg[msg.id] || []}
                  currentUser={currentUser}
                  onAddReaction={(msgId, emoji) => addReaction.mutate({ messageId: msgId, emoji })}
                  onRemoveReaction={(id) => removeReaction.mutate(id)}
                />
              </div>
            </div>
          </div>
        );
      })}
      <div ref={bottomRef} />

      {selectedUser && (
        <UserProfilePopup
          userEmail={selectedUser.email}
          userName={selectedUser.name}
          onlineUsers={onlineUsers}
          userBadges={badgeMap[selectedUser.email] || {}}
          onClose={() => setSelectedUser(null)}
          onOpenDM={onOpenDM}
        />
      )}
    </div>
  );
}