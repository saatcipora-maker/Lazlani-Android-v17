import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Upload, Loader2, Image, Smile, X } from "lucide-react";
import { Button } from "@/components/ui/button";



export default function AdminMediaUpload({ currentUser, type = "gif" }) {
  const [uploading, setUploading] = useState(false);
  const [count, setCount] = useState(0);
  const queryClient = useQueryClient();

  if (currentUser?.role !== "admin") return null;

  const entityName = type === "gif" ? "CustomGif" : "CustomEmoji";
  const queryKey = type === "gif" ? "custom-gifs" : "custom-emojis";

  const handleBulkUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploading(true);
    setCount(0);

    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const name = file.name.replace(/\.[^/.]+$/, "");
      await base44.entities[entityName].create({ name, image_url: file_url });
      setCount((c) => c + 1);
    }

    setUploading(false);
    queryClient.invalidateQueries({ queryKey: [queryKey] });
    e.target.value = "";
  };

  return (
    <label className="flex items-center gap-2 px-3 py-2 bg-muted rounded-lg cursor-pointer hover:bg-muted/80 transition-colors">
      {uploading ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin text-primary" />
          <span className="text-xs text-muted-foreground">{count} yüklendi...</span>
        </>
      ) : (
        <>
          <Upload className="w-4 h-4 text-primary" />
          <span className="text-xs font-medium text-foreground">
            {type === "gif" ? "GIF Toplu Yükle" : "Emoji Toplu Yükle"}
          </span>
        </>
      )}
      <input
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleBulkUpload}
        disabled={uploading}
      />
    </label>
  );
}