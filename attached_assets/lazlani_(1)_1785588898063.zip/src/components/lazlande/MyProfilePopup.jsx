import { useState } from "react";
import { X, Pencil, ShoppingBag, UserPlus, LogIn, LogOut, Activity } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";

const AVATAR_COLORS = [
  "#4CAF50", "#2196F3", "#FF9800", "#9C27B0", "#E91E63",
  "#00BCD4", "#FF5722", "#795548", "#607D8B", "#F44336",
];

function getAvatarColor(email) {
  if (!email) return "#FFD700";
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = email.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

export default function MyProfilePopup({ currentUser, onClose }) {
  const navigate = useNavigate();
  const displayName = currentUser?.full_name || currentUser?.email?.split("@")[0] || "Misafir";
  const username = currentUser?.email?.split("@")[0] || "guest";
  const initial = displayName[0]?.toUpperCase() || "?";
  const avatarColor = getAvatarColor(currentUser?.email);

  const MenuItem = ({ children, onClick, borderTop }) => (
    <button
      onClick={onClick}
      className={`w-full text-left px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors ${borderTop ? "border-t border-white/10" : ""}`}
    >
      {children}
    </button>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-12" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        className="relative bg-[#2a2a3e] rounded-2xl w-72 overflow-hidden shadow-2xl max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between px-4 pt-4">
          <div className="flex-1 min-w-0">
            <p className="text-white text-lg font-bold truncate">{displayName}</p>
            <p className="text-gray-400 text-xs">{username}</p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-white ml-2 flex-shrink-0 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Avatar */}
        <div className="flex flex-col items-center py-4">
          <div className="relative">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center text-white text-3xl font-bold"
              style={{ backgroundColor: avatarColor }}
            >
              {initial}
            </div>
            <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-green-500 border-[3px] border-[#2a2a3e]" />
          </div>
          <p className="text-green-400 text-sm mt-2">Aktif</p>
        </div>

        <div className="border-t border-white/10" />

        {/* Menu items */}
        <MenuItem onClick={() => { onClose(); navigate("/profile"); }}>
          Kullanıcı Adını Değiştir
        </MenuItem>
        <div className="border-t border-white/10" />

        <MenuItem>
          Durum Değiştir
        </MenuItem>
        <div className="border-t border-white/10" />

        <MenuItem onClick={() => { onClose(); navigate("/cart"); }}>
          Mağazayı Ziyaret Et
        </MenuItem>
        <div className="border-t border-white/10" />

        {!currentUser && (
          <>
            <MenuItem onClick={() => base44.auth.redirectToLogin()}>
              Kayıt Ol
            </MenuItem>
            <div className="border-t border-white/10" />

            <MenuItem onClick={() => base44.auth.redirectToLogin()}>
              Giriş Yap
            </MenuItem>
            <div className="border-t border-white/10" />
          </>
        )}

        {currentUser && (
          <>
            <MenuItem onClick={() => base44.auth.logout()}>
              Çıkış Yap
            </MenuItem>
          </>
        )}
      </div>
    </div>
  );
}