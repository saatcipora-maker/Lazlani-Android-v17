import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Send, Image as ImageIcon, X } from "lucide-react";
import { format } from "date-fns";

const AVATAR_COLORS = [
  "#4CAF50", "#2196F3", "#FF9800", "#9C27B0", "#E91E63",
  "#00BCD4", "#FF5722", "#795548", "#607D8B", "#F44336",
];

function getAvatarColor(email) {
  if (!email) return AVATAR_COLORS[0];
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = email.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function getConversationId(email1, email2) {
  return [email1, email2].sort().join("_");
}

export default function DMPanel({ currentUser, targetEmail, targetName, onClose }) {
  const [text, setText] = useState("");
  const bottomRef = useRef(null);
  const queryClient = useQueryClient();
  const conversationId = getConversationId(currentUser.email, targetEmail);

  const { data: messages = [] } = useQuery({
    queryKey: ["dm-messages", conversationId],
    queryFn: () => base44.entities.Message.filter({ conversation_id: conversationId }, "created_date", 100),
    refetchInterval: 3000,
  });

  // Subscribe to real-time
  useEffect(() => {
    const unsub = base44.entities.Message.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["dm-messages", conversationId] });
    });
    return unsub;
  }, [conversationId]);

  // Mark unread as read
  useEffect(() => {
    const markRead = async () => {
      const unread = messages.filter(
        (m) => m.receiver_email === currentUser.email && !m.is_read
      );
      for (const m of unread) {
        await base44.entities.Message.update(m.id, { is_read: true });
      }
    };
    if (messages.length > 0) markRead();
  }, [messages]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const sendMutation = useMutation({
    mutationFn: (content) =>
      base44.entities.Message.create({
        sender_email: currentUser.email,
        sender_name: currentUser.full_name,
        receiver_email: targetEmail,
        receiver_name: targetName,
        content,
        conversation_id: conversationId,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dm-messages", conversationId] });
      setText("");
    },
  });

  const handleSend = () => {
    if (!text.trim()) return;
    sendMutation.mutate(text.trim());
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await base44.entities.Message.create({
      sender_email: currentUser.email,
      sender_name: currentUser.full_name,
      receiver_email: targetEmail,
      receiver_name: targetName,
      content: "📷 Fotoğraf",
      image_url: file_url,
      conversation_id: conversationId,
    });
    queryClient.invalidateQueries({ queryKey: ["dm-messages", conversationId] });
    e.target.value = "";
  };

  const avatarColor = getAvatarColor(targetEmail);
  const initial = (targetName || targetEmail)?.[0]?.toUpperCase() || "?";

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-muted">
      {/* Header */}
      <div className="flex items-center gap-3 px-3 py-2.5 bg-card border-b border-border flex-shrink-0">
        <button
          onClick={onClose}
          className="w-9 h-9 flex items-center justify-center text-muted-foreground"
          style={{ minWidth: "36px" }}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: avatarColor }}
        >
          <span className="text-white text-sm font-bold">{initial}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-foreground truncate">{targetName || targetEmail?.split("@")[0]}</p>
          <p className="text-[10px] text-muted-foreground">Özel Mesaj</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 min-h-0 overflow-y-auto px-3 py-3 space-y-2">
        {messages.length === 0 && (
          <p className="text-center text-muted-foreground text-xs py-8">Henüz mesaj yok. İlk mesajı gönder!</p>
        )}
        {messages.map((msg) => {
          const isOwn = msg.sender_email === currentUser.email;
          return (
            <div key={msg.id} className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[75%] rounded-2xl px-3.5 py-2 shadow-sm ${
                  isOwn
                    ? "rounded-br-sm bg-primary"
                    : "rounded-bl-sm bg-card"
                }`}
              >
                {msg.image_url && (
                  <img src={msg.image_url} alt="" className="max-w-full max-h-48 rounded-lg mb-1" />
                )}
                <p className="text-[14px] leading-relaxed break-words text-foreground">
                  {msg.content}
                </p>
                <p className={`text-[10px] mt-0.5 ${isOwn ? "text-right text-primary-foreground/70" : "text-muted-foreground"}`}>
                  {msg.created_date ? format(new Date(msg.created_date), "HH:mm") : ""}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="flex items-center gap-1.5 px-2 py-2 bg-card border-t border-border flex-shrink-0" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <label className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 text-primary hover:bg-primary/10 cursor-pointer transition-colors">
          <ImageIcon className="w-5 h-5" />
          <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
        </label>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Mesaj yaz..."
          className="flex-1 h-10 rounded-full bg-background border border-border px-4 text-sm outline-none focus:border-primary transition-colors"
          style={{ fontSize: "16px" }}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
        />
        <button
          onClick={handleSend}
          disabled={!text.trim()}
          className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-primary text-primary-foreground shadow-sm disabled:opacity-40 active:scale-95 transition-transform"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}