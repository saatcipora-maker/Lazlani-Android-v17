import { X, Mail, EyeOff } from "lucide-react";
import { useNavigate } from "react-router-dom";



const AVATAR_COLORS = [
  "#4CAF50", "#2196F3", "#FF9800", "#9C27B0", "#E91E63",
  "#00BCD4", "#FF5722", "#795548", "#607D8B", "#F44336",
  "#8BC34A", "#3F51B5", "#FFEB3B", "#009688", "#673AB7",
];

function getAvatarColor(email) {
  if (!email) return AVATAR_COLORS[0];
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = email.charCodeAt(i) + ((hash << 5) - hash);
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

export default function UserProfilePopup({ userEmail, userName, onClose, onlineUsers = [], userBadges = {}, onOpenDM }) {
  const navigate = useNavigate();
  const displayName = userName || userEmail?.split("@")[0] || "?";
  const initial = displayName[0]?.toUpperCase() || "?";
  const avatarColor = getAvatarColor(userEmail);
  const isStaff = userBadges?.role === "admin";
  const isOnline = onlineUsers.some((u) => u.user_email === userEmail);

  // Role label and indicator color based on authority level
  let roleLabel = "Ziyaretçi";
  let indicatorColor = isOnline ? "bg-green-500" : "bg-gray-500";

  if (isStaff) {
    roleLabel = "👑 Yönetici";
    indicatorColor = isOnline ? "bg-blue-500" : "bg-blue-900";
  } else if (userBadges.has_vip) {
    roleLabel = "⭐ VIP Üye";
    indicatorColor = isOnline ? "bg-yellow-400" : "bg-yellow-900";
  } else if (userBadges.has_author_badge) {
    roleLabel = "✍️ Onaylı Yazar";
    indicatorColor = isOnline ? "bg-emerald-400" : "bg-emerald-900";
  } else if (userBadges.has_magazin_badge) {
    roleLabel = "🎭 Magazin";
    indicatorColor = isOnline ? "bg-rose-500" : "bg-rose-900";
  }

  const statusLabel = isOnline ? "Çevrimiçi" : "Çevrim Dışı";

  const handleDM = () => {
    onClose();
    if (onOpenDM) {
      onOpenDM(userEmail, displayName);
    } else {
      navigate(`/messages?to=${encodeURIComponent(userEmail)}&name=${encodeURIComponent(displayName)}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        className="relative bg-[#2a2a3e] rounded-2xl w-72 overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with close */}
        <div className="flex justify-end p-3 pb-0">
          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-white transition-colors rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User info */}
        <div className="flex flex-col items-center px-5 pb-4">
          <div className="relative mb-3">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center text-white text-2xl font-bold"
              style={{ backgroundColor: avatarColor }}
            >
              {initial}
            </div>
            <div
              className={`absolute bottom-0 right-0 w-5 h-5 rounded-full border-[3px] border-[#2a2a3e] ${indicatorColor}`}
            />
          </div>
          <p className="text-white text-lg font-bold">{displayName}</p>
          <p className="text-gray-400 text-xs mt-0.5">{userEmail?.split("@")[0]}</p>
          <p className="text-gray-300 text-sm mt-2">{roleLabel}</p>
          <p className={`text-sm ${isOnline ? "text-green-400" : "text-gray-500"}`}>{statusLabel}</p>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10" />

        {/* Actions */}
        <div>
          <button
            onClick={handleDM}
            className="w-full text-left px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors"
          >
            DM
          </button>
          <div className="border-t border-white/10" />
          <button
            className="w-full text-left px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors"
          >
            Kullanıcıyı Yoksay
          </button>
          <div className="border-t border-white/10" />
          <button
            onClick={onClose}
            className="w-full text-left px-5 py-4 text-gray-400 text-[15px] font-semibold hover:bg-white/5 transition-colors"
          >
            Menüyü Kapat
          </button>
        </div>
      </div>
    </div>
  );
}