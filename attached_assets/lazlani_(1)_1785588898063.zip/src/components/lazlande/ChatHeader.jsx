import { useState } from "react";
import { Menu, User, Settings, Music, MessageSquare, Users, Plus, Trash2, ChevronDown, UserPlus, LogIn, Search, ExternalLink, Wifi, Rocket, LogOut, Pencil, History, Building, EyeOff, Eraser, Wrench, Gamepad2, Trophy } from "lucide-react";
import { Link } from "react-router-dom";
import MyProfilePopup from "@/components/lazlande/MyProfilePopup";
import AdminUserActions from "@/components/lazlande/AdminUserActions";
import RoomAdminPanel from "@/components/lazlande/RoomAdminPanel";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger } from
"@/components/ui/dropdown-menu";



export default function ChatHeader({ currentUser, rooms, activeRoom, onRoomChange, onlineUsers, onSettingsToggle, showSettings, onShowUserList, onSearchUser, onOpenDMList, onClearMessages, onStartTournament }) {
  const [newRoomName, setNewRoomName] = useState("");
  const [menuTab, setMenuTab] = useState("menu"); // "menu" | "rooms"
  const [showMyProfile, setShowMyProfile] = useState(false);
  const [selectedUserForAdmin, setSelectedUserForAdmin] = useState(null);
  const [editingRoom, setEditingRoom] = useState(null);
  const queryClient = useQueryClient();
  const isAdmin = currentUser?.role === "admin";

  // Fetch all users to get chat_role info
  const { data: allUsers = [] } = useQuery({
    queryKey: ["all-users-roles"],
    queryFn: () => base44.entities.User.list("-created_date", 500),
    refetchInterval: 15000
  });
  const userRoleMap = {};
  allUsers.forEach((u) => {userRoleMap[u.email] = u.chat_role || "ziyaretci";});

  const ROLE_LABELS = {
    ziyaretci: "Ziyaretçi",
    kullanici: "Kullanıcı",
    gorevli: "Görevli",
    kurucu: "Kurucu",
    yonetici: "Yönetici"
  };
  const ROLE_COLORS = {
    ziyaretci: "#9ca3af",
    kullanici: "#3b82f6",
    gorevli: "#f97316",
    kurucu: "#a855f7",
    yonetici: "#eab308"
  };
  const ROLE_AVATAR_BG = {
    ziyaretci: "#6b7280",
    kullanici: "#2563eb",
    gorevli: "#ea580c",
    kurucu: "#9333ea",
    yonetici: "#ca8a04"
  };

  const createRoom = useMutation({
    mutationFn: (name) => base44.entities.ChatRoom.create({ name, created_by: currentUser.email }),
    onSuccess: () => {
      setNewRoomName("");
      queryClient.invalidateQueries({ queryKey: ["chat-rooms"] });
    }
  });

  const deleteRoom = useMutation({
    mutationFn: (id) => base44.entities.ChatRoom.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["chat-rooms"] })
  });

  const activeRoomName = rooms.find((r) => r.id === activeRoom)?.name || "Ana";

  return (
    <div className="bg-[#f0f0f5] px-3 py-1 flex items-center gap-0 border-b border-[#d0d0d8] flex-shrink-0">
      {/* Left icons */}
      {/* Hamburger - Room list */}
      <Sheet>
        <SheetTrigger asChild>
          <button className="w-10 h-10 flex items-center justify-center text-[#555]" style={{ minWidth: "40px" }} aria-label="Menü">
            <Menu className="w-5 h-5" />
          </button>
        </SheetTrigger>
        <SheetContent side="left" className="w-72 p-0 bg-[#1a1a2e] border-r-0">
          {/* Tab switcher */}
          <div className="flex border-b border-white/10">
            <button
              onClick={() => setMenuTab("menu")}
              className={`flex-1 py-3 text-sm font-semibold transition-colors ${menuTab === "menu" ? "text-white border-b-2 border-blue-500" : "text-gray-400"}`}>
              
              Menü
            </button>
            <button
              onClick={() => setMenuTab("rooms")}
              className={`flex-1 py-3 text-sm font-semibold transition-colors ${menuTab === "rooms" ? "text-white border-b-2 border-blue-500" : "text-gray-400"}`}>
              
              Odalar
            </button>
          </div>

          {menuTab === "menu" ?
          <div className="py-2 flex flex-col flex-1">
              {!currentUser &&
            <>
                  <button
                onClick={() => base44.auth.redirectToLogin()}
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                    <UserPlus className="w-5 h-5 text-gray-400" />
                    Kayıt Ol
                  </button>
                  <button
                onClick={() => base44.auth.redirectToLogin()}
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                    <LogIn className="w-5 h-5 text-gray-400" />
                    Giriş Yap
                  </button>
                </>
            }

              <button
              onClick={() => {onShowUserList?.();}}
              className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
              
                <Users className="w-5 h-5 text-gray-400" />
                Kullanıcı Listesi
              </button>

              <button
              onClick={() => {onSearchUser?.();}}
              className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
              
                <Search className="w-5 h-5 text-gray-400" />
                Kullanıcı Arama
              </button>

              <button
              className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
              
                <ExternalLink className="w-5 h-5 text-gray-400" />
                Popout
              </button>

              <button
              className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
              
                <Wifi className="w-5 h-5 text-gray-400" />
                Kararlı Bağlantı
              </button>

              <button
              className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
              
                <Rocket className="w-5 h-5 text-gray-400" />
                Sohbeti Güçlendir 🚀
              </button>

              <Link
                to="/bird-match"
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                <Gamepad2 className="w-5 h-5 text-green-400" />
                🐦 Bird Match Oyunu
              </Link>

              {currentUser && (
                <button
                  onClick={() => onStartTournament?.()}
                  className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                  
                  <Trophy className="w-5 h-5 text-amber-400" />
                  🏆 Turnuva Başlat
                </button>
              )}

              {currentUser &&
            <button
              onClick={() => base44.auth.logout()}
              className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left border-t border-white/10">
              
                  <LogOut className="w-5 h-5 text-red-400" />
                  Çıkış Yap
                </button>
            }

              {/* Admin-only: DENETLEME section */}
              {isAdmin &&
            <>
                  <div className="px-5 pt-4 pb-1 border-t border-white/10">
                    <p className="text-[11px] font-bold text-gray-500 tracking-widest uppercase">Denetleme</p>
                  </div>
                  <button
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                    <History className="w-5 h-5 text-gray-400" />
                    Aksiyon Geçmişi
                  </button>
                  <button
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                    <Building className="w-5 h-5 text-gray-400" />
                    Upgrade Organization
                  </button>
                  <button
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                    <EyeOff className="w-5 h-5 text-gray-400" />
                    Göm
                  </button>
                  <button
                onClick={() => {
                  if (window.confirm(`"${rooms.find((r) => r.id === activeRoom)?.name || "Bu oda"}" odasındaki TÜM mesajlar silinecek. Emin misiniz?`)) {
                    onClearMessages?.();
                  }
                }}
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                    <Eraser className="w-5 h-5 text-red-400" />
                    Mesajları Temizle
                  </button>
                  <button
                onClick={() => {
                  const room = rooms.find((r) => r.id === activeRoom);
                  if (room) setEditingRoom(room);
                }}
                className="flex items-center gap-3 px-5 py-4 text-white text-[15px] font-semibold hover:bg-white/5 transition-colors text-left">
                
                    <Wrench className="w-5 h-5 text-gray-400" />
                    Chati Düzenle
                  </button>
                </>
            }
            </div> :

          <div className="flex flex-col flex-1">
              <div className="py-2 space-y-1 flex-1 overflow-y-auto px-2">
                {rooms.map((room) =>
              <div key={room.id} className="flex items-center gap-2">
                    <button
                  onClick={() => onRoomChange(room.id)}
                  className={`flex-1 text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  activeRoom === room.id ? "bg-blue-500/20 text-blue-400" : "text-gray-300 hover:bg-white/5"}`
                  }>
                  
                      # {room.name}
                    </button>
                    {isAdmin &&
                <button
                  onClick={() => setEditingRoom(room)}
                  className="px-3 py-2 text-blue-400 hover:bg-blue-500/10 rounded">
                  
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                }
                    {isAdmin && room.name !== "Genel" &&
                <button
                  onClick={() => deleteRoom.mutate(room.id)}
                  className="px-3 py-2 text-red-400 hover:bg-red-500/10 rounded">
                  
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                }
                  </div>
              )}
              </div>
              {isAdmin &&
            <div className="p-3 border-t border-white/10 flex gap-2">
                  <Input
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                placeholder="Yeni oda adı..."
                className="h-8 text-sm bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                onKeyDown={(e) => e.key === "Enter" && newRoomName.trim() && createRoom.mutate(newRoomName.trim())} />
              
                  <Button
                size="icon"
                className="h-8 w-8 flex-shrink-0"
                disabled={!newRoomName.trim()}
                onClick={() => createRoom.mutate(newRoomName.trim())}>
                
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
            }
            </div>
          }
        </SheetContent>
      </Sheet>

      {/* User icon */}
      <button
        className="w-10 h-10 flex items-center justify-center text-[#555]"
        style={{ minWidth: "40px" }}
        onClick={() => setShowMyProfile(true)}
        aria-label="Profil">
        
        <User className="w-5 h-5" />
      </button>

      {showMyProfile &&
      <MyProfilePopup
        currentUser={currentUser}
        onClose={() => setShowMyProfile(false)} />

      }

      {/* Settings icon */}
      {isAdmin &&
      <button
        onClick={onSettingsToggle}
        className={`w-10 h-10 flex items-center justify-center ${showSettings ? "text-primary" : "text-[#555]"}`}
        style={{ minWidth: "40px" }}
        aria-label="Ayarlar">
        
          <Settings className="w-5 h-5" />
        </button>
      }

      {/* Music icon */}
      <button className="w-10 h-10 flex items-center justify-center text-[#555]" style={{ minWidth: "40px" }} aria-label="Müzik">
        <Music className="w-5 h-5" />
      </button>

      {/* Room selector dropdown - center */}
      <div className="flex-1 flex justify-center">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-1 px-3 py-1.5 bg-white border border-[#ccc] rounded-full text-sm font-semibold text-[#333] hover:bg-gray-50 transition-colors">
              {activeRoomName}
              <ChevronDown className="w-3.5 h-3.5 text-[#888]" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="center" className="min-w-[140px]">
            {rooms.map((room) =>
            <DropdownMenuItem
              key={room.id}
              onClick={() => onRoomChange(room.id)}
              className={activeRoom === room.id ? "bg-primary/10 text-primary font-semibold" : ""}>
              
                {room.name}
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Chat icon - DM list */}
      <button
        onClick={() => onOpenDMList?.()}
        className="w-10 h-10 flex items-center justify-center text-[#555] relative"
        style={{ minWidth: "40px" }}
        aria-label="Özel mesajlar">
        
        <MessageSquare className="w-5 h-5" />
      </button>

      {/* Online users */}
      <Sheet>
        <SheetTrigger asChild>
          <button className="w-10 h-10 flex items-center justify-center text-[#555] relative" style={{ minWidth: "40px" }} aria-label="Çevrimiçi kullanıcılar">
            <Users className="w-5 h-5" />
            {onlineUsers.length > 0 &&
            <span className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">
                {onlineUsers.length}
              </span>
            }
          </button>
        </SheetTrigger>
        <SheetContent side="right" className="w-72 p-0 bg-[#1a1a2e] border-l-0">
          <div className="px-4 pt-5 pb-3">
            <h3 className="text-white font-semibold text-base">
              Kullanıcılar — {onlineUsers.length} <ChevronDown className="w-3.5 h-3.5 inline text-gray-400" />
            </h3>
          </div>
          <div className="px-3 space-y-1 overflow-y-auto flex-1">
            {onlineUsers.map((u) => {
              const chatRole = userRoleMap[u.user_email] || "ziyaretci";
              const initial = (u.user_name || u.user_email)?.[0]?.toUpperCase() || "?";
              const avatarBg = ROLE_AVATAR_BG[chatRole] || "#FFD700";
              const badgeColor = ROLE_COLORS[chatRole] || "#9ca3af";
              const roleLabel = ROLE_LABELS[chatRole] || "Ziyaretçi";

              return (
                <button
                  key={u.user_email}
                  className="w-full flex items-center gap-3 px-2 py-2.5 rounded-xl hover:bg-white/5 transition-colors text-left"
                  onClick={() => isAdmin && u.user_email !== currentUser?.email && setSelectedUserForAdmin({ email: u.user_email, name: u.user_name })}
                  >
                  
                  {/* Avatar */}
                  <div className="relative flex-shrink-0">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ backgroundColor: avatarBg }}>
                      
                      {initial}
                    </div>
                    <div
                      className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#1a1a2e]"
                      style={{ backgroundColor: badgeColor }} />
                    
                  </div>
                  {/* Name + role */}
                  <div className="min-w-0 flex-1">
                    <p className="text-white text-sm font-bold truncate leading-tight">
                      {u.user_name || u.user_email?.split("@")[0]}
                    </p>
                    <p className="text-xs truncate leading-tight mt-0.5" style={{ color: badgeColor }}>
                      {roleLabel}
                    </p>
                  </div>
                </button>);

            })}
            {onlineUsers.length === 0 &&
            <p className="text-gray-500 text-xs text-center py-8">Kimse çevrimiçi değil</p>
            }
          </div>
        </SheetContent>
      </Sheet>

      {/* Admin user actions popup */}
      {selectedUserForAdmin && isAdmin &&
      <AdminUserActions
        userEmail={selectedUserForAdmin.email}
        userName={selectedUserForAdmin.name}
        onClose={() => setSelectedUserForAdmin(null)} />

      }

      {/* Room admin panel popup */}
      {editingRoom && isAdmin &&
      <RoomAdminPanel
        room={editingRoom}
        onClose={() => setEditingRoom(null)} />

      }
    </div>);

}