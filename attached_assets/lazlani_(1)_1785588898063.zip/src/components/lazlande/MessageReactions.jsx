import { useState } from "react";
import { SmilePlus } from "lucide-react";

const REACTION_EMOJIS = ["❤️", "😂", "👍", "😮", "😢", "🔥", "👎", "💯"];

export default function MessageReactions({ messageId, reactions = [], currentUser, onAddReaction, onRemoveReaction }) {
  const [showPicker, setShowPicker] = useState(false);

  const grouped = {};
  reactions.forEach((r) => {
    if (!grouped[r.emoji]) grouped[r.emoji] = { count: 0, users: [], ids: [] };
    grouped[r.emoji].count++;
    grouped[r.emoji].users.push(r.user_email);
    grouped[r.emoji].ids.push(r.id);
  });

  const handleToggle = (emoji) => {
    const group = grouped[emoji];
    if (group && group.users.includes(currentUser?.email)) {
      const idx = group.users.indexOf(currentUser.email);
      onRemoveReaction(group.ids[idx]);
    } else {
      onAddReaction(messageId, emoji);
    }
    setShowPicker(false);
  };

  const handlePickerSelect = (emoji) => {
    if (!currentUser) return;
    const group = grouped[emoji];
    if (group && group.users.includes(currentUser.email)) {
      const idx = group.users.indexOf(currentUser.email);
      onRemoveReaction(group.ids[idx]);
    } else {
      onAddReaction(messageId, emoji);
    }
    setShowPicker(false);
  };

  return (
    <div className="flex items-center gap-1 flex-wrap mt-1 relative">
      {Object.entries(grouped).map(([emoji, data]) => {
        const isMine = data.users.includes(currentUser?.email);
        return (
          <button
            key={emoji}
            onClick={() => handleToggle(emoji)}
            className={`inline-flex items-center gap-0.5 px-2 py-1 rounded-full text-xs transition-colors ${
              isMine
                ? "bg-blue-500/20 border border-blue-400/40"
                : "bg-black/10 border border-transparent hover:bg-black/15"
            }`}
          >
            <span className="text-sm">{emoji}</span>
            <span className={`text-[10px] font-semibold ${isMine ? "text-blue-600" : "text-gray-600"}`}>
              {data.count}
            </span>
          </button>
        );
      })}

      {currentUser && (
        <div className="relative">
          <button
            onClick={() => setShowPicker(!showPicker)}
            className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-black/5 hover:bg-black/10 transition-colors"
          >
            <SmilePlus className="w-4 h-4 text-gray-500" />
          </button>

          {showPicker && (
            <div className="absolute bottom-10 left-0 z-50 bg-[#2a2a3e] rounded-xl shadow-xl p-2 flex gap-1 flex-wrap w-48">
              {REACTION_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => handlePickerSelect(emoji)}
                  className="text-xl hover:scale-125 transition-transform p-1.5 rounded-lg"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}