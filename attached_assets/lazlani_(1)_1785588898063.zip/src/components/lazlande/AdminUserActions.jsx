import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { X, Ban, Shield, ShieldCheck, Crown, UserX, UserCheck } from "lucide-react";



const CHAT_ROLES = [
  { value: "ziyaretci", label: "Ziyaretçi", icon: UserX, color: "text-gray-400" },
  { value: "kullanici", label: "Kullanıcı", icon: UserCheck, color: "text-blue-400" },
  { value: "gorevli", label: "Görevli", icon: Shield, color: "text-green-400" },
  { value: "kurucu", label: "Kurucu", icon: ShieldCheck, color: "text-purple-400" },
  { value: "yonetici", label: "Yönetici", icon: Crown, color: "text-yellow-400" },
];

export default function AdminUserActions({ userEmail, userName, onClose }) {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);

  // Fetch the target user's data
  const { data: users = [] } = useQuery({
    queryKey: ["admin-user-lookup", userEmail],
    queryFn: () => base44.entities.User.filter({ email: userEmail }, "-created_date", 1),
    enabled: !!userEmail,
  });

  const targetUser = users[0];
  const currentChatRole = targetUser?.chat_role || "ziyaretci";
  const isBanned = targetUser?.is_banned;
  const isTargetAdmin = targetUser?.role === "admin";

  const handleBan = async () => {
    if (!targetUser || isTargetAdmin) return;
    setLoading(true);
    await base44.entities.User.update(targetUser.id, {
      is_banned: true,
      ban_until: "permanent",
    });
    queryClient.invalidateQueries({ queryKey: ["admin-user-lookup"] });
    queryClient.invalidateQueries({ queryKey: ["online-users"] });
    setLoading(false);
  };

  const handleUnban = async () => {
    if (!targetUser) return;
    setLoading(true);
    await base44.entities.User.update(targetUser.id, {
      is_banned: false,
      ban_until: "",
    });
    queryClient.invalidateQueries({ queryKey: ["admin-user-lookup"] });
    setLoading(false);
  };

  const handleRoleChange = async (newRole) => {
    if (!targetUser || isTargetAdmin) return;
    setLoading(true);
    await base44.entities.User.update(targetUser.id, {
      chat_role: newRole,
    });
    queryClient.invalidateQueries({ queryKey: ["admin-user-lookup"] });
    queryClient.invalidateQueries({ queryKey: ["online-users"] });
    setLoading(false);
  };

  const displayName = userName || userEmail?.split("@")[0] || "?";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        className="relative bg-[#1e1e30] rounded-2xl w-72 overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 pt-4 pb-2">
          <h3 className="text-white font-bold text-sm">Yönetim — {displayName}</h3>
          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-white rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current status */}
        <div className="px-4 pb-3">
          <p className="text-gray-400 text-xs">
            Mevcut Rol: <span className="text-white font-semibold">{CHAT_ROLES.find(r => r.value === currentChatRole)?.label || "Ziyaretçi"}</span>
          </p>
          {isBanned && (
            <p className="text-red-400 text-xs font-semibold mt-1">⛔ Süresiz Yasaklı</p>
          )}
        </div>

        <div className="border-t border-white/10" />

        {/* Role buttons */}
        <div className="py-2">
          <p className="px-4 py-1 text-[10px] text-gray-500 uppercase font-bold tracking-wider">Rol Değiştir</p>
          {CHAT_ROLES.map((role) => {
            const Icon = role.icon;
            const isActive = currentChatRole === role.value;
            return (
              <button
                key={role.value}
                onClick={() => handleRoleChange(role.value)}
                disabled={loading || isTargetAdmin}
                className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors ${
                  isActive ? "bg-white/10 text-white" : "text-gray-300 hover:bg-white/5"
                } disabled:opacity-40`}
              >
                <Icon className={`w-4 h-4 ${role.color}`} />
                <span className="text-sm font-medium">{role.label}</span>
                {isActive && <span className="ml-auto text-[10px] text-green-400 font-bold">AKTİF</span>}
              </button>
            );
          })}
        </div>

        <div className="border-t border-white/10" />

        {/* Ban/Unban */}
        <div className="py-2">
          {isBanned ? (
            <button
              onClick={handleUnban}
              disabled={loading}
              className="w-full flex items-center gap-3 px-4 py-3 text-green-400 hover:bg-green-500/10 transition-colors text-left disabled:opacity-40"
            >
              <UserCheck className="w-4 h-4" />
              <span className="text-sm font-semibold">Yasağı Kaldır</span>
            </button>
          ) : (
            <button
              onClick={handleBan}
              disabled={loading || isTargetAdmin}
              className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 transition-colors text-left disabled:opacity-40"
            >
              <Ban className="w-4 h-4" />
              <span className="text-sm font-semibold">Süresiz Yasakla</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}