import { useState, useRef } from "react";
import { Send, Smile, Plus, Mic, MicOff, BookOpen, Palette, X, Clock } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

const NAME_COLORS = [
  "#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4",
  "#3b82f6", "#8b5cf6", "#ec4899", "#f43f5e", "#14b8a6",
  "#a855f7", "#6366f1",
];

const DEFAULT_EMOJIS = ["😀","😂","🥰","😎","🤔","😢","😡","👍","👎","❤️","🔥","⭐","🎉","💯","🙏","✨","💪","🤝","📚","✍️","🎭","🌟","💡","🎵","🤣","😍","🥺","😤","🙌","👀"];

export default function ChatInput({ currentUser, activeRoom, activeRoomData, textColor, onColorChange, nameColor, onNameColorChange, replyTo, onClearReply }) {
  const [text, setText] = useState("");
  const [showPanel, setShowPanel] = useState(null); // "emoji" | "gif" | "books" | "color" | null
  const [isRecording, setIsRecording] = useState(false);
  const [lastSentTime, setLastSentTime] = useState(0);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const queryClient = useQueryClient();
  const slowMode = activeRoomData?.slow_mode_seconds || 0;
  const voiceEnabled = activeRoomData?.voice_enabled !== false;
  const gifEnabled = activeRoomData?.gif_enabled !== false;

  const { data: customEmojis = [] } = useQuery({
    queryKey: ["custom-emojis"],
    queryFn: () => base44.entities.CustomEmoji.list("-created_date", 100),
  });

  const { data: customGifs = [] } = useQuery({
    queryKey: ["custom-gifs"],
    queryFn: () => base44.entities.CustomGif.list("-created_date", 100),
  });

  const { data: myBooks = [] } = useQuery({
    queryKey: ["my-books-lazlande", currentUser?.email],
    queryFn: () => base44.entities.Book.filter({ author_email: currentUser.email, status: "yayinda" }, "-created_date", 50),
    enabled: !!currentUser?.email,
  });

  const sendMessage = useMutation({
    mutationFn: (data) => base44.entities.LazlanMessage.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["lazlan-messages", activeRoom] }),
  });

  const togglePanel = (name) => setShowPanel((p) => (p === name ? null : name));

  const canSend = () => {
    if (!slowMode) return true;
    return Date.now() - lastSentTime >= slowMode * 1000;
  };

  const slowModeRemaining = () => {
    if (!slowMode) return 0;
    const remaining = Math.ceil((slowMode * 1000 - (Date.now() - lastSentTime)) / 1000);
    return remaining > 0 ? remaining : 0;
  };

  const handleSend = () => {
    if (!text.trim() || !currentUser) return;
    if (!canSend()) return;
    const msgData = {
      room_id: activeRoom,
      user_email: currentUser.email,
      user_name: currentUser.full_name,
      content: text.trim(),
      type: "text",
      text_color: textColor || "",
    };
    if (replyTo) {
      msgData.reply_to_id = replyTo.id;
      msgData.reply_to_name = replyTo.name;
      msgData.reply_to_content = replyTo.content;
    }
    sendMessage.mutate(msgData);
    setText("");
    setLastSentTime(Date.now());
    onClearReply?.();
  };

  const handleGifSend = (gif) => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    sendMessage.mutate({
      room_id: activeRoom,
      user_email: currentUser.email,
      user_name: currentUser.full_name,
      content: "GIF",
      type: "gif",
      media_url: gif.image_url,
      expires_at: tomorrow.toISOString(),
    });
    setShowPanel(null);
  };

  const handleBookShare = (book) => {
    sendMessage.mutate({
      room_id: activeRoom,
      user_email: currentUser.email,
      user_name: currentUser.full_name,
      content: book.title,
      type: "book",
      book_id: book.id,
      book_title: book.title,
      media_url: book.cover_image || "",
    });
    setShowPanel(null);
  };

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    chunksRef.current = [];
    recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
    recorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      const file = new File([blob], "voice.webm", { type: "audio/webm" });
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      sendMessage.mutate({
        room_id: activeRoom,
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        content: "Ses kaydı",
        type: "voice",
        media_url: file_url,
        expires_at: tomorrow.toISOString(),
      });
    };
    mediaRecorderRef.current = recorder;
    recorder.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <div className="bg-card border-t border-border flex-shrink-0" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      {/* Popup panels */}
      {showPanel === "emoji" && (
        <div className="bg-card border-t border-border p-3 max-h-48 overflow-y-auto">
          <div className="flex flex-wrap gap-2">
            {DEFAULT_EMOJIS.map((e) => (
              <button
                key={e}
                onClick={() => setText((t) => t + e)}
                className="text-xl hover:scale-125 transition-transform p-1"
              >
                {e}
              </button>
            ))}
            {customEmojis.map((e) => (
              <button
                key={e.id}
                onClick={() => setText((t) => t + ` :${e.name}: `)}
                className="hover:scale-125 transition-transform p-1"
              >
                <img src={e.image_url} alt={e.name} className="w-7 h-7 object-contain" />
              </button>
            ))}
          </div>
        </div>
      )}

      {showPanel === "gif" && (
        <div className="bg-card border-t border-border p-3 max-h-48 overflow-y-auto">
          {customGifs.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-4">Henüz GIF eklenmemiş</p>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {customGifs.map((g) => (
                <button
                  key={g.id}
                  onClick={() => handleGifSend(g)}
                  className="rounded-lg overflow-hidden hover:ring-2 hover:ring-blue-400 transition-all"
                >
                  <img src={g.image_url} alt={g.name} className="w-full h-20 object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {showPanel === "books" && (
        <div className="bg-card border-t border-border p-3 max-h-48 overflow-y-auto space-y-1">
          {myBooks.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-4">Yayında kitabınız yok</p>
          ) : (
            myBooks.map((book) => (
              <button
                key={book.id}
                onClick={() => handleBookShare(book)}
                className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-gray-100 transition-colors text-left"
              >
                {book.cover_image ? (
                  <img src={book.cover_image} alt={book.title} className="w-8 h-11 object-cover rounded flex-shrink-0" />
                ) : (
                  <div className="w-8 h-11 bg-blue-100 rounded flex items-center justify-center flex-shrink-0">
                    <BookOpen className="w-3 h-3 text-blue-500" />
                  </div>
                )}
                <span className="text-xs font-medium text-foreground truncate">{book.title}</span>
              </button>
            ))
          )}
        </div>
      )}

      {showPanel === "color" && (
        <div className="bg-card border-t border-border p-3">
          <p className="text-xs font-medium text-muted-foreground mb-2">Yazı & İsim Rengi</p>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => { onColorChange(""); onNameColorChange(""); }}
              className="w-8 h-8 rounded-full bg-gray-200 border-2 border-gray-300 flex items-center justify-center"
            >
              <X className="w-3 h-3 text-gray-500" />
            </button>
            {NAME_COLORS.map((c) => (
              <button
                key={c}
                onClick={() => { onColorChange(c); onNameColorChange(c); }}
                className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${
                  nameColor === c ? "ring-2 ring-offset-2 ring-blue-500" : "border-transparent"
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Slow mode warning */}
      {slowMode > 0 && slowModeRemaining() > 0 && (
        <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 border-t border-amber-200">
          <Clock className="w-3.5 h-3.5 text-amber-500" />
          <p className="text-[11px] text-amber-600 font-medium">Yavaş mod: {slowModeRemaining()} saniye bekle</p>
        </div>
      )}

      {/* Reply preview */}
      {replyTo && (
        <div className="flex items-center gap-2 px-3 py-2 bg-card border-t border-border">
          <div className="flex-1 min-w-0 border-l-2 border-primary pl-2">
            <p className="text-[11px] font-semibold text-primary">{replyTo.name}</p>
            <p className="text-[11px] text-muted-foreground truncate">{replyTo.content}</p>
          </div>
          <button
            onClick={onClearReply}
            className="flex-shrink-0 w-9 h-9 flex items-center justify-center rounded-full hover:bg-muted"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      )}

      {/* Input bar */}
      <div className="flex items-center gap-1 px-2 py-2">
        {/* Plus button - opens sub menu */}
        <Popover>
          <PopoverTrigger asChild>
            <button
              className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-primary text-primary-foreground shadow-sm active:scale-95 transition-transform"
            >
              <Plus className="w-5 h-5" />
            </button>
          </PopoverTrigger>
          <PopoverContent side="top" align="start" className="w-48 p-2">
            <button
              onClick={() => { togglePanel("books"); }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 text-sm text-left"
            >
              <BookOpen className="w-4 h-4 text-blue-500" />
              Kitap Paylaş
            </button>
            <button
              onClick={() => { togglePanel("color"); }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 text-sm text-left"
            >
              <Palette className="w-4 h-4 text-purple-500" />
              Renk Seç
            </button>
            {voiceEnabled && (
              <button
                onClick={isRecording ? stopRecording : startRecording}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 text-sm text-left"
              >
                {isRecording ? (
                  <><MicOff className="w-4 h-4 text-red-500" />Kaydı Durdur</>
                ) : (
                  <><Mic className="w-4 h-4 text-green-500" />Ses Kaydet</>
                )}
              </button>
            )}
          </PopoverContent>
        </Popover>

        {/* Text input */}
        <div className="flex-1 min-w-0">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Mesaj Gir"
            className="w-full h-10 rounded-full bg-background border border-border px-4 text-sm outline-none focus:border-primary transition-colors"
            style={{ fontSize: "16px", color: textColor || undefined }}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
          />
        </div>

        {/* Send button */}
        <button
          onClick={handleSend}
          disabled={!text.trim() || !canSend()}
          className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-primary text-primary-foreground shadow-sm disabled:opacity-40 active:scale-95 transition-transform"
          title={slowModeRemaining() > 0 ? `Yavaş mod: ${slowModeRemaining()} sn bekle` : ""}
        >
          <Send className="w-4 h-4" />
        </button>

        {/* GIF button */}
        {gifEnabled && (
          <button
            onClick={() => togglePanel("gif")}
            className={`px-3 h-10 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-sm transition-colors ${
              showPanel === "gif" ? "bg-primary text-primary-foreground" : "text-primary hover:bg-primary/10"
            }`}
            
          >
            GIF
          </button>
        )}

        {/* Emoji button */}
        <button
          onClick={() => togglePanel("emoji")}
          className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
            showPanel === "emoji" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
          }`}
        >
          <Smile className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}