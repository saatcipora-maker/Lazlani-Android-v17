import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Crown, Sparkles, Check, Loader2, Clock } from "lucide-react";
import { toast } from "sonner";

export default function PremiumCard({ currentUser }) {
  const queryClient = useQueryClient();
  const [applying, setApplying] = useState(false);

  const { data: membership } = useQuery({
    queryKey: ["premium-membership", currentUser?.email],
    queryFn: async () => {
      const results = await base44.entities.PremiumMembership.filter(
        { user_email: currentUser.email },
        "-created_date",
        1
      );
      return results[0] || null;
    },
    enabled: !!currentUser?.email,
    staleTime: 60000,
  });

  const { data: settings = [] } = useQuery({
    queryKey: ["premium-settings"],
    queryFn: () => base44.entities.AppSettings.list("-created_date", 50),
    staleTime: 5 * 60 * 1000,
  });

  const getSetting = (key, fallback) => settings.find(s => s.key === key)?.value || fallback;
  const premiumPrice = getSetting("premium_price", "0");
  const premiumName = getSetting("premium_name", "Premium");
  const premiumFeatures = getSetting("premium_features", "Özel profil rozeti,Premium etiketi,Öne çıkan içerik,Yüksek paylaşım limiti,Reklamsız kullanım,Premium topluluk erişimi");

  const features = premiumFeatures.split(",").map(f => f.trim()).filter(Boolean);

  const handleApply = async () => {
    if (applying) return;
    setApplying(true);
    try {
      await base44.entities.PremiumMembership.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        status: "pending",
        plan_name: premiumName,
        price: Number(premiumPrice) || 0,
        features: premiumFeatures,
      });
      queryClient.invalidateQueries({ queryKey: ["premium-membership"] });
      toast.success("Premium başvurunuz alındı!");
    } catch (err) {
      toast.error("Başvuru gönderilemedi");
    } finally {
      setApplying(false);
    }
  };

  const isPending = membership?.status === "pending";
  const isActive = membership?.status === "active";
  const isRejected = membership?.status === "rejected";

  return (
    <div className="mx-4 mb-4 rounded-2xl overflow-hidden" style={{
      background: "linear-gradient(135deg, rgba(50,20,72,0.8), rgba(40,16,30,0.6))",
      border: "1px solid rgba(180,100,240,0.15)",
      boxShadow: "0 8px 32px rgba(130,60,210,0.12), 0 0 0 0.5px rgba(180,100,240,0.05)"
    }}>
      {/* Header */}
      <div className="px-5 pt-5 pb-3 flex items-center gap-3">
        <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{
          background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))",
          boxShadow: "0 4px 16px rgba(130,60,210,0.3)"
        }}>
          <Crown className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="font-heading text-lg font-bold text-foreground">{premiumName}</h3>
          {Number(premiumPrice) > 0 && (
            <p className="text-xs text-muted-foreground">₺{premiumPrice}/ay</p>
          )}
        </div>
        {isActive && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: "rgba(34,197,94,0.15)", border: "1px solid rgba(34,197,94,0.2)" }}>
            <Check className="w-3.5 h-3.5 text-green-400" />
            <span className="text-[11px] font-semibold text-green-400">Aktif</span>
          </div>
        )}
      </div>

      {/* Features */}
      <div className="px-5 pb-4 space-y-2">
        {features.map((feature, i) => (
          <div key={i} className="flex items-center gap-2.5">
            <Sparkles className="w-3.5 h-3.5 text-primary/60 flex-shrink-0" />
            <span className="text-xs text-foreground/70">{feature}</span>
          </div>
        ))}
      </div>

      {/* Action */}
      <div className="px-5 pb-5">
        {isActive ? (
          <div className="text-center py-2 rounded-xl text-xs font-medium text-green-400" style={{ background: "rgba(34,197,94,0.08)" }}>
            Premium üyeliğiniz aktif ✨
          </div>
        ) : isPending ? (
          <div className="flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-medium text-yellow-400" style={{ background: "rgba(234,179,8,0.08)", border: "1px solid rgba(234,179,8,0.15)" }}>
            <Clock className="w-3.5 h-3.5" />
            Başvurunuz inceleniyor...
          </div>
        ) : isRejected ? (
          <div className="space-y-2">
            <div className="text-center py-2 rounded-xl text-xs text-red-400" style={{ background: "rgba(239,68,68,0.08)" }}>
              Başvurunuz reddedildi{membership?.admin_note ? `: ${membership.admin_note}` : ""}
            </div>
            <button
              onClick={handleApply}
              disabled={applying}
              className="w-full py-3 rounded-xl text-sm font-semibold text-white active:scale-[0.98] transition-transform"
              style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))", boxShadow: "0 4px 16px rgba(130,60,210,0.3)" }}
            >
              {applying ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Tekrar Başvur"}
            </button>
          </div>
        ) : (
          <button
            onClick={handleApply}
            disabled={applying}
            className="w-full py-3 rounded-xl text-sm font-semibold text-white active:scale-[0.98] transition-transform"
            style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))", boxShadow: "0 4px 16px rgba(130,60,210,0.3)" }}
          >
            {applying ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Premium Başvurusu Yap"}
          </button>
        )}
      </div>
    </div>
  );
}