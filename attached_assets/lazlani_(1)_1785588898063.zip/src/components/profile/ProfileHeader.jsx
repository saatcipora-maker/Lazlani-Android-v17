import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Camera, Loader2, Pencil, Award, BookOpen, Users, Heart, Crown, MessageCircle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import UserBadges from "@/components/badges/UserBadges";
import { useBadgeContext } from "@/lib/BadgeContext";
import { useAuth } from "@/lib/AuthContext";
import ProfileEditPopup from "./ProfileEditPopup";
import { useQuery } from "@tanstack/react-query";

export default function ProfileHeader({ currentUser, followers, following, onFollowersClick, onFollowingClick, onBadgesClick, myBooks, premiumStatus }) {
  const { autoBadgeMap } = useBadgeContext();
  const autoBadges = autoBadgeMap[currentUser?.email] || { is_author: false, is_active_reader: false };
  const { updateUser } = useAuth();
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [showEditPopup, setShowEditPopup] = useState(false);

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingAvatar(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await updateUser({ avatar_url: file_url });
    setUploadingAvatar(false);
    toast.success("Profil fotoğrafı güncellendi!");
  };

  const handleCoverUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingCover(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await updateUser({ cover_url: file_url });
    setUploadingCover(false);
    toast.success("Kapak fotoğrafı güncellendi!");
  };

  const displayName = currentUser?.display_name || currentUser?.full_name || "Kullanıcı";
  const opCount = myBooks?.length || 0;
  const isPremium = premiumStatus === "active";

  return (
    <>
      {/* Cover Photo */}
      <div className="relative h-56 overflow-hidden">
        {currentUser?.cover_url ? (
          <img src={currentUser.cover_url} alt="kapak" className="w-full h-full object-cover" />
        ) : (
          <div className="absolute inset-0" style={{
            background: "linear-gradient(160deg, hsl(270,45%,20%) 0%, hsl(280,35%,15%) 30%, hsl(300,25%,12%) 60%, hsl(24,50%,18%) 100%)"
          }} />
        )}
        {/* Overlay gradient */}
        <div className="absolute inset-0" style={{
          background: "linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.1) 40%, hsl(274,30%,6%) 95%)"
        }} />

        {/* Cover actions */}
        <div className="absolute top-3 right-3 flex gap-2 safe-top">
          <button
            onClick={() => setShowEditPopup(true)}
            className="rounded-full p-2.5 active:scale-90 transition-transform"
            style={{ background: "rgba(0,0,0,0.35)", backdropFilter: "blur(12px)" }}
            aria-label="Profili düzenle"
          >
            <Pencil className="w-4 h-4 text-white" />
          </button>
          <label className="rounded-full p-2.5 cursor-pointer active:scale-90 transition-transform" style={{ background: "rgba(0,0,0,0.35)", backdropFilter: "blur(12px)" }}>
            {uploadingCover ? <Loader2 className="w-4 h-4 text-white animate-spin" /> : <Camera className="w-4 h-4 text-white" />}
            <input type="file" accept="image/*" className="hidden" onChange={handleCoverUpload} />
          </label>
        </div>

        {/* Premium badge on cover */}
        {isPremium && (
          <div className="absolute top-3 left-3 safe-top flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{
            background: "linear-gradient(135deg, rgba(130,60,210,0.6), rgba(240,140,60,0.4))",
            backdropFilter: "blur(12px)",
            border: "1px solid rgba(255,255,255,0.15)"
          }}>
            <Crown className="w-3.5 h-3.5 text-white" />
            <span className="text-[10px] font-bold text-white tracking-wide">PREMIUM</span>
          </div>
        )}
      </div>

      {/* Avatar + Info */}
      <div className="px-5 -mt-16 pb-5">
        {/* Avatar row */}
        <div className="flex items-end justify-between mb-4">
          <div className="relative">
            <div className={`w-28 h-28 rounded-full flex items-center justify-center border-4 border-background overflow-hidden shadow-2xl ${isPremium ? "ring-2 ring-primary/50" : "ring-2 ring-primary/20"}`}
              style={{ background: "hsl(274,22%,10%)" }}>
              {currentUser?.avatar_url ? (
                <img src={currentUser.avatar_url} alt="profil" className="w-full h-full object-cover" />
              ) : (
                <span className="text-4xl font-bold text-primary">
                  {currentUser?.full_name?.[0]?.toUpperCase() || "?"}
                </span>
              )}
            </div>
            {/* Camera upload */}
            <label className="absolute bottom-1 right-1 rounded-full p-2 cursor-pointer shadow-lg ring-2 ring-background active:scale-90 transition-transform"
              style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
              {uploadingAvatar ? <Loader2 className="w-3.5 h-3.5 text-white animate-spin" /> : <Camera className="w-3.5 h-3.5 text-white" />}
              <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
            </label>
            {/* Premium glow */}
            {isPremium && (
              <div className="absolute inset-[-4px] rounded-full gold-glow pointer-events-none" style={{ background: "rgba(130,60,210,0.06)", filter: "blur(8px)" }} />
            )}
          </div>

          {/* Action buttons */}
          <div className="flex gap-2">
            <button
              onClick={onBadgesClick}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-full active:scale-95 transition-all text-xs font-semibold"
              style={{
                background: "linear-gradient(135deg, rgba(50,20,72,0.6), rgba(35,16,28,0.4))",
                border: "1px solid rgba(180,100,240,0.15)",
                color: "hsl(var(--primary))"
              }}
            >
              <Award className="w-4 h-4" />
              Rozetler
            </button>
          </div>
        </div>

        {/* Name + Badges */}
        <div className="flex items-center gap-2 mb-1 flex-wrap">
          <h1 className="text-2xl font-heading font-bold text-foreground tracking-tight">{displayName}</h1>
          {isPremium && <Crown className="w-5 h-5 text-primary" />}
          {currentUser?.is_verified && <CheckCircle2 className="w-4.5 h-4.5 text-blue-400" />}
          <UserBadges
            manualBadges={{
              has_ozel_badge: currentUser?.has_ozel_badge,
              has_vip: currentUser?.has_vip,
              has_author_badge: currentUser?.has_author_badge,
              has_magazin_badge: currentUser?.has_magazin_badge,
            }}
            autoBadges={autoBadges}
          />
        </div>

        {/* Username */}
        <p className="text-xs text-muted-foreground mb-2">@{currentUser?.email?.split("@")[0]}</p>

        {/* Status */}
        {currentUser?.status && (
          <p className="text-xs text-primary/80 italic mb-2">{currentUser.status}</p>
        )}

        {/* Bio */}
        {currentUser?.bio && (
          <p className="text-sm text-foreground/70 leading-relaxed mb-5">{currentUser.bio}</p>
        )}

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-2">
          <button
            onClick={onFollowersClick}
            className="py-3 rounded-2xl text-center active:scale-95 transition-transform"
            style={{ background: "linear-gradient(155deg, rgba(38,18,55,0.5), rgba(28,14,22,0.3))", border: "1px solid rgba(200,140,255,0.06)" }}
          >
            <span className="text-lg font-bold text-foreground block">{followers}</span>
            <p className="text-[9px] text-muted-foreground font-medium mt-0.5">Takipçi</p>
          </button>
          <button
            onClick={onFollowingClick}
            className="py-3 rounded-2xl text-center active:scale-95 transition-transform"
            style={{ background: "linear-gradient(155deg, rgba(38,18,55,0.5), rgba(28,14,22,0.3))", border: "1px solid rgba(200,140,255,0.06)" }}
          >
            <span className="text-lg font-bold text-foreground block">{following}</span>
            <p className="text-[9px] text-muted-foreground font-medium mt-0.5">Takip</p>
          </button>
          <div className="py-3 rounded-2xl text-center"
            style={{ background: "linear-gradient(155deg, rgba(38,18,55,0.5), rgba(28,14,22,0.3))", border: "1px solid rgba(200,140,255,0.06)" }}
          >
            <span className="text-lg font-bold text-foreground block">{opCount}</span>
            <p className="text-[9px] text-muted-foreground font-medium mt-0.5">Eser</p>
          </div>
          <div className="py-3 rounded-2xl text-center"
            style={{ background: "linear-gradient(155deg, rgba(38,18,55,0.5), rgba(28,14,22,0.3))", border: "1px solid rgba(200,140,255,0.06)" }}
          >
            <span className="text-lg font-bold text-foreground block">
              {myBooks?.reduce((sum, b) => sum + (b.like_count || 0), 0) || 0}
            </span>
            <p className="text-[9px] text-muted-foreground font-medium mt-0.5">Beğeni</p>
          </div>
        </div>
      </div>

      {/* Edit Popup */}
      <ProfileEditPopup
        isOpen={showEditPopup}
        onClose={() => setShowEditPopup(false)}
        currentUser={currentUser}
      />
    </>
  );
}