import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Globe, Pencil, Check, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const SOCIAL_FIELDS = [
  { key: "social_twitter", label: "X (Twitter)", placeholder: "@kullanici" },
  { key: "social_instagram", label: "Instagram", placeholder: "@kullanici" },
  { key: "social_wattpad", label: "Wattpad", placeholder: "kullanici" },
  { key: "social_goodreads", label: "Goodreads", placeholder: "profil linki" },
  { key: "website", label: "Web Sitesi", placeholder: "https://..." },
];

export default function SocialLinks({ currentUser, setCurrentUser }) {
  const [editing, setEditing] = useState(false);
  const [values, setValues] = useState({});

  const startEditing = () => {
    const initial = {};
    SOCIAL_FIELDS.forEach((f) => { initial[f.key] = currentUser?.[f.key] || ""; });
    setValues(initial);
    setEditing(true);
  };

  const handleSave = async () => {
    await base44.auth.updateMe(values);
    const updated = await base44.auth.me();
    setCurrentUser(updated);
    setEditing(false);
    toast.success("Sosyal bağlantılar güncellendi");
  };

  const hasSocial = SOCIAL_FIELDS.some((f) => currentUser?.[f.key]);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Sosyal Bağlantılar</h3>
        </div>
        {!editing && (
          <button onClick={startEditing} className="text-muted-foreground hover:text-primary transition-colors">
            <Pencil className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {editing ? (
        <div className="space-y-2">
          {SOCIAL_FIELDS.map((f) => (
            <Input
              key={f.key}
              value={values[f.key]}
              onChange={(e) => setValues((p) => ({ ...p, [f.key]: e.target.value }))}
              placeholder={f.placeholder}
              className="h-9 text-sm"
            />
          ))}
          <div className="flex gap-2 pt-1">
            <Button size="sm" className="rounded-full flex-1 h-8" onClick={handleSave}>
              <Check className="w-3.5 h-3.5 mr-1" /> Kaydet
            </Button>
            <Button size="sm" variant="outline" className="rounded-full h-8" onClick={() => setEditing(false)}>
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      ) : hasSocial ? (
        <div className="flex flex-wrap gap-2">
          {SOCIAL_FIELDS.filter((f) => currentUser?.[f.key]).map((f) => (
            <span key={f.key} className="px-3 py-1.5 rounded-full bg-muted text-xs font-medium text-foreground">
              {f.label}: {currentUser[f.key]}
            </span>
          ))}
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">Henüz bağlantı eklenmedi</p>
      )}
    </div>
  );
}