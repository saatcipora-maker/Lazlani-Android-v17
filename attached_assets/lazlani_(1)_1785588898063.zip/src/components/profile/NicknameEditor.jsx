import { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { AtSign, Pencil, Check, X, Clock, History } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function NicknameEditor({ currentUser, setCurrentUser }) {
  const [editing, setEditing] = useState(false);
  const [nickname, setNickname] = useState(currentUser?.nickname || "");
  const [showHistory, setShowHistory] = useState(false);

  const canChange = useMemo(() => {
    if (!currentUser?.nickname_changed_at) return true;
    return Date.now() - new Date(currentUser.nickname_changed_at).getTime() >= 24 * 60 * 60 * 1000;
  }, [currentUser?.nickname_changed_at]);

  const handleSave = async () => {
    if (!nickname.trim()) return;
    const history = [...(currentUser?.nickname_history || [])];
    if (currentUser?.nickname && currentUser.nickname !== nickname.trim()) {
      history.push(currentUser.nickname);
    }
    await base44.auth.updateMe({
      nickname: nickname.trim(),
      nickname_changed_at: new Date().toISOString(),
      nickname_history: history.slice(-10),
    });
    const updated = await base44.auth.me();
    setCurrentUser(updated);
    setEditing(false);
    toast.success("Takma ad güncellendi!");
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AtSign className="w-4 h-4 text-accent" />
          <h3 className="text-sm font-semibold text-foreground">Takma Ad</h3>
        </div>
        <div className="flex items-center gap-1">
          {(currentUser?.nickname_history?.length > 0) && (
            <button onClick={() => setShowHistory(!showHistory)} className="text-muted-foreground hover:text-primary p-1">
              <History className="w-3.5 h-3.5" />
            </button>
          )}
          {!editing && canChange && (
            <button onClick={() => { setNickname(currentUser?.nickname || ""); setEditing(true); }} className="text-muted-foreground hover:text-primary p-1">
              <Pencil className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {editing ? (
        <div className="space-y-2">
          <Input
            value={nickname}
            onChange={(e) => setNickname(e.target.value)}
            placeholder="Takma adınız..."
            className="h-9 text-sm"
            maxLength={30}
            autoFocus
          />
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">{nickname.length}/30</span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="h-7 text-xs rounded-full" onClick={() => setEditing(false)}>
                <X className="w-3 h-3 mr-1" /> İptal
              </Button>
              <Button size="sm" className="h-7 text-xs rounded-full" disabled={!nickname.trim()} onClick={handleSave}>
                <Check className="w-3 h-3 mr-1" /> Kaydet
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div>
          {currentUser?.nickname ? (
            <p className="text-sm font-medium text-foreground">{currentUser.nickname}</p>
          ) : (
            <p className="text-xs text-muted-foreground italic">Henüz belirlenmedi</p>
          )}
          {!canChange && (
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3" /> 24 saat içinde tekrar değiştirebilirsiniz
            </p>
          )}
        </div>
      )}

      {showHistory && currentUser?.nickname_history?.length > 0 && (
        <div className="p-3 rounded-xl bg-muted/50 space-y-1">
          <p className="text-xs font-medium text-muted-foreground mb-1">Önceki takma adlar:</p>
          {currentUser.nickname_history.map((n, i) => (
            <p key={i} className="text-xs text-foreground">{n}</p>
          ))}
        </div>
      )}
    </div>
  );
}