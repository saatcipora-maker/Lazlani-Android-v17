import { Link } from "react-router-dom";
import { BottomSheet } from "@/components/ui/bottom-sheet";

export default function FollowListModal({ title, list, nameKey, isOpen, onClose }) {
  return (
    <BottomSheet isOpen={isOpen} onClose={onClose} title={title}>
      {list.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground py-8">Henüz kimse yok</p>
      ) : (
        <div className="space-y-1">
          {list.map((item) => {
            const name = item[nameKey] || "Kullanıcı";
            const email = nameKey === "follower_name" ? item.follower_email : item.following_email;
            return (
              <Link
                key={item.id}
                to={`/user/${encodeURIComponent(email)}`}
                onClick={onClose}
                className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-primary">
                    {name[0]?.toUpperCase() || "?"}
                  </span>
                </div>
                <span className="text-sm font-medium text-foreground">{name}</span>
              </Link>
            );
          })}
        </div>
      )}
    </BottomSheet>
  );
}