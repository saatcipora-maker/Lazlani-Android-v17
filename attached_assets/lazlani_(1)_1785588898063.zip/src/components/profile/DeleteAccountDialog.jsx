import { AlertCircle, CheckCircle, ArrowRight, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useDeleteAccount } from '@/hooks/useDeleteAccount';

export default function DeleteAccountDialog() {
  const {
    isOpen,
    step,
    isPending,
    handleOpen,
    handleClose,
    handleNext,
    handleConfirmDelete,
  } = useDeleteAccount();

  return (
    <>
      <button
        onClick={handleOpen}
        className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-destructive rounded-sm hover:bg-destructive/10 transition-colors cursor-pointer"
      >
        <Trash2 className="w-4 h-4" />
        Hesabı Sil
      </button>

      <AlertDialog open={isOpen} onOpenChange={handleClose}>
        <AlertDialogContent>
          {step === 0 && (
            <>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 text-lg">
                  <AlertCircle className="w-5 h-5 text-destructive" />
                  Hesabı Silmek İstiyor musunuz?
                </AlertDialogTitle>
              </AlertDialogHeader>
              <AlertDialogDescription className="space-y-3">
                <p>
                  Bu işlem geri alınamaz. Aşağıdaki veriler kalıcı olarak silinecektir:
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    Tüm kişisel bilgileri
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    Yayınlanan kitaplar ve taslaklar
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    Tüm mesajlar ve yorumlar
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    Takipçi/Takip listesi
                  </li>
                </ul>
                <p className="text-xs text-muted-foreground pt-2">
                  Devam etmek istediğinizden emin misiniz?
                </p>
              </AlertDialogDescription>
              <AlertDialogFooter>
                <AlertDialogCancel>İptal</AlertDialogCancel>
                <Button
                  variant="destructive"
                  onClick={handleNext}
                  className="flex items-center gap-2"
                >
                  Devam Et
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </AlertDialogFooter>
            </>
          )}

          {step === 1 && (
            <>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 text-lg">
                  <AlertCircle className="w-5 h-5 text-destructive" />
                  Son Uyarı
                </AlertDialogTitle>
              </AlertDialogHeader>
              <AlertDialogDescription className="space-y-3">
                <p className="font-medium text-foreground">
                  Hesabınız ve tüm verileri kalıcı olarak silinecektir.
                </p>
                <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                  <p className="text-sm text-destructive font-medium">
                    Bu işlem geri alınamaz. Devam etmek istiyor musunuz?
                  </p>
                </div>
              </AlertDialogDescription>
              <AlertDialogFooter>
                <AlertDialogCancel>Vazgeç</AlertDialogCancel>
                <Button
                  variant="destructive"
                  onClick={handleNext}
                  disabled={isPending}
                  className="flex items-center gap-2"
                >
                  {isPending ? 'Siliniyor...' : 'Evet, Sil'}
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </AlertDialogFooter>
            </>
          )}

          {step === 2 && (
            <>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 text-lg">
                  <CheckCircle className="w-5 h-5 text-destructive" />
                  Son Onay
                </AlertDialogTitle>
              </AlertDialogHeader>
              <AlertDialogDescription className="space-y-3">
                <p>
                  Hesabınızı silmek için aşağıdaki butona tıklayarak onaylayın.
                </p>
                <div className="bg-muted rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">
                    Bu işlem tamamlandıktan sonra hesabınıza giriş yapamayacaksınız.
                  </p>
                </div>
              </AlertDialogDescription>
              <AlertDialogFooter>
                <AlertDialogCancel disabled={isPending}>Vazgeç</AlertDialogCancel>
                <Button
                  variant="destructive"
                  onClick={handleConfirmDelete}
                  disabled={isPending}
                  className="flex items-center gap-2"
                >
                  {isPending ? 'Siliniyor...' : 'Kalıcı Olarak Sil'}
                </Button>
              </AlertDialogFooter>
            </>
          )}
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}