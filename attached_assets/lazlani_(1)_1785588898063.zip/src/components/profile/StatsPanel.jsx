import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { BookOpen, Pen, Eye, Heart, BarChart3, Target, Gamepad2, Award } from "lucide-react";
import MatchBadges from "@/components/match3/MatchBadges";

export default function StatsPanel({ currentUser }) {
  const email = currentUser?.email;

  const { data: books = [] } = useQuery({
    queryKey: ["stats-books", email],
    queryFn: () => base44.entities.Book.filter({ author_email: email }, "-created_date", 50),
    enabled: !!email,
  });

  const { data: readHistory = [] } = useQuery({
    queryKey: ["stats-reads", email],
    queryFn: () => base44.entities.ReadHistory.filter({ user_email: email }, "-created_date", 100),
    enabled: !!email,
  });

  const { data: gameProfiles = [] } = useQuery({
    queryKey: ["stats-game-profile", email],
    queryFn: () => base44.entities.GameProfile.filter({ user_email: email }, "-updated_date", 1),
    enabled: !!email,
  });
  const gameProfile = gameProfiles[0];

  const totalReads = books.reduce((s, b) => s + (b.read_count || 0), 0);
  const totalLikes = books.reduce((s, b) => s + (b.like_count || 0), 0);
  const publishedBooks = books.filter((b) => b.status === "yayinda").length;
  const booksRead = readHistory.length;

  const stats = [
    { icon: Pen, label: "Yazılan Kitap", value: publishedBooks, color: "text-primary" },
    { icon: BookOpen, label: "Okunan Kitap", value: booksRead, color: "text-blue-500" },
    { icon: Eye, label: "Toplam Okunma", value: totalReads, color: "text-amber-500" },
    { icon: Heart, label: "Toplam Beğeni", value: totalLikes, color: "text-red-500" },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <BarChart3 className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">İstatistikler</h3>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {stats.map((s) => (
          <div key={s.label} className="p-3 rounded-xl bg-card border border-border text-center">
            <s.icon className={`w-5 h-5 mx-auto mb-1.5 ${s.color}`} />
            <p className="text-lg font-bold text-foreground">{s.value}</p>
            <p className="text-[10px] text-muted-foreground font-medium">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Game stats */}
      {gameProfile && (
        <div className="p-4 rounded-xl glass-card">
          <div className="flex items-center gap-2 mb-2">
            <Gamepad2 className="w-4 h-4 text-accent" />
            <h4 className="text-xs font-semibold text-foreground">Oyun İstatistikleri</h4>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="text-center">
              <p className="text-2xl font-heading font-bold text-accent">{gameProfile.total_score || 0}</p>
              <p className="text-[10px] text-muted-foreground font-medium">Toplam Oyun Puanı</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-heading font-bold text-primary">{gameProfile.match_level || 1}</p>
              <p className="text-[10px] text-muted-foreground font-medium">Oyun Seviyesi</p>
            </div>
          </div>
        </div>
      )}

      {/* Game achievement badges */}
      {gameProfile && (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-accent" />
            <h4 className="text-xs font-semibold text-foreground">Oyun Başarımları</h4>
          </div>
          <MatchBadges totalScore={gameProfile.total_score || 0} compact />
        </div>
      )}

      {/* Goals */}
      {(currentUser?.reading_goal_monthly > 0 || currentUser?.writing_goal_daily > 0) && (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-accent" />
            <h4 className="text-xs font-semibold text-foreground">Hedefler</h4>
          </div>
          {currentUser?.reading_goal_monthly > 0 && (
            <div className="p-3 rounded-xl bg-muted/50">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs text-muted-foreground">Aylık Okuma Hedefi</span>
                <span className="text-xs font-bold text-foreground">{booksRead}/{currentUser.reading_goal_monthly}</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full transition-all"
                  style={{ width: `${Math.min(100, (booksRead / currentUser.reading_goal_monthly) * 100)}%` }}
                />
              </div>
            </div>
          )}
          {currentUser?.writing_goal_daily > 0 && (
            <div className="p-3 rounded-xl bg-muted/50">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs text-muted-foreground">Günlük Yazma Hedefi</span>
                <span className="text-xs font-bold text-foreground">{currentUser.total_words_written || 0} kelime</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}