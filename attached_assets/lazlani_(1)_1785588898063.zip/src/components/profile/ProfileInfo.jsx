import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { BookOpen, Newspaper, ShieldCheck, Megaphone, MessageCircle, ChevronRight, Image as ImageIcon, Send, Loader2, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Link, useNavigate } from "react-router-dom";
import HorizontalBookList from "@/components/books/HorizontalBookList";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function ProfileInfo({ currentUser, setCurrentUser, myBooks, isLoadingBooks, followers, isAdmin }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [editingBio, setEditingBio] = useState(false);
  const [bio, setBio] = useState(currentUser?.bio || "");
  const [bultenContent, setBultenContent] = useState("");
  const [bultenImageFile, setBultenImageFile] = useState(null);
  const [bultenImagePreview, setBultenImagePreview] = useState("");

  const saveBioMutation = useMutation({
    mutationFn: () => base44.auth.updateMe({ bio: bio.trim() }),
    onSuccess: async () => {
      const updated = await base44.auth.me();
      setCurrentUser(updated);
      setEditingBio(false);
      toast.success("Biyografi güncellendi!");
    }
  });

  const createBultenMutation = useMutation({
    mutationFn: async () => {
      let image_url = "";
      if (bultenImageFile) {
        const res = await base44.integrations.Core.UploadFile({ file: bultenImageFile });
        image_url = res.file_url;
      }
      return base44.entities.BultenPost.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        content: bultenContent.trim(),
        image_url,
        like_count: 0,
        comment_count: 0
      });
    },
    onSuccess: () => {
      setBultenContent("");
      setBultenImageFile(null);
      setBultenImagePreview("");
      queryClient.invalidateQueries({ queryKey: ["bulten-posts"] });
      toast.success("Bülten paylaşıldı!");
    }
  });

  const handleBultenImageSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setBultenImageFile(file);
    setBultenImagePreview(URL.createObjectURL(file));
  };

  const quickActions = [
  { icon: BookOpen, label: "Kitaplarım", to: "/write", color: "text-primary" },
  { icon: Megaphone, label: "Reklam Ver", to: "/write", color: "text-orange-500" },
  ...(isAdmin ? [{ icon: ShieldCheck, label: "Yönetici", to: "/admin", color: "text-red-500" }] : [])];


  return (
    <div className="space-y-5">
      {/* Bio Section */}
      <div className="px-4 mb-3">
        <div className="flex items-center justify-between mb-1">










        </div>
      </div>
      <div className="px-4">
        






        






        
        {editingBio ?
        <div className="space-y-2">
            <Textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Kendinizi kısaca tanıtın..."
            className="resize-none text-sm"
            maxLength={200} />
          
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{bio.length}/200</span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="h-7 text-xs rounded-full" onClick={() => setEditingBio(false)}>İptal</Button>
                <Button size="sm" className="h-7 text-xs rounded-full" onClick={() => saveBioMutation.mutate()} disabled={saveBioMutation.isPending}>Kaydet</Button>
              </div>
            </div>
          </div> : null




        }
      </div>

      {/* Quick Actions */}
      <div className="px-4">
        
        <div className="grid grid-cols-2 gap-2">
          {quickActions.map((action) =>
          <Link key={action.label} to={action.to}>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors">
                <action.icon className={`w-5 h-5 ${action.color} flex-shrink-0`} />
                <span className="text-sm font-medium text-foreground">{action.label}</span>
                <ChevronRight className="w-3.5 h-3.5 text-muted-foreground ml-auto" />
              </div>
            </Link>
          )}
        </div>
      </div>

      {/* Bültenler */}
      <div>
        <div className="px-4 mb-3">
          <Button variant="outline" className="rounded-full text-sm w-full">Bültenler</Button>
        </div>
        {currentUser &&
        <div className="px-4 pb-4">
            <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-primary">{currentUser?.full_name?.[0]?.toUpperCase() || "?"}</span>
                </div>
                <Textarea
                value={bultenContent}
                onChange={(e) => setBultenContent(e.target.value)}
                placeholder="Bir şeyler paylaş..."
                className="flex-1 min-h-[72px] resize-none border-0 bg-muted rounded-xl text-sm p-3 focus-visible:ring-0" />
              
              </div>
              {bultenImagePreview &&
            <img src={bultenImagePreview} alt="preview" className="w-full h-40 object-cover rounded-xl" />
            }
              <div className="flex items-center justify-between pt-1">
                <label className="cursor-pointer text-muted-foreground hover:text-primary transition-colors">
                  <ImageIcon className="w-5 h-5" />
                  <input type="file" accept="image/*" className="hidden" onChange={handleBultenImageSelect} />
                </label>
                <Button
                size="sm"
                className="rounded-full px-5"
                onClick={() => createBultenMutation.mutate()}
                disabled={!bultenContent.trim() || createBultenMutation.isPending}>
                
                  {createBultenMutation.isPending && <Loader2 className="w-3 h-3 mr-1 animate-spin" />}
                  <Send className="w-3 h-3 mr-1" />
                  Paylaş
                </Button>
              </div>
            </div>
          </div>
        }
      </div>

      {/* My Books */}
      <div>
        <div className="flex items-center justify-between px-4 mb-2">
          <h3 className="text-sm font-semibold text-foreground">Yayınlanan Kitaplarım</h3>
          <span className="text-xs text-muted-foreground">{myBooks.length} kitap</span>
        </div>
        {isLoadingBooks ?
        <div className="flex gap-3 px-4">
            {[1, 2].map((i) => <Skeleton key={i} className="w-36 h-52 rounded-xl flex-shrink-0" />)}
          </div> :
        myBooks.length === 0 ?
        <div className="mx-4 p-6 rounded-2xl bg-muted/50 text-center">
            <BookOpen className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Henüz yayınlanmış kitabınız yok</p>
            <Link to="/write">
              <Button size="sm" className="mt-3 rounded-full text-xs">Kitap Yaz</Button>
            </Link>
          </div> :

        <HorizontalBookList books={myBooks} />
        }
      </div>

      {/* Followers Preview */}
      {followers.length > 0 &&
      <div className="px-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-foreground">Takipçiler</h3>
            <span className="text-xs text-muted-foreground">{followers.length} kişi</span>
          </div>
          <div className="space-y-2">
            {followers.slice(0, 4).map((f) =>
          <div key={f.id} className="flex items-center justify-between p-3 rounded-xl bg-card border border-border">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-primary">{f.follower_name?.[0]?.toUpperCase() || "?"}</span>
                  </div>
                  <span className="text-sm font-medium text-foreground">{f.follower_name || f.follower_email}</span>
                </div>
                <Button
              size="sm" variant="outline" className="rounded-full text-xs h-8"
              onClick={() => navigate(`/messages?to=${f.follower_email}&name=${f.follower_name}`)}>

                  <MessageCircle className="w-3 h-3 mr-1" />
                  Mesaj
                </Button>
              </div>
          )}
          </div>
        </div>
      }
    </div>);

}