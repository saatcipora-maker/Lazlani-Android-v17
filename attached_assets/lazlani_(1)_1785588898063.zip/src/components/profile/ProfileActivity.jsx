import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { BookOpen, Heart, MessageCircle, Clock, BookMarked } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router-dom";

export default function ProfileActivity({ currentUser }) {
  const email = currentUser?.email;

  const { data: readHistory = [], isLoading: loadingHistory } = useQuery({
    queryKey: ["read-history", email],
    queryFn: () => base44.entities.ReadHistory.filter({ user_email: email }, "-updated_date", 10),
    enabled: !!email,
  });

  const { data: savedBooks = [], isLoading: loadingSaved } = useQuery({
    queryKey: ["saved-books", email],
    queryFn: () => base44.entities.SavedBook.filter({ user_email: email }, "-created_date", 10),
    enabled: !!email,
  });

  const { data: myComments = [], isLoading: loadingComments } = useQuery({
    queryKey: ["my-comments", email],
    queryFn: () => base44.entities.ChapterComment.filter({ user_email: email }, "-created_date", 10),
    enabled: !!email,
  });

  const { data: myBultenPosts = [], isLoading: loadingBulten } = useQuery({
    queryKey: ["my-bulten-posts", email],
    queryFn: () => base44.entities.BultenPost.filter({ user_email: email }, "-created_date", 10),
    enabled: !!email,
  });

  const isLoading = loadingHistory || loadingSaved || loadingComments || loadingBulten;

  if (isLoading) {
    return (
      <div className="px-4 space-y-3 pt-2">
        {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
      </div>
    );
  }

  const Section = ({ icon: Icon, title, color, children, empty }) => (
    <div>
      <div className="flex items-center gap-2 px-4 mb-2">
        <Icon className={`w-4 h-4 ${color}`} />
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      </div>
      {children || (
        <p className="px-4 text-xs text-muted-foreground py-3 bg-muted/40 mx-4 rounded-xl text-center">{empty}</p>
      )}
    </div>
  );

  return (
    <div className="space-y-6 pt-2 pb-4">
      {/* Okuma Geçmişi */}
      <Section icon={BookOpen} title="Okuma Geçmişi" color="text-primary" empty="Henüz okuma geçmişi yok">
        {readHistory.length > 0 && (
          <div className="space-y-2 px-4">
            {readHistory.map((item) => (
              <Link key={item.id} to={`/book/${item.book_id}`}>
                <div className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl hover:border-primary/30 transition-colors">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <BookOpen className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{item.book_title}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(item.updated_date || item.created_date), { addSuffix: true, locale: tr })}
                    </p>
                  </div>
                  <Clock className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </Section>

      {/* Kaydedilen Kitaplar */}
      <Section icon={BookMarked} title="Kaydedilen Kitaplar" color="text-blue-500" empty="Henüz kaydedilen kitap yok">
        {savedBooks.length > 0 && (
          <div className="space-y-2 px-4">
            {savedBooks.map((item) => (
              <Link key={item.id} to={`/book/${item.book_id}`}>
                <div className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl hover:border-blue-300 transition-colors">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                    <BookMarked className="w-4 h-4 text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{item.book_title}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(item.created_date), { addSuffix: true, locale: tr })}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </Section>

      {/* Yorumlarım */}
      <Section icon={MessageCircle} title="Yorumlarım" color="text-orange-500" empty="Henüz yorum yapılmadı">
        {myComments.length > 0 && (
          <div className="space-y-2 px-4">
            {myComments.map((c) => (
              <div key={c.id} className="p-3 bg-card border border-border rounded-xl">
                <p className="text-xs text-foreground/80 leading-relaxed line-clamp-2">{c.content}</p>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {formatDistanceToNow(new Date(c.created_date), { addSuffix: true, locale: tr })}
                </p>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* Bülten Paylaşımlarım */}
      <Section icon={Heart} title="Bülten Paylaşımlarım" color="text-red-500" empty="Henüz bülten paylaşımı yok">
        {myBultenPosts.length > 0 && (
          <div className="space-y-2 px-4">
            {myBultenPosts.map((p) => (
              <div key={p.id} className="p-3 bg-card border border-border rounded-xl">
                <p className="text-xs text-foreground/80 leading-relaxed line-clamp-2">{p.content}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                    <Heart className="w-3 h-3" />{p.like_count || 0}
                  </span>
                  <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                    <MessageCircle className="w-3 h-3" />{p.comment_count || 0}
                  </span>
                  <span className="text-[10px] text-muted-foreground ml-auto">
                    {formatDistanceToNow(new Date(p.created_date), { addSuffix: true, locale: tr })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </Section>
    </div>
  );
}