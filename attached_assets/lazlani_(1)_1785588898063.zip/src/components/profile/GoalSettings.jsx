import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Target, BookOpen, Pen, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function GoalSettings({ currentUser, setCurrentUser }) {
  const [readGoal, setReadGoal] = useState(currentUser?.reading_goal_monthly || 0);
  const [writeGoal, setWriteGoal] = useState(currentUser?.writing_goal_daily || 0);

  const handleSave = async () => {
    await base44.auth.updateMe({
      reading_goal_monthly: Number(readGoal) || 0,
      writing_goal_daily: Number(writeGoal) || 0,
    });
    const updated = await base44.auth.me();
    setCurrentUser(updated);
    toast.success("Hedefler güncellendi!");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Target className="w-4 h-4 text-accent" />
        <h3 className="text-sm font-semibold text-foreground">Hedefler</h3>
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border">
          <BookOpen className="w-4 h-4 text-blue-500 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs font-medium text-foreground">Aylık Okuma Hedefi</p>
            <p className="text-[10px] text-muted-foreground">Ayda kaç kitap?</p>
          </div>
          <Input
            type="number"
            min={0}
            max={100}
            value={readGoal}
            onChange={(e) => setReadGoal(e.target.value)}
            className="w-16 h-8 text-center text-sm"
          />
        </div>
        <div className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border">
          <Pen className="w-4 h-4 text-primary flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs font-medium text-foreground">Günlük Yazma Hedefi</p>
            <p className="text-[10px] text-muted-foreground">Günde kaç kelime?</p>
          </div>
          <Input
            type="number"
            min={0}
            max={10000}
            step={100}
            value={writeGoal}
            onChange={(e) => setWriteGoal(e.target.value)}
            className="w-20 h-8 text-center text-sm"
          />
        </div>
      </div>
      <Button size="sm" className="rounded-full w-full" onClick={handleSave}>
        <Check className="w-3.5 h-3.5 mr-1" /> Kaydet
      </Button>
    </div>
  );
}