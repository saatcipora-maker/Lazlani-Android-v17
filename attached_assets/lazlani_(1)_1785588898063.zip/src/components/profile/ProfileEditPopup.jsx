import { useState } from "react";
import { X, Camera, Loader2, Save } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";

export default function ProfileEditPopup({ isOpen, onClose, currentUser }) {
  const [username, setUsername] = useState(currentUser?.display_name || currentUser?.full_name || "");
  const [fullName, setFullName] = useState(currentUser?.full_name || "");
  const [status, setStatus] = useState(currentUser?.status || "");
  const [about, setAbout] = useState(currentUser?.bio || "");
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const { updateUser } = useAuth();

  const handleSave = async () => {
    setSaving(true);
    await updateUser({
      display_name: username.trim(),
      status: status.trim(),
      bio: about.trim(),
    });
    setSaving(false);
    toast.success("Profil güncellendi!");
    onClose();
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingAvatar(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await updateUser({ avatar_url: file_url });
    setUploadingAvatar(false);
    toast.success("Profil fotoğrafı güncellendi!");
  };

  const handleCoverUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingCover(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await updateUser({ cover_url: file_url });
    setUploadingCover(false);
    toast.success("Kapak fotoğrafı güncellendi!");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 100, opacity: 0, scale: 0.95 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 100, opacity: 0, scale: 0.95 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-card rounded-t-3xl sm:rounded-3xl border border-border shadow-2xl max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 pb-3">
              <h2 className="font-heading text-lg font-bold text-foreground">Profili Düzenle</h2>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            <div className="px-5 pb-6 space-y-4">
              {/* Photos */}
              <div className="flex gap-3">
                <div className="flex-1">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Profil Fotoğrafı</p>
                  <label className="flex items-center justify-center w-full h-20 rounded-2xl border-2 border-dashed border-border bg-muted/30 cursor-pointer hover:border-primary/40 hover:bg-primary/5 transition-all">
                    {uploadingAvatar ? (
                      <Loader2 className="w-5 h-5 text-primary animate-spin" />
                    ) : currentUser?.avatar_url ? (
                      <img src={currentUser.avatar_url} alt="" className="w-14 h-14 rounded-xl object-cover" />
                    ) : (
                      <Camera className="w-5 h-5 text-muted-foreground" />
                    )}
                    <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
                  </label>
                </div>
                <div className="flex-1">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Kapak Fotoğrafı</p>
                  <label className="flex items-center justify-center w-full h-20 rounded-2xl border-2 border-dashed border-border bg-muted/30 cursor-pointer hover:border-primary/40 hover:bg-primary/5 transition-all">
                    {uploadingCover ? (
                      <Loader2 className="w-5 h-5 text-primary animate-spin" />
                    ) : currentUser?.cover_url ? (
                      <img src={currentUser.cover_url} alt="" className="w-full h-full rounded-2xl object-cover" />
                    ) : (
                      <Camera className="w-5 h-5 text-muted-foreground" />
                    )}
                    <input type="file" accept="image/*" className="hidden" onChange={handleCoverUpload} />
                  </label>
                </div>
              </div>

              {/* Fields */}
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Kullanıcı Adı</label>
                <Input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Kullanıcı adınız..."
                  className="rounded-xl h-11 bg-muted/30 border-border/50"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">İsim Bilgisi</label>
                <Input
                  value={fullName}
                  disabled
                  className="rounded-xl h-11 bg-muted/50 border-border/50 opacity-60"
                />
                <p className="text-[10px] text-muted-foreground mt-1">İsim bilgisi hesap ayarlarından değiştirilir</p>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Durum</label>
                <Input
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  placeholder="Durumunuzu yazın..."
                  maxLength={100}
                  className="rounded-xl h-11 bg-muted/30 border-border/50"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Hakkında</label>
                <Textarea
                  value={about}
                  onChange={(e) => setAbout(e.target.value)}
                  placeholder="Kendiniz hakkında birkaç satır..."
                  rows={3}
                  maxLength={300}
                  className="rounded-xl bg-muted/30 border-border/50 resize-none"
                />
                <p className="text-[10px] text-muted-foreground mt-1 text-right">{about.length}/300</p>
              </div>

              {/* Save */}
              <Button
                onClick={handleSave}
                disabled={saving}
                className="w-full h-12 rounded-2xl font-semibold text-base shadow-lg shadow-primary/20 active:scale-[0.98] transition-transform"
              >
                {saving ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Kaydet
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}