import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Shield, Eye, EyeOff, Lock } from "lucide-react";
import { toast } from "sonner";

export default function PrivacyCenter({ currentUser, setCurrentUser }) {
  const [saving, setSaving] = useState(false);

  const toggleSetting = async (key) => {
    setSaving(true);
    const newVal = !currentUser?.[key];
    await base44.auth.updateMe({ [key]: newVal });
    const updated = await base44.auth.me();
    setCurrentUser(updated);
    setSaving(false);
    toast.success("Gizlilik ayarı güncellendi");
  };

  const settings = [
    { key: "display_nickname", label: "Takma adı görünen ad olarak kullan", desc: "Diğer kullanıcılara takma adınız gösterilir", icon: Eye },
    { key: "hide_real_name", label: "Gerçek adı gizle", desc: "Profilinizde gerçek adınız gösterilmez", icon: EyeOff },
    { key: "hide_email", label: "E-postayı gizle", desc: "E-posta adresiniz diğer kullanıcılardan gizlenir", icon: Lock },
    { key: "hide_location", label: "Konumu gizle", desc: "Konum bilgisi profilinizde gösterilmez", icon: EyeOff },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-1">
        <Shield className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Gizlilik Merkezi</h3>
      </div>
      {settings.map((s) => (
        <button
          key={s.key}
          onClick={() => toggleSetting(s.key)}
          disabled={saving}
          className="w-full flex items-center gap-3 p-3 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors text-left"
        >
          <s.icon className={`w-4 h-4 flex-shrink-0 ${currentUser?.[s.key] ? "text-primary" : "text-muted-foreground"}`} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground">{s.label}</p>
            <p className="text-xs text-muted-foreground">{s.desc}</p>
          </div>
          <div className={`w-10 h-6 rounded-full flex items-center transition-colors ${currentUser?.[s.key] ? "bg-primary" : "bg-muted"}`}>
            <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform mx-1 ${currentUser?.[s.key] ? "translate-x-4" : "translate-x-0"}`} />
          </div>
        </button>
      ))}
    </div>
  );
}