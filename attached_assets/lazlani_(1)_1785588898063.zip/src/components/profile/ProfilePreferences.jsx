import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Bell, Moon, Globe, Lock, Eye, EyeOff, ChevronRight, Check, MessageCircle, UserPlus, BookOpen, Info } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/AuthContext";

const CATEGORY_OPTIONS = [
  { value: "roman", label: "Roman" },
  { value: "romantik", label: "Romantik" },
  { value: "fantastik", label: "Fantastik" },
  { value: "bilim_kurgu", label: "Bilim Kurgu" },
  { value: "gerilim", label: "Gerilim" },
  { value: "dram", label: "Dram" },
  { value: "genc_yetiskin", label: "Genç Yetişkin" },
  { value: "macera", label: "Macera" },
  { value: "korku", label: "Korku" },
  { value: "tarih", label: "Tarih" },
];

export default function ProfilePreferences({ currentUser }) {
  const { updateUser } = useAuth();
  const prefs = currentUser?.preferences || {};
  const [favCategories, setFavCategories] = useState(prefs.fav_categories || []);
  const [notifications, setNotifications] = useState(prefs.notifications !== false);
  const [notifMessages, setNotifMessages] = useState(prefs.notif_messages !== false);
  const [notifFollows, setNotifFollows] = useState(prefs.notif_follows !== false);
  const [notifComments, setNotifComments] = useState(prefs.notif_comments !== false);
  const [notifBooks, setNotifBooks] = useState(prefs.notif_books !== false);
  const [notifSystem, setNotifSystem] = useState(prefs.notif_system !== false);
  const [privateProfile, setPrivateProfile] = useState(prefs.private_profile || false);

  const saveMutation = useMutation({
    mutationFn: (data) => updateUser({ preferences: data }),
    onSuccess: () => {
      toast.success("Tercihler kaydedildi!");
    },
  });

  const handleSave = () => {
    saveMutation.mutate({
      fav_categories: favCategories,
      notifications,
      notif_messages: notifMessages,
      notif_follows: notifFollows,
      notif_comments: notifComments,
      notif_books: notifBooks,
      notif_system: notifSystem,
      private_profile: privateProfile,
    });
  };

  const toggleCategory = (val) => {
    setFavCategories((prev) =>
      prev.includes(val) ? prev.filter((c) => c !== val) : [...prev, val]
    );
  };

  const ToggleRow = ({ icon: Icon, label, desc, value, onChange }) => (
    <div className="flex items-center justify-between p-4 bg-card border border-border rounded-xl">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center flex-shrink-0">
          <Icon className="w-4 h-4 text-muted-foreground" />
        </div>
        <div>
          <p className="text-sm font-medium text-foreground">{label}</p>
          {desc && <p className="text-xs text-muted-foreground">{desc}</p>}
        </div>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`w-11 h-6 rounded-full transition-colors relative ${value ? "bg-primary" : "bg-muted-foreground/30"}`}
      >
        <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${value ? "translate-x-5" : "translate-x-0.5"}`} />
      </button>
    </div>
  );

  return (
    <div className="px-4 space-y-6 pt-2">
      {/* Favori Kategoriler */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-1">Favori Kategoriler</h3>
        <p className="text-xs text-muted-foreground mb-3">Okumayı sevdiğiniz kategorileri seçin</p>
        <div className="flex flex-wrap gap-2">
          {CATEGORY_OPTIONS.map((cat) => {
            const isSelected = favCategories.includes(cat.value);
            return (
              <button
                key={cat.value}
                onClick={() => toggleCategory(cat.value)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                  isSelected
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground border-border hover:border-primary/40"
                }`}
                
              >
                {isSelected && <Check className="w-3 h-3" />}
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bildirim Tercihleri */}
      <div className="space-y-2">
        <h3 className="text-sm font-semibold text-foreground mb-1">Bildirim Tercihleri</h3>
        <p className="text-xs text-muted-foreground mb-3">Hangi bildirimler gönderilsin seçin</p>
        <ToggleRow
          icon={Bell}
          label="Tüm Bildirimler"
          desc="Ana bildirim anahtarı"
          value={notifications}
          onChange={setNotifications}
        />
        {notifications && (
          <>
            <ToggleRow
              icon={MessageCircle}
              label="Mesaj Bildirimleri"
              desc="Yeni mesaj geldiğinde bildir"
              value={notifMessages}
              onChange={setNotifMessages}
            />
            <ToggleRow
              icon={UserPlus}
              label="Takip Bildirimleri"
              desc="Biri seni takip ettiğinde bildir"
              value={notifFollows}
              onChange={setNotifFollows}
            />
            <ToggleRow
              icon={BookOpen}
              label="Kitap & Bölüm Bildirimleri"
              desc="Takip ettiğin yazarların yeni kitap ve bölümleri"
              value={notifBooks}
              onChange={setNotifBooks}
            />
            <ToggleRow
              icon={MessageCircle}
              label="Yorum Bildirimleri"
              desc="Yorumlarına gelen yanıt ve beğeniler"
              value={notifComments}
              onChange={setNotifComments}
            />
            <ToggleRow
              icon={Info}
              label="Sistem Bildirimleri"
              desc="Önemli uygulama güncellemeleri"
              value={notifSystem}
              onChange={setNotifSystem}
            />
          </>
        )}
      </div>

      {/* Gizlilik */}
      <div className="space-y-2">
        <h3 className="text-sm font-semibold text-foreground mb-3">Gizlilik</h3>
        <ToggleRow
          icon={Lock}
          label="Gizli Profil"
          desc="Profilin sadece takipçilerine görünsün"
          value={privateProfile}
          onChange={setPrivateProfile}
        />
      </div>

      {/* Save */}
      <button
        onClick={handleSave}
        disabled={saveMutation.isPending}
        className="w-full bg-primary text-primary-foreground rounded-xl py-3 text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60"
        style={{ minHeight: "44px" }}
      >
        {saveMutation.isPending ? "Kaydediliyor..." : "Tercihleri Kaydet"}
      </button>
    </div>
  );
}