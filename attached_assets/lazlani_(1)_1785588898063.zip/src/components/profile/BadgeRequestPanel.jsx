import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Star, Award, Crown, TrendingUp, Send, Check, Clock, Sparkles } from "lucide-react";
import NativeSelect from "@/components/ui/native-select";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const DURATIONS = [3, 5, 7, 15];

export default function BadgeRequestPanel({ currentUser, myBooks = [] }) {
  const [selectedFeaturedBook, setSelectedFeaturedBook] = useState("");
  const [selectedDuration, setSelectedDuration] = useState(7);
  const queryClient = useQueryClient();

  const { data: myRequests = [] } = useQuery({
    queryKey: ["badge-requests", currentUser?.email],
    queryFn: () => base44.entities.BadgeRequest.filter({ user_email: currentUser.email }, "-created_date", 20),
    enabled: !!currentUser?.email,
  });

  const pendingTypes = myRequests.filter((r) => r.status === "pending").map((r) => r.request_type);
  const approvedTypes = myRequests.filter((r) => r.status === "approved").map((r) => r.request_type);

  const sendRequest = useMutation({
    mutationFn: async ({ request_type, duration_days, book_id, book_title }) => {
      await base44.entities.BadgeRequest.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        request_type,
        duration_days,
        book_id,
        book_title,
        status: "pending",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["badge-requests", currentUser?.email] });
      toast.success("İsteğiniz yöneticiye iletildi!");
    },
  });

  const hasMagazin = currentUser?.has_magazin_badge;
  const hasAuthor = currentUser?.has_author_badge;
  const hasVip = currentUser?.has_vip;
  const hasOzel = currentUser?.has_ozel_badge;

  const items = [
    {
      key: "ozel_rozeti",
      icon: Sparkles,
      label: "Özel Rozet",
      desc: "Özel bölümünde video paylaşabilirsin",
      color: "text-purple-700",
      bg: "bg-purple-50 border-purple-200",
      active: hasOzel,
    },
    {
      key: "magazin_rozeti",
      icon: Star,
      label: "Magazin Rozeti",
      desc: "Magazin bölümünde paylaşım yapabilirsin",
      color: "text-[#9C2A2A]",
      bg: "bg-red-50 border-red-200",
      active: hasMagazin,
    },
    {
      key: "yazar_rozeti",
      icon: Award,
      label: "Yazar Rozeti",
      desc: "Özel yazar rozetiyle profilini öne çıkar",
      color: "text-primary",
      bg: "bg-primary/5 border-primary/20",
      active: hasAuthor,
    },
    {
      key: "vip_uyelik",
      icon: Crown,
      label: "VIP Üyelik",
      desc: "Mesaj ve yorumların mavi renkte görünsün",
      color: "text-blue-700",
      bg: "bg-blue-50 border-blue-200",
      active: hasVip,
    },
  ];

  return (
    <div className="px-4 mb-6 space-y-3">
      <h3 className="text-sm font-semibold text-foreground mb-2">Rozetler & Özellikler</h3>

      {items.map((item) => {
        const isPending = pendingTypes.includes(item.key);
        return (
          <div key={item.key} className={`rounded-2xl border p-4 ${item.bg}`}>
            <div className="flex items-center gap-3">
              <item.icon className={`w-5 h-5 ${item.color} flex-shrink-0`} />
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-semibold ${item.color}`}>{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
              {item.active ? (
                <span className="flex items-center gap-1 text-xs font-semibold text-green-700 bg-green-100 border border-green-300 px-2 py-1 rounded-full">
                  <Check className="w-3 h-3" /> Aktif
                </span>
              ) : isPending ? (
                <span className="flex items-center gap-1 text-xs text-orange-600 bg-orange-50 border border-orange-200 px-2 py-1 rounded-full">
                  <Clock className="w-3 h-3" /> Beklemede
                </span>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  className={`rounded-full text-xs h-8 ${item.color} border-current`}
                  disabled={sendRequest.isPending}
                  onClick={() => sendRequest.mutate({ request_type: item.key })}
                >
                  <Send className="w-3 h-3 mr-1" />
                  İstek Gönder
                </Button>
              )}
            </div>
          </div>
        );
      })}

      {/* Öne Çıkarma */}
      <div className="rounded-2xl border border-purple-200 bg-purple-50 p-4">
        <div className="flex items-center gap-3 mb-3">
          <TrendingUp className="w-5 h-5 text-purple-600 flex-shrink-0" />
          <div>
            <p className="text-sm font-semibold text-purple-700">Kitap Öne Çıkarma</p>
            <p className="text-xs text-muted-foreground">Kitabın ana sayfada öneriler bölümünde görünsün</p>
          </div>
        </div>
        {myBooks.length === 0 ? (
          <p className="text-xs text-muted-foreground">Yayınlanmış kitabınız yok</p>
        ) : (
          <div className="space-y-2">
            <NativeSelect
              value={selectedFeaturedBook}
              onChange={setSelectedFeaturedBook}
              options={myBooks.map((b) => ({ value: b.id, label: b.title }))}
              title="Kitap Seç"
              placeholder="Kitap seç..."
            />
            <div className="flex gap-1.5 flex-wrap">
              {DURATIONS.map((d) => (
                <button
                  key={d}
                  onClick={() => setSelectedDuration(d)}
                  className={`text-xs px-3 py-1 rounded-full border transition-colors ${
                    selectedDuration === d
                      ? "bg-purple-600 text-white border-purple-600"
                      : "border-purple-300 text-purple-600 hover:bg-purple-100"
                  }`}
                >
                  {d} gün
                </button>
              ))}
            </div>
            <Button
              size="sm"
              className="rounded-full w-full bg-purple-600 hover:bg-purple-700 text-white"
              disabled={!selectedFeaturedBook || sendRequest.isPending ||
                pendingTypes.includes("one_cikarma")}
              onClick={() => {
                const book = myBooks.find((b) => b.id === selectedFeaturedBook);
                sendRequest.mutate({
                  request_type: "one_cikarma",
                  duration_days: selectedDuration,
                  book_id: selectedFeaturedBook,
                  book_title: book?.title || "",
                });
              }}
            >
              {pendingTypes.includes("one_cikarma") ? (
                <><Clock className="w-3 h-3 mr-1" /> Beklemede</>
              ) : (
                <><Send className="w-3 h-3 mr-1" /> İstek Gönder</>
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}