import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { getRank } from "@/lib/gameData";


export default function Leaderboard() {
  const { data: profiles = [] } = useQuery({
    queryKey: ["game-leaderboard"],
    queryFn: () => base44.entities.GameProfile.list("-xp", 50),
  });

  const medals = ["🥇", "🥈", "🥉"];

  return (
    <div className="w-full max-w-md mx-auto">
      <h2 className="text-xl font-black text-white text-center mb-4">🏆 Lider Tablosu</h2>
      <div className="space-y-2 max-h-[60vh] overflow-y-auto scrollbar-hide">
        {profiles.map((p, i) => {
          const rank = getRank(p.xp || 0);
          return (
            <div
              key={p.id}
              className={`flex items-center gap-3 p-3 rounded-2xl border ${
                i < 3 ? "bg-yellow-500/10 border-yellow-400/20" : "bg-white/5 border-white/5"
              }`}
            >
              <span className="text-lg w-8 text-center font-black">
                {i < 3 ? medals[i] : <span className="text-white/40 text-sm">#{i + 1}</span>}
              </span>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                {(p.user_name || p.user_email)?.[0]?.toUpperCase() || "?"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-sm truncate">{p.user_name || p.user_email?.split("@")[0]}</p>
                <p className="text-white/50 text-xs">{rank.emoji} {rank.name}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-yellow-400 font-bold text-sm">⭐ {p.xp || 0}</p>
                <p className="text-white/40 text-[10px]">Lv.{p.level || 1}</p>
              </div>
            </div>
          );
        })}
        {profiles.length === 0 && (
          <p className="text-white/40 text-center py-8 text-sm">Henüz oyuncu yok</p>
        )}
      </div>
    </div>
  );
}