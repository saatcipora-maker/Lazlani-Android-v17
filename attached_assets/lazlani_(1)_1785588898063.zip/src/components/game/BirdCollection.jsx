import { BIRDS, RARITY_COLORS } from "@/lib/gameData";

export default function BirdCollection({ profile }) {
  const owned = new Set(profile?.owned_birds || []);
  const allBirds = Object.entries(BIRDS);

  return (
    <div className="w-full max-w-md mx-auto">
      <h2 className="text-xl font-black text-white text-center mb-2">🐦 Kuş Koleksiyonu</h2>
      <p className="text-white/50 text-xs text-center mb-4">{owned.size}/{allBirds.length} kuş açıldı</p>

      <div className="grid grid-cols-3 gap-3">
        {allBirds.map(([key, bird]) => {
          const isOwned = owned.has(key);
          const rarity = RARITY_COLORS[bird.rarity];
          return (
            <div
              key={key}
              className={`flex flex-col items-center gap-1 p-3 rounded-2xl border transition-all ${
                isOwned
                  ? "bg-white/10 border-white/15"
                  : "bg-white/5 border-white/5 opacity-30 grayscale"
              }`}
            >
              <span className="text-3xl">{bird.emoji}</span>
              <p className="text-white font-bold text-xs text-center">{bird.name}</p>
              <span
                className="px-2 py-0.5 rounded-full text-[9px] font-bold"
                style={{
                  backgroundColor: rarity.bg,
                  color: rarity.text,
                }}
              >
                {bird.rarity.toUpperCase()}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}