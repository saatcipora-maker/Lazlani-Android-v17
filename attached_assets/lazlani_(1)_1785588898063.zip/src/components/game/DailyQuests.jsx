import { DAILY_QUESTS } from "@/lib/gameData";
import { CheckCircle2 } from "lucide-react";

export default function DailyQuests({ profile }) {
  return (
    <div className="w-full max-w-md mx-auto">
      <h2 className="text-xl font-black text-white text-center mb-4">📋 Günlük Görevler</h2>
      <div className="space-y-3">
        {DAILY_QUESTS.map((q) => {
          const current = profile?.[q.field] || 0;
          const done = current >= q.target;
          const progress = Math.min(1, current / q.target);
          return (
            <div
              key={q.id}
              className={`p-4 rounded-2xl border transition-all ${
                done ? "bg-green-500/20 border-green-400/30" : "bg-white/10 border-white/10"
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {done && <CheckCircle2 className="w-4 h-4 text-green-400" />}
                  <span className="text-white font-bold text-sm">{q.label}</span>
                </div>
                <span className={`text-xs font-bold ${done ? "text-green-400" : "text-yellow-400"}`}>
                  +{q.reward} {q.rewardType === "coin" ? "🪙" : "⭐"}
                </span>
              </div>
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${done ? "bg-green-500" : "bg-yellow-500"}`}
                  style={{ width: `${progress * 100}%` }}
                />
              </div>
              <p className="text-white/50 text-[10px] mt-1 text-right">{current}/{q.target}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}