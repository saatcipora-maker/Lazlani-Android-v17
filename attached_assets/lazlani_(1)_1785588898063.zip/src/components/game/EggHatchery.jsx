import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { EGG_TYPES, BIRDS, hatchEgg, RARITY_COLORS } from "@/lib/gameData";

export default function EggHatchery({ profile, onHatch }) {
  const [hatching, setHatching] = useState(null);
  const [result, setResult] = useState(null);

  const getEggCount = (rarity) => profile?.[`eggs_${rarity}`] || 0;

  const handleHatch = (egg) => {
    const count = getEggCount(egg.id);
    if (count <= 0) return;
    setHatching(egg.id);
    setTimeout(() => {
      const birdKey = hatchEgg(egg.id);
      setResult({ bird: birdKey, egg: egg.id });
      setHatching(null);
      onHatch?.(egg.id, birdKey);
    }, 1500);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <h2 className="text-xl font-black text-white text-center mb-4">🥚 Yumurta Açma</h2>

      {/* Result popup */}
      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60"
            onClick={() => setResult(null)}
          >
            <motion.div
              initial={{ y: 50 }}
              animate={{ y: 0 }}
              className="bg-gradient-to-b from-purple-900 to-indigo-900 rounded-3xl p-8 text-center shadow-2xl border border-white/20"
              onClick={(e) => e.stopPropagation()}
            >
              <p className="text-white/60 text-sm mb-2">Yumurtadan çıkan kuş:</p>
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
                className="text-7xl mb-3"
              >
                {BIRDS[result.bird]?.emoji}
              </motion.div>
              <p className="text-white font-black text-xl">{BIRDS[result.bird]?.name}</p>
              <span
                className="inline-block mt-2 px-3 py-1 rounded-full text-xs font-bold"
                style={{
                  backgroundColor: RARITY_COLORS[BIRDS[result.bird]?.rarity]?.bg,
                  color: RARITY_COLORS[BIRDS[result.bird]?.rarity]?.text,
                }}
              >
                {BIRDS[result.bird]?.rarity?.toUpperCase()}
              </span>
              <button
                onClick={() => setResult(null)}
                className="block mx-auto mt-4 px-6 py-2 rounded-xl bg-white/20 text-white font-bold text-sm active:scale-95 transition-transform"
              >
                Harika! 🎉
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-3">
        {EGG_TYPES.map((egg) => {
          const count = getEggCount(egg.id);
          const isHatching = hatching === egg.id;
          return (
            <motion.button
              key={egg.id}
              onClick={() => handleHatch(egg)}
              disabled={count <= 0 || hatching}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border transition-all text-left ${
                count > 0
                  ? "bg-white/10 border-white/15 active:scale-[0.98]"
                  : "bg-white/5 border-white/5 opacity-40"
              }`}
              animate={isHatching ? { rotate: [0, -5, 5, -5, 5, 0], transition: { repeat: 3, duration: 0.3 } } : {}}
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-lg"
                style={{ backgroundColor: egg.color + "30", border: `2px solid ${egg.color}` }}
              >
                {egg.emoji}
              </div>
              <div className="flex-1">
                <p className="text-white font-bold text-sm">{egg.name}</p>
                <p className="text-white/50 text-xs">{count} adet</p>
              </div>
              {count > 0 && !hatching && (
                <span className="text-green-400 font-bold text-xs px-3 py-1 bg-green-500/20 rounded-lg">AÇ</span>
              )}
              {isHatching && (
                <span className="text-yellow-400 font-bold text-xs animate-pulse">Açılıyor...</span>
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}