import { motion } from "framer-motion";
import { getRank, RANKS } from "@/lib/gameData";
import { Play, Gift, Target, Trophy, Package } from "lucide-react";

export default function GameMenu({ profile, onChangeView }) {
  const rank = getRank(profile?.xp || 0);
  const nextRank = RANKS.find((r) => r.minXp > (profile?.xp || 0));
  const progress = nextRank
    ? ((profile?.xp || 0) - rank.minXp) / (nextRank.minXp - rank.minXp)
    : 1;

  const menuItems = [
    { id: "chapters",    icon: <Play className="w-6 h-6" />,         label: "Oyna",          color: "from-green-500 to-emerald-600" },
    { id: "daily",       icon: <Target className="w-6 h-6" />,       label: "Günlük Görev",  color: "from-blue-500 to-cyan-600" },
    { id: "leaderboard", icon: <Trophy className="w-6 h-6" />,       label: "Lider Tablosu", color: "from-yellow-500 to-amber-600" },
    { id: "eggs",        icon: <Package className="w-6 h-6" />,       label: "Yumurtalar",    color: "from-purple-500 to-pink-600" },
    { id: "collection",  icon: <Gift className="w-6 h-6" />,         label: "Koleksiyon",    color: "from-rose-500 to-red-600" },
  ];

  return (
    <div className="flex flex-col items-center gap-5 w-full max-w-sm mx-auto px-4">
      {/* Logo */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="text-center"
      >
        <h1 className="text-3xl font-black text-white tracking-tight" style={{ textShadow: "0 2px 10px rgba(0,0,0,0.5)" }}>
          🐦 Bird Match
        </h1>
        <p className="text-white/60 text-sm font-medium">Forest Edition</p>
      </motion.div>

      {/* Rank card */}
      <div className="w-full bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-2xl shadow-lg">
            {rank.emoji}
          </div>
          <div>
            <p className="text-white font-bold text-sm">{rank.name}</p>
            <p className="text-white/50 text-xs">Toplam {profile?.total_matches || 0} eşleşme</p>
          </div>
        </div>
        <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all" style={{ width: `${progress * 100}%` }} />
        </div>
        {nextRank && (
          <p className="text-white/40 text-[10px] mt-1 text-right">{nextRank.name}'e {nextRank.minXp - (profile?.xp || 0)} XP</p>
        )}
      </div>

      {/* Menu items */}
      <div className="w-full grid grid-cols-2 gap-3">
        {menuItems.map((item, i) => (
          <motion.button
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            onClick={() => onChangeView(item.id)}
            className={`flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br ${item.color} shadow-lg active:scale-95 transition-transform text-white`}

          >
            {item.icon}
            <span className="text-xs font-bold">{item.label}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}