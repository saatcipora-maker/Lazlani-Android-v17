import { motion } from "framer-motion";


export default function ChapterCompleteModal({ reward, chapter, onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <motion.div
        initial={{ scale: 0, rotate: -10 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: "spring", stiffness: 200 }}
        className="bg-gradient-to-b from-green-800 to-emerald-900 rounded-3xl p-8 text-center shadow-2xl border border-green-500/30 mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
          className="text-6xl mb-3"
        >
          🎉
        </motion.div>
        <h2 className="text-white font-black text-2xl mb-1">Tebrikler!</h2>
        <p className="text-white/60 text-sm mb-5">{chapter?.title} tamamlandı</p>

        <div className="flex items-center justify-center gap-6 mb-6">
          <motion.div initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.3 }} className="text-center">
            <p className="text-yellow-400 text-3xl font-black">🪙 {reward.coins}</p>
            <p className="text-white/50 text-xs">Coin</p>
          </motion.div>
          <motion.div initial={{ x: 30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.4 }} className="text-center">
            <p className="text-purple-400 text-3xl font-black">⭐ {reward.xp}</p>
            <p className="text-white/50 text-xs">XP</p>
          </motion.div>
        </div>

        {reward.multiplier >= 2 && (
          <p className="text-yellow-300 font-bold text-sm mb-3">
            🔥 x{reward.multiplier} Combo Bonusu!
          </p>
        )}

        <button
          onClick={onClose}
          className="px-8 py-3 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold text-sm shadow-lg active:scale-95 transition-transform"
        >
          Devam Et →
        </button>
      </motion.div>
    </div>
  );
}