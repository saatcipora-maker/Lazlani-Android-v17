import { motion } from "framer-motion";
import { generateChapter } from "@/lib/gameData";
import { Lock, ChevronRight } from "lucide-react";

export default function ChapterSelect({ currentChapter, onSelect }) {
  const chapters = Array.from({ length: 30 }, (_, i) => generateChapter(i + 1));

  return (
    <div className="w-full max-w-md mx-auto">
      <h2 className="text-xl font-black text-white text-center mb-4">Bölüm Seç</h2>
      <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1 scrollbar-hide">
        {chapters.map((ch) => {
          const unlocked = ch.num <= currentChapter;
          const isCurrent = ch.num === currentChapter;
          return (
            <motion.button
              key={ch.num}
              onClick={() => unlocked && onSelect(ch)}
              disabled={!unlocked}
              whileTap={unlocked ? { scale: 0.97 } : {}}
              className={`w-full flex items-center gap-3 p-3 rounded-2xl border transition-all text-left ${
                isCurrent
                  ? "bg-gradient-to-r from-amber-500/30 to-yellow-500/20 border-yellow-400/50 ring-1 ring-yellow-400/30"
                  : unlocked
                  ? "bg-white/10 border-white/10 hover:bg-white/15"
                  : "bg-white/5 border-white/5 opacity-40"
              }`}
            >
              {/* Chapter number */}
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm flex-shrink-0 ${
                isCurrent ? "bg-yellow-500 text-yellow-900" : unlocked ? "bg-white/20 text-white" : "bg-white/10 text-white/40"
              }`}>
                {unlocked ? ch.num : <Lock className="w-4 h-4" />}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm">{ch.zone.emoji}</span>
                  <span className="text-white font-bold text-sm truncate">{ch.title}</span>
                </div>
                <p className="text-white/60 text-xs truncate">{ch.description}</p>
              </div>

              {/* Rewards */}
              <div className="flex flex-col items-end gap-0.5 flex-shrink-0">
                <span className="text-yellow-400 text-xs font-bold">🪙 {ch.coinReward}</span>
                <span className="text-purple-300 text-xs font-bold">⭐ {ch.xpReward}xp</span>
              </div>

              {unlocked && <ChevronRight className="w-4 h-4 text-white/40 flex-shrink-0" />}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}