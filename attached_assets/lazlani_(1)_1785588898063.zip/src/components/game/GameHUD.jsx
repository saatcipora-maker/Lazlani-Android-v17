import { getRank } from "@/lib/gameData";
import { ArrowLeft } from "lucide-react";

export default function GameHUD({ profile, view, onChangeView }) {
  const rank = getRank(profile?.xp || 0);

  return (
    <div className="w-full flex items-center justify-between px-3 py-2 bg-black/30 backdrop-blur-sm flex-shrink-0">
      {/* Left */}
      <div className="flex items-center gap-2">
        {view !== "menu" && (
          <button
            onClick={() => onChangeView("menu")}
            className="rounded-xl bg-white/15 flex items-center justify-center active:scale-90 transition-transform p-2.5"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
        )}
        <div className="flex items-center gap-1">
          <span className="text-lg">{rank.emoji}</span>
          <span className="text-white font-bold text-xs">{rank.name}</span>
        </div>
      </div>

      {/* Right — stats */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          <span className="text-sm">🪙</span>
          <span className="text-yellow-400 font-bold text-sm">{profile?.coins || 0}</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-sm">⭐</span>
          <span className="text-purple-300 font-bold text-sm">{profile?.xp || 0}</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-sm">📊</span>
          <span className="text-white font-bold text-sm">Lv.{profile?.level || 1}</span>
        </div>
      </div>
    </div>
  );
}