import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BIRDS, getComboMultiplier } from "@/lib/gameData";
import { createBoard, swapCells, findAllMatches, removeAndDrop, shuffleBoard, bombRow, autoMatch } from "@/lib/gameBoard";

export default function GameBoard({ chapter, profile, onMatchComplete, onGameOver, onUsepower }) {
  const [board, setBoard] = useState([]);
  const [selected, setSelected] = useState(null);
  const [movesLeft, setMovesLeft] = useState(chapter.maxMoves);
  const [timeLeft, setTimeLeft] = useState(chapter.timeLimit);
  const [frozen, setFrozen] = useState(false);
  const [matchedCount, setMatchedCount] = useState(0);
  const [combo, setCombo] = useState(0);
  const [comboDisplay, setComboDisplay] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [particles, setParticles] = useState([]);

  // Init board
  useEffect(() => {
    setBoard(createBoard(chapter.gridSize, chapter.birds));
    setMovesLeft(chapter.maxMoves);
    setTimeLeft(chapter.timeLimit);
    setMatchedCount(0);
    setCombo(0);
  }, [chapter.num]);

  // Timer
  useEffect(() => {
    if (!chapter.timeLimit || frozen) return;
    if (timeLeft <= 0) {
      onGameOver?.("time");
      return;
    }
    const t = setInterval(() => setTimeLeft((p) => p - 1), 1000);
    return () => clearInterval(t);
  }, [chapter.timeLimit, timeLeft, frozen]);

  const spawnParticles = useCallback((row, col) => {
    const newP = Array.from({ length: 6 }, (_, i) => ({
      id: `${Date.now()}-${i}`,
      x: col * 60 + 30,
      y: row * 60 + 30,
      dx: (Math.random() - 0.5) * 80,
      dy: (Math.random() - 0.5) * 80,
    }));
    setParticles((p) => [...p, ...newP]);
    setTimeout(() => setParticles((p) => p.filter((pp) => !newP.find((n) => n.id === pp.id))), 600);
  }, []);

  const processMatches = useCallback((currentBoard, currentCombo) => {
    const matches = findAllMatches(currentBoard);
    if (matches.size === 0) {
      setCombo(0);
      setIsProcessing(false);
      return;
    }

    const newCombo = currentCombo + 1;
    const multiplier = getComboMultiplier(newCombo);

    if (multiplier >= 2) {
      setComboDisplay({ multiplier, id: Date.now() });
      setTimeout(() => setComboDisplay(null), 1200);
    }

    // Spawn particles for matched cells
    matches.forEach((key) => {
      const [r, c] = key.split("-").map(Number);
      spawnParticles(r, c);
    });

    const { board: newBoard, matchedBirds } = removeAndDrop(currentBoard, matches, chapter.birds);

    // Count target matches
    const targetMatched = matchedBirds[chapter.targetBird] || 0;
    const totalMatched = matchedCount + targetMatched;

    setBoard(newBoard);
    setCombo(newCombo);
    setMatchedCount(totalMatched);

    if (totalMatched >= chapter.matchCount) {
      setTimeout(() => onMatchComplete?.({ combo: newCombo, multiplier }), 400);
      return;
    }

    // Check for chain matches
    setTimeout(() => processMatches(newBoard, newCombo), 350);
  }, [chapter, matchedCount, spawnParticles, onMatchComplete]);

  const handleCellClick = (r, c) => {
    if (isProcessing) return;
    if (movesLeft <= 0) {
      onGameOver?.("moves");
      return;
    }

    if (!selected) {
      setSelected({ r, c });
      return;
    }

    // Check adjacency
    const dr = Math.abs(selected.r - r);
    const dc = Math.abs(selected.c - c);
    if ((dr === 1 && dc === 0) || (dr === 0 && dc === 1)) {
      setIsProcessing(true);
      const newBoard = swapCells(board, selected.r, selected.c, r, c);
      const matches = findAllMatches(newBoard);

      if (matches.size > 0) {
        setBoard(newBoard);
        setMovesLeft((m) => m - 1);
        setSelected(null);
        setTimeout(() => processMatches(newBoard, combo), 200);
      } else {
        // Invalid swap — revert
        setSelected(null);
        setIsProcessing(false);
      }
    } else {
      setSelected({ r, c });
    }
  };

  // Powers
  const handlePower = (powerId) => {
    if (isProcessing) return;
    if (powerId === "bomb" && profile?.power_bomb > 0) {
      const randomRow = Math.floor(Math.random() * chapter.gridSize);
      const { board: nb } = bombRow(board, randomRow, chapter.birds);
      setBoard(nb);
      onUsepower?.("power_bomb");
      setTimeout(() => processMatches(nb, combo), 300);
    } else if (powerId === "wind" && profile?.power_wind > 0) {
      setBoard(shuffleBoard(board, chapter.birds));
      onUsepower?.("power_wind");
    } else if (powerId === "freeze" && profile?.power_freeze > 0) {
      setFrozen(true);
      onUsepower?.("power_freeze");
      setTimeout(() => setFrozen(false), 10000);
    } else if (powerId === "auto_match" && profile?.power_auto_match > 0) {
      const nb = autoMatch(board, chapter.targetBird, chapter.birds);
      setBoard(nb);
      onUsepower?.("power_auto_match");
      setTimeout(() => processMatches(nb, combo), 300);
    } else if (powerId === "golden" && profile?.power_golden_feed > 0) {
      // Place 3 target birds randomly
      const nb = board.map((row) => row.map((cell) => ({ ...cell })));
      let placed = 0;
      const size = chapter.gridSize;
      while (placed < 3) {
        const rr = Math.floor(Math.random() * size);
        const cc = Math.floor(Math.random() * size);
        if (nb[rr][cc].bird !== chapter.targetBird) {
          nb[rr][cc].bird = chapter.targetBird;
          placed++;
        }
      }
      setBoard(nb);
      onUsepower?.("power_golden_feed");
    }
  };

  const progress = Math.min(1, matchedCount / chapter.matchCount);
  const gridPx = chapter.gridSize * 60;

  return (
    <div className="flex flex-col items-center gap-3 w-full">
      {/* HUD */}
      <div className="w-full flex items-center justify-between px-2">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{BIRDS[chapter.targetBird]?.emoji}</span>
          <span className="text-white font-bold text-sm">{matchedCount}/{chapter.matchCount}</span>
        </div>
        <div className="flex items-center gap-3">
          {chapter.timeLimit > 0 && (
            <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${timeLeft <= 10 ? "bg-red-500/80 animate-pulse" : "bg-white/20"}`}>
              <span className="text-white text-xs">⏱</span>
              <span className="text-white font-bold text-sm">{timeLeft}s</span>
              {frozen && <span className="text-xs">❄️</span>}
            </div>
          )}
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-white/20">
            <span className="text-white text-xs">🎯</span>
            <span className="text-white font-bold text-sm">{movesLeft}</span>
          </div>
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full h-3 bg-white/20 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-yellow-400 to-amber-500 rounded-full"
          animate={{ width: `${progress * 100}%` }}
          transition={{ type: "spring", stiffness: 200 }}
        />
      </div>

      {/* Combo display */}
      <AnimatePresence>
        {comboDisplay && (
          <motion.div
            key={comboDisplay.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1.2, opacity: 1 }}
            exit={{ scale: 2, opacity: 0 }}
            className="absolute top-24 z-50 text-4xl font-black text-yellow-300 drop-shadow-lg"
            style={{ textShadow: "0 0 20px rgba(234,179,8,0.8)" }}
          >
            x{comboDisplay.multiplier} COMBO! 🔥
          </motion.div>
        )}
      </AnimatePresence>

      {/* Board */}
      <div
        className="relative rounded-2xl bg-white/10 backdrop-blur-sm p-2 overflow-hidden"
        style={{ width: gridPx + 16, height: gridPx + 16, touchAction: "none" }}
      >
        {/* Particles */}
        <AnimatePresence>
          {particles.map((p) => (
            <motion.div
              key={p.id}
              initial={{ x: p.x, y: p.y, scale: 1, opacity: 1 }}
              animate={{ x: p.x + p.dx, y: p.y + p.dy, scale: 0, opacity: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="absolute w-3 h-3 rounded-full bg-yellow-400 pointer-events-none z-40"
            />
          ))}
        </AnimatePresence>

        {board.map((row, r) =>
          row.map((cell, c) => {
            const bird = BIRDS[cell.bird];
            const isSelected = selected?.r === r && selected?.c === c;
            return (
              <motion.button
                key={cell.id}
                layout
                onClick={() => handleCellClick(r, c)}
                className={`absolute flex items-center justify-center rounded-xl transition-all ${
                  isSelected ? "ring-2 ring-yellow-400 scale-110 z-10" : "hover:scale-105"
                }`}
                style={{
                  width: 54,
                  height: 54,
                  left: c * 60 + 3,
                  top: r * 60 + 3,
                  background: bird
                    ? `radial-gradient(circle, ${bird.color}40, ${bird.color}20)`
                    : "transparent",
                  border: isSelected ? "2px solid #facc15" : "1px solid rgba(255,255,255,0.15)",
                }}
                whileTap={{ scale: 0.9 }}
              >
                <span className="text-2xl select-none">{bird?.emoji || ""}</span>
              </motion.button>
            );
          })
        )}
      </div>

      {/* Powers */}
      <div className="flex items-center gap-2 flex-wrap justify-center">
        {[
          { id: "bomb", emoji: "💣", count: profile?.power_bomb, label: "Bombalı Dal" },
          { id: "golden", emoji: "🌾", count: profile?.power_golden_feed, label: "Altın Yem" },
          { id: "freeze", emoji: "❄️", count: profile?.power_freeze, label: "Donma Gücü" },
          { id: "wind", emoji: "🌪️", count: profile?.power_wind, label: "Rüzgar Gücü" },
          { id: "auto_match", emoji: "🤖", count: profile?.power_auto_match, label: "Otomatik Eşleştirme" },
        ].map((p) => (
          <button
            key={p.id}
            onClick={() => handlePower(p.id)}
            disabled={!p.count || isProcessing}
            className="flex flex-col items-center justify-center gap-0.5 w-12 h-12 rounded-xl bg-white/15 backdrop-blur-sm border border-white/20 disabled:opacity-30 active:scale-90 transition-transform"
            aria-label={p.label}
          >
            <span className="text-lg">{p.emoji}</span>
            <span className="text-[10px] text-white font-bold">{p.count || 0}</span>
          </button>
        ))}
      </div>
    </div>
  );
}