import { motion } from "framer-motion";

export default function GameOverModal({ reason, onRetry, onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="bg-gradient-to-b from-red-900 to-rose-900 rounded-3xl p-8 text-center shadow-2xl border border-red-500/30 mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="text-5xl mb-3">😔</div>
        <h2 className="text-white font-black text-xl mb-2">Bölüm Başarısız</h2>
        <p className="text-white/60 text-sm mb-6">
          {reason === "lose_time" ? "Süre doldu!" : "Hamle hakkın bitti!"}
        </p>

        <div className="flex items-center gap-3 justify-center">
          <button
            onClick={onRetry}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-600 text-white font-bold text-sm shadow-lg active:scale-95 transition-transform"
          >
            Tekrar Dene 🔄
          </button>
          <button
            onClick={onClose}
            className="px-6 py-3 rounded-2xl bg-white/15 text-white font-bold text-sm active:scale-95 transition-transform"
          >
            Geri Dön
          </button>
        </div>
      </motion.div>
    </div>
  );
}