import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Send, Smile, X, Ban, Plus, Loader2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import ChatBubble from "@/components/community/ChatBubble";
import BookSharePicker from "@/components/community/BookSharePicker";
import ShareMenu from "@/components/community/ShareMenu";
import { containsProfanity } from "@/utils/profanityFilter";

const EMOJIS = ["😀", "😂", "❤️", "🔥", "👍", "👏", "🎉", "😍", "🤔", "😢", "💯", "✨", "📚", "✍️", "🌟", "💜"];
const GEZEP_TRIGGER = /gezep/i;

export default function CommunityChat({ getUserRole, nickname }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showBookPicker, setShowBookPicker] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const fileRef = useRef(null);
  const isAdmin = user?.role === "admin";
  const myRole = getUserRole?.(user?.email) || "user";
  const effectiveRole = isAdmin ? "admin" : myRole;
  const canModerate = effectiveRole !== "user";
  const displayName = nickname || user?.full_name || user?.email?.split("@")[0];

  // Fetch dynamic banned words
  const { data: bannedWords = [] } = useQuery({
    queryKey: ["banned-words"],
    queryFn: () => base44.entities.BannedWord.list("-created_date", 500),
    staleTime: 30000,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ["community-messages"],
    queryFn: () => base44.entities.CommunityMessage.list("-created_date", 80),
    staleTime: 3000,
  });

  const { data: myLikes = [] } = useQuery({
    queryKey: ["community-likes", user?.email],
    queryFn: () => base44.entities.CommunityLike.filter({ user_email: user.email }, "-created_date", 200),
    enabled: !!user?.email,
  });

  const likedMsgIds = new Set(myLikes.map((l) => l.message_id));

  const { data: bans = [] } = useQuery({
    queryKey: ["community-bans", user?.email],
    queryFn: () => base44.entities.CommunityChatBan.filter({ user_email: user.email, is_active: true }, "-created_date", 5),
    enabled: !!user?.email,
    staleTime: 10000,
  });

  const activeBan = bans.find((b) => b.is_active && b.expires_at && new Date(b.expires_at) > new Date());
  const isKicked = activeBan?.ban_type === "kick";
  const isMuted = activeBan?.ban_type === "mute";

  useEffect(() => {
    const unsub = base44.entities.CommunityMessage.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["community-messages"] });
    });
    return unsub;
  }, [queryClient]);

  useEffect(() => {
    if (scrollRef.current) {
      requestAnimationFrame(() => {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      });
    }
  }, [messages.length]);

  const sortedMessages = [...messages].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

  const makePayload = (extra) => ({
    user_email: user.email,
    user_name: displayName,
    user_avatar: user.avatar_url || "",
    user_role: effectiveRole,
    like_count: 0,
    ...extra,
  });

  // Check profanity including dynamic banned words
  const checkProfanityLocal = (text) => {
    if (containsProfanity(text)) return true;
    const lower = text.toLowerCase();
    return bannedWords.some((bw) => bw.word && lower.includes(bw.word.toLowerCase()));
  };

  // Trigger Gezep bot response
  const triggerGezep = useCallback(async (triggerText) => {
    const recent = sortedMessages.slice(-8).map((m) => ({
      user_name: m.user_name,
      content: m.content,
    }));
    try {
      const res = await base44.functions.invoke("gezepBot", {
        triggerMessage: triggerText,
        recentMessages: recent,
      });
      if (res.data?.reply) {
        await base44.entities.CommunityMessage.create({
          user_email: "gezep@lazlani.com",
          user_name: "Gezep",
          user_avatar: "",
          user_role: "admin",
          content: res.data.reply,
          type: "text",
          like_count: 0,
        });
      }
    } catch {
      // Bot error — silently ignore
    }
  }, [sortedMessages]);

  const handleSend = useCallback(async () => {
    const text = message.trim();
    if (!text || sending || isMuted || isKicked) return;

    // Client-side profanity check (static + dynamic)
    if (checkProfanityLocal(text)) {
      toast.error("Mesajınız uygunsuz içerik nedeniyle engellendi");
      setMessage("");
      base44.functions.invoke("checkProfanity", { content: text, type: "community_chat", userName: displayName }).then((res) => {
        if (res.data?.blocked) {
          queryClient.invalidateQueries({ queryKey: ["community-bans"] });
        }
      }).catch(() => {});
      return;
    }

    setSending(true);
    setMessage("");
    const payload = makePayload({ content: text, type: "text" });
    if (replyTo) {
      payload.reply_to_id = replyTo.id;
      payload.reply_to_name = replyTo.user_name;
      payload.reply_to_content = replyTo.content?.slice(0, 100);
    }
    await base44.entities.CommunityMessage.create(payload);
    setReplyTo(null);
    setSending(false);
    inputRef.current?.focus();

    // Check if message mentions Gezep
    if (GEZEP_TRIGGER.test(text)) {
      setTimeout(() => triggerGezep(text), 3000);
    }
  }, [message, sending, isMuted, isKicked, user, effectiveRole, replyTo, displayName, queryClient, bannedWords, triggerGezep]);

  const handleBookShare = async (book) => {
    setShowBookPicker(false);
    setSending(true);
    await base44.entities.CommunityMessage.create(makePayload({
      content: "📖 Kitap Paylaşımı",
      type: "book_share",
      book_id: book.id,
      book_title: book.title,
      book_cover: book.cover_image || "",
      book_description: (book.description || "").slice(0, 120),
      book_author: book.author_name || "",
    }));
    setSending(false);
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await base44.entities.CommunityMessage.create(makePayload({
      content: "📷 Fotoğraf",
      type: "image",
      image_url: file_url,
    }));
    setUploadingImage(false);
    e.target.value = "";
  };

  const handleLike = async (msgId) => {
    if (likedMsgIds.has(msgId)) {
      const existing = myLikes.find((l) => l.message_id === msgId);
      if (existing) await base44.entities.CommunityLike.delete(existing.id);
      const msg = messages.find((m) => m.id === msgId);
      if (msg && (msg.like_count || 0) > 0) await base44.entities.CommunityMessage.update(msgId, { like_count: (msg.like_count || 1) - 1 });
    } else {
      await base44.entities.CommunityLike.create({ message_id: msgId, user_email: user.email });
      const msg = messages.find((m) => m.id === msgId);
      await base44.entities.CommunityMessage.update(msgId, { like_count: (msg?.like_count || 0) + 1 });
    }
    queryClient.invalidateQueries({ queryKey: ["community-likes"] });
    queryClient.invalidateQueries({ queryKey: ["community-messages"] });
  };

  const handleDelete = async (msgId) => {
    await base44.entities.CommunityMessage.delete(msgId);
    toast.success("Mesaj silindi");
  };

  if (isKicked) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
        <Ban className="w-12 h-12 text-orange-400/40 mb-3" />
        <p className="text-sm font-semibold text-orange-400">Odadan uzaklaştırıldınız</p>
        <p className="text-xs text-muted-foreground mt-1">Süre: {activeBan.duration_label || "Geçici"}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col flex-1 min-h-0 overflow-hidden">
      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto overflow-x-hidden px-2 py-2 space-y-2 scrollbar-hide">
        {sortedMessages.map((msg) => (
          <ChatBubble
            key={msg.id}
            msg={msg}
            isOwn={msg.user_email === user?.email}
            isLiked={likedMsgIds.has(msg.id)}
            onLike={handleLike}
            onReply={setReplyTo}
            canDelete={msg.user_email === user?.email || canModerate}
            onDelete={handleDelete}
          />
        ))}
        {messages.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-sm">Topluluk odasına hoş geldiniz! 💜</p>
            <p className="text-muted-foreground/60 text-xs mt-1">İlk mesajı siz gönderin</p>
          </div>
        )}
      </div>

      {/* Emoji picker */}
      {showEmoji && (
        <div className="px-3 py-2 flex flex-wrap gap-1.5 border-t flex-shrink-0" style={{ background: "rgba(38,18,55,0.7)", borderColor: "rgba(200,140,255,0.06)" }}>
          {EMOJIS.map((e) => (
            <button key={e} onClick={() => { setMessage((prev) => prev + e); setShowEmoji(false); inputRef.current?.focus(); }}
              className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-primary/10 text-lg active:scale-90 transition-transform">
              {e}
            </button>
          ))}
          <button onClick={() => setShowEmoji(false)} className="ml-auto btn-sm text-muted-foreground"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Reply preview */}
      {replyTo && (
        <div className="px-3 py-2 flex items-center gap-2 border-t flex-shrink-0" style={{ background: "rgba(234,179,8,0.06)", borderColor: "rgba(234,179,8,0.12)" }}>
          <div className="flex-1 min-w-0" style={{ borderLeft: "3px solid #EAB308", paddingLeft: 8 }}>
            <p className="text-[10px] font-semibold text-yellow-400">{replyTo.user_name}</p>
            <p className="text-[10px] text-yellow-200/60 truncate">{replyTo.content}</p>
          </div>
          <button onClick={() => setReplyTo(null)} className="btn-sm text-muted-foreground"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Input area */}
      {isMuted ? (
        <div className="px-4 py-3 flex items-center gap-2 justify-center border-t flex-shrink-0 safe-bottom"
          style={{ background: "rgba(239,68,68,0.08)", borderColor: "rgba(239,68,68,0.1)" }}>
          <Ban className="w-4 h-4 text-red-400" />
          <span className="text-xs text-red-400 font-medium">Topluluk kurallarını ihlal ettiğiniz için mesaj gönderme yetkiniz geçici olarak devre dışı bırakılmıştır.</span>
        </div>
      ) : (
        <div className="flex-shrink-0 border-t safe-bottom"
          style={{ background: "rgba(30,12,45,0.92)", borderColor: "rgba(200,140,255,0.06)", backdropFilter: "blur(20px)" }}>
          <div className="px-2 py-2 flex items-center gap-1.5">
            {/* Share button */}
            <div className="relative">
              <button
                onClick={() => setShowShareMenu((p) => !p)}
                className="w-10 h-10 flex items-center justify-center rounded-full text-muted-foreground hover:text-primary active:scale-90 transition-transform">
                {uploadingImage ? <Loader2 className="w-5 h-5 animate-spin text-primary" /> : <Plus className="w-5 h-5" />}
              </button>
              <ShareMenu
                open={showShareMenu}
                onClose={() => setShowShareMenu(false)}
                onPhoto={() => fileRef.current?.click()}
                onBook={() => setShowBookPicker(true)}
              />
            </div>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />

            {/* Emoji */}
            <button onClick={() => setShowEmoji((p) => !p)}
              className="w-10 h-10 flex items-center justify-center rounded-full text-muted-foreground hover:text-primary active:scale-90 transition-transform">
              <Smile className="w-5 h-5" />
            </button>

            {/* Text input */}
            <input
              ref={inputRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
              placeholder="Mesaj yaz..."
              className="flex-1 min-w-0 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none py-2.5"
              style={{ fontSize: "16px" }}
              maxLength={500}
            />

            {/* Send */}
            <button
              onClick={handleSend}
              disabled={!message.trim() || sending}
              className="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center active:scale-90 transition-all disabled:opacity-30"
              style={{ background: message.trim() ? "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" : "transparent" }}>
              <Send className={`w-4 h-4 ${message.trim() ? "text-white" : "text-muted-foreground"}`} />
            </button>
          </div>
        </div>
      )}

      {/* Book picker modal */}
      {showBookPicker && <BookSharePicker onSelect={handleBookShare} onClose={() => setShowBookPicker(false)} />}
    </div>
  );
}