import { Shield, Star, Crown, X, Bot } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const ROLE_CONFIG = {
  admin: { label: "Yönetici", icon: Crown, gradient: "linear-gradient(135deg, #E88C40, #F0B060)" },
  operator: { label: "Operatör", icon: Shield, gradient: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" },
  vip: { label: "VIP", icon: Star, gradient: "linear-gradient(135deg, #F59E0B, #EAB308)" },
};

const GEZEP_BOT = {
  id: "gezep-bot",
  user_email: "gezep@lazlani.com",
  user_name: "Gezep",
  user_avatar: "",
  user_role: "bot",
};

export default function OnlinePanel({ open, onClose, activeUsers = [], onUserTap }) {
  const sorted = [GEZEP_BOT, ...[...activeUsers].sort((a, b) => {
    const order = { admin: 0, operator: 1, vip: 2, user: 3 };
    return (order[a.user_role] || 3) - (order[b.user_role] || 3);
  })];

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[55] bg-black/40"
            onClick={onClose}
          />
          {/* Panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 z-[56] w-72 max-w-[85vw] flex flex-col overflow-hidden"
            style={{
              background: "linear-gradient(170deg, rgba(38,18,55,0.97), rgba(20,8,30,0.98))",
              borderLeft: "1px solid rgba(200,140,255,0.08)",
              boxShadow: "-8px 0 40px rgba(0,0,0,0.5)",
              paddingTop: "env(safe-area-inset-top, 0px)",
              paddingBottom: "env(safe-area-inset-bottom, 0px)",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-4 border-b" style={{ borderColor: "rgba(200,140,255,0.06)" }}>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-sm font-heading font-bold text-foreground">Çevrimiçi ({activeUsers.length + 1})</span>
              </div>
              <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center active:scale-90 transition-transform"
                style={{ background: "rgba(255,255,255,0.05)" }}>
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            {/* User list */}
            <div className="flex-1 overflow-y-auto scrollbar-hide px-3 py-3 space-y-1.5">
              {sorted.map(u => {
                const isBot = u.user_role === "bot";
                const rc = isBot ? null : ROLE_CONFIG[u.user_role];
                const RoleIcon = rc?.icon;
                return (
                  <button
                    key={u.id}
                    onClick={() => !isBot && onUserTap?.(u)}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-left active:scale-[0.98] transition-transform"
                    style={{ background: isBot ? "rgba(6,182,212,0.06)" : "rgba(38,18,55,0.3)", border: isBot ? "1px solid rgba(6,182,212,0.1)" : "1px solid rgba(200,140,255,0.04)" }}
                  >
                    {/* Avatar */}
                    <div className="relative flex-shrink-0">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold overflow-hidden ${rc ? "ring-2" : ""} ${isBot ? "ring-2 ring-cyan-400/50" : ""}`}
                        style={{ background: isBot ? "linear-gradient(135deg, #06b6d4, #8b5cf6)" : (rc?.gradient || "linear-gradient(135deg, rgba(130,60,210,0.15), rgba(240,140,60,0.08))") }}>
                        {isBot ? (
                          <Bot className="w-4.5 h-4.5 text-white" />
                        ) : u.user_avatar ? (
                          <img src={u.user_avatar} alt="" className="w-full h-full rounded-full object-cover" />
                        ) : (
                          <span className={rc ? "text-white" : "text-primary"}>
                            {(u.user_name || u.user_email)[0]?.toUpperCase()}
                          </span>
                        )}
                      </div>
                      <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-green-400 ring-2 ring-background" />
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-semibold truncate ${isBot ? "text-cyan-400" : rc ? "text-primary" : "text-foreground"}`}>
                        {u.nickname || u.user_name || u.user_email.split("@")[0]}
                      </p>
                      {isBot && (
                        <span className="inline-flex items-center gap-0.5 text-[7px] font-bold text-white px-1.5 py-0.5 rounded-full mt-0.5"
                          style={{ background: "linear-gradient(135deg, #06b6d4, #8b5cf6)" }}>
                          <Bot className="w-2 h-2" /> Bot
                        </span>
                      )}
                      {rc && (
                        <span className="inline-flex items-center gap-0.5 text-[7px] font-bold text-white px-1.5 py-0.5 rounded-full mt-0.5"
                          style={{ background: rc.gradient }}>
                          {RoleIcon && <RoleIcon className="w-2 h-2" />} {rc.label}
                        </span>
                      )}
                    </div>

                    {/* Online dot */}
                    <span className={`text-[8px] font-medium ${isBot ? "text-cyan-400" : "text-green-400"}`}>
                      {isBot ? "Her zaman aktif" : "Çevrimiçi"}
                    </span>
                  </button>
                );
              })}
              {sorted.length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-8">Odada kimse yok</p>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}