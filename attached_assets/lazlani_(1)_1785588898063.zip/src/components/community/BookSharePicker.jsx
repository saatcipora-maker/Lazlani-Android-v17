import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { X, BookOpen, Search } from "lucide-react";

export default function BookSharePicker({ onSelect, onClose }) {
  const { user } = useAuth();
  const [search, setSearch] = useState("");

  const { data: myBooks = [], isLoading } = useQuery({
    queryKey: ["my-books-share", user?.email],
    queryFn: () => base44.entities.Book.filter({ author_email: user.email, status: "yayinda" }, "-created_date", 50),
    enabled: !!user?.email,
  });

  const filtered = search
    ? myBooks.filter(b => b.title?.toLowerCase().includes(search.toLowerCase()))
    : myBooks;

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-md rounded-t-3xl p-5 animate-fade-in-up max-h-[70vh] flex flex-col"
        style={{
          background: "linear-gradient(170deg, rgba(38,18,55,0.97), rgba(20,8,30,0.98))",
          border: "1px solid rgba(200,140,255,0.08)",
          paddingBottom: "calc(1.5rem + env(safe-area-inset-bottom, 0px))",
        }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-heading font-bold text-foreground">Kitap Paylaş</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.05)" }}>
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Kitap ara..."
            className="w-full pl-9 pr-3 py-2.5 rounded-xl text-sm outline-none"
            style={{ fontSize: "16px", background: "rgba(38,18,55,0.5)", border: "1px solid rgba(200,140,255,0.06)" }}
          />
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto scrollbar-hide space-y-2">
          {isLoading ? (
            <p className="text-xs text-muted-foreground text-center py-8">Yükleniyor...</p>
          ) : filtered.length === 0 ? (
            <div className="text-center py-8">
              <BookOpen className="w-8 h-8 text-muted-foreground/20 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground">
                {myBooks.length === 0 ? "Yayınlanmış kitabınız yok" : "Sonuç bulunamadı"}
              </p>
            </div>
          ) : filtered.map(book => (
            <button
              key={book.id}
              onClick={() => onSelect(book)}
              className="w-full flex items-center gap-3 p-3 rounded-2xl text-left active:scale-[0.98] transition-transform"
              style={{ background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}
            >
              <div className="w-12 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-primary/10">
                {book.cover_image ? (
                  <img src={book.cover_image} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center"><BookOpen className="w-5 h-5 text-primary/30" /></div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate text-foreground">{book.title}</p>
                <p className="text-[10px] text-muted-foreground truncate">{book.category || "Kitap"}</p>
                {book.description && (
                  <p className="text-[10px] text-muted-foreground/60 line-clamp-1 mt-0.5">{book.description}</p>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}