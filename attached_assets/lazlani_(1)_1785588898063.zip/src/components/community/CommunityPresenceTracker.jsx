import { useEffect, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

const PING_INTERVAL = 15000;
const STALE_THRESHOLD = 30000;

export function useCommunityPresence(nickname) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const presenceRef = useRef(null);
  const intervalRef = useRef(null);

  const { data: roles = [] } = useQuery({
    queryKey: ["community-roles"],
    queryFn: () => base44.entities.CommunityRole.list("-created_date", 200),
    staleTime: 60000,
  });

  const getUserRole = (email) => {
    if (!email) return "user";
    const role = roles.find(r => r.user_email === email);
    return role?.role || "user";
  };

  useEffect(() => {
    if (!user?.email || !nickname) return;

    const join = async () => {
      const existing = await base44.entities.CommunityPresence.filter({ user_email: user.email }, "-created_date", 1);
      const myRole = getUserRole(user.email);
      const adminRole = user.role === "admin" ? "admin" : myRole;
      const data = {
        last_ping: new Date().toISOString(),
        user_name: nickname,
        user_avatar: user.avatar_url || "",
        user_role: adminRole,
      };

      if (existing.length > 0) {
        try {
          await base44.entities.CommunityPresence.update(existing[0].id, data);
          presenceRef.current = existing[0];
        } catch {
          // Record was deleted, create a new one
          presenceRef.current = await base44.entities.CommunityPresence.create({ user_email: user.email, ...data });
        }
      } else {
        presenceRef.current = await base44.entities.CommunityPresence.create({
          user_email: user.email,
          ...data,
        });
      }
    };

    join();

    intervalRef.current = setInterval(async () => {
      if (presenceRef.current?.id) {
        await base44.entities.CommunityPresence.update(presenceRef.current.id, { last_ping: new Date().toISOString() });
      }
    }, PING_INTERVAL);

    return () => {
      clearInterval(intervalRef.current);
      if (presenceRef.current?.id) {
        base44.entities.CommunityPresence.delete(presenceRef.current.id).catch(() => {});
        presenceRef.current = null;
      }
    };
  }, [user?.email, nickname, roles]);

  const { data: presenceList = [] } = useQuery({
    queryKey: ["community-presence"],
    queryFn: () => base44.entities.CommunityPresence.list("-last_ping", 100),
    refetchInterval: 10000,
  });

  useEffect(() => {
    const unsub = base44.entities.CommunityPresence.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["community-presence"] });
    });
    return unsub;
  }, [queryClient]);

  const now = Date.now();
  const activeUsers = presenceList.filter(p => p.last_ping && (now - new Date(p.last_ping).getTime()) < STALE_THRESHOLD);

  return { activeUsers, getUserRole, roles };
}