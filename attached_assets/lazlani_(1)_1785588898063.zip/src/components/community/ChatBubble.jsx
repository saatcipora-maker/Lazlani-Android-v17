import { useState, useRef } from "react";
import { Heart, Reply, Shield, Star, Crown, BookOpen, Trash2, Bot } from "lucide-react";
import { Link } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";

const ROLE_BADGES = {
  admin: { label: "Yönetici", icon: Crown, bg: "linear-gradient(135deg, #E88C40, #F0B060)", nameColor: "text-amber-400" },
  operator: { label: "Operatör", icon: Shield, bg: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))", nameColor: "text-primary" },
  vip: { label: "VIP", icon: Star, bg: "linear-gradient(135deg, #F59E0B, #EAB308)", nameColor: "text-yellow-400" },
};

const isGezep = (email) => email === "gezep@lazlani.com";

export default function ChatBubble({ msg, isOwn, onLike, onReply, isLiked, canDelete, onDelete }) {
  const [showActions, setShowActions] = useState(false);
  const timerRef = useRef(null);
  const isBot = isGezep(msg.user_email);
  const roleCfg = isBot ? null : ROLE_BADGES[msg.user_role];
  const RoleIcon = roleCfg?.icon;

  const onTouchStart = () => { timerRef.current = setTimeout(() => setShowActions(true), 400); };
  const onTouchEnd = () => clearTimeout(timerRef.current);

  // Avatar content
  const avatarContent = isBot ? (
    <div className="w-full h-full flex items-center justify-center"
      style={{ background: "linear-gradient(135deg, #06b6d4, #8b5cf6)" }}>
      <Bot className="w-4 h-4 text-white" />
    </div>
  ) : msg.user_avatar ? (
    <img src={msg.user_avatar} alt="" className="w-full h-full rounded-full object-cover" />
  ) : (
    <span className={roleCfg ? "text-white" : "text-primary"}>{(msg.user_name || "?")[0]?.toUpperCase()}</span>
  );

  const avatarWrapper = (
    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold overflow-hidden ${roleCfg ? "ring-2" : ""} ${isBot ? "ring-2 ring-cyan-400/50" : ""}`}
      style={{ background: isBot ? undefined : (roleCfg?.bg || "linear-gradient(135deg, rgba(130,60,210,0.15), rgba(240,140,60,0.08))") }}>
      {avatarContent}
    </div>
  );

  return (
    <div className={`flex gap-2 ${isOwn ? "flex-row-reverse" : ""}`}>
      {/* Avatar */}
      {isBot ? (
        <div className="flex-shrink-0 self-start">{avatarWrapper}</div>
      ) : (
        <Link to={`/user/${encodeURIComponent(msg.user_email)}`} className="flex-shrink-0 self-start">
          {avatarWrapper}
        </Link>
      )}

      {/* Content */}
      <div className={`max-w-[72%] min-w-0 ${isOwn ? "items-end" : "items-start"}`}>
        {/* Name + badge */}
        <div className={`flex items-center gap-1.5 mb-0.5 ${isOwn ? "justify-end" : ""}`}>
          <span className={`text-[10px] font-semibold truncate ${isBot ? "text-cyan-400" : (roleCfg?.nameColor || "text-muted-foreground")}`}>
            {msg.user_name || msg.user_email.split("@")[0]}
          </span>
          {isBot && (
            <span className="flex items-center gap-0.5 text-[7px] font-bold text-white px-1.5 py-0.5 rounded-full"
              style={{ background: "linear-gradient(135deg, #06b6d4, #8b5cf6)" }}>
              <Bot className="w-2 h-2" /> Bot
            </span>
          )}
          {roleCfg && (
            <span className="flex items-center gap-0.5 text-[7px] font-bold text-white px-1.5 py-0.5 rounded-full" style={{ background: roleCfg.bg }}>
              {RoleIcon && <RoleIcon className="w-2 h-2" />} {roleCfg.label}
            </span>
          )}
        </div>

        {/* Reply preview */}
        {msg.reply_to_id && msg.reply_to_content && (
          <div className={`rounded-xl px-3 py-1.5 mb-1 ${isOwn ? "rounded-tr-md" : "rounded-tl-md"}`}
            style={{ background: "rgba(234,179,8,0.1)", borderLeft: "3px solid #EAB308" }}>
            <p className="text-[9px] font-semibold text-amber-600">{msg.reply_to_name || "Kullanıcı"}</p>
            <p className="text-[10px] text-gray-500 line-clamp-1">{msg.reply_to_content}</p>
          </div>
        )}

        {/* Bubble */}
        <div
          className={`rounded-2xl px-3.5 py-2.5 ${isOwn ? "rounded-tr-md" : "rounded-tl-md"} relative`}
          style={{
            background: "#FFFFFF",
            border: "1px solid rgba(0,0,0,0.08)",
            boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
          }}
          onTouchStart={isBot ? undefined : onTouchStart}
          onTouchEnd={isBot ? undefined : onTouchEnd}
          onTouchMove={isBot ? undefined : onTouchEnd}
          onContextMenu={isBot ? undefined : (e) => { e.preventDefault(); setShowActions(true); }}
        >
          {/* Photo */}
          {msg.type === "image" && msg.image_url && (
            <img src={msg.image_url} alt="" className="rounded-xl max-w-full max-h-[200px] object-cover mb-1.5" />
          )}

          {/* Book share card */}
          {msg.type === "book_share" && msg.book_id && (
            <Link to={`/book/${msg.book_id}`} className="block mb-1.5">
              <div className="flex gap-2.5 rounded-xl p-2.5" style={{ background: "rgba(0,0,0,0.15)" }}>
                <div className="w-11 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-primary/10">
                  {msg.book_cover ? (
                    <img src={msg.book_cover} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center"><BookOpen className="w-4 h-4 text-primary/30" /></div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold truncate" style={{ color: "#111111" }}>{msg.book_title}</p>
                  {msg.book_author && (
                    <p className="text-[9px] text-gray-500">{msg.book_author}</p>
                  )}
                  {msg.book_description && (
                    <p className="text-[9px] line-clamp-2 mt-0.5 text-gray-500">{msg.book_description}</p>
                  )}
                  <span className="inline-block mt-1 text-[8px] font-bold text-white px-2 py-0.5 rounded-full"
                    style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
                    Kitabı Aç →
                  </span>
                </div>
              </div>
            </Link>
          )}

          {msg.content && msg.content !== "📖 Kitap Paylaşımı" && msg.content !== "📷 Fotoğraf" && (
            <p className="text-sm leading-relaxed break-words" style={{ color: "#111111" }}>{msg.content}</p>
          )}
        </div>

        {/* Footer */}
        <div className={`flex items-center gap-2 mt-0.5 ${isOwn ? "justify-end" : ""}`}>
          <span className="text-[9px] text-muted-foreground">
            {msg.created_date ? formatDistanceToNow(new Date(msg.created_date), { addSuffix: true, locale: tr }) : ""}
          </span>
          {(msg.like_count || 0) > 0 && (
            <span className="flex items-center gap-0.5 text-[9px] text-red-400">
              <Heart className="w-2.5 h-2.5 fill-red-400" /> {msg.like_count}
            </span>
          )}
        </div>

        {/* Action popup — only for non-bot messages */}
        {showActions && !isBot && (
          <div className="mt-1 relative z-10">
            <div className="inline-flex items-center gap-1 rounded-2xl px-2 py-1.5 shadow-xl animate-fade-in-up"
              style={{ background: "linear-gradient(155deg, rgba(50,20,72,0.97), rgba(35,16,28,0.97))", border: "1px solid rgba(200,140,255,0.12)" }}>
              <ActionBtn icon={Heart} label="Beğen" active={isLiked} color="red" onClick={() => { onLike(msg.id); setShowActions(false); }} />
              <ActionBtn icon={Reply} label="Cevap" onClick={() => { onReply(msg); setShowActions(false); }} />
              {canDelete && <ActionBtn icon={Trash2} label="Sil" color="red" onClick={() => { onDelete(msg.id); setShowActions(false); }} />}
              <button onClick={() => setShowActions(false)} className="w-8 h-8 flex items-center justify-center rounded-lg active:scale-90 transition-transform">
                <span className="text-muted-foreground text-[10px]">✕</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ActionBtn({ icon: Icon, onClick, active, color, label }) {
  return (
    <button onClick={onClick}
      className="flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg active:scale-90 transition-transform"
      style={{ background: active ? "rgba(239,68,68,0.15)" : "rgba(255,255,255,0.05)" }}>
      <Icon className={`w-3.5 h-3.5 ${active ? "text-red-400 fill-red-400" : color === "red" ? "text-red-400" : "text-muted-foreground"}`} />
      {label && <span className={`text-[8px] ${active ? "text-red-400" : "text-muted-foreground"}`}>{label}</span>}
    </button>
  );
}