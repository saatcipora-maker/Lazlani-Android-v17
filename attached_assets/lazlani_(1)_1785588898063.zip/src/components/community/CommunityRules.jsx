import { X, ShieldCheck, AlertTriangle, Ban, MessageSquareOff } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const RULES = [
  { icon: ShieldCheck, text: "Saygılı ve yapıcı olun, herkesin görüşüne değer verin.", color: "#22C55E" },
  { icon: AlertTriangle, text: "Küfür, hakaret, ırkçılık ve cinsel içerik kesinlikle yasaktır.", color: "#F59E0B" },
  { icon: MessageSquareOff, text: "1. ihlal: Uyarı — 2. ihlal: 1 gün susturma — 3. ihlal: 7 gün yasak + rapor.", color: "#EF4444" },
  { icon: Ban, text: "Spam, reklam, sahte bilgi paylaşımı ve trolleme yasaktır.", color: "#F97316" },
  { icon: ShieldCheck, text: "Moderatörler (VIP/Operatör) kurallara uymayanlara ceza verebilir.", color: "#8B5CF6" },
];

export default function CommunityRules({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm" onClick={onClose}
          />
          <motion.div
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 z-[61] w-full max-w-md mx-auto rounded-t-3xl p-5 pb-8"
            style={{
              background: "linear-gradient(170deg, rgba(38,18,55,0.98), rgba(20,8,30,0.99))",
              border: "1px solid rgba(200,140,255,0.08)",
              paddingBottom: "calc(2rem + env(safe-area-inset-bottom, 0px))",
            }}
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-heading font-bold text-foreground">Topluluk Kuralları</h3>
              <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.05)" }}>
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            <div className="space-y-3">
              {RULES.map((rule, i) => (
                <div key={i} className="flex items-start gap-3 px-3 py-3 rounded-2xl"
                  style={{ background: `${rule.color}06`, border: `1px solid ${rule.color}12` }}>
                  <rule.icon className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: rule.color }} />
                  <p className="text-xs text-foreground/90 leading-relaxed">{rule.text}</p>
                </div>
              ))}
            </div>

            <div className="mt-4 p-3 rounded-2xl" style={{ background: "rgba(130,60,210,0.06)", border: "1px solid rgba(130,60,210,0.1)" }}>
              <p className="text-[10px] text-muted-foreground leading-relaxed text-center">
                Kuralları ihlal eden mesajlar otomatik olarak engellenir.
                Tekrarlanan ihlallerde hesabınız geçici veya kalıcı olarak kısıtlanabilir.
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}