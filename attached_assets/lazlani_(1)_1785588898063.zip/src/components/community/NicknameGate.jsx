import { useState, useEffect } from "react";
import { Users, ArrowRight, AlertCircle } from "lucide-react";
import { containsProfanity } from "@/utils/profanityFilter";

const STORAGE_KEY = "lazlani_community_nickname";

export default function NicknameGate({ onEnter, existingNicknames = [], isAdmin, adminName }) {
  const [nickname, setNickname] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    // Admin bypasses nickname gate
    if (isAdmin && adminName) {
      onEnter(adminName);
      return;
    }
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) setNickname(saved);
  }, [isAdmin, adminName, onEnter]);

  const validate = () => {
    const trimmed = nickname.trim();
    if (!trimmed) return "Takma ad boş bırakılamaz";
    if (trimmed.length < 3) return "Takma ad en az 3 karakter olmalı";
    if (trimmed.length > 20) return "Takma ad en fazla 20 karakter olabilir";
    if (containsProfanity(trimmed)) return "Uygunsuz kelime tespit edildi";
    if (existingNicknames.some(n => n.toLowerCase() === trimmed.toLowerCase())) return "Bu takma ad zaten kullanılıyor";
    return null;
  };

  const handleSubmit = () => {
    const err = validate();
    if (err) { setError(err); return; }
    localStorage.setItem(STORAGE_KEY, nickname.trim());
    onEnter(nickname.trim());
  };

  // If admin, don't show gate
  if (isAdmin) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-6"
      style={{ background: "linear-gradient(170deg, hsl(280,28%,7%) 0%, hsl(274,30%,6%) 50%, hsl(300,20%,8%) 100%)" }}>
      <div className="w-full max-w-sm rounded-3xl p-6 animate-fade-in-up"
        style={{
          background: "linear-gradient(155deg, rgba(38,18,55,0.8), rgba(28,14,22,0.6))",
          backdropFilter: "blur(20px)",
          border: "1px solid rgba(200,140,255,0.08)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.5), 0 0 80px rgba(130,60,210,0.06)",
        }}>

        {/* Icon */}
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5"
          style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
          <Users className="w-7 h-7 text-white" />
        </div>

        <h2 className="text-center font-heading text-lg font-bold text-foreground mb-1">
          Topluluk Odasına Hoş Geldiniz
        </h2>
        <p className="text-center text-xs text-muted-foreground mb-5">
          Sohbete katılmak için bir takma ad belirleyin
        </p>

        {/* Input */}
        <div className="relative mb-3">
          <input
            value={nickname}
            onChange={e => { setNickname(e.target.value); setError(""); }}
            onKeyDown={e => e.key === "Enter" && handleSubmit()}
            placeholder="Takma adınız..."
            maxLength={20}
            className="w-full px-4 py-3.5 rounded-2xl text-sm text-foreground placeholder:text-muted-foreground outline-none"
            style={{ fontSize: "16px", background: "rgba(38,18,55,0.5)", border: error ? "1px solid rgba(239,68,68,0.4)" : "1px solid rgba(200,140,255,0.1)" }}
            autoFocus
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">
            {nickname.length}/20
          </span>
        </div>

        {/* Error */}
        {error && (
          <div className="flex items-center gap-1.5 mb-3 px-1">
            <AlertCircle className="w-3 h-3 text-red-400 flex-shrink-0" />
            <span className="text-[11px] text-red-400">{error}</span>
          </div>
        )}

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!nickname.trim()}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-semibold text-white active:scale-[0.98] transition-all disabled:opacity-40"
          style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
          Odaya Gir
          <ArrowRight className="w-4 h-4" />
        </button>

        <p className="text-[9px] text-muted-foreground/50 text-center mt-3">3–20 karakter • Uygunsuz kelimeler yasaktır</p>
      </div>
    </div>
  );
}