import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { X, Shield, Star, Ban, Clock, UserMinus, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function UserActionSheet({ targetUser, userRole, onClose }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [action, setAction] = useState(null);
  const isAdmin = user?.role === "admin";
  const isOperator = userRole === "operator";
  const isVip = userRole === "vip";

  const grantRoleMutation = useMutation({
    mutationFn: async (role) => {
      // Remove existing role first
      const existing = await base44.entities.CommunityRole.filter({ user_email: targetUser.user_email }, "-created_date", 10);
      for (const r of existing) await base44.entities.CommunityRole.delete(r.id);
      // Grant new role
      await base44.entities.CommunityRole.create({
        user_email: targetUser.user_email,
        user_name: targetUser.user_name,
        role,
        granted_by_email: user.email,
        granted_by_name: user.full_name || user.email,
      });
    },
    onSuccess: (_, role) => {
      queryClient.invalidateQueries({ queryKey: ["community-roles"] });
      toast.success(`${role === "vip" ? "VIP" : "Operatör"} yetkisi verildi`);
      onClose();
    },
  });

  const removeRoleMutation = useMutation({
    mutationFn: async () => {
      const existing = await base44.entities.CommunityRole.filter({ user_email: targetUser.user_email }, "-created_date", 10);
      for (const r of existing) await base44.entities.CommunityRole.delete(r.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-roles"] });
      toast.success("Yetki kaldırıldı");
      onClose();
    },
  });

  const muteMutation = useMutation({
    mutationFn: async (minutes) => {
      await base44.entities.CommunityChatBan.create({
        user_email: targetUser.user_email,
        user_name: targetUser.user_name,
        banned_by_email: user.email,
        banned_by_name: user.full_name || user.email,
        reason: "Moderatör tarafından susturuldu",
        ban_type: "mute",
        duration_label: minutes >= 60 ? `${minutes / 60} saat` : `${minutes} dk`,
        expires_at: new Date(Date.now() + minutes * 60 * 1000).toISOString(),
        is_active: true,
        issued_by_role: isAdmin ? "admin" : isOperator ? "operator" : "vip",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-bans"] });
      toast.success("Kullanıcı susturuldu");
      onClose();
    },
  });

  const kickMutation = useMutation({
    mutationFn: async (minutes) => {
      await base44.entities.CommunityChatBan.create({
        user_email: targetUser.user_email,
        user_name: targetUser.user_name,
        banned_by_email: user.email,
        banned_by_name: user.full_name || user.email,
        reason: "Operatör tarafından uzaklaştırıldı",
        ban_type: "kick",
        duration_label: minutes >= 60 ? `${minutes / 60} saat` : `${minutes} dk`,
        expires_at: new Date(Date.now() + minutes * 60 * 1000).toISOString(),
        is_active: true,
        issued_by_role: isAdmin ? "admin" : "operator",
      });
      // Delete their presence
      const pres = await base44.entities.CommunityPresence.filter({ user_email: targetUser.user_email }, "-created_date", 5);
      for (const p of pres) await base44.entities.CommunityPresence.delete(p.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-bans"] });
      toast.success("Kullanıcı odadan uzaklaştırıldı");
      onClose();
    },
  });

  const unmuteMutation = useMutation({
    mutationFn: async () => {
      const bans = await base44.entities.CommunityChatBan.filter({ user_email: targetUser.user_email, is_active: true }, "-created_date", 10);
      for (const b of bans) await base44.entities.CommunityChatBan.update(b.id, { is_active: false });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-bans"] });
      toast.success("Engel kaldırıldı");
      onClose();
    },
  });

  if (targetUser.user_email === user?.email) return null;

  const currentTargetRole = targetUser.user_role || "user";
  const MUTE_OPTIONS = [
    { label: "5 Dakika", minutes: 5 },
    { label: "30 Dakika", minutes: 30 },
    { label: "1 Saat", minutes: 60 },
  ];

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-md rounded-t-3xl p-5 pb-8 animate-fade-in-up"
        style={{
          background: "linear-gradient(170deg, rgba(38,18,55,0.97), rgba(20,8,30,0.98))",
          border: "1px solid rgba(200,140,255,0.08)",
          paddingBottom: "calc(2rem + env(safe-area-inset-bottom, 0px))",
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold overflow-hidden"
              style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.2), rgba(240,140,60,0.1))" }}>
              {targetUser.user_avatar ? (
                <img src={targetUser.user_avatar} alt="" className="w-full h-full rounded-full object-cover" />
              ) : (
                <span className="text-primary">{(targetUser.user_name || "?")[0]?.toUpperCase()}</span>
              )}
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">{targetUser.user_name}</p>
              <p className="text-[10px] text-muted-foreground">{targetUser.user_email}</p>
              {currentTargetRole !== "user" && (
                <span className="text-[8px] font-bold text-white px-1.5 py-0.5 rounded-full mt-0.5 inline-block"
                  style={{ background: currentTargetRole === "operator" ? "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" : "linear-gradient(135deg, #F59E0B, #EAB308)" }}>
                  {currentTargetRole === "operator" ? "Operatör" : "VIP"}
                </span>
              )}
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.05)" }}>
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Actions */}
        {action === null && (
          <div className="space-y-2">
            {/* Admin-only: role management */}
            {isAdmin && (
              <>
                {currentTargetRole !== "vip" && (
                  <ActionBtn icon={Star} label="VIP Yetkisi Ver" color="#F59E0B" onClick={() => grantRoleMutation.mutate("vip")} />
                )}
                {currentTargetRole !== "operator" && (
                  <ActionBtn icon={Shield} label="Operatör Yetkisi Ver" color="hsl(270,60%,56%)" onClick={() => grantRoleMutation.mutate("operator")} />
                )}
                {currentTargetRole !== "user" && (
                  <ActionBtn icon={X} label="Yetkiyi Kaldır" color="#EF4444" onClick={() => removeRoleMutation.mutate()} />
                )}
              </>
            )}

            {/* VIP + Operator + Admin: mute */}
            {(isAdmin || isOperator || isVip) && (
              <ActionBtn icon={VolumeX} label="Mesaj Yazmasını Engelle" color="#EF4444" onClick={() => setAction("mute")} />
            )}
            {(isAdmin || isOperator || isVip) && (
              <ActionBtn icon={Volume2} label="Engelini Kaldır" color="#22C55E" onClick={() => unmuteMutation.mutate()} />
            )}

            {/* Operator + Admin: kick */}
            {(isAdmin || isOperator) && (
              <ActionBtn icon={UserMinus} label="Odadan Uzaklaştır" color="#F97316" onClick={() => setAction("kick")} />
            )}
          </div>
        )}

        {/* Mute duration picker */}
        {action === "mute" && (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-foreground mb-3">Susturma Süresi Seçin</p>
            {MUTE_OPTIONS.map(opt => (
              <button key={opt.minutes} onClick={() => muteMutation.mutate(opt.minutes)}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left active:scale-[0.98] transition-transform"
                style={{ background: "rgba(239,68,68,0.06)", border: "1px solid rgba(239,68,68,0.1)" }}>
                <Clock className="w-4 h-4 text-red-400" />
                <span className="text-sm font-medium text-foreground">{opt.label}</span>
              </button>
            ))}
            <button onClick={() => setAction(null)} className="w-full text-center text-xs text-muted-foreground py-2">İptal</button>
          </div>
        )}

        {/* Kick duration picker */}
        {action === "kick" && (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-foreground mb-3">Uzaklaştırma Süresi Seçin</p>
            {MUTE_OPTIONS.map(opt => (
              <button key={opt.minutes} onClick={() => kickMutation.mutate(opt.minutes)}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-left active:scale-[0.98] transition-transform"
                style={{ background: "rgba(249,115,22,0.06)", border: "1px solid rgba(249,115,22,0.1)" }}>
                <Clock className="w-4 h-4 text-orange-400" />
                <span className="text-sm font-medium text-foreground">{opt.label}</span>
              </button>
            ))}
            <button onClick={() => setAction(null)} className="w-full text-center text-xs text-muted-foreground py-2">İptal</button>
          </div>
        )}
      </div>
    </div>
  );
}

function ActionBtn({ icon: Icon, label, color, onClick }) {
  return (
    <button onClick={onClick}
      className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-left active:scale-[0.98] transition-transform"
      style={{ background: `${color}08`, border: `1px solid ${color}15` }}>
      <Icon className="w-4.5 h-4.5" style={{ color }} />
      <span className="text-sm font-medium text-foreground">{label}</span>
    </button>
  );
}