import { Camera, BookOpen, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ShareMenu({ open, onClose, onPhoto, onBook }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[58] bg-black/30"
            onClick={onClose}
          />
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 30, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 350 }}
            className="absolute bottom-full left-0 mb-2 z-[59] w-48 rounded-2xl p-2 shadow-xl"
            style={{
              background: "linear-gradient(155deg, rgba(50,20,72,0.97), rgba(35,16,28,0.97))",
              border: "1px solid rgba(200,140,255,0.1)",
            }}
          >
            <button
              onClick={() => { onPhoto(); onClose(); }}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left active:scale-[0.97] transition-transform hover:bg-primary/5"
            >
              <Camera className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-foreground">Fotoğraf Paylaş</span>
            </button>
            <button
              onClick={() => { onBook(); onClose(); }}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left active:scale-[0.97] transition-transform hover:bg-primary/5"
            >
              <BookOpen className="w-5 h-5 text-accent" />
              <span className="text-sm font-medium text-foreground">Kitabını Paylaş</span>
            </button>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}