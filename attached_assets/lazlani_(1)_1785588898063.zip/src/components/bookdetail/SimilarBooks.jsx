import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { BookOpen } from "lucide-react";

export default function SimilarBooks({ category, currentBookId }) {
  const { data: books = [] } = useQuery({
    queryKey: ["similar-books", category, currentBookId],
    queryFn: () =>
      base44.entities.Book.filter({ category, status: "yayinda" }, "-read_count", 10),
    enabled: !!category,
  });

  const filtered = books.filter((b) => b.id !== currentBookId).slice(0, 6);
  if (filtered.length === 0) return null;

  return (
    <div className="mt-6">
      <h3 className="font-semibold text-foreground mb-3">Benzer Kitaplar</h3>
      <div className="overflow-x-auto scrollbar-hide">
        <div className="flex gap-3 pb-1">
          {filtered.map((book) => (
            <Link
              key={book.id}
              to={`/book/${book.id}`}
              className="flex-shrink-0 w-28 group"
            >
              <div className="w-28 h-40 rounded-xl overflow-hidden relative shadow-md">
                {book.cover_image ? (
                  <img src={book.cover_image} alt={book.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-primary/60 to-primary/20 flex items-center justify-center p-2">
                    <span className="text-white text-xs font-bold text-center leading-tight">{book.title}</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-2">
                  <p className="text-white text-[10px] font-semibold leading-tight line-clamp-2">{book.title}</p>
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1.5 truncate">{book.author_name}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}