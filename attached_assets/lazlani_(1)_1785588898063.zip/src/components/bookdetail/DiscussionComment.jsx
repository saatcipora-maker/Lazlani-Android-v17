import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Trash2, Heart, CornerDownRight, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";
import { useUserBadges, getBadgeNameClass } from "@/hooks/useUserBadges";
import { Link } from "react-router-dom";
import { incrementBookCommentCount, decrementBookCommentCount } from "@/lib/bookStats";

export default function DiscussionComment({ comment, currentUser, queryKey }) {
  const [showReply, setShowReply] = useState(false);
  const [replyText, setReplyText] = useState("");
  const queryClient = useQueryClient();
  const badgeMap = useUserBadges();
  const nameClass = getBadgeNameClass(comment.user_email, badgeMap);
  const isOwn = currentUser?.email === comment.user_email;

  // Like query
  const { data: likes = [] } = useQuery({
    queryKey: ["comment-likes", comment.id],
    queryFn: () => base44.entities.ChapterLike.filter({ chapter_id: comment.id }, "-created_date", 200),
    enabled: !!comment.id,
  });

  useEffect(() => {
    const unsub = base44.entities.ChapterLike.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["comment-likes", comment.id] });
    });
    return unsub;
  }, [comment.id]);

  const isLiked = currentUser && likes.some((l) => l.user_email === currentUser.email);

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (isLiked) {
        const myLike = likes.find((l) => l.user_email === currentUser.email);
        if (myLike) await base44.entities.ChapterLike.delete(myLike.id);
      } else {
        await base44.entities.ChapterLike.create({
          chapter_id: comment.id,
          user_email: currentUser.email,
        });
        // Send notification to comment author
        if (comment.user_email !== currentUser.email) {
          await base44.entities.Notification.create({
            receiver_email: comment.user_email,
            sender_name: currentUser.full_name || currentUser.email,
            sender_email: currentUser.email,
            type: "comment_like",
            message: `${currentUser.full_name || currentUser.email} yorumunuzu beğendi`,
            is_read: false,
          });
        }
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["comment-likes", comment.id] }),
  });

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities.ChapterComment.delete(comment.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      if (comment.chapter_id?.startsWith("book_")) {
        decrementBookCommentCount(comment.chapter_id.replace("book_", ""));
      }
    },
  });

  const replyMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.ChapterComment.create({
        chapter_id: comment.chapter_id,
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        content: `@${comment.user_name}: ${replyText.trim()}`,
      });
      // Send notification to comment author
      if (comment.user_email !== currentUser.email) {
        await base44.entities.Notification.create({
          receiver_email: comment.user_email,
          sender_name: currentUser.full_name || currentUser.email,
          sender_email: currentUser.email,
          type: "comment_reply",
          message: `${currentUser.full_name || currentUser.email} yorumunuza cevap verdi: "${replyText.trim().substring(0, 60)}..."`,
          is_read: false,
        });
      }
    },
    onSuccess: () => {
      setReplyText("");
      setShowReply(false);
      queryClient.invalidateQueries({ queryKey });
      if (comment.chapter_id?.startsWith("book_")) {
        incrementBookCommentCount(comment.chapter_id.replace("book_", ""));
      }
    },
  });

  return (
    <div className="flex gap-2">
      <Link
        to={`/user/${encodeURIComponent(comment.user_email)}`}
        className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5"
      >
        <span className="text-[10px] font-bold text-primary">
          {comment.user_name?.[0]?.toUpperCase() || "?"}
        </span>
      </Link>
      <div className="flex-1 min-w-0">
        <div className="bg-white rounded-2xl px-3.5 py-2.5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.08)" }}>
          <Link
            to={`/user/${encodeURIComponent(comment.user_email)}`}
            className={`text-[11px] font-semibold ${nameClass || "text-foreground"} hover:underline`}
          >
            {comment.user_name}
          </Link>
          <p className="text-[13px] mt-0.5 leading-relaxed whitespace-pre-wrap break-words" style={{ color: "#111111" }}>
            {comment.content}
          </p>
        </div>
        <div className="flex items-center gap-1 mt-1 px-1">
          <span className="text-[10px] text-muted-foreground py-2 px-1">
            {comment.created_date &&
              formatDistanceToNow(new Date(comment.created_date), { addSuffix: true, locale: tr })}
          </span>

          {/* Like button */}
          {currentUser && (
            <button
              onClick={() => likeMutation.mutate()}
              disabled={likeMutation.isPending}
              aria-label={isLiked ? "Beğeniyi kaldır" : "Beğen"}
              className={`text-[10px] font-medium flex items-center gap-0.5 py-2 px-2 rounded-md transition-colors ${
                isLiked ? "text-red-500" : "text-muted-foreground hover:text-red-500"
              }`}
            >
              <Heart className={`w-3 h-3 ${isLiked ? "fill-red-500" : ""}`} />
              {likes.length > 0 && <span>{likes.length}</span>}
            </button>
          )}

          {/* Reply */}
          {currentUser && (
            <button
              onClick={() => setShowReply((v) => !v)}
              className="text-[10px] text-primary font-medium flex items-center gap-0.5 py-2 px-2 rounded-md"
            >
              <CornerDownRight className="w-3 h-3" />
              Cevap
            </button>
          )}

          {/* Delete */}
          {isOwn && (
            <button
              onClick={() => deleteMutation.mutate()}
              disabled={deleteMutation.isPending}
              aria-label="Yorumu sil"
              className="text-[10px] text-destructive font-medium flex items-center gap-0.5 py-2 px-2 rounded-md"
            >
              <Trash2 className="w-3 h-3" />
              Sil
            </button>
          )}
        </div>

        {/* Reply input */}
        {showReply && (
          <div className="flex gap-2 mt-2">
            <input
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder={`@${comment.user_name} cevapla...`}
              className="flex-1 text-xs border border-border rounded-full px-3 py-1.5 bg-background outline-none focus:border-primary"
              style={{ fontSize: "16px" }}
              onKeyDown={(e) => e.key === "Enter" && replyText.trim() && replyMutation.mutate()}
            />
            <Button
              size="icon"
              className="rounded-full h-7 w-7 flex-shrink-0"
              disabled={!replyText.trim() || replyMutation.isPending}
              onClick={() => replyMutation.mutate()}
            >
              <Send className="w-3 h-3" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}