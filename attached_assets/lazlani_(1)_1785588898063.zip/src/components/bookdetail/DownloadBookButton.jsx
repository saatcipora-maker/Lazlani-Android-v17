import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function DownloadBookButton({ bookId, bookTitle }) {
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await base44.functions.invoke("downloadBook", { book_id: bookId }, { responseType: "arraybuffer" });
      
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${bookTitle || "kitap"}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("Kitap indirildi!");
    } catch (err) {
      toast.error("İndirme başarısız oldu");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Button
      variant="outline"
      className="rounded-full"
      onClick={handleDownload}
      disabled={downloading}
    >
      {downloading ? (
        <Loader2 className="w-4 h-4 mr-1 animate-spin" />
      ) : (
        <Download className="w-4 h-4 mr-1" />
      )}
      {downloading ? "İndiriliyor..." : "İndir"}
    </Button>
  );
}