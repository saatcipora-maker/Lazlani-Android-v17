import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Star, Send, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";
import { recalcBookRating } from "@/lib/bookStats";

function StarRating({ value, onChange, size = "w-6 h-6" }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type="button"
          onMouseEnter={() => onChange && setHovered(s)}
          onMouseLeave={() => onChange && setHovered(0)}
          onClick={() => onChange && onChange(s)}
          className="transition-transform hover:scale-110"
        >
          <Star
            className={`${size} transition-colors ${
              s <= (hovered || value)
                ? "fill-yellow-400 text-yellow-400"
                : "text-muted-foreground/40"
            }`}
          />
        </button>
      ))}
    </div>
  );
}

export function BookRatingSummary({ bookId }) {
  const { data: reviews = [] } = useQuery({
    queryKey: ["book-reviews", bookId],
    queryFn: () => base44.entities.BookReview.filter({ book_id: bookId }, "-created_date", 200),
    enabled: !!bookId,
  });

  if (reviews.length === 0) return null;

  const avg = reviews.reduce((s, r) => s + r.rating, 0) / reviews.length;

  return (
    <div className="flex items-center gap-2">
      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
      <span className="text-sm font-bold text-foreground">{avg.toFixed(1)}</span>
      <span className="text-xs text-muted-foreground">({reviews.length} değerlendirme)</span>
    </div>
  );
}

export default function BookReviews({ bookId, currentUser }) {
  const [rating, setRating] = useState(0);
  const [content, setContent] = useState("");
  const queryClient = useQueryClient();

  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ["book-reviews", bookId],
    queryFn: () => base44.entities.BookReview.filter({ book_id: bookId }, "-created_date", 200),
    enabled: !!bookId,
  });

  useEffect(() => {
    const unsub = base44.entities.BookReview.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["book-reviews", bookId] });
    });
    return unsub;
  }, [bookId]);

  const myReview = reviews.find((r) => r.user_email === currentUser?.email);
  const avg = reviews.length > 0 ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

  const submitMutation = useMutation({
    mutationFn: () =>
      base44.entities.BookReview.create({
        book_id: bookId,
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        rating,
        content: content.trim(),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book-reviews", bookId] });
      recalcBookRating(bookId);
      setRating(0);
      setContent("");
      toast.success("Değerlendirmeniz eklendi!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.BookReview.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book-reviews", bookId] });
      recalcBookRating(bookId);
      toast.success("Değerlendirme silindi");
    },
  });

  return (
    <div className="mt-6">
      {/* Header with average */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2">
          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
          Değerlendirmeler
          <span className="text-muted-foreground text-sm font-normal">({reviews.length})</span>
        </h3>
        {reviews.length > 0 && (
          <div className="flex items-center gap-1.5 bg-yellow-50 border border-yellow-200 rounded-full px-3 py-1">
            <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-bold text-yellow-700">{avg.toFixed(1)}</span>
            <span className="text-xs text-yellow-600">/ 5</span>
          </div>
        )}
      </div>

      {/* Rating distribution bar */}
      {reviews.length > 0 && (
        <div className="bg-muted rounded-xl p-3 mb-4 space-y-1.5">
          {[5, 4, 3, 2, 1].map((star) => {
            const count = reviews.filter((r) => r.rating === star).length;
            const pct = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
            return (
              <div key={star} className="flex items-center gap-2 text-xs">
                <span className="w-3 text-xs text-muted-foreground text-right">{star}</span>
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400 flex-shrink-0" />
                <div className="flex-1 bg-background rounded-full h-1.5 overflow-hidden">
                  <div
                    className="h-full bg-yellow-400 rounded-full transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="w-4 text-xs text-muted-foreground text-right">{count}</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Write review */}
      {currentUser && !myReview && (
        <div className="bg-card border border-border rounded-2xl p-4 mb-4 space-y-3">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Değerlendirmeni Yaz</p>
          <StarRating value={rating} onChange={setRating} />
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value.slice(0, 500))}
            placeholder="Bu kitap hakkında ne düşünüyorsunuz? (isteğe bağlı)"
            className="min-h-[80px] resize-none text-sm"
          />
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">{content.length}/500</span>
            <Button
              size="sm"
              className="rounded-full"
              disabled={rating === 0 || submitMutation.isPending}
              onClick={() => submitMutation.mutate()}
            >
              <Send className="w-3 h-3 mr-1" />
              Gönder
            </Button>
          </div>
        </div>
      )}

      {/* My review already submitted */}
      {myReview && (
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-3 mb-4 text-xs text-primary font-medium flex items-center justify-between">
          <span>✓ Değerlendirmenizi zaten eklediniz</span>
          <button onClick={() => deleteMutation.mutate(myReview.id)} className="text-destructive hover:underline ml-2">
            Sil
          </button>
        </div>
      )}

      {/* Reviews list */}
      {isLoading ? (
        <p className="text-xs text-muted-foreground text-center py-3">Yükleniyor...</p>
      ) : reviews.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">Henüz değerlendirme yok. İlk değerlendirmeyi siz yapın!</p>
      ) : (
        <div className="space-y-3">
          {reviews.map((review) => (
            <div key={review.id} className="bg-white rounded-2xl p-3.5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.08)" }}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-[10px] font-bold text-primary">{review.user_name?.[0]?.toUpperCase() || "?"}</span>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-foreground">{review.user_name}</p>
                    <StarRating value={review.rating} size="w-3 h-3" />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground">
                    {formatDistanceToNow(new Date(review.created_date), { addSuffix: true, locale: tr })}
                  </span>
                  {currentUser?.email === review.user_email && (
                    <button onClick={() => deleteMutation.mutate(review.id)} className="text-muted-foreground hover:text-destructive">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
              {review.content && (
                <p className="text-[13px] mt-2 leading-relaxed pl-9 whitespace-pre-wrap break-words" style={{ color: "#111111" }}>{review.content}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}