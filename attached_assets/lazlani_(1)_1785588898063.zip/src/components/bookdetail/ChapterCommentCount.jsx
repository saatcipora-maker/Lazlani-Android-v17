import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { MessageCircle } from "lucide-react";

export default function ChapterCommentCount({ chapterId }) {
  const { data: comments = [] } = useQuery({
    queryKey: ["chapter-comment-count", chapterId],
    queryFn: () => base44.entities.ChapterComment.filter({ chapter_id: chapterId }, "-created_date", 200),
    staleTime: 30000,
  });

  if (comments.length === 0) return null;

  return (
    <span className="flex items-center gap-0.5 text-xs text-muted-foreground">
      <MessageCircle className="w-3 h-3" />
      {comments.length}
    </span>
  );
}