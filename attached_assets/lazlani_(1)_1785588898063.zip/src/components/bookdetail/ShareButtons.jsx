import { Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function ShareButtons({ book, chapter }) {
  const appUrl = "https://lazlani.base44.app";
  const bookUrl = `${appUrl}/book/${book?.id}`;
  const chapterUrl = chapter ? `${appUrl}/read/${book?.id}/${chapter.id}` : null;

  const shareUrl = chapterUrl || bookUrl;
  const title = chapter
    ? `📖 "${chapter.title}" - ${book.title} | ${book.author_name}`
    : `📚 "${book.title}" - ${book.author_name}`;
  const text = chapter
    ? `"${book.title}" kitabının "${chapter.title}" bölümünü oku!`
    : book.description
      ? `${book.description.slice(0, 120)}...`
      : `"${book.title}" kitabını oku!`;

  const handleShare = async () => {
    // Use native share API if available (mobile)
    if (navigator.share) {
      try {
        await navigator.share({ title, text, url: shareUrl });
        return;
      } catch {
        // User cancelled or not supported, fall through
      }
    }

    // Fallback: copy link
    try {
      await navigator.clipboard.writeText(`${title}\n${shareUrl}`);
      toast.success("Bağlantı kopyalandı! Yapıştırarak paylaşabilirsiniz.");
    } catch {
      toast.error("Kopyalama başarısız oldu");
    }
  };

  return (
    <Button
      variant="outline"
      className="rounded-full"
      onClick={handleShare}
      title="Paylaş"
    >
      <Share2 className="w-4 h-4 mr-1" />
      Paylaş
    </Button>
  );
}