import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { User } from "lucide-react";

export default function AuthorBio({ authorEmail, authorName }) {
  const { data: authorBooks = [] } = useQuery({
    queryKey: ["author-books", authorEmail],
    queryFn: () => base44.entities.Book.filter({ author_email: authorEmail, status: "yayinda" }, "-created_date", 20),
    enabled: !!authorEmail,
  });

  const { data: followers = [] } = useQuery({
    queryKey: ["author-followers", authorEmail],
    queryFn: () => base44.entities.Follow.filter({ following_email: authorEmail }, "-created_date", 200),
    enabled: !!authorEmail,
  });

  return (
    <div className="mt-6">
      <h3 className="font-semibold text-foreground mb-3">Yazar Hakkında</h3>
      <div className="p-4 rounded-2xl bg-card border border-border flex items-start gap-4">
        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
          <User className="w-6 h-6 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <Link
            to={`/user/${encodeURIComponent(authorEmail)}`}
            className="font-semibold text-foreground hover:text-primary transition-colors"
          >
            {authorName}
          </Link>
          <div className="flex gap-4 mt-1.5">
            <span className="text-xs text-muted-foreground">
              <span className="font-semibold text-foreground">{authorBooks.length}</span> kitap
            </span>
            <span className="text-xs text-muted-foreground">
              <span className="font-semibold text-foreground">{followers.length}</span> takipçi
            </span>
          </div>
          <Link
            to={`/user/${encodeURIComponent(authorEmail)}`}
            className="inline-block mt-2 text-xs text-primary hover:underline"
          >
            Profile git →
          </Link>
        </div>
      </div>
    </div>
  );
}