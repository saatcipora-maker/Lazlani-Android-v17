import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Send } from "lucide-react";
import { toast } from "sonner";
import DiscussionComment from "@/components/bookdetail/DiscussionComment";
import { incrementBookCommentCount } from "@/lib/bookStats";

export default function BookComments({ bookId, currentUser }) {
  const [text, setText] = useState("");
  const queryClient = useQueryClient();

  // We'll use ChapterComment entity with chapter_id = "book_" + bookId to store book-level comments
  const commentKey = `book_${bookId}`;

  const { data: comments = [], isLoading } = useQuery({
    queryKey: ["book-comments", bookId],
    queryFn: () =>
      base44.entities.ChapterComment.filter({ chapter_id: commentKey }, "-created_date", 50),
    enabled: !!bookId,
  });

  // Real-time subscribe
  useEffect(() => {
    const unsub = base44.entities.ChapterComment.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["book-comments", bookId] });
      queryClient.invalidateQueries({ queryKey: ["book-comments-count", bookId] });
    });
    return unsub;
  }, [bookId]);

  const addMutation = useMutation({
    mutationFn: () =>
      base44.entities.ChapterComment.create({
        chapter_id: commentKey,
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        content: text.trim(),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book-comments", bookId] });
      incrementBookCommentCount(bookId);
      setText("");
      toast.success("Yorum eklendi!");
    },
  });

  return (
    <div className="mt-6">
      <div className="flex items-center gap-2 mb-3">
        <MessageCircle className="w-4 h-4 text-primary" />
        <h3 className="font-semibold text-foreground">Yorumlar ({comments.length})</h3>
      </div>

      {/* Add comment */}
      {currentUser && (
        <div className="flex gap-2 mb-4">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Bu kitap hakkında düşüncelerinizi yazın..."
            className="flex-1 min-h-[70px] text-sm resize-none"
          />
          <Button
            size="icon"
            className="self-end rounded-full h-9 w-9 flex-shrink-0"
            disabled={!text.trim() || addMutation.isPending}
            onClick={() => addMutation.mutate()}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Comments list */}
      {isLoading ? (
        <p className="text-xs text-muted-foreground text-center py-3">Yükleniyor...</p>
      ) : comments.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">
          Henüz yorum yok. İlk yorumu siz yapın!
        </p>
      ) : (
        <div className="space-y-3">
          {comments.map((c) => (
            <DiscussionComment
              key={c.id}
              comment={c}
              currentUser={currentUser}
              queryKey={["book-comments", bookId]}
            />
          ))}
        </div>
      )}
    </div>
  );
}