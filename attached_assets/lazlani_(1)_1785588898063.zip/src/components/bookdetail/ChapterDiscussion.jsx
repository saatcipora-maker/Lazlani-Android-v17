import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Send, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import DiscussionComment from "./DiscussionComment";

export default function ChapterDiscussion({ chapters, bookId, currentUser }) {
  const [expandedChapter, setExpandedChapter] = useState(null);
  const [text, setText] = useState("");
  const queryClient = useQueryClient();

  const { data: allComments = [], isLoading } = useQuery({
    queryKey: ["chapter-discussions", bookId],
    queryFn: async () => {
      const chapterIds = chapters.map((c) => c.id);
      const results = await Promise.all(
        chapterIds.map((cid) =>
          base44.entities.ChapterComment.filter({ chapter_id: cid }, "-created_date", 100)
        )
      );
      return results.flat();
    },
    enabled: chapters.length > 0,
  });

  useEffect(() => {
    const unsub = base44.entities.ChapterComment.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["chapter-discussions", bookId] });
    });
    return unsub;
  }, [bookId]);

  const addMutation = useMutation({
    mutationFn: (chapterId) =>
      base44.entities.ChapterComment.create({
        chapter_id: chapterId,
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        content: text.trim(),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chapter-discussions", bookId] });
      setText("");
      toast.success("Yorum eklendi!");
    },
  });

  const getChapterComments = (chapterId) =>
    allComments.filter((c) => c.chapter_id === chapterId);

  if (chapters.length === 0) return null;

  return (
    <div className="mt-6">
      <div className="flex items-center gap-2 mb-3">
        <MessageCircle className="w-4 h-4 text-primary" />
        <h3 className="font-semibold text-foreground">Bölüm Tartışmaları</h3>
      </div>

      <div className="space-y-2">
        {chapters.map((chapter, idx) => {
          const chapterComments = getChapterComments(chapter.id);
          const isExpanded = expandedChapter === chapter.id;

          return (
            <div key={chapter.id} className="rounded-xl border border-border bg-card overflow-hidden">
              <button
                onClick={() => setExpandedChapter(isExpanded ? null : chapter.id)}
                className="w-full flex items-center justify-between p-3 hover:bg-muted/50 transition-colors text-left"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-6 h-6 rounded-lg bg-accent flex items-center justify-center text-[10px] font-bold text-accent-foreground">
                    {idx + 1}
                  </span>
                  <span className="text-sm font-medium text-foreground">{chapter.title}</span>
                </div>
                <div className="flex items-center gap-2">
                  {chapterComments.length > 0 && (
                    <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">
                      {chapterComments.length} yorum
                    </span>
                  )}
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-muted-foreground" />
                  )}
                </div>
              </button>

              {isExpanded && (
                <div className="border-t border-border px-3 py-3 space-y-3">
                  {/* Comment input */}
                  {currentUser && (
                    <div className="flex gap-2">
                      <Textarea
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        placeholder={`"${chapter.title}" hakkında düşünceniz...`}
                        className="flex-1 min-h-[60px] text-sm resize-none"
                      />
                      <Button
                        size="icon"
                        className="self-end rounded-full h-9 w-9 flex-shrink-0"
                        disabled={!text.trim() || addMutation.isPending}
                        onClick={() => addMutation.mutate(chapter.id)}
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  )}

                  {/* Comments */}
                  {chapterComments.length === 0 ? (
                    <p className="text-xs text-muted-foreground text-center py-3">
                      Bu bölüm hakkında henüz yorum yok
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {chapterComments.map((c) => (
                        <DiscussionComment
                          key={c.id}
                          comment={c}
                          currentUser={currentUser}
                          queryKey={["chapter-discussions", bookId]}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}