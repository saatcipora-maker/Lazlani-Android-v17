import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, X, Share } from "lucide-react";

const DISMISS_KEY = "pwa_install_dismissed";
const DISMISS_DAYS = 7;

export default function PwaInstallPrompt() {
  const [show, setShow] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      window.navigator.standalone === true;
    if (isStandalone) return;

    const dismissed = localStorage.getItem(DISMISS_KEY);
    if (dismissed) {
      const daysSince =
        (Date.now() - new Date(dismissed).getTime()) / (1000 * 60 * 60 * 24);
      if (daysSince < DISMISS_DAYS) return;
    }

    const isIOSDevice =
      /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    const isSafari =
      /^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent);

    if (isIOSDevice && isSafari) {
      setIsIOS(true);
      const timer = setTimeout(() => setShow(true), 3000);
      return () => clearTimeout(timer);
    }

    const handler = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShow(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    setShow(false);
    localStorage.setItem(DISMISS_KEY, new Date().toISOString());
  };

  const handleDismiss = () => {
    setShow(false);
    localStorage.setItem(DISMISS_KEY, new Date().toISOString());
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 60 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="fixed bottom-24 left-3 right-3 z-[100]"
        >
          <div className="glass-card rounded-2xl p-3.5 flex items-center gap-3 shadow-2xl">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{
                background:
                  "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))",
              }}
            >
              <Download className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground">
                Uygulamayı Ana Ekrana Ekle
              </p>
              <p className="text-xs text-muted-foreground leading-tight mt-0.5">
                {isIOS
                  ? "Paylaş butonuna basıp 'Ana Ekrana Ekle'yi seçin"
                  : "Tam ekran, adres çubuğu olmadan çalışsın"}
              </p>
            </div>
            {!isIOS && (
              <button
                onClick={handleInstall}
                className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white flex-shrink-0 active:scale-95 transition-transform"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))",
                }}
              >
                Yükle
              </button>
            )}
            <button
              onClick={handleDismiss}
              className="btn-sm text-muted-foreground hover:text-foreground flex-shrink-0 p-1.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}