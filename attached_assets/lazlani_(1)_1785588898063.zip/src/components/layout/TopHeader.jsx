import { useState } from "react";
import { Search, User, X, ArrowLeft, Bell, Zap } from "lucide-react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import SideMenu from "./SideMenu";
import { useAuth } from "@/lib/AuthContext";
import SearchSuggestions from "./SearchSuggestions";
import { useNavigation } from "@/lib/NavigationContext";

export default function TopHeader() {
  const { user: currentUser } = useAuth();
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const location = useLocation();
  const { getDepth } = useNavigation();
  const routeDepth = getDepth(location.pathname);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setShowSearch(false);
      setSearchQuery("");
    }
  };

  return (
    <header className="sticky top-0 z-40 flex-shrink-0" style={{ paddingTop: "env(safe-area-inset-top)", paddingLeft: "env(safe-area-inset-left, 0px)", paddingRight: "env(safe-area-inset-right, 0px)" }}>
      <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(16,8,24,0.88), rgba(16,8,24,0.65))", backdropFilter: "blur(30px)", WebkitBackdropFilter: "blur(30px)" }} />

      <div className="relative max-w-lg w-full flex items-center h-[52px] px-1">
        {showSearch ? (
          <form onSubmit={handleSearchSubmit} className="flex-1 flex items-center gap-2 relative">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <input autoFocus value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Kitap, yazar veya seri ara..."
                className="w-full pl-9 pr-3 h-10 rounded-xl border text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-primary/30 transition-all"
                style={{ fontSize: "16px", background: "rgba(38,18,55,0.5)", borderColor: "rgba(180,100,240,0.1)" }} />
              <SearchSuggestions query={searchQuery} onClose={() => {setShowSearch(false);setSearchQuery("");}} />
            </div>
            <button type="button" onClick={() => {setShowSearch(false);setSearchQuery("");}} className="text-muted-foreground p-1" aria-label="Kapat">
              <X className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <>
            {/* Left */}
            <div className="flex items-center gap-1 flex-1">
              {routeDepth > 1 ? (
                <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-transform" aria-label="Geri dön">
                  <ArrowLeft className="w-[18px] h-[18px] text-foreground" strokeWidth={1.8} />
                </button>
              ) : (
                <Link to="/subscriptions" className="btn-sm flex items-center gap-1 px-2.5 py-1 rounded-full" style={{ background: "rgba(240,140,60,0.1)", border: "1px solid rgba(240,140,60,0.12)" }}>
                  <Zap className="w-3 h-3 text-accent" />
                  <span className="text-[10px] font-bold text-accent">Premium</span>
                </Link>
              )}
            </div>

            {/* Center — brand name */}
            <div className="flex items-center justify-center px-2">
              <h1 className="font-heading text-[16px] font-bold tracking-[0.22em] select-none text-gold-gradient">LAZLANİ</h1>
            </div>

            {/* Right */}
            <div className="flex items-center gap-0.5 flex-1 justify-end">
              <button onClick={() => setShowSearch(true)} className="w-9 h-9 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors" aria-label="Arama">
                <Search className="w-[18px] h-[18px]" strokeWidth={1.7} />
              </button>

              <Link to="/notifications" className="w-9 h-9 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors" aria-label="Bildirimler">
                <Bell className="w-[18px] h-[18px]" strokeWidth={1.7} />
              </Link>

              <Sheet>
                <SheetTrigger asChild>
                  <button className="relative ml-0.5" aria-label="Menü">
                    <div className="w-9 h-9 rounded-full overflow-hidden transition-all active:scale-95" style={{ border: "1.5px solid rgba(180,100,240,0.15)" }}>
                      {currentUser?.avatar_url ? (
                        <img src={currentUser.avatar_url} alt="profil" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.18), rgba(240,140,60,0.08))" }}>
                          <span className="text-[11px] font-bold text-primary">{currentUser?.full_name?.[0]?.toUpperCase() || <User className="w-3.5 h-3.5 text-primary" />}</span>
                        </div>
                      )}
                    </div>
                  </button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-[280px]"><SideMenu /></SheetContent>
              </Sheet>
            </div>
          </>
        )}
      </div>
    </header>
  );
}