import { Link } from "react-router-dom";
import { User, CreditCard, BookOpen, HelpCircle, Download, FileCheck, Star, ShieldCheck, LogOut, ChevronRight, Settings, Package } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { SheetClose } from "@/components/ui/sheet";
import { useAuth } from "@/lib/AuthContext";

const menuItems = [
  { icon: User, label: "Profilim", path: "/profile", color: "text-blue-500" },
  { icon: CreditCard, label: "Sepet", path: "/cart", color: "text-purple-500" },
  { icon: Package, label: "Abonelik Paketleri", path: "/subscriptions", color: "text-indigo-500" },
  { icon: Settings, label: "Okuma Tercihleri", path: "/profile?tab=tercihler", color: "text-emerald-500" },
  { icon: HelpCircle, label: "Destek", path: "/chat", color: "text-amber-500" },
  { icon: Download, label: "İndirilen Kitaplar", path: "/library", color: "text-cyan-500" },
  { icon: FileCheck, label: "Telif Hakkı", path: "/telif-hakki.html", color: "text-rose-500", external: true },
  { icon: Star, label: "Bizi Değerlendirin", path: "/my-recommendations", color: "text-yellow-500" },
];

export default function SideMenu() {
  const { user: currentUser } = useAuth();
  const isAdmin = currentUser?.role === "admin";

  return (
    <div className="flex flex-col h-full bg-card">
      {/* Profile section */}
      <div className="p-6 pb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center overflow-hidden shadow-lg shadow-primary/20 ring-2 ring-primary/10">
            {currentUser?.avatar_url ? (
              <img src={currentUser.avatar_url} alt="profil" className="w-full h-full object-cover" />
            ) : (
              <span className="text-xl font-bold text-primary-foreground">
                {currentUser?.full_name?.[0]?.toUpperCase() || "?"}
              </span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-heading text-base font-bold text-foreground truncate">
              {currentUser?.display_name || currentUser?.full_name || "Kullanıcı"}
            </h3>
            <p className="text-[11px] text-muted-foreground truncate mt-0.5">{currentUser?.email}</p>
          </div>
        </div>
      </div>

      <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent mx-5" />

      {/* Menu items */}
      <div className="flex-1 py-3 overflow-y-auto">
        {menuItems.map((item) => (
          <SheetClose asChild key={item.path}>
            {item.external ? (
              <a
                href={item.path}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3.5 px-6 py-3.5 text-sm font-medium text-foreground hover:bg-primary/5 active:bg-primary/10 transition-all duration-200 group"
              >
                <div className={`w-9 h-9 rounded-xl bg-muted/80 flex items-center justify-center group-hover:bg-primary/10 transition-colors ${item.color}`}>
                  <item.icon className="w-[18px] h-[18px]" />
                </div>
                <span className="flex-1">{item.label}</span>
                <ChevronRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-primary/60 transition-colors" />
              </a>
            ) : (
              <Link
                to={item.path}
                className="flex items-center gap-3.5 px-6 py-3.5 text-sm font-medium text-foreground hover:bg-primary/5 active:bg-primary/10 transition-all duration-200 group"
              >
                <div className={`w-9 h-9 rounded-xl bg-muted/80 flex items-center justify-center group-hover:bg-primary/10 transition-colors ${item.color}`}>
                  <item.icon className="w-[18px] h-[18px]" />
                </div>
                <span className="flex-1">{item.label}</span>
                <ChevronRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-primary/60 transition-colors" />
              </Link>
            )}
          </SheetClose>
        ))}

        {/* Admin panel link */}
        {isAdmin && (
          <>
            <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent mx-5 my-2" />
            <SheetClose asChild>
              <Link
                to="/admin"
                className="flex items-center gap-3.5 px-6 py-3.5 text-sm font-medium text-foreground hover:bg-primary/5 active:bg-primary/10 transition-all duration-200 group"
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center group-hover:from-primary/30 group-hover:to-accent/30 transition-colors">
                  <ShieldCheck className="w-[18px] h-[18px] text-primary" />
                </div>
                <span className="flex-1 font-semibold text-primary">Yönetici Paneline Giriş</span>
                <ChevronRight className="w-4 h-4 text-primary/60" />
              </Link>
            </SheetClose>
          </>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 pt-2">
        <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent mb-3" />
        <button
          onClick={() => base44.auth.logout("/")}
          className="flex items-center gap-3 px-4 py-3 text-sm text-destructive hover:bg-destructive/5 rounded-xl w-full transition-colors font-medium"
        >
          <LogOut className="w-4 h-4" />
          Çıkış Yap
        </button>
        <p className="text-[10px] text-muted-foreground/50 text-center mt-3">LAZLANİ v5.0</p>
      </div>
    </div>
  );
}