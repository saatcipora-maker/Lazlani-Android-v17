import { useRef, useEffect } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import TopHeader from "./TopHeader";
import BottomNav from "./BottomNav";
import AnimatedPage from "./AnimatedPage";
import { useNavigation } from "@/lib/NavigationContext";
import { useHeartbeat } from "@/hooks/useOnlineStatus";
import PwaInstallPrompt from "@/components/PwaInstallPrompt";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function AppLayout() {
  useHeartbeat();
  const { user } = useAuth();

  // Real-time notification toast
  useEffect(() => {
    if (!user?.email) return;
    const unsub = base44.entities.Notification.subscribe((event) => {
      if (event.type === "create" && event.data?.receiver_email === user.email) {
        toast(event.data.message, { duration: 4000 });
      }
    });
    return unsub;
  }, [user?.email]);
  const location = useLocation();
  const navigate = useNavigate();
  const { getCurrentTabId, isTabRoot, getDepth, updateStack } = useNavigation();

  const prevPath = useRef(location.pathname);
  const prevTabId = useRef(getCurrentTabId(location.pathname));

  const currentTabId = getCurrentTabId(location.pathname);
  const isTabSwitch = prevTabId.current !== currentTabId && isTabRoot(location.pathname);
  const isRootRoute = isTabRoot(location.pathname);

  // Update navigation stack for current tab
  updateStack(location.pathname);

  const prevDepth = getDepth(prevPath.current);
  const currDepth = getDepth(location.pathname);

  // direction: 1 = slide from right (push), -1 = slide from left (pop), 0 = fade (tab switch)
  let direction = 0;
  if (!isTabSwitch) {
    direction = currDepth >= prevDepth ? 1 : -1;
  }

  prevPath.current = location.pathname;
  prevTabId.current = currentTabId;

  const FULLSCREEN_PATHS = ["/lazlande", "/messages", "/chat"];
  const isFullscreen = FULLSCREEN_PATHS.some((p) => location.pathname.startsWith(p));

  return (
    <div className="bg-background font-body h-screen flex flex-col overflow-hidden" style={{ paddingBottom: isFullscreen ? 0 : undefined, paddingLeft: "env(safe-area-inset-left, 0px)", paddingRight: "env(safe-area-inset-right, 0px)" }}>
      {!isFullscreen && <TopHeader />}
      






      
      <main className="flex-1 w-full overflow-y-auto overflow-x-hidden" style={{ paddingBottom: isFullscreen ? 0 : "calc(72px + env(safe-area-inset-bottom, 0px) + 12px)" }}>
        <AnimatePresence mode="wait" initial={false}>
          <AnimatedPage key={location.pathname} direction={direction}>
            <Outlet />
          </AnimatedPage>
        </AnimatePresence>
      </main>
      {!isFullscreen && <BottomNav />}
      <PwaInstallPrompt />
    </div>);

}