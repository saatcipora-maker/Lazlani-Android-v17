import { createContext, useContext } from 'react';
import { useNavigationStack } from '@/hooks/useNavigationStack';

const NavigationStackContext = createContext();

export function NavigationStackProvider({ children, tabId }) {
  const stack = useNavigationStack(tabId);
  
  return (
    <NavigationStackContext.Provider value={stack}>
      {children}
    </NavigationStackContext.Provider>
  );
}

export function useNavigationStackContext() {
  return useContext(NavigationStackContext);
}