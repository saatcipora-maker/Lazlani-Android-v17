import { useState, useEffect, useRef, useCallback } from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, MessageCircle, BookOpen, PenLine, User } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useNavigation } from "@/lib/NavigationContext";
import { useAuth } from "@/lib/AuthContext";

const NAV_ITEMS = [
  { icon: Home, path: "/", label: "Ana Sayfa" },
  { icon: MessageCircle, path: "/messages", label: "Mesajlar", badgeKey: "messages" },
  { icon: PenLine, path: "/write", label: "Yaz", isCenter: true },
  { icon: BookOpen, path: "/library", label: "Kütüphane" },
  { icon: User, path: "/profile", label: "Profil" }
];

export default function BottomNav() {
  const location = useLocation();
  const { getTabStack, clearTabStack, TAB_ROOTS } = useNavigation();
  const { user: authUser } = useAuth();
  const [notifCount, setNotifCount] = useState(0);
  const [msgCount, setMsgCount] = useState(0);
  const timerRef = useRef(null);

  const check = useCallback(async () => {
    if (!authUser?.email) return;
    try {
      const [notifs, msgs] = await Promise.all([
        base44.entities.Notification.filter({ receiver_email: authUser.email, is_read: false }, "-created_date", 50),
        base44.entities.Message.filter({ receiver_email: authUser.email, is_read: false }, "-created_date", 50)
      ]);
      setNotifCount(notifs.length);
      setMsgCount(msgs.length);
    } catch (_) {/* rate limit */}
  }, [authUser?.email]);

  useEffect(() => {
    if (!authUser?.email) return;
    const t = setTimeout(check, 2000);
    const debouncedCheck = () => {
      clearTimeout(timerRef.current);
      timerRef.current = setTimeout(check, 5000);
    };
    const unsub1 = base44.entities.Notification.subscribe(debouncedCheck);
    const unsub2 = base44.entities.Message.subscribe(debouncedCheck);
    return () => { unsub1(); unsub2(); clearTimeout(t); clearTimeout(timerRef.current); };
  }, [authUser?.email, check]);

  const getNavTo = (item, isActive) => {
    if (isActive) return item.path;
    const tab = TAB_ROOTS.find((t) => t.path === item.path);
    if (tab) { const stack = getTabStack(tab.id); if (stack.length > 0) return stack[stack.length - 1]; }
    return item.path;
  };

  const handleClick = (item, isActive) => {
    if (isActive) { const tab = TAB_ROOTS.find((t) => t.path === item.path); if (tab) clearTabStack(tab.id); }
  };

  const getBadge = (item) => {
    if (item.badgeKey === "notifications") return notifCount;
    if (item.badgeKey === "messages") return msgCount;
    return 0;
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 flex justify-center" style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)", paddingLeft: "env(safe-area-inset-left, 0px)", paddingRight: "env(safe-area-inset-right, 0px)" }}>
      <div className="relative mx-4 mb-2 w-full max-w-md rounded-[22px]"
        style={{
          background: "linear-gradient(165deg, rgba(30,12,45,0.92), rgba(24,10,30,0.94))",
          backdropFilter: "blur(30px)",
          WebkitBackdropFilter: "blur(30px)",
          border: "1px solid rgba(180,100,240,0.06)",
          boxShadow: "0 -2px 20px rgba(0,0,0,0.3), 0 4px 24px rgba(0,0,0,0.35)"
        }}>

        <div className="relative flex items-center justify-around px-1" style={{ height: "58px" }}>
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.path || item.path !== "/" && location.pathname.startsWith(item.path);
            const badgeCount = getBadge(item);

            if (item.isCenter) {
              return (
                <Link key={item.path} to={getNavTo(item, isActive)} onClick={() => handleClick(item, isActive)} className="flex-shrink-0 relative -mt-4 z-10" aria-label={item.label}>
                  <div className="relative w-[50px] h-[50px] rounded-full flex items-center justify-center active:scale-90 transition-transform duration-200"
                    style={{
                      background: "linear-gradient(135deg, hsl(270,55%,50%), hsl(290,45%,42%), hsl(24,80%,50%))",
                      boxShadow: "0 4px 20px rgba(130,60,210,0.3), 0 2px 10px rgba(240,140,60,0.1)",
                      outline: "3px solid rgba(24,10,30,0.95)"
                    }}>
                    <PenLine className="w-[20px] h-[20px] text-white" strokeWidth={1.8} />
                  </div>
                </Link>
              );
            }

            return (
              <Link key={item.path} to={getNavTo(item, isActive)} onClick={() => handleClick(item, isActive)} aria-label={item.label}
                className="flex-1 flex flex-col items-center justify-center relative active:scale-90 transition-all duration-200" style={{ minHeight: "50px" }}>
                <div className="relative">
                  <item.icon
                    className={`w-[21px] h-[21px] transition-colors duration-300 ${isActive ? "text-primary" : "text-white/35"}`}
                    strokeWidth={isActive ? 2 : 1.5} />

                  {badgeCount > 0 &&
                    <span className="absolute -top-1 -right-2 text-white text-[7px] font-bold rounded-full min-w-[14px] h-[14px] flex items-center justify-center px-0.5"
                      style={{ background: "linear-gradient(135deg, hsl(24,85%,55%), hsl(340,65%,52%))", boxShadow: "0 0 0 2px rgba(24,10,30,0.95)" }}>
                      {badgeCount > 99 ? "99+" : badgeCount}
                    </span>
                  }
                </div>
                <span className={`text-[8px] mt-1 leading-none transition-colors duration-300 ${isActive ? "text-primary font-semibold" : "text-white/25 font-medium"}`}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}