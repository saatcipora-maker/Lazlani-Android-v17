import { motion } from "framer-motion";

// Standard iOS-like easing: [0.25, 0.46, 0.45, 0.94]
const EASE = [0.25, 0.46, 0.45, 0.94];
const DURATION = 0.22;

// direction: 1 = push forward, -1 = pop back, 0 = tab switch (fade)
export default function AnimatedPage({ children, direction = 1 }) {
  const isFade = direction === 0;

  const variants = isFade
    ? {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit:    { opacity: 0 },
      }
    : {
        initial: { opacity: 0, x: direction * 28 },
        animate: { opacity: 1, x: 0 },
        exit:    { opacity: 0, x: direction * -20 },
      };

  return (
    <motion.div
      variants={variants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ duration: DURATION, ease: EASE }}
      style={{ willChange: "transform, opacity", minHeight: "100%" }}
    >
      {children}
    </motion.div>
  );
}