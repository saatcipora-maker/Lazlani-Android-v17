import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { BookOpen, User } from "lucide-react";

export default function SearchSuggestions({ query, onClose }) {
  const { data: books = [] } = useQuery({
    queryKey: ["search-suggestions-books"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-read_count", 8),
    staleTime: 60000,
  });

  const { data: users = [] } = useQuery({
    queryKey: ["search-suggestions-users"],
    queryFn: () => base44.entities.User.list("-created_date", 10),
    staleTime: 60000,
  });

  const q = query.trim().toLowerCase();

  const filteredBooks = q
    ? books.filter(b => b.title?.toLowerCase().includes(q) || b.author_name?.toLowerCase().includes(q))
    : books;

  const filteredUsers = q
    ? users.filter(u => u.full_name?.toLowerCase().includes(q) || u.email?.toLowerCase().includes(q))
    : users.slice(0, 5);

  if (filteredBooks.length === 0 && filteredUsers.length === 0) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-xl shadow-lg max-h-[60vh] overflow-y-auto z-50">
      {/* Kitaplar */}
      {filteredBooks.length > 0 && (
        <div className="p-2">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-1">
            {q ? "Kitaplar" : "Popüler Kitaplar"}
          </p>
          {filteredBooks.map((book) => (
            <Link
              key={book.id}
              to={`/book/${book.id}`}
              onClick={onClose}
              className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-muted transition-colors"
            >
              {book.cover_image ? (
                <img src={book.cover_image} alt="" className="w-8 h-11 rounded object-cover flex-shrink-0" />
              ) : (
                <div className="w-8 h-11 rounded bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-3.5 h-3.5 text-primary" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-foreground truncate">{book.title}</p>
                <p className="text-[10px] text-muted-foreground truncate">{book.author_name}</p>
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* Yazarlar / Kullanıcılar */}
      {filteredUsers.length > 0 && (
        <div className="p-2 border-t border-border">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-1">
            {q ? "Kullanıcılar" : "Yazarlar"}
          </p>
          {filteredUsers.map((u) => (
            <Link
              key={u.id}
              to={`/user/${encodeURIComponent(u.email)}`}
              onClick={onClose}
              className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-muted transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
                {u.avatar_url ? (
                  <img src={u.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-3.5 h-3.5 text-primary" />
                )}
              </div>
              <p className="text-xs font-medium text-foreground truncate">{u.full_name || u.email}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}