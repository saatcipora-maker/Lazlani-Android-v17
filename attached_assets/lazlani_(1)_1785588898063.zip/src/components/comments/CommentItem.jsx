import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Trash2, CornerDownRight, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";
import { useUserBadges, getBadgeNameClass, getBadgeTextClass } from "@/hooks/useUserBadges";

export default function CommentItem({
  comment,
  currentUser,
  entityName, // "BultenComment" | "MagazinComment" | "ChapterComment"
  queryKey,
  parentId = null, // for nested reply display
}) {
  const [showReply, setShowReply] = useState(false);
  const [replyText, setReplyText] = useState("");
  const queryClient = useQueryClient();
  const badgeMap = useUserBadges();
  const nameClass = getBadgeNameClass(comment.user_email, badgeMap);
  const textClass = getBadgeTextClass(comment.user_email, badgeMap);

  const isOwn = currentUser?.email === comment.user_email;

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities[entityName].delete(comment.id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey }),
  });

  const replyMutation = useMutation({
    mutationFn: () =>
      base44.entities[entityName].create({
        ...comment,
        id: undefined,
        created_date: undefined,
        updated_date: undefined,
        content: `@${comment.user_name}: ${replyText.trim()}`,
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        reply_to: comment.id,
      }),
    onSuccess: () => {
      setReplyText("");
      setShowReply(false);
      queryClient.invalidateQueries({ queryKey });
    },
  });

  return (
    <div className={`flex gap-2 ${parentId ? "ml-8" : ""}`}>
      <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
        <span className="text-[10px] font-bold text-primary">{comment.user_name?.[0]?.toUpperCase() || "?"}</span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="bg-white rounded-2xl px-3.5 py-2.5 shadow-sm" style={{ border: "1px solid rgba(0,0,0,0.08)" }}>
          <p className={`text-[11px] font-semibold ${nameClass || "text-foreground"}`}>{comment.user_name}</p>
          <p className="text-[13px] mt-0.5 leading-relaxed whitespace-pre-wrap break-words" style={{ color: "#111111" }}>{comment.content}</p>
        </div>
        <div className="flex items-center gap-1 mt-1 px-1">
          <span className="text-[10px] text-muted-foreground py-2 px-1">
            {formatDistanceToNow(new Date(comment.created_date), { addSuffix: true, locale: tr })}
          </span>
          {currentUser && (
            <button
              onClick={() => setShowReply((v) => !v)}
              className="text-[10px] text-primary font-medium flex items-center gap-0.5 py-2 px-2 rounded-md"
            >
              <CornerDownRight className="w-3 h-3" />
              Cevap Ver
            </button>
          )}
          {isOwn && (
            <button
              onClick={() => deleteMutation.mutate()}
              disabled={deleteMutation.isPending}
              className="text-[10px] text-destructive font-medium flex items-center gap-0.5 py-2 px-2 rounded-md"
            >
              <Trash2 className="w-3 h-3" />
              Sil
            </button>
          )}
        </div>
        {showReply && (
          <div className="flex gap-2 mt-2">
            <input
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder={`@${comment.user_name} cevapla...`}
              className="flex-1 text-xs border border-border rounded-full px-3 py-1.5 bg-background outline-none focus:border-primary"
              style={{ fontSize: "16px" }}
              onKeyDown={(e) => e.key === "Enter" && replyText.trim() && replyMutation.mutate()}
            />
            <Button
              size="icon"
              className="rounded-full h-7 w-7 flex-shrink-0"
              disabled={!replyText.trim() || replyMutation.isPending}
              onClick={() => replyMutation.mutate()}
            >
              <Send className="w-3 h-3" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}