import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function SplashScreen({ onFinish }) {
  const [show, setShow] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShow(false);
      setTimeout(onFinish, 600);
    }, 2800);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden"
          style={{
            background: "linear-gradient(160deg, hsl(280,35%,10%) 0%, hsl(270,40%,14%) 30%, hsl(290,30%,12%) 55%, hsl(330,25%,10%) 80%, hsl(270,35%,8%) 100%)"
          }}
        >
          {/* Ambient orbs */}
          <div className="absolute top-[-15%] left-[-10%] w-[55vw] h-[55vw] rounded-full" style={{ background: "radial-gradient(circle, rgba(160,80,220,0.12), transparent 65%)", filter: "blur(60px)" }} />
          <div className="absolute bottom-[-10%] right-[-8%] w-[45vw] h-[45vw] rounded-full" style={{ background: "radial-gradient(circle, rgba(240,140,60,0.08), transparent 65%)", filter: "blur(60px)" }} />
          <div className="absolute top-[30%] right-[10%] w-[25vw] h-[25vw] rounded-full" style={{ background: "radial-gradient(circle, rgba(200,100,240,0.06), transparent 65%)", filter: "blur(40px)" }} />

          {/* Logo */}
          <motion.div
            initial={{ scale: 0.6, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
            className="relative mb-6"
          >
            <div className="w-24 h-24 rounded-[28px] flex items-center justify-center relative"
              style={{
                background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(300,50%,48%), hsl(24,85%,55%))",
                boxShadow: "0 12px 48px rgba(130,60,210,0.35), 0 6px 24px rgba(240,140,60,0.15), inset 0 1px 0 rgba(255,255,255,0.15)"
              }}
            >
              <span className="text-4xl font-heading font-bold text-white tracking-wider">L</span>
            </div>
            {/* Glow ring */}
            <motion.div
              animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.6, 0.3] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute inset-[-8px] rounded-[32px]"
              style={{ background: "linear-gradient(135deg, rgba(160,80,220,0.15), rgba(240,140,60,0.08))", filter: "blur(12px)" }}
            />
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="font-heading text-4xl font-bold tracking-[0.15em] text-gold-gradient mb-3"
          >
            LAZLANİ
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.0 }}
            className="text-sm text-foreground/50 text-center max-w-[260px] leading-relaxed"
          >
            Hikâyelerin yazıldığı, keşfedildiği ve paylaşıldığı premium kitap platformu.
          </motion.p>

          {/* Loading dots */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.4 }}
            className="flex gap-1.5 mt-10"
          >
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0.8, 0.3] }}
                transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
                className="w-2 h-2 rounded-full"
                style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}
              />
            ))}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}