import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Upload, X, Loader2, Star } from "lucide-react";
import MagazinPostCard from "./MagazinPostCard";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function MagazinTab() {
  const [currentUser, setCurrentUser] = useState(null);
  const [content, setContent] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["magazin-posts"],
    queryFn: () => base44.entities.MagazinPost.list("-created_date", 50),
  });

  const hasMagazinBadge = currentUser?.has_magazin_badge === true;

  const postMutation = useMutation({
    mutationFn: async () => {
      let image_url = "";
      if (imageFile) {
        setUploading(true);
        const res = await base44.integrations.Core.UploadFile({ file: imageFile });
        image_url = res.file_url;
        setUploading(false);
      }
      await base44.entities.MagazinPost.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        content: content.trim(),
        image_url,
        like_count: 0,
        comment_count: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["magazin-posts"] });
      setContent("");
      setImageFile(null);
      setImagePreview(null);
      toast.success("Paylaşım yapıldı!");
    },
  });

  const handleImage = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  return (
    <div className="py-4 space-y-4">
      {/* Create post - only for magazin badge holders */}
      {currentUser && hasMagazinBadge && (
        <div className="mx-4 bg-card border border-border rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <Star className="w-4 h-4 text-yellow-500" />
            <span className="text-xs font-semibold text-yellow-600">Magazin Yazarı</span>
          </div>
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value.slice(0, 3000))}
            placeholder="Magazin içeriği yaz... (max 3000 karakter)"
            className="min-h-[100px] resize-none text-sm"
          />
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">{content.length}/3000</span>
          </div>
          {imagePreview && (
            <div className="relative">
              <img src={imagePreview} alt="" className="w-full h-40 object-cover rounded-xl" />
              <button
                onClick={() => { setImageFile(null); setImagePreview(null); }}
                className="absolute top-2 right-2 bg-black/50 rounded-full p-1 text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          <div className="flex gap-2">
            <label className="flex items-center gap-2 px-3 py-1.5 border border-border rounded-full cursor-pointer text-xs text-muted-foreground hover:bg-muted transition-colors">
              <Upload className="w-3.5 h-3.5" />
              Fotoğraf
              <input type="file" accept="image/*" className="hidden" onChange={handleImage} />
            </label>
            <Button
              size="sm"
              className="rounded-full ml-auto"
              disabled={!content.trim() || postMutation.isPending || uploading}
              onClick={() => postMutation.mutate()}
            >
              {(postMutation.isPending || uploading) && <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" />}
              Paylaş
            </Button>
          </div>
        </div>
      )}

      {/* Non-badge notice */}
      {currentUser && !hasMagazinBadge && (
        <div className="mx-4 bg-yellow-50 border border-yellow-200 rounded-2xl p-4 text-center">
          <Star className="w-6 h-6 text-yellow-500 mx-auto mb-1" />
          <p className="text-sm font-semibold text-yellow-800">Sadece Magazin rozetli yazarlar paylaşım yapabilir</p>
          <p className="text-xs text-yellow-600 mt-1">Yorum ve beğeni yapabilirsiniz</p>
        </div>
      )}

      {/* Posts */}
      <div className="px-4 space-y-4">
        {isLoading ? (
          [1, 2].map((i) => <Skeleton key={i} className="h-48 rounded-2xl" />)
        ) : posts.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-8">Henüz magazin yazısı yok</p>
        ) : (
          posts.map((post) => (
            <MagazinPostCard
              key={post.id}
              post={post}
              currentUser={currentUser}
              onDelete={currentUser?.email === post.user_email ? () => {
                base44.entities.MagazinPost.delete(post.id).then(() =>
                  queryClient.invalidateQueries({ queryKey: ["magazin-posts"] })
                );
              } : undefined}
            />
          ))
        )}
      </div>
    </div>
  );
}