import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Heart, MessageCircle, Send, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";
import CommentItem from "@/components/comments/CommentItem";
import { useUserBadges, getBadgeNameClass, getBadgeTextClass } from "@/hooks/useUserBadges";
import { useOptimisticUpdate } from "@/hooks/useOptimisticUpdate";

export default function MagazinPostCard({ post, currentUser, onDelete }) {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const queryClient = useQueryClient();
  const { optimisticLike, optimisticComment, rollback } = useOptimisticUpdate();
  const isOwn = currentUser?.email === post.user_email;
  const badgeMap = useUserBadges();
  const nameClass = getBadgeNameClass(post.user_email, badgeMap);
  const textClass = getBadgeTextClass(post.user_email, badgeMap);

  const { data: likes = [] } = useQuery({
    queryKey: ["magazin-likes", post.id],
    queryFn: () => base44.entities.MagazinLike.filter({ post_id: post.id }, "-created_date", 200),
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["magazin-comments", post.id],
    queryFn: () => base44.entities.MagazinComment.filter({ post_id: post.id }, "created_date", 100),
  });

  // Real-time subscriptions
  useEffect(() => {
    const unsubLikes = base44.entities.MagazinLike.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["magazin-likes", post.id] });
    });
    const unsubComments = base44.entities.MagazinComment.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["magazin-comments", post.id] });
    });
    return () => { unsubLikes(); unsubComments(); };
  }, [post.id]);

  const isLiked = likes.some((l) => l.user_email === currentUser?.email);

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (isLiked) {
        const mine = likes.find((l) => l.user_email === currentUser.email);
        await base44.entities.MagazinLike.delete(mine.id);
        await base44.entities.MagazinPost.update(post.id, { like_count: Math.max(0, (post.like_count || 0) - 1) });
      } else {
        await base44.entities.MagazinLike.create({ post_id: post.id, user_email: currentUser.email });
        await base44.entities.MagazinPost.update(post.id, { like_count: (post.like_count || 0) + 1 });
      }
    },
    onMutate: () => {
      queryClient.cancelQueries({ queryKey: ["magazin-likes", post.id] });
      const prevLikes = queryClient.getQueryData(["magazin-likes", post.id]);
      queryClient.setQueryData(["magazin-likes", post.id], (old) => {
        if (isLiked) return (old || []).filter((l) => l.user_email !== currentUser.email);
        return [...(old || []), { id: "__temp__", post_id: post.id, user_email: currentUser.email }];
      });
      const prevPosts = optimisticLike({ entityId: post.id, queryKey: ["magazin-posts"], userId: currentUser.email, isLiked });
      return { prevLikes, prevPosts };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prevPosts !== undefined) rollback(["magazin-posts"], ctx.prevPosts);
      if (ctx?.prevLikes !== undefined) queryClient.setQueryData(["magazin-likes", post.id], ctx.prevLikes);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["magazin-likes", post.id] });
      queryClient.invalidateQueries({ queryKey: ["magazin-posts"] });
    },
  });

  const commentMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.MagazinComment.create({
        post_id: post.id,
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        content: commentText.trim(),
      });
      await base44.entities.MagazinPost.update(post.id, { comment_count: (post.comment_count || 0) + 1 });
    },
    onMutate: () => {
      const newComment = {
        post_id: post.id,
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email,
        content: commentText.trim(),
      };
      const prevComments = optimisticComment({ entityId: post.id, queryKey: ["magazin-comments", post.id], newComment });
      setCommentText("");
      return { prevComments };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prevComments !== undefined) rollback(["magazin-comments", post.id], ctx.prevComments);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["magazin-comments", post.id] });
      queryClient.invalidateQueries({ queryKey: ["magazin-posts"] });
    },
  });

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-4 pb-2">
        <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-bold text-primary">{post.user_name?.[0]?.toUpperCase() || "?"}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-semibold ${nameClass || "text-foreground"}`}>{post.user_name}</p>
          <p className="text-[10px] text-muted-foreground">
            {formatDistanceToNow(new Date(post.created_date), { addSuffix: true, locale: tr })}
          </p>
        </div>
      </div>

      {/* Image */}
      {post.image_url && (
        <img src={post.image_url} alt="" className="w-full object-cover max-h-80" />
      )}

      {/* Content */}
      <div className="px-4 py-3">
        <p className={`text-sm leading-relaxed whitespace-pre-wrap ${textClass || "text-foreground"}`}>{post.content}</p>
      </div>

      {/* Actions */}
      <div className="px-4 pb-3 flex items-center gap-4 border-t border-border pt-2">
        <button
          className={`flex items-center gap-1.5 text-sm transition-colors ${isLiked ? "text-red-500" : "text-muted-foreground hover:text-red-400"}`}
          onClick={() => currentUser && likeMutation.mutate()}
          disabled={!currentUser || likeMutation.isPending}
        >
          <Heart className={`w-4 h-4 ${isLiked ? "fill-current" : ""}`} />
          <span>{likes.length}</span>
        </button>
        <button
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
          onClick={() => setShowComments((v) => !v)}
        >
          <MessageCircle className="w-4 h-4" />
          <span>{comments.length}</span>
        </button>
        {isOwn && onDelete && (
          <button
            onClick={onDelete}
            className="ml-auto flex items-center gap-1 text-xs text-destructive"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Sil
          </button>
        )}
      </div>

      {/* Comments section */}
      {showComments && (
        <div className="border-t border-border px-4 pb-4 pt-3 space-y-3">
          {comments.map((c) => (
            <CommentItem
              key={c.id}
              comment={c}
              currentUser={currentUser}
              entityName="MagazinComment"
              queryKey={["magazin-comments", post.id]}
            />
          ))}
          {currentUser && (
            <div className="flex gap-2 mt-2">
              <input
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Yorum yaz..."
                className="flex-1 border border-border rounded-full px-3 py-1.5 bg-background outline-none focus:border-primary"
                style={{ fontSize: "16px" }}
                onKeyDown={(e) => e.key === "Enter" && commentText.trim() && commentMutation.mutate()}
              />
              <Button
                size="icon"
                className="rounded-full h-8 w-8 flex-shrink-0"
                disabled={!commentText.trim() || commentMutation.isPending}
                onClick={() => commentMutation.mutate()}
              >
                <Send className="w-3.5 h-3.5" />
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}