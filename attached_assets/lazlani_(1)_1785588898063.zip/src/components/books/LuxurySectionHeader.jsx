import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

export default function LuxurySectionHeader({ title, subtitle, icon, linkTo, linkLabel = "Tümünü Gör" }) {
  return (
    <div className="px-5 mb-3.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {icon && (
            <div className="w-9 h-9 rounded-[14px] glass-card flex items-center justify-center">{icon}</div>
          )}
          <div>
            {subtitle && <p className="text-[8px] font-bold uppercase tracking-[0.2em] text-primary/40 mb-0.5">{subtitle}</p>}
            <h2 className="font-heading text-foreground text-[16px] font-bold leading-tight tracking-tight">{title}</h2>
          </div>
        </div>
        {linkTo && (
          <Link to={linkTo} className="btn-sm flex items-center gap-0.5 text-primary/50 text-[10px] font-semibold hover:text-primary transition-colors">
            {linkLabel}<ChevronRight className="w-3.5 h-3.5" />
          </Link>
        )}
      </div>
    </div>
  );
}