import LuxuryBookCard from "./LuxuryBookCard";
export default function PremiumBookCard(props) {
  return <LuxuryBookCard {...props} />;
}