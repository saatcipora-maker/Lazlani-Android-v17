import LuxuryBookList from "./LuxuryBookList";
export default function PremiumBookList(props) {
  return <LuxuryBookList {...props} />;
}