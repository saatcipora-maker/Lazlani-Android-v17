import LuxurySectionHeader from "./LuxurySectionHeader";
export default function SectionHeader(props) {
  return <LuxurySectionHeader {...props} />;
}