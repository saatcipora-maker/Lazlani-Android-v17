import { Eye, Heart, MessageCircle, Star, Bookmark } from "lucide-react";
import { fmtStat } from "@/lib/bookStats";

export default function BookStatsBar({ book, totalReads, totalLikes, totalComments, libraryCount }) {
  const avgRating = book.average_rating || 0;
  const ratingCount = book.rating_count || 0;

  const stats = [
    { icon: Eye, label: "Okunma", value: totalReads ?? book.read_count ?? 0, color: "text-blue-400" },
    { icon: Heart, label: "Beğeni", value: totalLikes, color: "text-red-400" },
    { icon: MessageCircle, label: "Yorum", value: totalComments, color: "text-cyan-400" },
    { icon: Star, label: "Puan", value: avgRating > 0 ? `${avgRating.toFixed(1)}` : "—", sub: ratingCount > 0 ? `(${ratingCount})` : "", color: "text-yellow-400" },
    { icon: Bookmark, label: "Kütüphane", value: libraryCount || 0, color: "text-emerald-400" },
  ];

  return (
    <div className="grid grid-cols-5 gap-2 mt-3">
      {stats.map((s, i) => (
        <div key={i} className="flex flex-col items-center gap-0.5 p-2 rounded-xl bg-card border border-border">
          <s.icon className={`w-3.5 h-3.5 ${s.color}`} />
          <span className="text-[13px] font-bold text-foreground leading-none mt-0.5">{fmtStat(s.value)}</span>
          <span className="text-[8px] text-muted-foreground leading-none">{s.label}</span>
          {s.sub && <span className="text-[7px] text-muted-foreground/60 leading-none">{s.sub}</span>}
        </div>
      ))}
    </div>
  );
}