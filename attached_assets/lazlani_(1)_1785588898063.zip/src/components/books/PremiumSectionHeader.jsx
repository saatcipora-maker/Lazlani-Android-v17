import LuxurySectionHeader from "./LuxurySectionHeader";
export default function PremiumSectionHeader(props) {
  return <LuxurySectionHeader {...props} />;
}