import LuxuryBookList from "./LuxuryBookList";
export default function HorizontalBookList(props) {
  return <LuxuryBookList {...props} />;
}