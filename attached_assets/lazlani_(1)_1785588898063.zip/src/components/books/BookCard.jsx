import LuxuryBookCard from "./LuxuryBookCard";
export default function BookCard(props) {
  return <LuxuryBookCard {...props} />;
}