import { Link } from "react-router-dom";
import { Heart, Eye, Star, MessageCircle } from "lucide-react";
import { useFavorites } from "@/hooks/useFavorites";
import { fmtStat } from "@/lib/bookStats";

const SIZE_MAP = {
  small: "w-[100px] h-[140px]",
  medium: "w-[126px] h-[178px]",
  large: "w-[144px] h-[202px]",
  featured: "w-[156px] h-[220px]",
  hero: "w-[168px] h-[238px]",
};

export default function LuxuryBookCard({ book, size = "medium", showInfo = false, rank }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const fav = isFavorite(book.id);

  const handleFavorite = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite.mutate({ bookId: book.id, bookTitle: book.title });
  };

  return (
    <Link to={`/book/${book.id}`} className="flex-shrink-0 group">
      <div className="relative">
        {/* Rank badge */}
        {rank && (
          <div className="absolute -left-1 -top-1 z-20 w-7 h-7 rounded-full flex items-center justify-center ring-2"
            style={{ background: "linear-gradient(135deg, hsl(272,70%,58%), hsl(310,55%,48%))", boxShadow: "0 4px 14px rgba(140,70,230,0.35)", ringColor: "hsl(268,32%,6%)" }}>
            <span className="text-[10px] font-black text-white">{rank}</span>
          </div>
        )}

        <div className={`${SIZE_MAP[size]} rounded-[18px] overflow-hidden relative premium-card`}
          style={{ boxShadow: "0 12px 40px -8px rgba(0,0,0,0.6), 0 4px 14px -4px rgba(0,0,0,0.3), 0 0 0 1px rgba(170,90,255,0.06)" }}>
          {book.cover_image ? (
            <img src={book.cover_image} alt={book.title} className="w-full h-full object-cover" loading="lazy" />
          ) : (
            <div className="w-full h-full flex items-center justify-center p-3" style={{ background: "linear-gradient(135deg, rgba(140,70,230,0.35), rgba(220,100,200,0.15), hsl(268,24%,10%))" }}>
              <span className="text-foreground font-display text-sm font-bold text-center leading-snug">{book.title}</span>
            </div>
          )}

          {/* Gradient overlay */}
          <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.1) 45%, transparent 100%)" }} />

          {/* Favorite button */}
          <button onClick={handleFavorite}
            className="btn-sm absolute top-2.5 right-2.5 w-7 h-7 rounded-full flex items-center justify-center z-10 active:scale-90 transition-transform"
            style={{ background: "rgba(0,0,0,0.35)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.06)" }}>
            <Heart className={`w-3.5 h-3.5 transition-all duration-300 ${fav ? "fill-pink-400 text-pink-400 drop-shadow-[0_0_6px_rgba(236,72,153,0.5)]" : "text-white/40"}`} />
          </button>

          {/* Bottom info */}
          <div className="absolute bottom-0 left-0 right-0 p-2.5">
            {showInfo && <p className="text-white font-semibold text-[10px] leading-tight truncate mb-0.5">{book.title}</p>}
            <p className="text-white/40 text-[9px] font-medium truncate">{book.author_name}</p>
            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
              <span className="flex items-center gap-0.5 text-white/30 text-[8px]"><Eye className="w-2.5 h-2.5" /> {fmtStat(book.read_count)}</span>
              <span className="flex items-center gap-0.5 text-white/30 text-[8px]"><Heart className="w-2.5 h-2.5" /> {fmtStat(book.like_count)}</span>
              {book.comment_count > 0 && <span className="flex items-center gap-0.5 text-white/30 text-[8px]"><MessageCircle className="w-2.5 h-2.5" /> {fmtStat(book.comment_count)}</span>}
              {book.average_rating > 0 && <span className="flex items-center gap-0.5 text-yellow-400/60 text-[8px]"><Star className="w-2.5 h-2.5 fill-current" /> {book.average_rating.toFixed(1)}</span>}
            </div>
          </div>

          {/* Approved badge */}
          {book.is_approved && (
            <div className="absolute top-2.5 left-2.5 text-white text-[7px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5"
              style={{ background: "linear-gradient(135deg, rgba(140,70,230,0.85), rgba(200,100,220,0.7))", backdropFilter: "blur(8px)" }}>
              <Star className="w-2 h-2 fill-current" /> Onaylı
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}