import LuxuryBookCard from "./LuxuryBookCard";

export default function LuxuryBookList({ books, size = "medium", showInfo = false, showRanks = false }) {
  if (!books || books.length === 0) {
    return (
      <div className="px-5 py-10 text-center text-muted-foreground/30 text-sm font-medium">
        Henüz kitap bulunmuyor
      </div>
    );
  }

  return (
    <div className="overflow-x-auto scrollbar-hide">
      <div className="flex gap-3.5 px-5 pb-2">
        {books.map((book, i) => (
          <LuxuryBookCard
            key={book.id}
            book={book}
            size={size}
            showInfo={showInfo}
            rank={showRanks ? i + 1 : undefined}
          />
        ))}
      </div>
    </div>
  );
}