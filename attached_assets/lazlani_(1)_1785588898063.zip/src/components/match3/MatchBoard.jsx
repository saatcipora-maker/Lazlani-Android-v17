import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bomb, Zap } from "lucide-react";
import {
  BOARD_SIZE, COLORS, createBoard, findMatchGroups, getAllMatchedCells,
  removeCells, applyGravity, areAdjacent, swapTiles, scoreForMatch,
  cascadeMultiplier, levelTarget, levelMoves, detonateBomb, hasValidMoves,
} from "@/lib/match3Logic";

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

export default function MatchBoard({ profile, onScoreGain, onLevelComplete, onUseBomb, onMovesOut }) {
  const [board, setBoard] = useState(() => createBoard());
  const [selected, setSelected] = useState(null);
  const [exploding, setExploding] = useState(new Set());
  const [busy, setBusy] = useState(false);
  const [sessionScore, setSessionScore] = useState(0);
  const [moves, setMoves] = useState(() => levelMoves(profile?.match_level || 1));
  const [combo, setCombo] = useState(0);
  const [bombFlash, setBombFlash] = useState(null);
  const boardRef = useRef(board);
  boardRef.current = board;

  const level = profile?.match_level || 1;
  const target = levelTarget(level);
  const bombs = profile?.daily_bombs ?? 3;

  const gainScore = useCallback((amount) => {
    setSessionScore(prev => {
      const next = prev + amount;
      if (next >= target) {
        // Level complete
        onLevelComplete?.(next, level);
      }
      return next;
    });
    onScoreGain?.(amount);
  }, [target, onScoreGain, onLevelComplete, level]);

  const processCascade = useCallback(async (startBoard) => {
    let current = startBoard;
    let depth = 0;
    let cascadeScore = 0;

    while (true) {
      const groups = findMatchGroups(current);
      if (groups.length === 0) break;

      depth++;
      const mult = cascadeMultiplier(depth);
      const matchedCells = getAllMatchedCells(groups);

      // Animate explosion
      setExploding(matchedCells);
      setCombo(depth);
      await sleep(350);

      // Score
      let stepScore = 0;
      groups.forEach(g => { stepScore += scoreForMatch(g.length); });
      stepScore = Math.floor(stepScore * mult);
      cascadeScore += stepScore;

      // Remove + gravity
      current = removeCells(current, matchedCells);
      setBoard(current);
      setExploding(new Set());
      await sleep(100);
      current = applyGravity(current);
      setBoard(current);
      await sleep(300);
    }

    if (cascadeScore > 0) {
      gainScore(cascadeScore);
    }
    setCombo(0);

    // Check for valid moves
    if (!hasValidMoves(current)) {
      current = createBoard();
      setBoard(current);
    }

    return cascadeScore;
  }, [gainScore]);

  const handleSwap = useCallback(async (r1, c1, r2, c2) => {
    if (busy) return;
    setBusy(true);

    const swapped = swapTiles(boardRef.current, r1, c1, r2, c2);
    const groups = findMatchGroups(swapped);

    if (groups.length === 0) {
      // Invalid swap — animate back
      setBoard(swapped);
      await sleep(200);
      setBoard(boardRef.current);
      setBusy(false);
      return;
    }

    // Valid swap
    setBoard(swapped);
    setMoves(prev => prev - 1);
    await sleep(150);

    await processCascade(swapped);

    // Check moves
    setMoves(prevMoves => {
      if (prevMoves <= 0) {
        onMovesOut?.();
      }
      return prevMoves;
    });

    setBusy(false);
  }, [busy, processCascade, onMovesOut]);

  const handleTileTap = useCallback((r, c) => {
    if (busy) return;
    if (!selected) {
      setSelected({ r, c });
      return;
    }
    if (selected.r === r && selected.c === c) {
      setSelected(null);
      return;
    }
    if (areAdjacent(selected.r, selected.c, r, c)) {
      handleSwap(selected.r, selected.c, r, c);
      setSelected(null);
    } else {
      setSelected({ r, c });
    }
  }, [busy, selected, handleSwap]);

  const handleBomb = useCallback(async () => {
    if (busy || bombs <= 0) return;
    setBusy(true);
    onUseBomb?.();

    const { color, cells, count, score } = detonateBomb(boardRef.current);
    setBombFlash(color);
    setExploding(cells);
    await sleep(500);

    let current = removeCells(boardRef.current, cells);
    setBoard(current);
    setExploding(new Set());
    await sleep(100);
    current = applyGravity(current);
    setBoard(current);
    await sleep(300);
    setBombFlash(null);

    gainScore(score);
    await processCascade(current);
    setBusy(false);
  }, [busy, bombs, onUseBomb, gainScore, processCascade]);

  const resetBoard = useCallback(() => {
    setBoard(createBoard());
    setSessionScore(0);
    setMoves(levelMoves(profile?.match_level || 1));
    setSelected(null);
  }, [profile?.match_level]);

  const tileSize = `calc((min(92vw, 420px) - ${(BOARD_SIZE - 1) * 4}px) / ${BOARD_SIZE})`;

  return (
    <div className="flex flex-col items-center gap-3">
      {/* Stats bar */}
      <div className="w-full max-w-[420px] flex items-center justify-between gap-2">
        <div className="flex-1 glass-card rounded-2xl px-3 py-2 text-center">
          <p className="text-[9px] text-muted-foreground font-medium">Seviye</p>
          <p className="text-lg font-heading font-bold text-primary">{level}</p>
        </div>
        <div className="flex-1 glass-card rounded-2xl px-3 py-2 text-center">
          <p className="text-[9px] text-muted-foreground font-medium">Puan</p>
          <p className="text-lg font-heading font-bold text-accent">{sessionScore}<span className="text-[10px] text-muted-foreground">/{target}</span></p>
        </div>
        <div className="flex-1 glass-card rounded-2xl px-3 py-2 text-center">
          <p className="text-[9px] text-muted-foreground font-medium">Hamle</p>
          <p className={`text-lg font-heading font-bold ${moves <= 5 ? "text-red-400" : "text-foreground"}`}>{moves}</p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full max-w-[420px] h-2 rounded-full bg-muted overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ background: "linear-gradient(90deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}
          animate={{ width: `${Math.min(100, (sessionScore / target) * 100)}%` }}
          transition={{ duration: 0.4 }}
        />
      </div>

      {/* Combo indicator */}
      <AnimatePresence>
        {combo >= 2 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5 }}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-full"
            style={{ background: "linear-gradient(135deg, rgba(245,158,11,0.2), rgba(236,72,153,0.2))", border: "1px solid rgba(245,158,11,0.3)" }}
          >
            <Zap className="w-3.5 h-3.5 text-accent" fill="currentColor" />
            <span className="text-xs font-bold text-accent">Kombo x{combo}!</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Board */}
      <div
        className="relative rounded-2xl gold-glass p-2"
        style={{ width: "min(92vw, 420px)" }}
      >
        {bombFlash !== null && (
          <div
            className="absolute inset-0 rounded-2xl pointer-events-none z-20"
            style={{ background: COLORS[bombFlash].glow, opacity: 0.3, filter: "blur(20px)" }}
          />
        )}
        <div className="relative grid" style={{ gridTemplateColumns: `repeat(${BOARD_SIZE}, 1fr)`, gap: "4px" }}>
          {board.map((row, r) =>
            row.map((tile, c) => {
              const key = tile ? tile.id : `empty-${r}-${c}`;
              const isExploding = exploding.has(`${r},${c}`);
              const isSelected = selected && selected.r === r && selected.c === c;
              return (
                <motion.div
                  key={key}
                  layout
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: isExploding ? 0 : 1, opacity: isExploding ? 0 : 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  onClick={() => tile && handleTileTap(r, c)}
                  className="cursor-pointer rounded-lg flex items-center justify-center"
                  style={{
                    width: tileSize,
                    height: tileSize,
                    background: tile ? COLORS[tile.color].bg : "transparent",
                    boxShadow: isSelected ? `0 0 0 3px hsl(270,60%,56%), 0 0 16px ${COLORS[tile.color].glow}` : "inset 0 1px 0 rgba(255,255,255,0.15), 0 2px 6px rgba(0,0,0,0.2)",
                    transform: isSelected ? "scale(1.08)" : "scale(1)",
                  }}
                >
                  {tile && (
                    <div
                      className="w-1/2 h-1/2 rounded-full"
                      style={{ background: "rgba(255,255,255,0.25)", filter: "blur(2px)" }}
                    />
                  )}
                </motion.div>
              );
            })
          )}
        </div>
      </div>

      {/* Bomb button */}
      <button
        onClick={handleBomb}
        disabled={busy || bombs <= 0}
        className="flex items-center gap-2 px-5 py-2.5 rounded-2xl font-semibold text-sm transition-all active:scale-95 disabled:opacity-40"
        style={{
          background: bombs > 0 ? "linear-gradient(135deg, #7c3aed, #c026d3)" : "rgba(100,100,100,0.2)",
          boxShadow: bombs > 0 ? "0 4px 16px rgba(124,58,237,0.35)" : "none",
        }}
      >
        <Bomb className="w-4 h-4 text-white" fill="currentColor" />
        <span className="text-white">Çikolatalı Bomba</span>
        <span className="text-white/80 text-xs bg-white/20 px-2 py-0.5 rounded-full">{bombs}</span>
      </button>

      {bombs <= 0 && (
        <p className="text-[10px] text-muted-foreground">Yarın 3 yeni bomba hakkı gelecek</p>
      )}
    </div>
  );
}