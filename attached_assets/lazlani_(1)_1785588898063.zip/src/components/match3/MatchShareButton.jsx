import { useState } from "react";
import { Share2, Instagram, MessageCircle, Copy, Check } from "lucide-react";
import { getEarnedBadges } from "@/lib/gameBadges";

export default function MatchShareButton({ profile }) {
  const [showOptions, setShowOptions] = useState(false);
  const [copied, setCopied] = useState(false);

  const buildShareText = () => {
    const level = profile?.match_level || 1;
    const score = profile?.total_score || 0;
    const badges = getEarnedBadges(score);
    const badgeNames = badges.map((b) => b.name).join(", ");
    return `🎮 Renk Patlatma\n🏆 Seviye ${level} | ${score} puan\n🎖️ Nişanlar: ${badgeNames}\n\n#Lazlani #RenkPatlatma`;
  };

  const handleShare = async () => {
    const text = buildShareText();
    if (navigator.share) {
      try {
        await navigator.share({ title: "Renk Patlatma", text });
        return;
      } catch (_) {}
    }
    setShowOptions(true);
  };

  const handleWhatsApp = () => {
    const text = buildShareText();
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const handleInstagram = async () => {
    const text = buildShareText();
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (_) {}
    window.open("https://www.instagram.com/", "_blank");
  };

  return (
    <div className="w-full max-w-sm">
      <button
        onClick={handleShare}
        className="w-full h-11 rounded-2xl flex items-center justify-center gap-2 text-sm font-semibold text-foreground glass-card active:scale-[0.97] transition-transform"
      >
        <Share2 className="w-4 h-4 text-primary" />
        Sonucunu Paylaş
      </button>
      {showOptions && (
        <div className="flex gap-2 mt-2">
          <button
            onClick={handleWhatsApp}
            className="flex-1 h-11 rounded-2xl flex items-center justify-center gap-2 text-sm font-semibold text-white active:scale-95 transition-transform"
            style={{ background: "#25D366" }}
          >
            <MessageCircle className="w-4 h-4" fill="currentColor" />
            WhatsApp
          </button>
          <button
            onClick={handleInstagram}
            className="flex-1 h-11 rounded-2xl flex items-center justify-center gap-2 text-sm font-semibold text-white active:scale-95 transition-transform"
            style={{ background: "linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045)" }}
          >
            {copied ? <Check className="w-4 h-4" /> : <Instagram className="w-4 h-4" />}
            {copied ? "Kopyalandı" : "Instagram"}
          </button>
        </div>
      )}
    </div>
  );
}