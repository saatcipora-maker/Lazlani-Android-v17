import { Footprints, Palette, Flame, Zap, Crown, Sparkles, Lock } from "lucide-react";
import { GAME_BADGES } from "@/lib/gameBadges";

const ICON_MAP = { Footprints, Palette, Flame, Zap, Crown, Sparkles };

export default function MatchBadges({ totalScore = 0, compact = false }) {
  return (
    <div className={compact ? "flex gap-2 overflow-x-auto scrollbar-hide pb-1" : "grid grid-cols-3 gap-2"}>
      {GAME_BADGES.map((badge) => {
        const earned = (totalScore || 0) >= badge.threshold;
        const Icon = ICON_MAP[badge.icon] || Lock;
        return (
          <div
            key={badge.id}
            className={`flex flex-col items-center gap-1.5 p-3 rounded-xl text-center transition-all ${compact ? "flex-shrink-0 w-20" : ""}`}
            style={{
              background: earned ? `linear-gradient(135deg, ${badge.color}22, ${badge.color}11)` : "rgba(38,18,55,0.2)",
              border: earned ? `1px solid ${badge.color}44` : "1px solid rgba(200,140,255,0.04)",
            }}
          >
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{
                background: earned ? `linear-gradient(135deg, ${badge.color}, ${badge.color}99)` : "rgba(100,100,100,0.2)",
                boxShadow: earned ? `0 0 12px ${badge.color}44` : "none",
              }}
            >
              {earned ? (
                <Icon className="w-5 h-5 text-white" />
              ) : (
                <Lock className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
            <p className={`text-[10px] font-semibold leading-tight ${earned ? "text-foreground" : "text-muted-foreground"}`}>
              {badge.name}
            </p>
            {!compact && (
              <p className="text-[8px] text-muted-foreground leading-tight">
                {earned ? "Kazanıldı" : `${badge.threshold} puan`}
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}