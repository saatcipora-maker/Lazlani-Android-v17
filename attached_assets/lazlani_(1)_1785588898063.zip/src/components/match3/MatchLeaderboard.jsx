import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Crown, Trophy } from "lucide-react";

const PERIODS = [
  { key: "daily_score", label: "Günlük" },
  { key: "weekly_score", label: "Haftalık" },
  { key: "monthly_score", label: "Aylık" },
  { key: "total_score", label: "Tüm Zamanlar" },
];

export default function MatchLeaderboard({ currentUserEmail }) {
  const [activePeriod, setActivePeriod] = useState("daily_score");

  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ["match-leaderboard", activePeriod],
    queryFn: () => base44.entities.GameProfile.filter({}, `-${activePeriod}`, 100),
  });

  const sorted = [...profiles]
    .filter(p => (p[activePeriod] || 0) > 0)
    .sort((a, b) => (b[activePeriod] || 0) - (a[activePeriod] || 0));

  const myRank = sorted.findIndex(p => p.user_email === currentUserEmail);

  return (
    <div className="flex flex-col gap-3">
      {/* Period tabs */}
      <div className="flex gap-1.5 p-1 rounded-2xl glass-card">
        {PERIODS.map(p => (
          <button
            key={p.key}
            onClick={() => setActivePeriod(p.key)}
            className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${activePeriod === p.key ? "text-white" : "text-muted-foreground"}`}
            style={activePeriod === p.key ? { background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" } : {}}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* My rank card */}
      {myRank >= 0 && (
        <div className="glass-card rounded-2xl px-4 py-3 flex items-center gap-3" style={{ border: "1px solid rgba(245,158,11,0.3)" }}>
          <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm" style={{ background: "linear-gradient(135deg, #f59e0b, #d97706)" }}>
            <Trophy className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Senin sıran</p>
            <p className="text-sm font-bold text-foreground">#{myRank + 1}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Seviyen</p>
            <p className="text-sm font-bold text-primary">{sorted[myRank]?.match_level || 1}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Puanın</p>
            <p className="text-sm font-bold text-accent">{sorted[myRank]?.[activePeriod] || 0}</p>
          </div>
        </div>
      )}

      {/* Leaderboard list */}
      <div className="flex flex-col gap-1.5">
        {isLoading && (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-muted border-t-primary rounded-full animate-spin" />
          </div>
        )}
        {!isLoading && sorted.length === 0 && (
          <div className="text-center py-8">
            <p className="text-sm text-muted-foreground">Henüz puan yok. İlk oyunu başlatan sen ol!</p>
          </div>
        )}
        {sorted.map((p, i) => {
          const isMe = p.user_email === currentUserEmail;
          const medal = i === 0 ? "#fbbf24" : i === 1 ? "#cbd5e1" : i === 2 ? "#d97706" : null;
          return (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.03 }}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl"
              style={{
                background: isMe ? "rgba(245,158,11,0.08)" : "rgba(38,18,55,0.3)",
                border: isMe ? "1px solid rgba(245,158,11,0.2)" : "1px solid rgba(200,140,255,0.04)",
              }}
            >
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                style={{ background: medal ? `linear-gradient(135deg, ${medal}, ${medal}99)` : "rgba(130,60,210,0.15)", color: medal ? "#1a1a1a" : "hsl(var(--foreground))" }}>
                {i < 3 ? <Crown className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-xs font-semibold truncate ${isMe ? "text-accent" : "text-foreground"}`}>
                  {p.user_name || p.user_email?.split("@")[0]}
                </p>
                <p className="text-[9px] text-muted-foreground">Seviye {p.match_level || 1}</p>
              </div>
              <p className="text-sm font-bold text-accent flex-shrink-0">{p[activePeriod] || 0}</p>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}