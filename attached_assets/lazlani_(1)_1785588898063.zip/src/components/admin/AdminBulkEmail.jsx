import { useState } from "react";
import { Send, FileText, History } from "lucide-react";
import AdminEmailCompose from "@/components/admin/AdminEmailCompose";
import AdminEmailHistory from "@/components/admin/AdminEmailHistory";
import AdminEmailTemplates from "@/components/admin/AdminEmailTemplates";

const SUB_TABS = [
  { id: "compose", label: "Yaz", icon: Send },
  { id: "history", label: "Gecmis", icon: History },
  { id: "templates", label: "Sablon", icon: FileText },
];

export default function AdminBulkEmail({ allUsers = [] }) {
  const [subTab, setSubTab] = useState("compose");

  return (
    <div className="space-y-4">
      <div className="flex gap-1 rounded-2xl p-1" style={{ background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}>
        {SUB_TABS.map((t) => (
          <button key={t.id} onClick={() => setSubTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${subTab === t.id ? "text-foreground" : "text-muted-foreground"}`}
            style={subTab === t.id ? { background: "linear-gradient(135deg, rgba(50,20,72,0.7), rgba(35,16,28,0.5))", border: "1px solid rgba(180,100,240,0.1)" } : {}}>
            <t.icon className="w-3.5 h-3.5" />
            {t.label}
          </button>
        ))}
      </div>

      {subTab === "compose" && <AdminEmailCompose allUsers={allUsers} />}
      {subTab === "history" && <AdminEmailHistory />}
      {subTab === "templates" && <AdminEmailTemplates />}
    </div>
  );
}