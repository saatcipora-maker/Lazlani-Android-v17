import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Eye, EyeOff, Save, X, GripVertical } from "lucide-react";
import { toast } from "sonner";

const EMPTY_PLAN = { name: "", description: "", price: 0, duration_days: 30, features: "", icon: "Crown", color: "#f59e0b", is_active: true, sort_order: 0 };

export default function AdminSubscriptions() {
  const queryClient = useQueryClient();
  const [editingPlan, setEditingPlan] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_PLAN);

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["admin", "subscription-plans"],
    queryFn: () => base44.entities.SubscriptionPlan.list("sort_order", 50),
  });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (editingPlan) {
        await base44.entities.SubscriptionPlan.update(editingPlan.id, data);
      } else {
        await base44.entities.SubscriptionPlan.create({ ...data, sort_order: plans.length });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "subscription-plans"] });
      toast.success(editingPlan ? "Paket güncellendi!" : "Yeni paket oluşturuldu!");
      resetForm();
    },
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, is_active }) => base44.entities.SubscriptionPlan.update(id, { is_active: !is_active }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "subscription-plans"] });
      toast.success("Durum güncellendi!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SubscriptionPlan.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "subscription-plans"] });
      toast.success("Paket silindi!");
    },
  });

  const resetForm = () => {
    setForm(EMPTY_PLAN);
    setEditingPlan(null);
    setShowForm(false);
  };

  const startEdit = (plan) => {
    setForm({ name: plan.name, description: plan.description || "", price: plan.price, duration_days: plan.duration_days || 30, features: plan.features || "", icon: plan.icon || "Crown", color: plan.color || "#f59e0b", is_active: plan.is_active !== false, sort_order: plan.sort_order || 0 });
    setEditingPlan(plan);
    setShowForm(true);
  };

  const handleSubmit = () => {
    if (!form.name.trim() || form.price <= 0) {
      toast.error("Paket adı ve fiyat zorunludur!");
      return;
    }
    saveMutation.mutate(form);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-foreground">Abonelik Paketleri ({plans.length})</h3>
        {!showForm && (
          <Button size="sm" className="rounded-full text-xs gap-1.5" onClick={() => { resetForm(); setShowForm(true); }}>
            <Plus className="w-3.5 h-3.5" /> Yeni Paket
          </Button>
        )}
      </div>

      {/* Form */}
      {showForm && (
        <div className="p-4 rounded-2xl bg-card border-2 border-primary/30 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-foreground">{editingPlan ? "Paketi Düzenle" : "Yeni Paket"}</p>
            <button onClick={resetForm} className="text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Paket Adı</label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1 h-9 text-sm" placeholder="VIP Üyelik" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Açıklama</label>
            <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1 h-9 text-sm" placeholder="Premium özellikler" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Fiyat (₺)</label>
              <Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) || 0 })} className="mt-1 h-9 text-sm" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Süre (gün)</label>
              <Input type="number" value={form.duration_days} onChange={(e) => setForm({ ...form, duration_days: parseInt(e.target.value) || 30 })} className="mt-1 h-9 text-sm" />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Renk</label>
            <div className="flex gap-2 mt-1">
              {["#f59e0b", "#6366f1", "#ec4899", "#10b981", "#3b82f6", "#8b5cf6", "#ef4444"].map((c) => (
                <button key={c} onClick={() => setForm({ ...form, color: c })}
                  className={`w-7 h-7 rounded-full border-2 transition-transform ${form.color === c ? "border-foreground scale-110" : "border-transparent"}`}
                  style={{ backgroundColor: c }} />
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Özellikler (her satıra bir tane)</label>
            <textarea
              value={form.features}
              onChange={(e) => setForm({ ...form, features: e.target.value })}
              className="mt-1 w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm min-h-[80px] resize-none"
              placeholder={"Özel rozet\nSınırsız erişim\nÖncelikli destek"}
            />
          </div>
          <Button className="w-full rounded-full gap-1.5" onClick={handleSubmit} disabled={saveMutation.isPending}>
            <Save className="w-3.5 h-3.5" /> {editingPlan ? "Güncelle" : "Oluştur"}
          </Button>
        </div>
      )}

      {/* Plans List */}
      {isLoading ? (
        <div className="space-y-2">{[1,2,3].map((i) => <div key={i} className="h-20 rounded-2xl bg-muted animate-pulse" />)}</div>
      ) : plans.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-sm text-muted-foreground">Henüz abonelik paketi oluşturulmamış</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {plans.map((plan) => (
            <div key={plan.id} className={`p-4 rounded-2xl border transition-opacity ${plan.is_active ? "bg-card border-border" : "bg-muted/50 border-border/50 opacity-60"}`}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${plan.color || '#f59e0b'}20` }}>
                  <span className="text-lg">💎</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-foreground truncate">{plan.name}</p>
                    <Badge variant={plan.is_active ? "default" : "secondary"} className="text-[9px]">
                      {plan.is_active ? "Aktif" : "Pasif"}
                    </Badge>
                  </div>
                  {plan.description && <p className="text-xs text-muted-foreground mt-0.5">{plan.description}</p>}
                  <div className="flex items-center gap-3 mt-1.5">
                    <span className="text-sm font-bold" style={{ color: plan.color || '#f59e0b' }}>₺{plan.price}</span>
                    <span className="text-[10px] text-muted-foreground">{plan.duration_days || 30} gün</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-1.5 mt-3 justify-end">
                <button onClick={() => toggleMutation.mutate({ id: plan.id, is_active: plan.is_active })}
                  className="p-1.5 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors" title={plan.is_active ? "Pasif Yap" : "Aktif Yap"}>
                  {plan.is_active ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
                <button onClick={() => startEdit(plan)} className="p-1.5 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors" title="Düzenle">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => { if (confirm("Bu paketi silmek istediğinize emin misiniz?")) deleteMutation.mutate(plan.id); }}
                  className="p-1.5 rounded-lg border border-red-200 text-red-500 hover:bg-red-50 transition-colors" title="Sil">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}