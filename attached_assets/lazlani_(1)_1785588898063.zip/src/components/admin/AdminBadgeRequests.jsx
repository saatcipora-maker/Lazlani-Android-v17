import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Bell, Clock, Award, Loader2 } from "lucide-react";
import { toast } from "sonner";

const TYPE_LABELS = {
  ozel_rozeti: { label: "Özel Rozet", emoji: "✨", color: "bg-pink-50 border-pink-200 text-pink-700" },
  magazin_rozeti: { label: "Magazin Rozeti", emoji: "📰", color: "bg-blue-50 border-blue-200 text-blue-700" },
  yazar_rozeti: { label: "Yazarlık Rozeti", emoji: "✍️", color: "bg-purple-50 border-purple-200 text-purple-700" },
  vip_uyelik: { label: "VIP Üyelik", emoji: "👑", color: "bg-amber-50 border-amber-200 text-amber-700" },
  one_cikarma: { label: "Öne Çıkarma", emoji: "🚀", color: "bg-green-50 border-green-200 text-green-700" },
};

const STATUS_BADGE = {
  pending: { label: "Bekliyor", variant: "secondary" },
  approved: { label: "Onaylandı", variant: "default" },
  rejected: { label: "Reddedildi", variant: "destructive" },
};

export default function AdminBadgeRequests({ allBadgeRequests = [] }) {
  const [filter, setFilter] = useState("pending");
  const queryClient = useQueryClient();

  const filtered = allBadgeRequests.filter((r) =>
    filter === "all" ? true : r.status === filter
  );

  const pendingCount = allBadgeRequests.filter((r) => r.status === "pending").length;

  const approveMutation = useMutation({
    mutationFn: async (req) => {
      await base44.entities.BadgeRequest.update(req.id, { status: "approved" });
      const users = await base44.entities.User.filter({ email: req.user_email }, "-created_date", 1);
      if (!users[0]) return;
      const badgeFieldMap = {
        ozel_rozeti: { has_ozel_badge: true },
        magazin_rozeti: { has_magazin_badge: true },
        yazar_rozeti: { has_author_badge: true },
        vip_uyelik: { has_vip: true },
      };
      const updateFields = badgeFieldMap[req.request_type];
      if (updateFields) {
        await base44.entities.User.update(users[0].id, updateFields);
      }
      if (req.request_type === "one_cikarma" && req.book_id) {
        await base44.entities.Book.update(req.book_id, { is_recommended: true, recommendation_status: "approved" });
      }
      await base44.entities.Notification.create({
        receiver_email: req.user_email,
        sender_name: "Lazlani",
        type: "system",
        message: `${TYPE_LABELS[req.request_type]?.label || req.request_type} talebiniz onaylandı! 🎉`,
        is_read: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin"] });
      toast.success("Rozet başvurusu onaylandı ve kullanıcıya işlendi!");
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (req) => {
      await base44.entities.BadgeRequest.update(req.id, { status: "rejected" });
      await base44.entities.Notification.create({
        receiver_email: req.user_email,
        sender_name: "Lazlani",
        type: "system",
        message: `${TYPE_LABELS[req.request_type]?.label || req.request_type} talebiniz reddedildi.`,
        is_read: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "badge-requests"] });
      toast.success("Başvuru reddedildi");
    },
  });

  const filters = [
    { id: "pending", label: `Bekleyen (${pendingCount})` },
    { id: "approved", label: "Onaylanan" },
    { id: "rejected", label: "Reddedilen" },
    { id: "all", label: "Tümü" },
  ];

  return (
    <div className="space-y-4">
      {/* Filter tabs */}
      <div className="flex gap-1 overflow-x-auto scrollbar-hide bg-muted/60 rounded-xl p-1">
        {filters.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
              filter === f.id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="text-center py-12">
          <Bell className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">
            {filter === "pending" ? "Bekleyen başvuru yok" : "Başvuru bulunamadı"}
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((req) => {
            const typeInfo = TYPE_LABELS[req.request_type] || { label: req.request_type, emoji: "📋", color: "bg-muted border-border text-foreground" };
            const statusInfo = STATUS_BADGE[req.status] || STATUS_BADGE.pending;
            const isPending = req.status === "pending";
            const isProcessing = approveMutation.isPending || rejectMutation.isPending;

            return (
              <div key={req.id} className="p-4 rounded-2xl bg-card border border-border">
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">
                      {req.user_name || req.user_email}
                    </p>
                    <p className="text-[11px] text-muted-foreground truncate">{req.user_email}</p>
                  </div>
                  <Badge variant={statusInfo.variant} className="text-[10px] flex-shrink-0 ml-2">
                    {statusInfo.label}
                  </Badge>
                </div>

                {/* Type badge */}
                <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-medium mb-2 ${typeInfo.color}`}>
                  <span>{typeInfo.emoji}</span>
                  <span>{typeInfo.label}</span>
                </div>

                {/* Book info for öne çıkarma */}
                {req.request_type === "one_cikarma" && req.book_title && (
                  <p className="text-xs text-muted-foreground mb-2">
                    📖 {req.book_title}
                    {req.duration_days ? ` • ${req.duration_days} gün` : ""}
                  </p>
                )}

                {/* Date */}
                <p className="text-[10px] text-muted-foreground mb-3">
                  <Clock className="w-3 h-3 inline mr-1" />
                  {req.created_date
                    ? new Date(req.created_date).toLocaleDateString("tr-TR", {
                        day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit",
                      })
                    : "—"}
                </p>

                {/* Actions */}
                {isPending && (
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="flex-1 rounded-full text-xs h-9 bg-green-600 hover:bg-green-700 gap-1"
                      onClick={() => approveMutation.mutate(req)}
                      disabled={isProcessing}
                    >
                      {approveMutation.isPending ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      Onayla
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 rounded-full text-xs h-9 text-destructive border-destructive/30 gap-1"
                      onClick={() => rejectMutation.mutate(req)}
                      disabled={isProcessing}
                    >
                      {rejectMutation.isPending ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <XCircle className="w-3.5 h-3.5" />
                      )}
                      Reddet
                    </Button>
                  </div>
                )}

                {/* Approved/Rejected info */}
                {req.status === "approved" && (
                  <div className="flex items-center gap-1.5 text-xs text-green-600">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Rozet kullanıcıya işlendi</span>
                  </div>
                )}
                {req.status === "rejected" && (
                  <div className="flex items-center gap-1.5 text-xs text-destructive">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Başvuru reddedildi</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}