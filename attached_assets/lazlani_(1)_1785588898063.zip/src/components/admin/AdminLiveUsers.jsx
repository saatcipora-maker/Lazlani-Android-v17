import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Wifi, WifiOff, Clock } from "lucide-react";

const ONLINE_THRESHOLD = 5 * 60 * 1000; // 5 min

export default function AdminLiveUsers() {
  const queryClient = useQueryClient();
  const [now, setNow] = useState(Date.now());

  const { data: onlineUsers = [] } = useQuery({
    queryKey: ["admin", "online"],
    queryFn: () => base44.entities.OnlineUser.list("-last_seen", 100),
    refetchInterval: 15000,
  });

  // Real-time subscription
  useEffect(() => {
    const unsub = base44.entities.OnlineUser.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["admin", "online"] });
    });
    const timer = setInterval(() => setNow(Date.now()), 30000);
    return () => { unsub(); clearInterval(timer); };
  }, []);

  const activeUsers = onlineUsers.filter((u) => u.last_seen && (now - new Date(u.last_seen).getTime()) < ONLINE_THRESHOLD);
  const recentUsers = onlineUsers.filter((u) => u.last_seen && (now - new Date(u.last_seen).getTime()) >= ONLINE_THRESHOLD);

  const getTimeAgo = (lastSeen) => {
    const diff = Math.floor((now - new Date(lastSeen).getTime()) / 1000);
    if (diff < 60) return "şimdi";
    if (diff < 3600) return `${Math.floor(diff / 60)}dk önce`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}sa önce`;
    return `${Math.floor(diff / 86400)}g önce`;
  };

  return (
    <div className="space-y-4">
      {/* Active count header */}
      <div className="flex items-center gap-3 p-4 rounded-2xl bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200">
        <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
          <Wifi className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <p className="text-3xl font-black text-green-700">{activeUsers.length}</p>
          <p className="text-xs text-green-600 font-medium">Anlık Aktif Kullanıcı</p>
        </div>
        <span className="ml-auto w-3 h-3 rounded-full bg-green-500 animate-pulse" />
      </div>

      {/* Active users */}
      {activeUsers.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-green-600 mb-2 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-green-500" /> Çevrimiçi ({activeUsers.length})
          </p>
          <div className="space-y-1.5">
            {activeUsers.map((u) => (
              <div key={u.id} className="flex items-center gap-2.5 p-2.5 rounded-xl bg-card border border-border">
                <span className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0" />
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-primary">{(u.user_name || u.user_email)?.[0]?.toUpperCase()}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{u.user_name || u.user_email}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{u.user_email}</p>
                </div>
                <span className="text-[10px] text-green-600 font-medium flex-shrink-0">{getTimeAgo(u.last_seen)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recently offline */}
      {recentUsers.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-muted-foreground mb-2 flex items-center gap-1.5">
            <WifiOff className="w-3 h-3" /> Yakın Zamanda Ayrılan ({recentUsers.length})
          </p>
          <div className="space-y-1.5">
            {recentUsers.slice(0, 20).map((u) => (
              <div key={u.id} className="flex items-center gap-2.5 p-2.5 rounded-xl bg-muted/50 border border-border/50">
                <span className="w-2 h-2 rounded-full bg-muted-foreground/30 flex-shrink-0" />
                <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-muted-foreground">{(u.user_name || u.user_email)?.[0]?.toUpperCase()}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-muted-foreground truncate">{u.user_name || u.user_email}</p>
                </div>
                <span className="text-[10px] text-muted-foreground flex-shrink-0 flex items-center gap-0.5">
                  <Clock className="w-2.5 h-2.5" /> {getTimeAgo(u.last_seen)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeUsers.length === 0 && recentUsers.length === 0 && (
        <div className="text-center py-12">
          <WifiOff className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Şu anda çevrimiçi kullanıcı yok</p>
        </div>
      )}
    </div>
  );
}