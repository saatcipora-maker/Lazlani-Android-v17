import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { MessageCircle, Trash2, Shield, Ban, Star, UserX, Check, Clock, Crown, AlertTriangle, Plus, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import { useAuth } from "@/lib/AuthContext";

export default function AdminCommunity() {
  const { user } = useAuth();
  const [tab, setTab] = useState("moderation");
  const queryClient = useQueryClient();
  const [roleEmail, setRoleEmail] = useState("");
  const [roleName, setRoleName] = useState("");
  const [roleType, setRoleType] = useState("vip");
  const [newBannedWord, setNewBannedWord] = useState("");

  const { data: messages = [] } = useQuery({
    queryKey: ["admin-community-messages"],
    queryFn: () => base44.entities.CommunityMessage.list("-created_date", 100),
  });

  const { data: bans = [] } = useQuery({
    queryKey: ["admin-community-bans"],
    queryFn: () => base44.entities.CommunityChatBan.list("-created_date", 100),
  });

  const { data: roles = [] } = useQuery({
    queryKey: ["admin-community-roles"],
    queryFn: () => base44.entities.CommunityRole.list("-created_date", 100),
  });

  const { data: bannedWords = [] } = useQuery({
    queryKey: ["admin-banned-words"],
    queryFn: () => base44.entities.BannedWord.list("-created_date", 500),
  });

  const { data: violations = [] } = useQuery({
    queryKey: ["admin-violations"],
    queryFn: () => base44.entities.ProfanityViolation.list("-created_date", 200),
  });

  const deleteMsgMutation = useMutation({
    mutationFn: (id) => base44.entities.CommunityMessage.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-community-messages"] }); toast.success("Mesaj silindi"); },
  });

  const grantRoleMutation = useMutation({
    mutationFn: async () => {
      const existing = await base44.entities.CommunityRole.filter({ user_email: roleEmail.trim() }, "-created_date", 10);
      for (const r of existing) await base44.entities.CommunityRole.delete(r.id);
      await base44.entities.CommunityRole.create({
        user_email: roleEmail.trim(),
        user_name: roleName.trim() || roleEmail.trim(),
        role: roleType,
        granted_by_email: user.email,
        granted_by_name: user.full_name || user.email,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-community-roles"] });
      queryClient.invalidateQueries({ queryKey: ["community-roles"] });
      setRoleEmail(""); setRoleName("");
      toast.success(`${roleType === "vip" ? "VIP" : "Operatör"} yetkisi verildi`);
    },
  });

  const removeRoleMutation = useMutation({
    mutationFn: (id) => base44.entities.CommunityRole.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-community-roles"] });
      queryClient.invalidateQueries({ queryKey: ["community-roles"] });
      toast.success("Yetki kaldırıldı");
    },
  });

  const liftBanMutation = useMutation({
    mutationFn: (id) => base44.entities.CommunityChatBan.update(id, { is_active: false }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-community-bans"] }); toast.success("Ceza kaldırıldı"); },
  });

  const addBannedWordMutation = useMutation({
    mutationFn: () => base44.entities.BannedWord.create({
      word: newBannedWord.trim().toLowerCase(),
      added_by_email: user.email,
      added_by_name: user.full_name || user.email,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-banned-words"] });
      queryClient.invalidateQueries({ queryKey: ["banned-words"] });
      setNewBannedWord("");
      toast.success("Yasaklı kelime eklendi");
    },
  });

  const deleteBannedWordMutation = useMutation({
    mutationFn: (id) => base44.entities.BannedWord.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-banned-words"] });
      queryClient.invalidateQueries({ queryKey: ["banned-words"] });
      toast.success("Yasaklı kelime silindi");
    },
  });

  const resetViolationMutation = useMutation({
    mutationFn: (id) => base44.entities.ProfanityViolation.update(id, { violation_count: 0, status: "normal", is_muted: false }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-violations"] });
      toast.success("Uyarı sayısı sıfırlandı");
    },
  });

  const manualBanMutation = useMutation({
    mutationFn: async ({ email, name, type, duration }) => {
      const durationMap = { "1h": 3600000, "1d": 86400000, "7d": 604800000, "30d": 2592000000, "perm": 0 };
      const ms = durationMap[duration] || 86400000;
      const expiresAt = duration === "perm" ? new Date(Date.now() + 365 * 86400000) : new Date(Date.now() + ms);
      const durationLabels = { "1h": "1 saat", "1d": "1 gün", "7d": "7 gün", "30d": "30 gün", "perm": "Kalıcı" };
      await base44.entities.CommunityChatBan.create({
        user_email: email,
        user_name: name || email,
        banned_by_email: user.email,
        banned_by_name: user.full_name || user.email,
        reason: "Yönetici tarafından engellendi",
        ban_type: type,
        duration_label: durationLabels[duration],
        expires_at: expiresAt.toISOString(),
        is_active: true,
        issued_by_role: "admin",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-community-bans"] });
      toast.success("Ceza verildi");
    },
  });

  const activeBans = bans.filter(b => b.is_active && (!b.expires_at || new Date(b.expires_at) > new Date()));

  const tabs = [
    { id: "moderation", label: "Moderasyon", icon: AlertTriangle, count: activeBans.length },
    { id: "banned-words", label: "Yasaklı Kelimeler", icon: Ban, count: bannedWords.length },
    { id: "messages", label: "Mesajlar", icon: MessageCircle, count: messages.length },
    { id: "roles", label: "Yetkililer", icon: Shield, count: roles.length },
    { id: "log", label: "Kayıtlar", icon: Clock, count: bans.length },
  ];

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <div className="flex gap-1 rounded-xl p-1 overflow-x-auto scrollbar-hide" style={{ background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex-shrink-0 flex items-center justify-center gap-1 px-2.5 py-2.5 rounded-lg text-xs font-medium transition-all ${tab === t.id ? "text-foreground shadow-sm" : "text-muted-foreground"}`}
            style={tab === t.id ? { background: "linear-gradient(135deg, rgba(50,20,72,0.7), rgba(35,16,28,0.5))", border: "1px solid rgba(180,100,240,0.1)" } : {}}>
            <t.icon className="w-3 h-3" />
            {t.label}
            {t.count > 0 && <span className="text-[8px] bg-primary/20 text-primary px-1.5 rounded-full">{t.count}</span>}
          </button>
        ))}
      </div>

      {/* Moderation Tab */}
      {tab === "moderation" && (
        <div className="space-y-4">
          {/* Active bans */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-foreground">Aktif Cezalar ({activeBans.length})</p>
            {activeBans.length === 0 ? (
              <EmptyState icon={Ban} text="Aktif ceza yok" />
            ) : activeBans.map(b => (
              <BanCard key={b.id} ban={b} onLift={() => liftBanMutation.mutate(b.id)} />
            ))}
          </div>

          {/* Violations */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-foreground">Uyarı Kayıtları ({violations.length})</p>
            {violations.length === 0 ? (
              <EmptyState icon={AlertTriangle} text="Uyarı kaydı yok" />
            ) : violations.map(v => (
              <div key={v.id} className="flex items-center gap-3 p-3 rounded-2xl glass-card">
                <div className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ background: v.violation_count >= 3 ? "rgba(239,68,68,0.1)" : "rgba(234,179,8,0.1)" }}>
                  <AlertTriangle className={`w-4 h-4 ${v.violation_count >= 3 ? "text-red-400" : "text-yellow-400"}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate">{v.user_email}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${v.violation_count >= 3 ? "bg-red-500/20 text-red-400" : v.violation_count >= 2 ? "bg-yellow-500/20 text-yellow-400" : "bg-blue-500/20 text-blue-400"}`}>
                      {v.violation_count} ihlal
                    </span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium ${v.status === "muted" ? "bg-red-500/20 text-red-400" : v.status === "warning" ? "bg-yellow-500/20 text-yellow-400" : "bg-green-500/20 text-green-400"}`}>
                      {v.status === "muted" ? "Susturuldu" : v.status === "warning" ? "Uyarıldı" : v.status === "reported" ? "Raporlandı" : "Normal"}
                    </span>
                  </div>
                  {v.last_violation_date && (
                    <p className="text-[9px] text-muted-foreground mt-0.5">
                      Son ihlal: {format(new Date(v.last_violation_date), "dd MMM HH:mm", { locale: tr })}
                    </p>
                  )}
                </div>
                <button onClick={() => resetViolationMutation.mutate(v.id)}
                  className="text-[10px] text-green-400 font-medium px-2 py-1 rounded-lg flex items-center gap-1"
                  style={{ background: "rgba(34,197,94,0.08)" }}>
                  <RotateCcw className="w-3 h-3" /> Sıfırla
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Banned Words Tab */}
      {tab === "banned-words" && (
        <div className="space-y-4">
          <div className="glass-card rounded-2xl p-4 space-y-3">
            <p className="text-xs font-semibold text-foreground">Yeni Yasaklı Kelime Ekle</p>
            <div className="flex gap-2">
              <Input
                placeholder="Yasaklı kelime..."
                value={newBannedWord}
                onChange={e => setNewBannedWord(e.target.value)}
                onKeyDown={e => e.key === "Enter" && newBannedWord.trim() && addBannedWordMutation.mutate()}
                className="h-9 text-xs flex-1"
              />
              <Button size="sm" className="rounded-xl text-xs" onClick={() => addBannedWordMutation.mutate()} disabled={!newBannedWord.trim()}>
                <Plus className="w-3.5 h-3.5 mr-1" /> Ekle
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-foreground">Yasaklı Kelimeler ({bannedWords.length})</p>
            {bannedWords.length === 0 ? (
              <EmptyState icon={Ban} text="Yasaklı kelime yok" />
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {bannedWords.map(bw => (
                  <div key={bw.id} className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs"
                    style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.15)" }}>
                    <span className="text-red-400 font-medium">{bw.word}</span>
                    <button onClick={() => deleteBannedWordMutation.mutate(bw.id)} className="btn-sm text-red-400/60 hover:text-red-400 ml-0.5">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Messages Tab */}
      {tab === "messages" && (
        <div className="space-y-2 max-h-[60vh] overflow-y-auto scrollbar-hide">
          {messages.length === 0 ? (
            <EmptyState icon={MessageCircle} text="Mesaj yok" />
          ) : messages.map(m => (
            <div key={m.id} className="flex items-start gap-2.5 p-3 rounded-2xl glass-card">
              <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-[10px] font-bold text-primary" style={{ background: "rgba(130,60,210,0.1)" }}>
                {(m.user_name || "?")[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-semibold truncate">{m.user_name}</span>
                  <RoleBadge role={m.user_role} />
                  <span className="text-[9px] text-muted-foreground ml-auto flex-shrink-0">
                    {m.created_date ? format(new Date(m.created_date), "dd MMM HH:mm", { locale: tr }) : ""}
                  </span>
                </div>
                <p className="text-xs text-foreground/70 mt-0.5 break-words">{m.content}</p>
                {m.type === "book_share" && <span className="text-[9px] text-primary">📖 {m.book_title}</span>}
                {m.reply_to_id && <span className="text-[9px] text-yellow-400">↩ Yanıt: {m.reply_to_content?.slice(0, 40)}</span>}
              </div>
              <button onClick={() => deleteMsgMutation.mutate(m.id)} className="btn-sm text-muted-foreground hover:text-destructive">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Roles Tab */}
      {tab === "roles" && (
        <div className="space-y-4">
          <div className="glass-card rounded-2xl p-4 space-y-3">
            <p className="text-xs font-semibold text-foreground">Yetki Ata</p>
            <Input placeholder="Kullanıcı email" value={roleEmail} onChange={e => setRoleEmail(e.target.value)} className="h-9 text-xs" />
            <Input placeholder="Kullanıcı adı (opsiyonel)" value={roleName} onChange={e => setRoleName(e.target.value)} className="h-9 text-xs" />
            <div className="flex gap-2">
              <button onClick={() => setRoleType("vip")}
                className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-medium ${roleType === "vip" ? "text-white" : "text-muted-foreground"}`}
                style={roleType === "vip" ? { background: "linear-gradient(135deg, #F59E0B, #EAB308)" } : { background: "rgba(38,18,55,0.4)" }}>
                <Star className="w-3 h-3" /> VIP
              </button>
              <button onClick={() => setRoleType("operator")}
                className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-medium ${roleType === "operator" ? "text-white" : "text-muted-foreground"}`}
                style={roleType === "operator" ? { background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" } : { background: "rgba(38,18,55,0.4)" }}>
                <Shield className="w-3 h-3" /> Operatör
              </button>
            </div>
            <Button size="sm" className="w-full rounded-xl text-xs" onClick={() => grantRoleMutation.mutate()} disabled={!roleEmail.trim()}>
              <Check className="w-3.5 h-3.5 mr-1" /> Yetki Ver
            </Button>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-foreground">Mevcut Yetkililer</p>
            {roles.length === 0 ? (
              <EmptyState icon={Shield} text="Yetkili yok" />
            ) : roles.map(r => (
              <div key={r.id} className="flex items-center gap-3 p-3 rounded-2xl glass-card">
                <div className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ background: r.role === "operator" ? "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" : "linear-gradient(135deg, #F59E0B, #EAB308)" }}>
                  {r.role === "operator" ? <Shield className="w-3.5 h-3.5 text-white" /> : <Star className="w-3.5 h-3.5 text-white" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate">{r.user_name || r.user_email}</p>
                  <p className="text-[10px] text-muted-foreground">{r.user_email}</p>
                </div>
                <button onClick={() => removeRoleMutation.mutate(r.id)}
                  className="text-[10px] text-red-400 font-medium px-2 py-1 rounded-lg" style={{ background: "rgba(239,68,68,0.08)" }}>
                  Kaldır
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Log Tab */}
      {tab === "log" && (
        <div className="space-y-2 max-h-[60vh] overflow-y-auto scrollbar-hide">
          <p className="text-xs font-semibold text-foreground">Tüm Moderasyon Kayıtları ({bans.length})</p>
          {bans.length === 0 ? (
            <EmptyState icon={Clock} text="Kayıt yok" />
          ) : bans.map(b => (
            <div key={b.id} className="p-3 rounded-2xl glass-card">
              <div className="flex items-center gap-2 mb-1">
                <span className={`w-2 h-2 rounded-full ${b.is_active && (!b.expires_at || new Date(b.expires_at) > new Date()) ? "bg-red-400" : "bg-green-400"}`} />
                <span className="text-xs font-semibold">{b.user_name || b.user_email}</span>
                <span className={`text-[8px] font-bold text-white px-1.5 py-0.5 rounded-full ${b.ban_type === "kick" ? "bg-orange-500" : "bg-red-500"}`}>
                  {b.ban_type === "kick" ? "Uzaklaştırma" : "Susturma"}
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground">{b.reason}</p>
              <p className="text-[9px] text-muted-foreground mt-0.5">
                İşlemi yapan: {b.banned_by_name} ({b.issued_by_role || "admin"})
                {" • "}{b.duration_label || ""}
                {" • "}{b.created_date ? format(new Date(b.created_date), "dd MMM HH:mm", { locale: tr }) : ""}
              </p>
              {b.expires_at && (
                <p className="text-[9px] text-muted-foreground">
                  Bitiş: {format(new Date(b.expires_at), "dd MMM HH:mm", { locale: tr })}
                  {new Date(b.expires_at) <= new Date() && " ✅ Süresi doldu"}
                </p>
              )}
              {b.is_active && (
                <button onClick={() => liftBanMutation.mutate(b.id)}
                  className="text-[10px] text-green-400 font-medium px-2 py-1 rounded-lg mt-1"
                  style={{ background: "rgba(34,197,94,0.08)" }}>
                  Cezayı Kaldır
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyState({ icon: Icon, text }) {
  return (
    <div className="text-center py-10">
      <Icon className="w-8 h-8 text-muted-foreground/20 mx-auto mb-2" />
      <p className="text-xs text-muted-foreground">{text}</p>
    </div>
  );
}

function RoleBadge({ role }) {
  if (!role || role === "user") return null;
  const cfg = {
    admin: { label: "Yönetici", bg: "linear-gradient(135deg, #E88C40, #F0B060)" },
    operator: { label: "Operatör", bg: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" },
    vip: { label: "VIP", bg: "linear-gradient(135deg, #F59E0B, #EAB308)" },
  };
  const c = cfg[role];
  if (!c) return null;
  return <span className="text-[7px] font-bold text-white px-1.5 py-0.5 rounded-full" style={{ background: c.bg }}>{c.label}</span>;
}

function BanCard({ ban, onLift }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-2xl glass-card">
      <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: ban.ban_type === "kick" ? "rgba(249,115,22,0.1)" : "rgba(239,68,68,0.1)" }}>
        {ban.ban_type === "kick" ? <UserX className="w-4 h-4 text-orange-400" /> : <Ban className="w-4 h-4 text-red-400" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold truncate">{ban.user_name || ban.user_email}</p>
        <p className="text-[10px] text-muted-foreground">{ban.reason} • {ban.duration_label}</p>
        <p className="text-[9px] text-muted-foreground">
          {ban.banned_by_name} ({ban.issued_by_role})
          {ban.expires_at && ` • Bitiş: ${format(new Date(ban.expires_at), "dd MMM HH:mm", { locale: tr })}`}
        </p>
      </div>
      <button onClick={onLift} className="text-[10px] text-green-400 font-medium px-2 py-1 rounded-lg" style={{ background: "rgba(34,197,94,0.08)" }}>
        Kaldır
      </button>
    </div>
  );
}