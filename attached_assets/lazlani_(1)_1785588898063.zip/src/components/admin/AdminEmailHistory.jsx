import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Mail, CheckCircle2, XCircle, Clock, ChevronDown, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function AdminEmailHistory() {
  const [expandedId, setExpandedId] = useState(null);
  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["email-logs"],
    queryFn: () => base44.entities.EmailLog.list("-created_date", 100),
  });

  if (isLoading) return [1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />);

  if (logs.length === 0) return (
    <div className="text-center py-12"><Mail className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Henüz e-posta gonderilmadi</p></div>
  );

  return (
    <div className="space-y-2">
      {logs.map((log) => (
        <div key={log.id} className="rounded-2xl glass-card overflow-hidden">
          <button onClick={() => setExpandedId(expandedId === log.id ? null : log.id)} className="w-full p-3 flex items-center gap-3 text-left">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">{log.subject}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[10px] text-muted-foreground">{log.created_date ? new Date(log.created_date).toLocaleString("tr-TR") : "—"}</span>
                <Badge variant="secondary" className="text-[9px] h-4 px-1.5">{log.target_type === "all" ? "Tum" : log.target_type === "admins" ? "Yönetici" : "Sectili"}</Badge>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {log.status === "sending" ? (
                <Badge className="text-[9px] bg-yellow-500/20 text-yellow-400 border-0"><Clock className="w-2.5 h-2.5 mr-0.5" /> Gonderiliyor</Badge>
              ) : (
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] flex items-center gap-0.5 text-green-400"><CheckCircle2 className="w-3 h-3" />{log.success_count}</span>
                  {log.failure_count > 0 && <span className="text-[10px] flex items-center gap-0.5 text-red-400"><XCircle className="w-3 h-3" />{log.failure_count}</span>}
                </div>
              )}
              <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${expandedId === log.id ? "rotate-180" : ""}`} />
            </div>
          </button>
          {expandedId === log.id && (
            <div className="px-3 pb-3 border-t border-border/50 pt-2 space-y-2">
              <div>
                <p className="text-[10px] font-medium text-muted-foreground mb-0.5">Icerik</p>
                <p className="text-xs text-foreground/80 whitespace-pre-wrap max-h-32 overflow-y-auto">{log.body}</p>
              </div>
              <div className="flex gap-3 text-[10px] text-muted-foreground">
                <span>Toplam: <b className="text-foreground">{log.recipient_count}</b></span>
                <span className="text-green-400">Basarili: <b>{log.success_count}</b></span>
                <span className="text-red-400">Basarisiz: <b>{log.failure_count}</b></span>
              </div>
              {log.failed_emails && (
                <div>
                  <p className="text-[10px] font-medium text-red-400 mb-0.5">Basarisiz e-posta:</p>
                  <p className="text-[10px] text-muted-foreground break-all">{log.failed_emails}</p>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground">Gönderen: {log.sent_by_name} ({log.sent_by_email})</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}