import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { CalendarDays, TrendingUp, Users } from "lucide-react";

export default function AdminActiveStats() {
  const [period, setPeriod] = useState("daily");

  const today = new Date();
  const todayStr = today.toISOString().slice(0, 10);
  
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoStr = weekAgo.toISOString().slice(0, 10);
  
  const monthAgo = new Date(today);
  monthAgo.setDate(monthAgo.getDate() - 30);
  const monthAgoStr = monthAgo.toISOString().slice(0, 10);

  const { data: dailyLogins = [] } = useQuery({
    queryKey: ["admin", "daily-logins"],
    queryFn: () => base44.entities.DailyLogin.list("-created_date", 500),
    staleTime: 60000,
  });

  // Calculate unique users per period
  const todayLogins = new Set(dailyLogins.filter((l) => l.login_date === todayStr).map((l) => l.user_email)).size;
  const weekLogins = new Set(dailyLogins.filter((l) => l.login_date >= weekAgoStr).map((l) => l.user_email)).size;
  const monthLogins = new Set(dailyLogins.filter((l) => l.login_date >= monthAgoStr).map((l) => l.user_email)).size;

  // Daily breakdown for last 7 days
  const dailyBreakdown = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().slice(0, 10);
    const count = new Set(dailyLogins.filter((l) => l.login_date === dateStr).map((l) => l.user_email)).size;
    dailyBreakdown.push({ date: dateStr, label: d.toLocaleDateString("tr-TR", { weekday: "short" }), count });
  }

  const maxCount = Math.max(...dailyBreakdown.map((d) => d.count), 1);

  const periods = [
    { id: "daily", label: "Günlük" },
    { id: "weekly", label: "Haftalık" },
    { id: "monthly", label: "Aylık" },
  ];

  return (
    <div className="space-y-4">
      {/* Period selector */}
      <div className="flex gap-1 bg-muted/60 rounded-xl p-1">
        {periods.map((p) => (
          <button key={p.id} onClick={() => setPeriod(p.id)}
            className={`flex-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${period === p.id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>
            {p.label}
          </button>
        ))}
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className={`p-3 rounded-2xl border text-center ${period === "daily" ? "bg-primary/5 border-primary/20" : "bg-card border-border"}`}>
          <CalendarDays className="w-4 h-4 text-primary mx-auto mb-1" />
          <p className="text-2xl font-black text-foreground">{todayLogins}</p>
          <p className="text-[10px] text-muted-foreground">Bugün</p>
        </div>
        <div className={`p-3 rounded-2xl border text-center ${period === "weekly" ? "bg-primary/5 border-primary/20" : "bg-card border-border"}`}>
          <TrendingUp className="w-4 h-4 text-blue-500 mx-auto mb-1" />
          <p className="text-2xl font-black text-foreground">{weekLogins}</p>
          <p className="text-[10px] text-muted-foreground">Bu Hafta</p>
        </div>
        <div className={`p-3 rounded-2xl border text-center ${period === "monthly" ? "bg-primary/5 border-primary/20" : "bg-card border-border"}`}>
          <Users className="w-4 h-4 text-purple-500 mx-auto mb-1" />
          <p className="text-2xl font-black text-foreground">{monthLogins}</p>
          <p className="text-[10px] text-muted-foreground">Bu Ay</p>
        </div>
      </div>

      {/* Daily chart */}
      <div className="p-4 rounded-2xl bg-card border border-border">
        <p className="text-xs font-semibold text-foreground mb-3">Son 7 Gün Aktif Kullanıcı</p>
        <div className="flex items-end gap-2 h-24">
          {dailyBreakdown.map((d) => (
            <div key={d.date} className="flex-1 flex flex-col items-center gap-1">
              <span className="text-[10px] font-bold text-foreground">{d.count}</span>
              <div className="w-full rounded-t-md bg-primary/20 relative" style={{ height: `${Math.max((d.count / maxCount) * 100, 4)}%` }}>
                <div className="absolute inset-0 bg-primary rounded-t-md" style={{ opacity: d.date === todayStr ? 1 : 0.6 }} />
              </div>
              <span className="text-[9px] text-muted-foreground">{d.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}