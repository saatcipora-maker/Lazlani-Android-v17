import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Search, Ban, CheckCircle2, Trash2, Award, Star, ShieldCheck, Sparkles, Crown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const BAN_DURATIONS = [
  { label: "1 Gün", days: 1 },
  { label: "3 Gün", days: 3 },
  { label: "7 Gün", days: 7 },
  { label: "15 Gün", days: 15 },
  { label: "30 Gün", days: 30 },
  { label: "Süresiz", days: 0 },
];

export default function AdminUserList({ allUsers, isLoading }) {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [banMenuUserId, setBanMenuUserId] = useState(null);

  const filtered = allUsers.filter((u) =>
    !searchQuery ||
    u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleAuthorBadge = useMutation({
    mutationFn: ({ userId, current }) => base44.entities.User.update(userId, { has_author_badge: !current }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); toast.success("Yazar rozeti güncellendi!"); },
  });

  const toggleMagazinBadge = useMutation({
    mutationFn: ({ userId, current }) => base44.entities.User.update(userId, { has_magazin_badge: !current }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); toast.success("Magazin rozeti güncellendi!"); },
  });

  const toggleOzelBadge = useMutation({
    mutationFn: ({ userId, current }) => base44.entities.User.update(userId, { has_ozel_badge: !current }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); toast.success("Özel rozeti güncellendi!"); },
  });

  const toggleVipBadge = useMutation({
    mutationFn: ({ userId, current }) => base44.entities.User.update(userId, { has_vip: !current }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); toast.success("VIP rozeti güncellendi!"); },
  });

  const deleteUserMutation = useMutation({
    mutationFn: (userId) => base44.entities.User.delete(userId),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); toast.success("Kullanıcı silindi!"); },
  });

  const banUserMutation = useMutation({
    mutationFn: ({ userId, days }) => {
      const ban_until = days === 0 ? "permanent" : new Date(Date.now() + days * 86400000).toISOString();
      return base44.entities.User.update(userId, { is_banned: true, ban_until });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); setBanMenuUserId(null); toast.success("Kullanıcı banlandı!"); },
  });

  const unbanUserMutation = useMutation({
    mutationFn: (userId) => base44.entities.User.update(userId, { is_banned: false, ban_until: "" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); toast.success("Ban kaldırıldı!"); },
  });

  const toggleAdmin = useMutation({
    mutationFn: ({ userId, current }) => base44.entities.User.update(userId, { role: current === "admin" ? "user" : "admin" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "users"] }); toast.success("Rol güncellendi!"); },
  });

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Kullanıcı ara..."
          className="pl-9 rounded-full h-10 bg-muted border-0"
        />
      </div>

      <p className="text-xs text-muted-foreground">{filtered.length} kullanıcı</p>

      {isLoading ? (
        [1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)
      ) : (
        filtered.map((u) => (
          <div key={u.id} className={`rounded-2xl bg-card border overflow-hidden ${u.is_banned ? "border-red-300 bg-red-50/50" : "border-border"}`}>
            <div className="flex items-center gap-3 p-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
                {u.avatar_url ? (
                  <img src={u.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm font-bold text-primary">{u.full_name?.[0]?.toUpperCase() || "?"}</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{u.full_name}</p>
                <p className="text-[10px] text-muted-foreground truncate">{u.email}</p>
                {u.is_banned && <p className="text-[10px] text-red-500 font-semibold">🚫 Banlı</p>}
              </div>
              <div className="flex flex-col items-end gap-1.5">
                <Badge variant={u.role === "admin" ? "default" : "secondary"} className="text-[10px]">
                  {u.role === "admin" ? "Admin" : "Üye"}
                </Badge>
                <div className="flex gap-1">
                  <button onClick={() => toggleOzelBadge.mutate({ userId: u.id, current: u.has_ozel_badge })}
                    className={`p-1 rounded-lg border transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${u.has_ozel_badge ? "bg-purple-100 border-purple-300 text-purple-700" : "border-border text-muted-foreground"}`}
                    title="Özel Rozeti" aria-label="Özel rozeti değiştir">
                    <Sparkles className="w-3 h-3" />
                  </button>
                  <button onClick={() => toggleAuthorBadge.mutate({ userId: u.id, current: u.has_author_badge })}
                    className={`p-1 rounded-lg border transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${u.has_author_badge ? "bg-primary/10 border-primary/30 text-primary" : "border-border text-muted-foreground"}`}
                    title="Yazar Rozeti" aria-label="Yazar rozeti değiştir">
                    <Award className="w-3 h-3" />
                  </button>
                  <button onClick={() => toggleMagazinBadge.mutate({ userId: u.id, current: u.has_magazin_badge })}
                    className={`p-1 rounded-lg border transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${u.has_magazin_badge ? "bg-yellow-100 border-yellow-300 text-yellow-700" : "border-border text-muted-foreground"}`}
                    title="Magazin Rozeti" aria-label="Magazin rozeti değiştir">
                    <Star className="w-3 h-3" />
                  </button>
                  <button onClick={() => toggleVipBadge.mutate({ userId: u.id, current: u.has_vip })}
                    className={`p-1 rounded-lg border transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${u.has_vip ? "bg-amber-100 border-amber-300 text-amber-700" : "border-border text-muted-foreground"}`}
                    title="VIP Rozeti" aria-label="VIP rozeti değiştir">
                    <Crown className="w-3 h-3" />
                  </button>
                  <button onClick={() => toggleAdmin.mutate({ userId: u.id, current: u.role })}
                    className={`p-1 rounded-lg border transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${u.role === "admin" ? "bg-primary/10 border-primary/30 text-primary" : "border-border text-muted-foreground"}`}
                    title={u.role === "admin" ? "Yöneticiliği Kaldır" : "Yönetici Yap"} aria-label="Yönetici rolü değiştir">
                    <ShieldCheck className="w-3 h-3" />
                  </button>
                  {u.is_banned ? (
                    <button onClick={() => unbanUserMutation.mutate(u.id)}
                      className="p-1 rounded-lg border border-green-300 bg-green-50 text-green-700 min-h-[44px] min-w-[44px] flex items-center justify-center" title="Banı Kaldır" aria-label="Banı kaldır">
                      <CheckCircle2 className="w-3 h-3" />
                    </button>
                  ) : (
                    <button onClick={() => setBanMenuUserId(banMenuUserId === u.id ? null : u.id)}
                      className="p-1 rounded-lg border border-orange-300 text-orange-600 hover:bg-orange-50 min-h-[44px] min-w-[44px] flex items-center justify-center" title="Banla" aria-label="Yasakla">
                      <Ban className="w-3 h-3" />
                    </button>
                  )}
                  {u.role !== "admin" && (
                    <button onClick={() => { if (confirm("Bu kullanıcıyı silmek istediğinize emin misiniz?")) deleteUserMutation.mutate(u.id); }}
                      className="p-1 rounded-lg border border-red-300 text-red-600 hover:bg-red-50 min-h-[44px] min-w-[44px] flex items-center justify-center" title="Sil" aria-label="Kullanıcıyı sil">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            </div>
            {banMenuUserId === u.id && (
              <div className="border-t border-border bg-muted/50 px-3 py-2 flex flex-wrap gap-1.5">
                <p className="text-[10px] text-muted-foreground w-full mb-1">Ban süresi seç:</p>
                {BAN_DURATIONS.map((d) => (
                  <button key={d.label} onClick={() => banUserMutation.mutate({ userId: u.id, days: d.days })}
                    className="text-[10px] px-2.5 py-1 rounded-full bg-orange-100 border border-orange-300 text-orange-700 hover:bg-orange-200 transition-colors">
                    {d.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
}