import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Crown, Check, X, Clock, RefreshCw, Users, Settings, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { format } from "date-fns";
import { tr } from "date-fns/locale";

const DURATION_OPTIONS = [
  { label: "1 Ay", days: 30 },
  { label: "3 Ay", days: 90 },
  { label: "6 Ay", days: 180 },
  { label: "1 Yıl", days: 365 },
  { label: "Süresiz", days: 0 },
];

export default function AdminPremium() {
  const [tab, setTab] = useState("requests");
  const queryClient = useQueryClient();
  const [rejectNote, setRejectNote] = useState({});
  const [selectedDuration, setSelectedDuration] = useState({});

  const { data: allMemberships = [] } = useQuery({
    queryKey: ["admin", "premium-memberships"],
    queryFn: () => base44.entities.PremiumMembership.list("-created_date", 200),
  });

  const { data: settings = [] } = useQuery({
    queryKey: ["app-settings"],
    queryFn: () => base44.entities.AppSettings.list("-created_date", 50),
  });

  const getSetting = (key, fallback) => settings.find(s => s.key === key)?.value || fallback;

  const [premiumPrice, setPremiumPrice] = useState("");
  const [premiumName, setPremiumName] = useState("");
  const [premiumFeatures, setPremiumFeatures] = useState("");

  useEffect(() => {
    setPremiumPrice(getSetting("premium_price", "0"));
    setPremiumName(getSetting("premium_name", "Premium"));
    setPremiumFeatures(getSetting("premium_features", "Özel profil rozeti,Premium etiketi,Öne çıkan içerik,Yüksek paylaşım limiti,Reklamsız kullanım,Premium topluluk erişimi"));
  }, [settings]);

  const saveSetting = async (key, value) => {
    const existing = settings.find(s => s.key === key);
    if (existing) await base44.entities.AppSettings.update(existing.id, { value });
    else await base44.entities.AppSettings.create({ key, value });
    queryClient.invalidateQueries({ queryKey: ["app-settings"] });
    toast.success("Ayar güncellendi!");
  };

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin", "premium-memberships"] });

  const approveMutation = useMutation({
    mutationFn: async ({ id, days }) => {
      const now = new Date();
      const update = { status: "active", started_at: now.toISOString() };
      if (days > 0) {
        update.expires_at = new Date(now.getTime() + days * 24 * 60 * 60 * 1000).toISOString();
      }
      await base44.entities.PremiumMembership.update(id, update);
    },
    onSuccess: () => { invalidate(); toast.success("Premium onaylandı!"); },
  });

  const rejectMutation = useMutation({
    mutationFn: ({ id, note }) => base44.entities.PremiumMembership.update(id, { status: "rejected", admin_note: note || "" }),
    onSuccess: () => { invalidate(); toast.success("Başvuru reddedildi"); },
  });

  const cancelMutation = useMutation({
    mutationFn: (id) => base44.entities.PremiumMembership.update(id, { status: "cancelled" }),
    onSuccess: () => { invalidate(); toast.success("Premium iptal edildi"); },
  });

  const reactivateMutation = useMutation({
    mutationFn: async ({ id, days }) => {
      const now = new Date();
      const update = { status: "active", started_at: now.toISOString() };
      if (days > 0) update.expires_at = new Date(now.getTime() + days * 24 * 60 * 60 * 1000).toISOString();
      await base44.entities.PremiumMembership.update(id, update);
    },
    onSuccess: () => { invalidate(); toast.success("Premium yeniden etkinleştirildi!"); },
  });

  const pending = allMemberships.filter(m => m.status === "pending");
  const active = allMemberships.filter(m => m.status === "active");

  const tabs = [
    { id: "requests", label: "Başvurular", count: pending.length, icon: Clock },
    { id: "active", label: "Aktif", count: active.length, icon: Crown },
    { id: "all", label: "Tümü", count: allMemberships.length, icon: Users },
    { id: "settings", label: "Ayarlar", icon: Settings },
  ];

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { label: "Bekleyen", val: pending.length, color: "text-yellow-400" },
          { label: "Aktif", val: active.length, color: "text-green-400" },
          { label: "Reddedilen", val: allMemberships.filter(m => m.status === "rejected").length, color: "text-red-400" },
          { label: "Toplam", val: allMemberships.length, color: "text-foreground" },
        ].map((s, i) => (
          <div key={i} className="glass-card rounded-2xl p-2.5 text-center">
            <p className={`text-xl font-bold ${s.color}`}>{s.val}</p>
            <p className="text-[9px] text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 rounded-xl p-1" style={{ background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}>
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-1 px-2 py-2.5 rounded-lg text-xs font-medium transition-all ${tab === t.id ? "text-foreground shadow-sm" : "text-muted-foreground"}`}
            style={tab === t.id ? { background: "linear-gradient(135deg, rgba(50,20,72,0.7), rgba(35,16,28,0.5))", border: "1px solid rgba(180,100,240,0.1)" } : {}}
          >
            <t.icon className="w-3 h-3" />
            {t.label}
            {t.count > 0 && <span className="text-[8px] bg-primary/20 text-primary px-1.5 rounded-full">{t.count}</span>}
          </button>
        ))}
      </div>

      {/* Requests */}
      {tab === "requests" && (
        <div className="space-y-3">
          {pending.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="w-10 h-10 text-muted-foreground/20 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Bekleyen başvuru yok</p>
            </div>
          ) : pending.map(m => (
            <div key={m.id} className="glass-card rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.2), rgba(240,140,60,0.1))" }}>
                  <span className="text-sm font-bold text-primary">{(m.user_name || m.user_email)[0]?.toUpperCase()}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{m.user_name || m.user_email}</p>
                  <p className="text-[11px] text-muted-foreground truncate">{m.user_email}</p>
                </div>
                <p className="text-[10px] text-muted-foreground">{m.created_date ? format(new Date(m.created_date), "dd MMM", { locale: tr }) : ""}</p>
              </div>

              {/* Duration selector */}
              <div>
                <p className="text-[10px] text-muted-foreground mb-1.5 flex items-center gap-1"><Calendar className="w-3 h-3" /> Süre Seçin</p>
                <div className="flex gap-1 flex-wrap">
                  {DURATION_OPTIONS.map(opt => (
                    <button
                      key={opt.days}
                      onClick={() => setSelectedDuration(prev => ({ ...prev, [m.id]: opt.days }))}
                      className={`px-2.5 py-1.5 rounded-lg text-[10px] font-medium transition-all ${(selectedDuration[m.id] ?? 30) === opt.days ? "text-white" : "text-muted-foreground"}`}
                      style={(selectedDuration[m.id] ?? 30) === opt.days ? { background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" } : { background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reject note */}
              <Input
                placeholder="Ret notu (opsiyonel)"
                value={rejectNote[m.id] || ""}
                onChange={e => setRejectNote(prev => ({ ...prev, [m.id]: e.target.value }))}
                className="h-8 text-xs bg-muted/30"
              />

              <div className="flex gap-2">
                <Button size="sm" className="flex-1 rounded-xl text-xs h-9 text-white" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}
                  onClick={() => approveMutation.mutate({ id: m.id, days: selectedDuration[m.id] ?? 30 })} disabled={approveMutation.isPending}>
                  <Check className="w-3.5 h-3.5 mr-1" /> Onayla
                </Button>
                <Button size="sm" variant="outline" className="flex-1 rounded-xl text-xs h-9 text-destructive border-destructive/30"
                  onClick={() => rejectMutation.mutate({ id: m.id, note: rejectNote[m.id] || "" })} disabled={rejectMutation.isPending}>
                  <X className="w-3.5 h-3.5 mr-1" /> Reddet
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Active */}
      {tab === "active" && (
        <div className="space-y-2">
          {active.length === 0 ? (
            <div className="text-center py-12">
              <Crown className="w-10 h-10 text-muted-foreground/20 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Aktif premium üye yok</p>
            </div>
          ) : active.map(m => (
            <div key={m.id} className="flex items-center gap-3 p-3 rounded-2xl glass-card">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.2), rgba(240,140,60,0.1))" }}>
                <Crown className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{m.user_name || m.user_email}</p>
                <p className="text-[10px] text-muted-foreground">
                  {m.expires_at ? `Bitiş: ${format(new Date(m.expires_at), "dd MMM yyyy", { locale: tr })}` : "Süresiz"}
                </p>
              </div>
              <button onClick={() => cancelMutation.mutate(m.id)} className="text-[10px] text-red-400 font-medium px-2.5 py-1.5 rounded-lg transition-colors" style={{ background: "rgba(239,68,68,0.08)" }}>
                İptal
              </button>
            </div>
          ))}
        </div>
      )}

      {/* All */}
      {tab === "all" && (
        <div className="space-y-2">
          {allMemberships.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-10 h-10 text-muted-foreground/20 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Henüz üyelik yok</p>
            </div>
          ) : allMemberships.map(m => {
            const statusColors = { pending: "text-yellow-400", active: "text-green-400", rejected: "text-red-400", cancelled: "text-muted-foreground", expired: "text-muted-foreground" };
            const statusLabels = { pending: "Bekliyor", active: "Aktif", rejected: "Reddedildi", cancelled: "İptal", expired: "Süresi Doldu" };
            return (
              <div key={m.id} className="flex items-center gap-3 p-3 rounded-2xl glass-card">
                <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "rgba(130,60,210,0.1)" }}>
                  <span className="text-xs font-bold text-primary">{(m.user_name || m.user_email)[0]?.toUpperCase()}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{m.user_name || m.user_email}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{m.user_email}</p>
                </div>
                <div className="text-right">
                  <p className={`text-[10px] font-semibold ${statusColors[m.status] || "text-muted-foreground"}`}>{statusLabels[m.status] || m.status}</p>
                  {(m.status === "cancelled" || m.status === "expired") && (
                    <button onClick={() => reactivateMutation.mutate({ id: m.id, days: 30 })} className="text-[9px] text-primary font-medium mt-0.5">
                      <RefreshCw className="w-2.5 h-2.5 inline mr-0.5" />Etkinleştir
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Settings */}
      {tab === "settings" && (
        <div className="space-y-4">
          <div className="glass-card rounded-2xl p-4 space-y-4">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Premium Paket Adı</label>
              <div className="flex gap-2 mt-1">
                <Input value={premiumName} onChange={e => setPremiumName(e.target.value)} className="h-9 text-sm" />
                <Button size="sm" className="rounded-xl" onClick={() => saveSetting("premium_name", premiumName)}>Kaydet</Button>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Aylık Ücret (₺)</label>
              <div className="flex gap-2 mt-1">
                <Input value={premiumPrice} onChange={e => setPremiumPrice(e.target.value)} type="number" className="h-9 text-sm" />
                <Button size="sm" className="rounded-xl" onClick={() => saveSetting("premium_price", premiumPrice)}>Kaydet</Button>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Premium Özellikleri (virgülle ayırın)</label>
              <textarea
                value={premiumFeatures}
                onChange={e => setPremiumFeatures(e.target.value)}
                rows={4}
                className="w-full mt-1 rounded-xl px-3 py-2 text-sm outline-none resize-none"
                style={{ fontSize: "16px", background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}
              />
              <Button size="sm" className="rounded-xl mt-2" onClick={() => saveSetting("premium_features", premiumFeatures)}>Kaydet</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}