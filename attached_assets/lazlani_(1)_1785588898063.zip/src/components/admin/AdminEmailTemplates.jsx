import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Plus, Trash2, FileText, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function AdminEmailTemplates() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ["email-templates"],
    queryFn: () => base44.entities.EmailTemplate.list("-created_date", 50),
  });

  const createMutation = useMutation({
    mutationFn: () => base44.entities.EmailTemplate.create({ name, subject, body, created_by_email: currentUser?.email || "" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["email-templates"] }); setName(""); setSubject(""); setBody(""); setShowForm(false); toast.success("Sablon kaydedildi!"); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.EmailTemplate.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["email-templates"] }); toast.success("Sablon silindi!"); },
  });

  const handleSave = () => {
    if (!name.trim() || !subject.trim() || !body.trim()) { toast.error("Tum alanlar gerekli"); return; }
    createMutation.mutate();
  };

  return (
    <div className="space-y-3">
      <Button onClick={() => setShowForm(!showForm)} variant="outline" className="w-full rounded-full h-10 text-sm">
        {showForm ? <><X className="w-4 h-4 mr-2" /> Iptal</> : <><Plus className="w-4 h-4 mr-2" /> Yeni Sablon</>}
      </Button>

      {showForm && (
        <div className="rounded-2xl glass-card p-3 space-y-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sablon ad" className="h-10" />
          <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Konu" className="h-10" />
          <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Icerik" className="min-h-[120px] resize-y" />
          <Button onClick={handleSave} disabled={createMutation.isPending} className="w-full rounded-full">
            {createMutation.isPending ? "Kaydediliyor..." : "Kaydet"}
          </Button>
        </div>
      )}

      {isLoading ? (
        [1, 2].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)
      ) : templates.length === 0 ? (
        <div className="text-center py-12"><FileText className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Sablon yok</p></div>
      ) : (
        templates.map((tpl) => (
          <div key={tpl.id} className="rounded-2xl glass-card p-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0"><FileText className="w-4 h-4 text-primary" /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{tpl.name}</p>
                <p className="text-xs text-muted-foreground truncate">{tpl.subject}</p>
                <p className="text-[10px] text-muted-foreground/70 mt-1 line-clamp-2">{tpl.body}</p>
              </div>
              <button onClick={() => deleteMutation.mutate(tpl.id)} className="p-1.5 rounded-lg border border-red-300/30 text-red-400 hover:bg-red-500/10 flex-shrink-0"><Trash2 className="w-3.5 h-3.5" /></button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}