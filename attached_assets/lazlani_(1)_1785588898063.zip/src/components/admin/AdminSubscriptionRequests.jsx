import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Clock, Loader2, Bell, CreditCard } from "lucide-react";
import { toast } from "sonner";

const STATUS_MAP = {
  pending: { label: "Bekliyor", variant: "secondary", color: "text-amber-600" },
  approved: { label: "Onaylandı", variant: "default", color: "text-green-600" },
  rejected: { label: "Reddedildi", variant: "destructive", color: "text-red-600" },
};

export default function AdminSubscriptionRequests() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState("pending");

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["admin", "subscription-requests"],
    queryFn: () => base44.entities.SubscriptionRequest.list("-created_date", 200),
  });

  const filtered = requests.filter((r) => filter === "all" ? true : r.status === filter);
  const pendingCount = requests.filter((r) => r.status === "pending").length;

  const approveMutation = useMutation({
    mutationFn: async (req) => {
      const expiresAt = new Date(Date.now() + (req.duration_days || 30) * 86400000).toISOString();
      await base44.entities.SubscriptionRequest.update(req.id, { status: "approved", expires_at: expiresAt });
      // Activate user subscription
      const users = await base44.entities.User.filter({ email: req.user_email }, "-created_date", 1);
      if (users[0]) {
        await base44.entities.User.update(users[0].id, { has_subscription: true, subscription_plan: req.plan_name, subscription_expires: expiresAt });
      }
      await base44.entities.Notification.create({
        receiver_email: req.user_email,
        sender_name: "Lazlani",
        type: "system",
        message: `${req.plan_name} aboneliğiniz onaylandı! 🎉 Artık tüm avantajlardan yararlanabilirsiniz.`,
        is_read: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "subscription-requests"] });
      toast.success("Abonelik onaylandı ve kullanıcıya işlendi!");
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (req) => {
      await base44.entities.SubscriptionRequest.update(req.id, { status: "rejected" });
      await base44.entities.Notification.create({
        receiver_email: req.user_email,
        sender_name: "Lazlani",
        type: "system",
        message: `${req.plan_name} abonelik talebiniz reddedildi. Detaylı bilgi için yöneticiyle iletişime geçin.`,
        is_read: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "subscription-requests"] });
      toast.success("Başvuru reddedildi, kullanıcıya bildirim gönderildi.");
    },
  });

  const filters = [
    { id: "pending", label: `Bekleyen (${pendingCount})` },
    { id: "approved", label: "Onaylanan" },
    { id: "rejected", label: "Reddedilen" },
    { id: "all", label: "Tümü" },
  ];

  return (
    <div className="space-y-4">
      {/* Filter tabs */}
      <div className="flex gap-1 overflow-x-auto scrollbar-hide bg-muted/60 rounded-xl p-1">
        {filters.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${filter === f.id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>
            {f.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">{[1,2,3].map((i) => <div key={i} className="h-20 rounded-2xl bg-muted animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <CreditCard className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">{filter === "pending" ? "Bekleyen başvuru yok" : "Başvuru bulunamadı"}</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((req) => {
            const statusInfo = STATUS_MAP[req.status] || STATUS_MAP.pending;
            const isPending = req.status === "pending";
            const isProcessing = approveMutation.isPending || rejectMutation.isPending;
            return (
              <div key={req.id} className="p-4 rounded-2xl bg-card border border-border">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{req.user_name || req.user_email}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{req.user_email}</p>
                  </div>
                  <Badge variant={statusInfo.variant} className="text-[10px] flex-shrink-0 ml-2">{statusInfo.label}</Badge>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-primary/10 text-primary text-xs font-medium">
                    💎 {req.plan_name}
                  </span>
                  <span className="text-sm font-bold text-primary">₺{req.price}</span>
                </div>
                <p className="text-[10px] text-muted-foreground mb-3">
                  <Clock className="w-3 h-3 inline mr-1" />
                  {req.created_date ? new Date(req.created_date).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—"}
                </p>
                {isPending && (
                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1 rounded-full text-xs h-9 bg-green-600 hover:bg-green-700 gap-1"
                      onClick={() => approveMutation.mutate(req)} disabled={isProcessing}>
                      {approveMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                      Onayla
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 rounded-full text-xs h-9 text-destructive border-destructive/30 gap-1"
                      onClick={() => rejectMutation.mutate(req)} disabled={isProcessing}>
                      {rejectMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5" />}
                      Reddet
                    </Button>
                  </div>
                )}
                {req.status === "approved" && req.expires_at && (
                  <p className="text-xs text-green-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Bitiş: {new Date(req.expires_at).toLocaleDateString("tr-TR")}
                  </p>
                )}
                {req.status === "rejected" && (
                  <p className="text-xs text-destructive flex items-center gap-1">
                    <XCircle className="w-3.5 h-3.5" /> Başvuru reddedildi
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}