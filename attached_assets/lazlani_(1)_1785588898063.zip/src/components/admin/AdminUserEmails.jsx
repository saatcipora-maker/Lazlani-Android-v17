import { useState, useMemo } from "react";
import { Search, Download, Mail, ShieldCheck, Ban, CheckCircle2, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const FILTERS = [
  { id: "all", label: "Tüm" },
  { id: "active", label: "Aktif" },
  { id: "banned", label: "Banlı" },
  { id: "admin", label: "Yönetici" },
];

export default function AdminUserEmails({ allUsers = [], isLoading }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const filtered = useMemo(() => {
    return allUsers.filter((u) => {
      const matchesSearch = !search ||
        u.email?.toLowerCase().includes(search.toLowerCase()) ||
        u.full_name?.toLowerCase().includes(search.toLowerCase());
      const matchesFilter =
        filter === "all" ? true :
        filter === "active" ? !u.is_banned :
        filter === "banned" ? u.is_banned :
        filter === "admin" ? u.role === "admin" : true;
      return matchesSearch && matchesFilter;
    });
  }, [allUsers, search, filter]);

  const exportCSV = () => {
    const headers = ["Ad", "E-posta", "Rol", "Durum", "Kayit Tarihi", "Son Giris"];
    const rows = filtered.map((u) => [
      u.full_name || "", u.email || "",
      u.role === "admin" ? "Yönetici" : "Kullanici",
      u.is_banned ? "Banli" : "Aktif",
      u.created_date ? new Date(u.created_date).toLocaleDateString("tr-TR") : "",
      u.last_login_at ? new Date(u.last_login_at).toLocaleDateString("tr-TR") : "",
    ]);
    const csv = "\uFEFF" + [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `kullanici_eposta_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    toast.success("CSV indirildi!");
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="E-posta veya ad ara..." className="pl-9 rounded-full h-10 bg-muted border-0" />
        </div>
        <button onClick={exportCSV} className="px-3 h-10 rounded-full glass-card flex items-center gap-1.5 text-xs font-medium flex-shrink-0">
          <Download className="w-3.5 h-3.5" /> CSV
        </button>
      </div>

      <div className="flex gap-1.5 overflow-x-auto scrollbar-hide">
        {FILTERS.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all flex-shrink-0 ${filter === f.id ? "text-foreground" : "text-muted-foreground"}`}
            style={filter === f.id ? { background: "linear-gradient(135deg, rgba(50,20,72,0.7), rgba(35,16,28,0.5))", border: "1px solid rgba(180,100,240,0.1)" } : { border: "1px solid rgba(200,140,255,0.06)" }}>
            {f.label}
          </button>
        ))}
      </div>

      <p className="text-xs text-muted-foreground">{filtered.length} kullanici</p>

      {isLoading ? (
        [1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)
      ) : filtered.length === 0 ? (
        <div className="text-center py-12"><Mail className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Kullanici bulunamad</p></div>
      ) : (
        filtered.map((u) => (
          <div key={u.id} className={`rounded-2xl border p-3 ${u.is_banned ? "border-red-300/30 bg-red-500/5" : "border-border bg-card"}`}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
                {u.avatar_url ? <img src={u.avatar_url} alt="" className="w-full h-full object-cover" /> : <span className="text-sm font-bold text-primary">{u.full_name?.[0]?.toUpperCase() || "?"}</span>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-foreground truncate">{u.full_name || "Isimsiz"}</p>
                  {u.role === "admin" && <Badge className="text-[9px] h-4 px-1.5"><ShieldCheck className="w-2.5 h-2.5 mr-0.5" /> Admin</Badge>}
                  {u.is_banned && <Badge variant="destructive" className="text-[9px] h-4 px-1.5"><Ban className="w-2.5 h-2.5 mr-0.5" /> Banli</Badge>}
                </div>
                <p className="text-xs text-muted-foreground truncate flex items-center gap-1"><Mail className="w-3 h-3" /> {u.email || "—"}</p>
                <div className="flex items-center gap-3 mt-0.5">
                  <span className="text-[10px] text-muted-foreground flex items-center gap-0.5"><Calendar className="w-2.5 h-2.5" />{u.created_date ? new Date(u.created_date).toLocaleDateString("tr-TR") : "—"}</span>
                  {u.last_login_at && <span className="text-[10px] text-muted-foreground">Son: {new Date(u.last_login_at).toLocaleDateString("tr-TR")}</span>}
                </div>
              </div>
              <div className="flex-shrink-0">
                {u.is_banned ? (
                  <span className="text-[10px] px-2 py-1 rounded-full bg-red-500/10 text-red-400 font-medium">Engellenmis</span>
                ) : (
                  <span className="text-[10px] px-2 py-1 rounded-full bg-green-500/10 text-green-400 font-medium flex items-center gap-0.5"><CheckCircle2 className="w-2.5 h-2.5" /> Aktif</span>
                )}
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}