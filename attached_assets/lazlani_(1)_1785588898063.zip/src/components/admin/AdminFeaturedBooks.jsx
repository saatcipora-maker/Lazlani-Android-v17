import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUp, ArrowDown, Trash2, Plus, Search, Star, CheckCircle2, X, Eye, Heart, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { fmtStat } from "@/lib/bookStats";

export default function AdminFeaturedBooks() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: featuredBooks = [], isLoading } = useQuery({
    queryKey: ["admin", "featured-books"],
    queryFn: () => base44.entities.FeaturedBook.list("sort_order", 50),
  });

  const { data: allBooks = [] } = useQuery({
    queryKey: ["admin", "books"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-created_date", 200),
  });

  // Pending feature requests
  const pendingRequests = allBooks.filter(b => b.feature_status === "pending");

  const searchResults = searchQuery.trim().length >= 2
    ? allBooks.filter(b =>
        !featuredBooks.some(f => f.book_id === b.id) &&
        b.title?.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["admin", "featured-books"] });
    queryClient.invalidateQueries({ queryKey: ["featured-books"] });
  };

  const addMutation = useMutation({
    mutationFn: (book) => base44.entities.FeaturedBook.create({
      book_id: book.id,
      book_title: book.title,
      book_cover: book.cover_image || "",
      book_description: book.description || "",
      author_name: book.author_name,
      author_email: book.author_email || "",
      sort_order: featuredBooks.length,
      is_active: true,
    }),
    onSuccess: () => {
      invalidate();
      toast.success("Kitap öne çıkarılanlara eklendi!");
    },
  });

  const removeMutation = useMutation({
    mutationFn: (id) => base44.entities.FeaturedBook.delete(id),
    onSuccess: () => {
      invalidate();
      toast.success("Kitap kaldırıldı!");
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, isActive }) => base44.entities.FeaturedBook.update(id, { is_active: !isActive }),
    onSuccess: () => invalidate(),
  });

  const reorderMutation = useMutation({
    mutationFn: async ({ book, direction }) => {
      const sorted = [...featuredBooks].sort((a, b) => a.sort_order - b.sort_order);
      const idx = sorted.findIndex(f => f.id === book.id);
      const swapIdx = direction === "up" ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= sorted.length) return;
      const swapBook = sorted[swapIdx];
      await Promise.all([
        base44.entities.FeaturedBook.update(book.id, { sort_order: swapBook.sort_order }),
        base44.entities.FeaturedBook.update(swapBook.id, { sort_order: book.sort_order }),
      ]);
    },
    onSuccess: () => {
      invalidate();
      toast.success("Sıralama güncellendi!");
    },
  });

  const approveRequestMutation = useMutation({
    mutationFn: async (book) => {
      await base44.entities.Book.update(book.id, { feature_status: "approved" });
      await base44.entities.FeaturedBook.create({
        book_id: book.id,
        book_title: book.title,
        book_cover: book.cover_image || "",
        book_description: book.description || "",
        author_name: book.author_name,
        author_email: book.author_email || "",
        sort_order: featuredBooks.length,
        is_active: true,
      });
    },
    onSuccess: () => {
      invalidate();
      queryClient.invalidateQueries({ queryKey: ["admin", "books"] });
      toast.success("İstek onaylandı ve vitrine eklendi!");
    },
  });

  const rejectRequestMutation = useMutation({
    mutationFn: (bookId) => base44.entities.Book.update(bookId, { feature_status: "rejected" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "books"] });
      toast.success("İstek reddedildi");
    },
  });

  const sorted = [...featuredBooks].sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

  return (
    <div className="space-y-4">
      {/* Pending requests */}
      {pendingRequests.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-orange-600 mb-2 flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5" /> Öne Çıkarma İsteği ({pendingRequests.length})
          </p>
          <div className="space-y-2">
            {pendingRequests.map((b) => (
              <div key={b.id} className="flex items-center gap-3 p-3 rounded-2xl bg-orange-50 border border-orange-200">
                <div className="w-9 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-primary/10">
                  {b.cover_image && <img src={b.cover_image} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{b.title}</p>
                  <p className="text-xs text-muted-foreground">{b.author_name}</p>
                </div>
                <Button size="sm" className="rounded-full text-xs h-7 bg-green-600 hover:bg-green-700" onClick={() => approveRequestMutation.mutate(b)}>Onayla</Button>
                <Button size="sm" variant="outline" className="rounded-full text-xs h-7 text-destructive" onClick={() => rejectRequestMutation.mutate(b.id)}>Reddet</Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add book */}
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Kitap ara ve vite ekle..."
            className="pl-9 h-10 rounded-xl"
          />
        </div>
        {searchResults.length > 0 && (
          <div className="absolute top-full left-0 right-0 z-20 mt-1 rounded-xl border border-border bg-popover shadow-lg overflow-hidden">
            {searchResults.map((b) => (
              <button
                key={b.id}
                onClick={() => { addMutation.mutate(b); setSearchQuery(""); }}
                className="w-full flex items-center gap-3 p-2.5 hover:bg-accent/10 transition-colors text-left"
              >
                <div className="w-8 h-10 rounded-lg overflow-hidden flex-shrink-0 bg-primary/10">
                  {b.cover_image && <img src={b.cover_image} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{b.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{b.author_name}</p>
                </div>
                <Plus className="w-4 h-4 text-primary flex-shrink-0" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Featured books list */}
      {isLoading ? (
        [1, 2, 3].map(i => <Skeleton key={i} className="h-16 rounded-2xl" />)
      ) : sorted.length === 0 ? (
        <div className="text-center py-12">
          <Star className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Henüz öne çıkan kitap yok</p>
          <p className="text-xs text-muted-foreground mt-1">Yukarıdan kitap arayıp ekleyin</p>
        </div>
      ) : (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground">{sorted.length} kitap • Sıralama</p>
          {sorted.map((fb, idx) => (
            <div key={fb.id} className={`flex items-center gap-3 p-3 rounded-2xl border ${fb.is_active ? "bg-card border-border" : "bg-muted/30 border-border opacity-50"}`}>
              <div className="flex flex-col gap-0.5">
                <button
                  onClick={() => reorderMutation.mutate({ book: fb, direction: "up" })}
                  disabled={idx === 0 || reorderMutation.isPending}
                  className="text-muted-foreground hover:text-foreground disabled:opacity-20"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => reorderMutation.mutate({ book: fb, direction: "down" })}
                  disabled={idx === sorted.length - 1 || reorderMutation.isPending}
                  className="text-muted-foreground hover:text-foreground disabled:opacity-20"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              </div>

              <span className="text-xs font-bold text-muted-foreground w-5 text-center">{idx + 1}</span>

              <div className="w-9 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-primary/10">
                {fb.book_cover && <img src={fb.book_cover} alt="" className="w-full h-full object-cover" />}
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{fb.book_title}</p>
                <p className="text-xs text-muted-foreground truncate">{fb.author_name}</p>
              </div>

              <button
                onClick={() => toggleActiveMutation.mutate({ id: fb.id, isActive: fb.is_active })}
                className="flex-shrink-0"
                aria-label="Aktif/pasif"
              >
                <Badge variant={fb.is_active ? "default" : "secondary"} className="text-[9px] cursor-pointer">
                  {fb.is_active ? "AKTİF" : "PASİF"}
                </Badge>
              </button>

              <button
                onClick={() => removeMutation.mutate(fb.id)}
                className="text-destructive hover:text-destructive/80 flex-shrink-0"
                aria-label="Kaldır"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}