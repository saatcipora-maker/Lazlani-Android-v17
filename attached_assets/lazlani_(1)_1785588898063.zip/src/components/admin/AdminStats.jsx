import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Users, BookOpen, Eye, Heart, PenTool, UserPlus, Activity, Wifi, CalendarDays } from "lucide-react";

export default function AdminStats({ allUsers, allBooks, onlineCount }) {
  const totalReads = allBooks.reduce((sum, b) => sum + (b.read_count || 0), 0);
  const totalLikes = allBooks.reduce((sum, b) => sum + (b.like_count || 0), 0);
  const publishedBooks = allBooks.filter((b) => b.status === "yayinda").length;
  const uniqueAuthors = new Set(allBooks.map((b) => b.author_email)).size;

  const todayStr = new Date().toISOString().slice(0, 10);

  const { data: todayLogins = [] } = useQuery({
    queryKey: ["admin", "daily-logins-today"],
    queryFn: () => base44.entities.DailyLogin.filter({ login_date: todayStr }, "-created_date", 500),
    staleTime: 60000,
  });

  const dailyActiveCount = new Set(todayLogins.map((l) => l.user_email)).size;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayISO = today.toISOString();
  const todayUsers = allUsers.filter((u) => u.created_date && u.created_date >= todayISO).length;

  const stats = [
    { icon: Users, label: "Toplam Kullanıcı", value: allUsers.length, color: "text-blue-500", bg: "bg-blue-50" },
    { icon: UserPlus, label: "Bugün Kayıt", value: todayUsers, color: "text-green-500", bg: "bg-green-50" },
    { icon: Wifi, label: "Çevrimiçi", value: onlineCount, color: "text-emerald-500", bg: "bg-emerald-50" },
    { icon: CalendarDays, label: "Günlük Aktif", value: dailyActiveCount, color: "text-teal-500", bg: "bg-teal-50" },
    { icon: BookOpen, label: "Toplam Kitap", value: allBooks.length, color: "text-purple-500", bg: "bg-purple-50" },
    { icon: Activity, label: "Yayında", value: publishedBooks, color: "text-indigo-500", bg: "bg-indigo-50" },
    { icon: PenTool, label: "Toplam Yazar", value: uniqueAuthors, color: "text-pink-500", bg: "bg-pink-50" },
    { icon: Eye, label: "Toplam Okuma", value: totalReads.toLocaleString("tr-TR"), color: "text-cyan-500", bg: "bg-cyan-50" },
    { icon: Heart, label: "Toplam Beğeni", value: totalLikes.toLocaleString("tr-TR"), color: "text-red-500", bg: "bg-red-50" },
  ];

  return (
    <div className="grid grid-cols-3 gap-2.5">
      {stats.map((s) => (
        <div key={s.label} className={`${s.bg} rounded-2xl p-3 border border-border/30`}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <s.icon className={`w-3.5 h-3.5 ${s.color}`} />
            <span className="text-[9px] font-medium text-muted-foreground leading-tight">{s.label}</span>
          </div>
          <p className="text-xl font-black text-foreground">{s.value}</p>
        </div>
      ))}
    </div>
  );
}