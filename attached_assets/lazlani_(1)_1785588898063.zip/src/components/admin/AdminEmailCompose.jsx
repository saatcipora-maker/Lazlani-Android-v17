import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Send, Loader2, Users, Mail, ChevronDown, FileText } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function AdminEmailCompose({ allUsers = [] }) {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const [targetType, setTargetType] = useState("all");
  const [selectedEmails, setSelectedEmails] = useState([]);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const [showUserList, setShowUserList] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState("");

  const { data: templates = [] } = useQuery({
    queryKey: ["email-templates"],
    queryFn: () => base44.entities.EmailTemplate.list("-created_date", 50),
  });

  const recipientCount = targetType === "all" ? allUsers.length : targetType === "admins" ? allUsers.filter((u) => u.role === "admin").length : selectedEmails.length;

  const loadTemplate = (templateId) => {
    setSelectedTemplateId(templateId);
    const tpl = templates.find((t) => t.id === templateId);
    if (tpl) { setSubject(tpl.subject); setBody(tpl.body); }
  };

  const toggleEmail = (email) => {
    setSelectedEmails((prev) => prev.includes(email) ? prev.filter((e) => e !== email) : [...prev, email]);
  };

  const handleSend = async () => {
    if (!subject.trim() || !body.trim()) { toast.error("Konu ve icerik gerekli"); return; }
    let recipients = [];
    if (targetType === "all") recipients = allUsers.map((u) => u.email).filter(Boolean);
    else if (targetType === "admins") recipients = allUsers.filter((u) => u.role === "admin").map((u) => u.email).filter(Boolean);
    else recipients = selectedEmails;
    if (recipients.length === 0) { toast.error("Alici secilmedi"); return; }

    setSending(true);
    setProgress({ current: 0, total: recipients.length });

    const log = await base44.entities.EmailLog.create({
      subject, body, recipient_count: recipients.length, success_count: 0, failure_count: 0,
      failed_emails: "", sent_by_email: currentUser?.email || "", sent_by_name: currentUser?.full_name || "",
      status: "sending", target_type: targetType,
    });

    let success = 0, failure = 0;
    const failed = [];

    for (let i = 0; i < recipients.length; i++) {
      try {
        await base44.integrations.Core.SendEmail({ to: recipients[i], subject, body });
        success++;
      } catch (e) { failure++; failed.push(recipients[i]); }
      setProgress({ current: i + 1, total: recipients.length });
    }

    await base44.entities.EmailLog.update(log.id, {
      success_count: success, failure_count: failure, failed_emails: failed.join(", "), status: "completed",
    });

    setSending(false);
    setProgress({ current: 0, total: 0 });
    setSubject(""); setBody(""); setSelectedEmails([]); setSelectedTemplateId("");
    queryClient.invalidateQueries({ queryKey: ["email-logs"] });
    toast.success(`${success} basarili, ${failure} basarisiz gonderildi`);
  };

  return (
    <div className="space-y-3">
      {/* Template selector */}
      {templates.length > 0 && (
        <div className="relative">
          <FileText className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none z-10" />
          <select value={selectedTemplateId} onChange={(e) => loadTemplate(e.target.value)}
            className="w-full h-10 pl-10 pr-3 rounded-xl bg-muted border-0 text-sm appearance-none cursor-pointer">
            <option value="">— Sablon sec —</option>
            {templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>
      )}

      {/* Recipient type */}
      <div>
        <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Alici</label>
        <div className="grid grid-cols-3 gap-2">
          {[{ id: "all", label: "Tum" }, { id: "admins", label: "Yönetici" }, { id: "selected", label: "Sectili" }].map((t) => (
            <button key={t.id} onClick={() => setTargetType(t.id)} disabled={sending}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition-all ${targetType === t.id ? "text-foreground" : "text-muted-foreground"}`}
              style={targetType === t.id ? { background: "linear-gradient(135deg, rgba(50,20,72,0.7), rgba(35,16,28,0.5))", border: "1px solid rgba(180,100,240,0.1)" } : { border: "1px solid rgba(200,140,255,0.06)" }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Selected users list */}
      {targetType === "selected" && (
        <div>
          <button onClick={() => setShowUserList(!showUserList)} className="w-full flex items-center justify-between p-2 rounded-xl glass-card text-xs font-medium">
            <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> {selectedEmails.length} kulanici secili</span>
            <ChevronDown className={`w-4 h-4 transition-transform ${showUserList ? "rotate-180" : ""}`} />
          </button>
          {showUserList && (
            <div className="mt-2 max-h-48 overflow-y-auto rounded-xl glass-card p-2 space-y-1">
              {allUsers.map((u) => (
                <label key={u.id} className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-muted/50 cursor-pointer">
                  <input type="checkbox" checked={selectedEmails.includes(u.email)} onChange={() => toggleEmail(u.email)} disabled={sending} className="w-4 h-4 accent-primary" />
                  <span className="text-xs truncate flex-1">{u.full_name || "Isimsiz"}</span>
                  <span className="text-[10px] text-muted-foreground truncate">{u.email}</span>
                </label>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Compose */}
      <div>
        <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Konu</label>
        <Input value={subject} onChange={(e) => setSubject(e.target.value)} disabled={sending} placeholder="E-posta konusu..." className="h-10" />
      </div>
      <div>
        <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Icerik</label>
        <Textarea value={body} onChange={(e) => setBody(e.target.value)} disabled={sending} placeholder="E-posta icerigi yazin..." className="min-h-[160px] resize-y" />
      </div>

      {/* Progress */}
      {sending && (
        <div className="p-3 rounded-xl glass-card">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium flex items-center gap-1.5"><Loader2 className="w-3.5 h-3.5 animate-spin" /> Gonderiliyor...</span>
            <span className="text-xs font-bold text-primary">{progress.current}/{progress.total}</span>
          </div>
          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
            <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress.total > 0 ? (progress.current / progress.total) * 100 : 0}%` }} />
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground flex items-center gap-1"><Mail className="w-3 h-3" /> {recipientCount} alici</span>
        <Button onClick={handleSend} disabled={sending || !subject.trim() || !body.trim()} className="rounded-full px-6">
          {sending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Gonderiliyor</> : <><Send className="w-4 h-4 mr-2" /> Gonder</>}
        </Button>
      </div>
    </div>
  );
}