import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Crown, PenLine, ShoppingCart } from "lucide-react";
import { toast } from "sonner";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export default function AvantajlarTab() {
  const queryClient = useQueryClient();

  const { data: settings = [] } = useQuery({
    queryKey: ["app-settings"],
    queryFn: () => base44.entities.AppSettings.list("-created_date", 50),
  });

  const getSetting = (key, fallback) => {
    const s = settings.find((s) => s.key === key);
    return s ? s.value : fallback;
  };

  const authorPrice = getSetting("yazarlik_rozeti_price", "99");
  const vipPrice = getSetting("vip_uyelik_price", "199");

  const addToCart = useMutation({
    mutationFn: async ({ product_name, product_type, price }) => {
      const user = await base44.auth.me();
      await base44.entities.CartItem.create({
        user_email: user.email,
        product_name,
        product_type,
        price: parseFloat(price),
        quantity: 1,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] });
      toast.success("Sepete eklendi!");
    },
  });

  return (
    <div className="px-4 py-6 space-y-4">
      <h2 className="text-lg font-bold text-foreground">Avantajlar</h2>
      <p className="text-sm text-muted-foreground">Platforma özel ayrıcalıklı paketler</p>

      {/* Yazarlık Rozeti */}
      <div className="bg-card border border-border rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
            <PenLine className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Yazarlık Rozeti</h3>
            <p className="text-xs text-muted-foreground">Yazar olarak tanın, öne çık</p>
          </div>
        </div>
        <ul className="text-xs text-muted-foreground space-y-1 mb-4 ml-1">
          <li>• Profilinde özel yazar rozeti</li>
          <li>• Kitaplarında onay damgası</li>
          <li>• Öne çıkarma önceliği</li>
        </ul>
        <div className="flex items-center justify-between">
          <span className="text-xl font-bold text-primary">{authorPrice} ₺</span>
          <Button
            size="sm"
            className="rounded-full"
            onClick={() => addToCart.mutate({ product_name: "Yazarlık Rozeti", product_type: "yazar_rozeti", price: authorPrice })}
            disabled={addToCart.isPending}
          >
            <ShoppingCart className="w-3.5 h-3.5 mr-1" />
            Satın Al
          </Button>
        </div>
      </div>

      {/* VIP Üyelik */}
      <div className="bg-gradient-to-br from-yellow-50 to-amber-50 border border-yellow-200 rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 rounded-full bg-yellow-100 flex items-center justify-center">
            <Crown className="w-5 h-5 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">VIP Üyelik</h3>
            <p className="text-xs text-muted-foreground">En üst düzey ayrıcalıklar</p>
          </div>
        </div>
        <ul className="text-xs text-muted-foreground space-y-1 mb-4 ml-1">
          <li>• Tüm içeriklere sınırsız erişim</li>
          <li>• VIP rozeti ve özel profil çerçevesi</li>
          <li>• Öncelikli destek</li>
        </ul>
        <div className="flex items-center justify-between">
          <span className="text-xl font-bold text-yellow-600">{vipPrice} ₺</span>
          <Button
            size="sm"
            className="rounded-full bg-yellow-500 hover:bg-yellow-600 text-white"
            onClick={() => addToCart.mutate({ product_name: "VIP Üyelik", product_type: "yazarlik_paketi", price: vipPrice })}
            disabled={addToCart.isPending}
          >
            <ShoppingCart className="w-3.5 h-3.5 mr-1" />
            Satın Al
          </Button>
        </div>
      </div>
    </div>
  );
}