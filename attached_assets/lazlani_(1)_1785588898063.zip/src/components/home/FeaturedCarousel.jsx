import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, BookOpen, Eye, Heart, MessageCircle, Star, Play, Pause, ChevronLeft, ChevronRight } from "lucide-react";
import { fmtStat } from "@/lib/bookStats";

const SLIDE_DURATION = 5000;

export default function FeaturedCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [touchStart, setTouchStart] = useState(null);
  const [dragOffset, setDragOffset] = useState(0);
  const containerRef = useRef(null);
  const isDragging = useRef(false);

  const { data: featuredBooks = [], isLoading } = useQuery({
    queryKey: ["featured-books"],
    queryFn: () => base44.entities.FeaturedBook.filter({ is_active: true }, "sort_order", 20),
    staleTime: 60 * 1000,
    placeholderData: (prev) => prev,
  });

  // Fetch live book data for stats
  const { data: liveBooks = [] } = useQuery({
    queryKey: ["featured-books-live", featuredBooks.map(f => f.book_id).join(",")],
    queryFn: async () => {
      if (!featuredBooks.length) return [];
      const results = await Promise.all(
        featuredBooks.map(f => base44.entities.Book.get(f.book_id).catch(() => null))
      );
      return results.filter(Boolean);
    },
    enabled: featuredBooks.length > 0,
    staleTime: 30 * 1000,
  });

  const slides = featuredBooks.map(fb => {
    const live = liveBooks.find(b => b.id === fb.book_id);
    return {
      ...fb,
      book: live || {
        id: fb.book_id,
        title: fb.book_title,
        cover_image: fb.book_cover,
        description: fb.book_description,
        author_name: fb.author_name,
        read_count: 0,
        like_count: 0,
        comment_count: 0,
        average_rating: 0,
      },
    };
  });

  const total = slides.length;

  const goTo = useCallback((idx) => {
    if (total === 0) return;
    setCurrentIndex(((idx % total) + total) % total);
  }, [total]);

  const next = useCallback(() => goTo(currentIndex + 1), [currentIndex, goTo]);
  const prev = useCallback(() => goTo(currentIndex - 1), [currentIndex, goTo]);

  // Auto-advance
  useEffect(() => {
    if (!isPlaying || total <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % total);
    }, SLIDE_DURATION);
    return () => clearInterval(timer);
  }, [isPlaying, total]);

  // Reset index if out of bounds
  useEffect(() => {
    if (currentIndex >= total && total > 0) setCurrentIndex(0);
  }, [total, currentIndex]);

  // Touch handlers
  const onTouchStart = (e) => {
    setTouchStart(e.touches[0].clientX);
    isDragging.current = true;
    setIsPlaying(false);
  };

  const onTouchMove = (e) => {
    if (!isDragging.current || touchStart === null) return;
    const delta = e.touches[0].clientX - touchStart;
    setDragOffset(delta);
  };

  const onTouchEnd = () => {
    if (!isDragging.current) return;
    const threshold = 50;
    if (dragOffset < -threshold) next();
    else if (dragOffset > threshold) prev();
    isDragging.current = false;
    setDragOffset(0);
    setTouchStart(null);
  };

  if (isLoading) {
    return (
      <div className="px-5 pt-4 pb-2">
        <Skeleton className="h-[240px] w-full rounded-[22px]" style={{ background: "rgba(40,18,65,0.4)" }} />
      </div>
    );
  }

  if (total === 0) return null;

  const slideWidth = 100 / total;
  const baseTranslate = -(currentIndex * slideWidth);
  const dragPercent = total > 0 ? (dragOffset / (containerRef.current?.offsetWidth || 1)) * 100 : 0;
  const translateX = baseTranslate + dragPercent;

  return (
    <div className="relative w-full overflow-hidden">
      <div className="ambient-orb w-[300px] h-[200px] top-[-50px] left-[20%]" style={{ background: "radial-gradient(circle, rgba(130,60,210,0.18), transparent)", opacity: 0.12 }} />
      <div className="ambient-orb w-[220px] h-[160px] bottom-[-30px] right-[-20px]" style={{ background: "radial-gradient(circle, rgba(240,140,60,0.12), transparent)", opacity: 0.1 }} />

      <div className="relative px-5 pt-4 pb-2">
        {/* Badge */}
        <div className="flex items-center justify-between mb-2.5">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full"
            style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.3), rgba(240,140,60,0.15))", backdropFilter: "blur(12px)", border: "1px solid rgba(240,140,60,0.15)" }}>
            <Sparkles className="w-3 h-3 text-accent" />
            <span className="text-[9px] font-bold text-white uppercase tracking-wider">Günün Kitabı</span>
          </div>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-7 h-7 rounded-full flex items-center justify-center glass-card active:scale-90 transition-transform"
            aria-label={isPlaying ? "Durdur" : "Oynat"}
          >
            {isPlaying ? <Pause className="w-3 h-3 text-foreground/70" /> : <Play className="w-3 h-3 text-foreground/70 ml-0.5" />}
          </button>
        </div>

        {/* Carousel viewport */}
        <div
          ref={containerRef}
          className="relative overflow-hidden rounded-[22px] featured-glow"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          <div
            className="flex transition-transform duration-500 ease-out"
            style={{
              width: `${total * 100}%`,
              transform: `translateX(${translateX}%)`,
              transitionDuration: isDragging.current ? "0ms" : "500ms",
            }}
          >
            {slides.map((slide, i) => {
              const book = slide.book;
              const desc = slide.book_description || book.description || "";
              return (
                <div key={slide.id} className="flex-shrink-0" style={{ width: `${slideWidth}%` }}>
                  <div className="relative h-[240px] mx-1 rounded-[22px] overflow-hidden"
                    style={{ background: "linear-gradient(155deg, rgba(50,20,72,0.5), rgba(35,16,22,0.35))", border: "1px solid rgba(180,100,240,0.1)" }}>
                    {book.cover_image ? (
                      <img src={book.cover_image} alt={book.title} className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
                    ) : (
                      <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.35), rgba(240,140,60,0.2), hsl(274,22%,10%))" }} />
                    )}
                    <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(16,8,24,0.97) 0%, rgba(16,8,24,0.5) 45%, rgba(16,8,24,0.08) 75%, transparent)" }} />

                    {/* Rating badge */}
                    {book.average_rating > 0 && (
                      <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 rounded-full"
                        style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(12px)" }}>
                        <Star className="w-3 h-3 text-accent fill-accent" />
                        <span className="text-[10px] font-bold text-white">{book.average_rating.toFixed(1)}</span>
                      </div>
                    )}

                    {/* Content */}
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <h2 className="font-heading text-[19px] font-bold text-white leading-tight mb-0.5 line-clamp-1">{book.title}</h2>
                      <p className="text-white/45 text-[12px] font-medium mb-1.5">{book.author_name}</p>
                      {desc && (
                        <p className="text-white/55 text-[11px] leading-relaxed mb-2.5 line-clamp-2">{desc}</p>
                      )}

                      {/* Stats */}
                      <div className="flex items-center gap-2.5 mb-2.5 flex-wrap">
                        <span className="flex items-center gap-0.5 text-white/50 text-[10px]"><Eye className="w-2.5 h-2.5" /> {fmtStat(book.read_count)}</span>
                        <span className="flex items-center gap-0.5 text-white/50 text-[10px]"><Heart className="w-2.5 h-2.5" /> {fmtStat(book.like_count)}</span>
                        {(book.comment_count || 0) > 0 && (
                          <span className="flex items-center gap-0.5 text-white/50 text-[10px]"><MessageCircle className="w-2.5 h-2.5" /> {fmtStat(book.comment_count)}</span>
                        )}
                        {book.average_rating > 0 && (
                          <span className="flex items-center gap-0.5 text-yellow-400/70 text-[10px]"><Star className="w-2.5 h-2.5 fill-current" /> {book.average_rating.toFixed(1)}</span>
                        )}
                      </div>

                      <Link to={`/book/${book.id}`}>
                        <div className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[12px] font-bold text-white active:scale-[0.97] transition-transform"
                          style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(300,50%,48%), hsl(24,85%,55%))", boxShadow: "0 4px 16px rgba(130,60,210,0.25), 0 2px 8px rgba(240,140,60,0.15)" }}>
                          <BookOpen className="w-3.5 h-3.5" /> Hemen Oku
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Nav arrows (desktop) */}
          {total > 1 && (
            <>
              <button onClick={prev} className="hidden sm:flex absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full items-center justify-center glass-card active:scale-90 transition-transform" aria-label="Önceki">
                <ChevronLeft className="w-4 h-4 text-white/70" />
              </button>
              <button onClick={next} className="hidden sm:flex absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full items-center justify-center glass-card active:scale-90 transition-transform" aria-label="Sonraki">
                <ChevronRight className="w-4 h-4 text-white/70" />
              </button>
            </>
          )}
        </div>

        {/* Dot indicators */}
        {total > 1 && (
          <div className="flex items-center justify-center gap-1.5 mt-3">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => { setCurrentIndex(i); setIsPlaying(false); }}
                className="rounded-full transition-all duration-300"
                style={{
                  width: i === currentIndex ? "20px" : "6px",
                  height: "6px",
                  background: i === currentIndex ? "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" : "rgba(200,140,255,0.2)",
                }}
                aria-label={`Slayt ${i + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}