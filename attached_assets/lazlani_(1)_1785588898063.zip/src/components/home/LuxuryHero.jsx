import { Link } from "react-router-dom";
import { Sparkles, BookOpen, Star, ChevronRight, BookMarked, Zap } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";

export default function LuxuryHero({ featuredBook }) {
  const { user } = useAuth();
  const firstName = user?.full_name ? user.full_name.split(" ")[0] : "Okuyucu";

  return (
    <div className="relative w-full overflow-hidden">
      {/* Warm ambient orbs */}
      <div className="ambient-orb w-[300px] h-[200px] top-[-50px] left-[20%]" style={{ background: "radial-gradient(circle, rgba(130,60,210,0.18), transparent)", opacity: 0.12 }} />
      <div className="ambient-orb w-[220px] h-[160px] bottom-[-30px] right-[-20px]" style={{ background: "radial-gradient(circle, rgba(240,140,60,0.12), transparent)", opacity: 0.1 }} />

      <div className="relative px-5 pt-4 pb-2">
        {/* Featured Book — Günün Kitabı */}
        {featuredBook && (
          <Link to={`/book/${featuredBook.id}`} className="block rounded-[22px] overflow-hidden active:scale-[0.98] transition-transform duration-300 mb-5 featured-glow"
            style={{ background: "linear-gradient(155deg, rgba(50,20,72,0.5), rgba(35,16,22,0.35))", border: "1px solid rgba(180,100,240,0.1)" }}>
            <div className="relative h-[220px] w-full">
              {featuredBook.cover_image ? (
                <img src={featuredBook.cover_image} alt={featuredBook.title} className="w-full h-full object-cover" loading="lazy" />
              ) : (
                <div className="w-full h-full" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.35), rgba(240,140,60,0.2), hsl(274,22%,10%))" }} />
              )}
              <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(16,8,24,0.95) 0%, rgba(16,8,24,0.45) 40%, rgba(16,8,24,0.08) 70%, transparent)" }} />

              <div className="absolute top-3 left-3">
                <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full"
                  style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.3), rgba(240,140,60,0.15))", backdropFilter: "blur(12px)", border: "1px solid rgba(240,140,60,0.15)" }}>
                  <Sparkles className="w-3 h-3 text-accent" />
                  <span className="text-[9px] font-bold text-white uppercase tracking-wider">Günün Kitabı</span>
                </div>
              </div>

              {featuredBook.rating > 0 && (
                <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 rounded-full"
                  style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(12px)" }}>
                  <Star className="w-3 h-3 text-accent fill-accent" />
                  <span className="text-[10px] font-bold text-white">{(featuredBook.rating || 9.5).toFixed(1)}</span>
                </div>
              )}

              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h2 className="font-heading text-[20px] font-bold text-white leading-tight mb-1">{featuredBook.title}</h2>
                <p className="text-white/45 text-[12px] font-medium mb-3">{featuredBook.author_name}</p>
                <div className="flex items-center gap-2.5">
                  <div className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[12px] font-bold text-white"
                    style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(300,50%,48%), hsl(24,85%,55%))", boxShadow: "0 4px 16px rgba(130,60,210,0.25), 0 2px 8px rgba(240,140,60,0.15)" }}>
                    <BookOpen className="w-3.5 h-3.5" /> Hemen Oku
                  </div>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center glass-card">
                    <BookMarked className="w-4 h-4 text-foreground/60" />
                  </div>
                </div>
              </div>
            </div>
          </Link>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-2.5 mb-4">
          <Link to="/library" className="glass-card rounded-2xl p-3.5 active:scale-[0.96] transition-transform duration-200">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "rgba(130,60,210,0.12)" }}>
                <BookOpen className="w-4 h-4 text-primary" />
              </div>
              <span className="text-[10px] font-bold text-primary uppercase tracking-wider">Okuma Hedefin</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative w-10 h-10">
                <svg viewBox="0 0 36 36" className="w-10 h-10 -rotate-90">
                  <circle cx="18" cy="18" r="15" fill="none" stroke="rgba(130,60,210,0.1)" strokeWidth="3" />
                  <circle cx="18" cy="18" r="15" fill="none" stroke="url(#progV40)" strokeWidth="3" strokeDasharray="94.2" strokeDashoffset="23.5" strokeLinecap="round" />
                  <defs><linearGradient id="progV40"><stop offset="0%" stopColor="hsl(270,60%,56%)" /><stop offset="100%" stopColor="hsl(24,85%,55%)" /></linearGradient></defs>
                </svg>
                <span className="absolute inset-0 flex items-center justify-center text-[9px] font-black text-accent">75%</span>
              </div>
              <p className="text-[10px] text-muted-foreground leading-tight">Sana özel 20 kitap<br/>hedefi hazırlandı!</p>
            </div>
          </Link>
          <Link to="/search" className="sapphire-glass rounded-2xl p-3.5 active:scale-[0.96] transition-transform duration-200">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "rgba(240,140,60,0.12)" }}>
                <Zap className="w-4 h-4 text-accent" />
              </div>
              <span className="text-[10px] font-bold text-accent uppercase tracking-wider">AI Önerileri</span>
            </div>
            <p className="text-[11px] text-foreground font-semibold leading-tight">Sana özel 8 yeni<br/>öneri hazırlandı</p>
          </Link>
        </div>
      </div>
    </div>
  );
}