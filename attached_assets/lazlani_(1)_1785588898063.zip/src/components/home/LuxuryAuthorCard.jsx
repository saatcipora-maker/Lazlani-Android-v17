import { Link } from "react-router-dom";
import { Crown, BookOpen, Eye, ChevronRight, Award } from "lucide-react";

export default function LuxuryAuthorCard({ author, bookCount, readCount }) {
  if (!author) return null;

  return (
    <div className="px-5">
      <Link to={`/user/${encodeURIComponent(author.email)}`} className="block gold-glass rounded-[20px] p-4 active:scale-[0.98] transition-transform duration-300">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5">
            <Crown className="w-3.5 h-3.5 text-primary" />
            <span className="text-[9px] font-bold text-primary uppercase tracking-[0.14em]">Haftanın Yazarı</span>
          </div>
          <div className="flex items-center gap-0.5 text-primary/35">
            <span className="text-[10px] font-medium">Profili Gör</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>
        <div className="flex items-center gap-3.5">
          <div className="relative">
            <div className="rounded-2xl overflow-hidden flex-shrink-0" style={{ width: "62px", height: "62px", border: "2px solid rgba(170,90,255,0.2)", boxShadow: "0 4px 20px rgba(140,70,230,0.15)" }}>
              {author.avatar_url ? (
                <img src={author.avatar_url} alt={author.full_name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, rgba(140,70,230,0.25), rgba(220,100,200,0.1))" }}>
                  <span className="text-xl font-bold text-primary">{author.full_name?.[0]?.toUpperCase()}</span>
                </div>
              )}
            </div>
            <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center shadow-lg"
              style={{ background: "linear-gradient(135deg, hsl(272,70%,58%), hsl(310,55%,48%))", boxShadow: "0 2px 10px rgba(140,70,230,0.35)" }}>
              <Award className="w-2.5 h-2.5 text-white" />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-heading text-[15px] font-bold text-foreground truncate">{author.full_name}</h3>
            <div className="flex items-center gap-4 mt-2">
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><BookOpen className="w-3 h-3 text-primary/35" /> {bookCount} eser</span>
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><Eye className="w-3 h-3 text-primary/35" /> {readCount} okuma</span>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}