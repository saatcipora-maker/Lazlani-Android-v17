import { Link } from "react-router-dom";
import { Sparkles, BookOpen, TrendingUp } from "lucide-react";

export default function HeroSection({ featuredBook, dailyBook }) {
  const hero = featuredBook || dailyBook;

  return (
    <div className="relative w-full overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-background to-accent/5" />
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-accent/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="relative px-5 pt-5 pb-6">
        {/* Welcome badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/15 mb-4">
          <Sparkles className="w-3 h-3 text-primary" />
          <span className="text-[11px] font-semibold text-primary">Premium Okuma Deneyimi</span>
        </div>

        {/* Hero title */}
        <h1 className="font-heading text-[22px] font-bold text-foreground leading-tight mb-1.5">
          Hikâyelerin Buluştuğu
          <br />
          <span className="text-primary">Dijital Ekosistem</span>
        </h1>
        <p className="text-[13px] text-muted-foreground leading-relaxed mb-5 max-w-[280px]">
          Binlerce eser keşfet, kendi hikâyeni yaz, topluluğa katıl.
        </p>

        {/* Quick action cards */}
        <div className="flex gap-2.5">
          <Link
            to="/search"
            className="flex-1 glass-card rounded-2xl p-3.5 active:scale-[0.97] transition-transform duration-200"
          >
            <div className="w-9 h-9 rounded-xl bg-primary/12 flex items-center justify-center mb-2.5">
              <BookOpen className="w-4.5 h-4.5 text-primary" />
            </div>
            <p className="text-[12px] font-bold text-foreground">Keşfet</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">Yeni eserler</p>
          </Link>
          <Link
            to="/write"
            className="flex-1 glass-card rounded-2xl p-3.5 active:scale-[0.97] transition-transform duration-200"
          >
            <div className="w-9 h-9 rounded-xl bg-accent/12 flex items-center justify-center mb-2.5">
              <Sparkles className="w-4.5 h-4.5 text-accent" />
            </div>
            <p className="text-[12px] font-bold text-foreground">Yaz</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">Hikâyeni paylaş</p>
          </Link>
          <Link
            to="/search"
            className="flex-1 glass-card rounded-2xl p-3.5 active:scale-[0.97] transition-transform duration-200"
          >
            <div className="w-9 h-9 rounded-xl bg-destructive/10 flex items-center justify-center mb-2.5">
              <TrendingUp className="w-4.5 h-4.5 text-destructive" />
            </div>
            <p className="text-[12px] font-bold text-foreground">Trendler</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">Popüler içerik</p>
          </Link>
        </div>

        {/* Featured book card */}
        {hero && (
          <Link
            to={`/book/${hero.id}`}
            className="mt-5 block glass-card rounded-2xl overflow-hidden active:scale-[0.98] transition-transform duration-200"
          >
            <div className="flex gap-3.5 p-3.5">
              <div className="w-20 h-28 rounded-xl overflow-hidden flex-shrink-0 shadow-lg">
                {hero.cover_image ? (
                  <img src={hero.cover_image} alt={hero.title} className="w-full h-full object-cover" loading="lazy" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center p-2">
                    <span className="text-white text-[10px] font-bold text-center">{hero.title}</span>
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0 py-0.5">
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span className="text-[9px] font-bold text-accent uppercase tracking-wider">Günün Kitabı</span>
                  <Sparkles className="w-2.5 h-2.5 text-accent" />
                </div>
                <h3 className="font-heading text-sm font-bold text-foreground leading-snug truncate">{hero.title}</h3>
                <p className="text-[11px] text-muted-foreground mt-0.5">{hero.author_name}</p>
                {hero.description && (
                  <p className="text-[10px] text-muted-foreground/70 mt-1.5 line-clamp-2 leading-relaxed">{hero.description}</p>
                )}
              </div>
            </div>
          </Link>
        )}
      </div>
    </div>
  );
}