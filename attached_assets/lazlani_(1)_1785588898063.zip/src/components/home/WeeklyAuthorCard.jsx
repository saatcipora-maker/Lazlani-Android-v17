import { Link } from "react-router-dom";
import { Award, BookOpen, Users } from "lucide-react";

export default function WeeklyAuthorCard({ author, bookCount, followerCount }) {
  if (!author) return null;

  return (
    <div className="px-5 mb-2">
      <Link
        to={`/user/${encodeURIComponent(author.email)}`}
        className="block glass-card rounded-2xl p-4 active:scale-[0.98] transition-transform duration-200"
      >
        <div className="flex items-center gap-1.5 mb-3">
          <Award className="w-3.5 h-3.5 text-accent" />
          <span className="text-[10px] font-bold text-accent uppercase tracking-wider">Haftanın Yazarı</span>
        </div>
        <div className="flex items-center gap-3.5">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center overflow-hidden border-2 border-primary/20 flex-shrink-0">
            {author.avatar_url ? (
              <img src={author.avatar_url} alt={author.full_name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-lg font-bold text-primary">{author.full_name?.[0]?.toUpperCase()}</span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-heading text-sm font-bold text-foreground truncate">{author.full_name}</h3>
            {author.bio && (
              <p className="text-[10px] text-muted-foreground mt-0.5 line-clamp-1">{author.bio}</p>
            )}
            <div className="flex items-center gap-3 mt-1.5">
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <BookOpen className="w-3 h-3" /> {bookCount} eser
              </span>
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <Users className="w-3 h-3" /> {followerCount} takipçi
              </span>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}