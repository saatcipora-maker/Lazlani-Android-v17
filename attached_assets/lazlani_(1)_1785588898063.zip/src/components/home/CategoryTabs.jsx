import { Store, Sparkles, BookOpen, Newspaper, MessageCircle } from "lucide-react";

const tabs = [
  { id: "kitaplar", label: "Mağaza", icon: Store },
  { id: "ozel", label: "Özel", icon: Sparkles },
  { id: "magazin", label: "Dergi", icon: BookOpen },
  { id: "bultenler", label: "Bültenler", icon: Newspaper },
  { id: "yazar", label: "Sohbet", icon: MessageCircle },
];

export default function CategoryTabs({ activeTab, onTabChange }) {
  return (
    <div className="overflow-x-auto scrollbar-hide">
      <div className="flex gap-1.5 px-4 py-2 min-w-max">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button key={tab.id} onClick={() => onTabChange(tab.id)}
              className={`py-2 px-4 text-[11px] font-semibold whitespace-nowrap rounded-full transition-all duration-300 flex items-center gap-1.5 ${
                isActive
                  ? "text-white pill-glow"
                  : "text-white/22 hover:text-white/38 border border-transparent"
              }`}
              style={isActive ? {
                background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(300,50%,48%), hsl(24,85%,55%))",
                border: "1px solid rgba(240,140,60,0.15)"
              } : {}}>
              <Icon className={`w-3.5 h-3.5 transition-all duration-300 ${isActive ? "text-white" : ""}`} strokeWidth={isActive ? 2.3 : 1.4} />
              {tab.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}