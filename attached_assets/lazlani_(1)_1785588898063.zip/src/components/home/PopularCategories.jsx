import { Link } from "react-router-dom";
import { Wand2, Heart, Rocket, Ghost, Compass, Flame } from "lucide-react";

const CATEGORIES = [
  { label: "Fantastik", icon: Wand2, color: "#A855F7" },
  { label: "Romantik", icon: Heart, color: "#EC4899" },
  { label: "Bilim Kurgu", icon: Rocket, color: "#3B82F6" },
  { label: "Gizem", icon: Ghost, color: "#10B981" },
  { label: "Aksiyon", icon: Flame, color: "#F0903C" },
  { label: "Tarihsel", icon: Compass, color: "#8B5CF6" },
];

export default function PopularCategories() {
  return (
    <div className="px-5">
      <div className="grid grid-cols-3 gap-2.5">
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          return (
            <Link key={cat.label} to={`/search?category=${encodeURIComponent(cat.label)}`}
              className="glass-card rounded-2xl p-3 flex flex-col items-center gap-2 active:scale-95 transition-transform duration-200">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${cat.color}12` }}>
                <Icon className="w-5 h-5" style={{ color: cat.color }} />
              </div>
              <span className="text-[10px] font-semibold text-foreground/75">{cat.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}