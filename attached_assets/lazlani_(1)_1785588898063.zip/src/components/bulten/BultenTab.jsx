import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Image, Loader2, Send, BookOpen, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import BultenPostCard from "./BultenPostCard";

export default function BultenTab() {
  const [currentUser, setCurrentUser] = useState(null);
  const [content, setContent] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState("");
  const [uploading, setUploading] = useState(false);
  const [selectedBook, setSelectedBook] = useState(null);
  const [showBookPicker, setShowBookPicker] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["bulten-posts"],
    queryFn: () => base44.entities.BultenPost.list("-created_date", 30),
  });

  const { data: myBooks = [] } = useQuery({
    queryKey: ["my-books-bulten", currentUser?.email],
    queryFn: () => base44.entities.Book.filter({ author_email: currentUser.email, status: "yayinda" }, "-created_date", 50),
    enabled: !!currentUser?.email,
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      let image_url = "";
      if (imageFile) {
        setUploading(true);
        const res = await base44.integrations.Core.UploadFile({ file: imageFile });
        image_url = res.file_url;
        setUploading(false);
      }
      return base44.entities.BultenPost.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        content: content.trim(),
        image_url,
        book_id: selectedBook?.id || "",
        book_title: selectedBook?.title || "",
        book_cover: selectedBook?.cover_image || "",
        like_count: 0,
        comment_count: 0,
      });
    },
    onSuccess: () => {
      setContent("");
      setImageFile(null);
      setImagePreview("");
      setSelectedBook(null);
      queryClient.invalidateQueries({ queryKey: ["bulten-posts"] });
    },
  });

  const handleImageSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const canPost = content.trim().length > 0 && !createMutation.isPending && !uploading;

  return (
    <div className="px-4 pt-4 pb-8 space-y-4">
      {/* Create post */}
      {currentUser && (
        <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-bold text-primary">{currentUser.full_name?.[0]?.toUpperCase() || "?"}</span>
            </div>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Bir şeyler paylaş..."
              className="flex-1 min-h-[72px] resize-none border-0 bg-muted rounded-xl text-sm p-3 focus-visible:ring-0"
            />
          </div>
          {imagePreview && (
            <img src={imagePreview} alt="preview" className="w-full h-40 object-cover rounded-xl" />
          )}
          {/* Selected book preview */}
          {selectedBook && (
            <div className="flex items-center gap-3 p-2.5 bg-muted rounded-xl">
              {selectedBook.cover_image ? (
                <img src={selectedBook.cover_image} alt={selectedBook.title} className="w-10 h-14 object-cover rounded-lg flex-shrink-0" />
              ) : (
                <div className="w-10 h-14 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-4 h-4 text-primary" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-foreground truncate">{selectedBook.title}</p>
                <p className="text-[10px] text-muted-foreground">Kitap paylaşılacak</p>
              </div>
              <button onClick={() => setSelectedBook(null)} className="text-muted-foreground p-1" style={{ minHeight: "auto", minWidth: "auto" }}>
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
          {/* Book picker dropdown */}
          {showBookPicker && myBooks.length > 0 && (
            <div className="bg-muted rounded-xl p-2 space-y-1 max-h-48 overflow-y-auto">
              <p className="text-xs font-medium text-muted-foreground px-2 pb-1">Kitabını seç:</p>
              {myBooks.map((book) => (
                <button
                  key={book.id}
                  onClick={() => { setSelectedBook(book); setShowBookPicker(false); }}
                  className="w-full flex items-center gap-2.5 p-2 rounded-lg hover:bg-card transition-colors text-left"
                  style={{ minHeight: "auto" }}
                >
                  {book.cover_image ? (
                    <img src={book.cover_image} alt={book.title} className="w-8 h-11 object-cover rounded-md flex-shrink-0" />
                  ) : (
                    <div className="w-8 h-11 bg-primary/20 rounded-md flex items-center justify-center flex-shrink-0">
                      <BookOpen className="w-3 h-3 text-primary" />
                    </div>
                  )}
                  <span className="text-xs font-medium text-foreground truncate">{book.title}</span>
                </button>
              ))}
            </div>
          )}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-3">
              <label className="cursor-pointer text-muted-foreground hover:text-primary transition-colors">
                <Image className="w-5 h-5" />
                <input type="file" accept="image/*" className="hidden" onChange={handleImageSelect} />
              </label>
              {myBooks.length > 0 && (
                <button
                  onClick={() => setShowBookPicker(!showBookPicker)}
                  aria-label="Kitabını paylaş"
                  className={`transition-colors ${selectedBook ? "text-primary" : "text-muted-foreground hover:text-primary"}`}
                  style={{ minHeight: "auto", minWidth: "auto" }}
                >
                  <BookOpen className="w-5 h-5" />
                </button>
              )}
            </div>
            <Button
              size="sm"
              className="rounded-full px-5"
              onClick={() => createMutation.mutate()}
              disabled={!canPost}
            >
              {(createMutation.isPending || uploading) && <Loader2 className="w-3 h-3 mr-1 animate-spin" />}
              <Send className="w-3 h-3 mr-1" />
              Paylaş
            </Button>
          </div>
        </div>
      )}

      {/* Posts */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-32 rounded-2xl" />)}
        </div>
      ) : posts.length === 0 ? (
        <p className="text-center text-muted-foreground text-sm py-12">Henüz paylaşım yok. İlk paylaşımı yap!</p>
      ) : (
        <div className="space-y-3">
          {posts.map((post) => (
            <BultenPostCard
              key={post.id}
              post={post}
              currentUser={currentUser}
              onDelete={currentUser?.email === post.user_email ? () => {
                base44.entities.BultenPost.delete(post.id).then(() =>
                  queryClient.invalidateQueries({ queryKey: ["bulten-posts"] })
                );
              } : undefined}
            />
          ))}
        </div>
      )}
    </div>
  );
}