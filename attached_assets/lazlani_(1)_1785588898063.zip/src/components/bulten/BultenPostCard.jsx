import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Heart, MessageCircle, Send, Trash2, BookOpen, Share2 } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";
import CommentItem from "@/components/comments/CommentItem";
import { useUserBadges, getBadgeNameClass, getBadgeTextClass } from "@/hooks/useUserBadges";
import { useOptimisticUpdate } from "@/hooks/useOptimisticUpdate";

export default function BultenPostCard({ post, currentUser, onDelete }) {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const queryClient = useQueryClient();
  const isOwn = currentUser?.email === post.user_email;
  const badgeMap = useUserBadges();
  const nameClass = getBadgeNameClass(post.user_email, badgeMap);
  const textClass = getBadgeTextClass(post.user_email, badgeMap);
  const { optimisticLike, optimisticComment, rollback } = useOptimisticUpdate();

  const { data: likes = [] } = useQuery({
    queryKey: ["bulten-likes", post.id],
    queryFn: () => base44.entities.BultenLike.filter({ post_id: post.id }, "-created_date", 200),
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["bulten-comments", post.id],
    queryFn: () => base44.entities.BultenComment.filter({ post_id: post.id }, "created_date", 100),
    enabled: showComments,
  });

  const isLiked = likes.some((l) => l.user_email === currentUser?.email);

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (isLiked) {
        const myLike = likes.find((l) => l.user_email === currentUser.email);
        await base44.entities.BultenLike.delete(myLike.id);
      } else {
        await base44.entities.BultenLike.create({ post_id: post.id, user_email: currentUser.email });
      }
    },
    onMutate: () => {
      const prevData = optimisticLike({
        entityId: post.id,
        queryKey: ["bulten-likes", post.id],
        userId: currentUser.email,
        isLiked,
      });
      return { prevData };
    },
    onError: (_err, _vars, ctx) => {
      rollback(["bulten-likes", post.id], ctx?.prevData);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["bulten-likes", post.id] }),
  });

  const commentMutation = useMutation({
    mutationFn: () =>
      base44.entities.BultenComment.create({
        post_id: post.id,
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        content: commentText.trim(),
      }),
    onMutate: () => {
      const prevData = optimisticComment({
        entityId: post.id,
        queryKey: ["bulten-comments", post.id],
        newComment: {
          content: commentText,
          user_name: currentUser.full_name,
          user_email: currentUser.email,
        },
      });
      return { prevData };
    },
    onError: (_err, _vars, ctx) => {
      rollback(["bulten-comments", post.id], ctx?.prevData);
    },
    onSettled: () => {
      setCommentText("");
      queryClient.invalidateQueries({ queryKey: ["bulten-comments", post.id] });
    },
  });

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 pb-3">
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-bold text-primary">{post.user_name?.[0]?.toUpperCase() || "?"}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-semibold ${nameClass || "text-foreground"}`}>{post.user_name || "Kullanıcı"}</p>
          <p className="text-[10px] text-muted-foreground">
            {formatDistanceToNow(new Date(post.created_date), { addSuffix: true, locale: tr })}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 pb-3">
        <p className={`text-sm leading-relaxed ${textClass || "text-foreground"}`}>{post.content}</p>
      </div>

      {/* Image */}
      {post.image_url && (
        <img src={post.image_url} alt="" className="w-full max-h-64 object-cover" />
      )}

      {/* Shared Book */}
      {post.book_id && (
        <div className="mx-4 mb-3">
          <Link
            to={`/book/${post.book_id}`}
            className="flex items-center gap-3 p-3 bg-muted rounded-xl border border-border hover:border-primary/30 transition-colors"
          >
            {post.book_cover ? (
              <img src={post.book_cover} alt={post.book_title} className="w-12 h-16 object-cover rounded-lg flex-shrink-0" />
            ) : (
              <div className="w-12 h-16 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-5 h-5 text-primary" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-foreground truncate">{post.book_title || "Kitap"}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{post.user_name} tarafından</p>
            </div>
            <span className="flex items-center gap-1 px-3 py-1.5 bg-primary text-primary-foreground text-xs font-semibold rounded-full flex-shrink-0">
              <BookOpen className="w-3 h-3" />
              Oku
            </span>
          </Link>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-4 px-4 py-3 border-t border-border/50">
        <button
          onClick={() => currentUser && likeMutation.mutate()}
          className={`flex items-center gap-1.5 text-sm transition-colors ${isLiked ? "text-red-500" : "text-muted-foreground hover:text-red-400"}`}
        >
          <Heart className={`w-4 h-4 ${isLiked ? "fill-current" : ""}`} />
          <span>{likes.length}</span>
        </button>
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{comments.length}</span>
        </button>
        <button
          onClick={async () => {
            const text = `📰 ${post.user_name}: ${post.content?.slice(0, 100)}${post.content?.length > 100 ? "..." : ""}`;
            if (navigator.share) {
              try { await navigator.share({ title: "Lazlani Bülten", text }); return; } catch {}
            }
            try { await navigator.clipboard.writeText(text); toast.success("Kopyalandı! Instagram hikayenize yapıştırabilirsiniz."); } catch {}
          }}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <Share2 className="w-4 h-4" />
        </button>
        {isOwn && onDelete && (
          <button
            onClick={onDelete}
            className="ml-auto flex items-center gap-1 text-xs text-destructive"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Sil
          </button>
        )}
      </div>

      {/* Comments */}
      {showComments && (
        <div className="px-4 pb-4 space-y-3 border-t border-border/50 pt-3">
          {comments.map((c) => (
            <CommentItem
              key={c.id}
              comment={c}
              currentUser={currentUser}
              entityName="BultenComment"
              queryKey={["bulten-comments", post.id]}
            />
          ))}
          {currentUser && (
            <div className="flex gap-2 pt-1">
              <Input
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Yorum yaz..."
                className="rounded-full h-8 bg-muted border-0"
                style={{ fontSize: "16px" }}
                onKeyDown={(e) => e.key === "Enter" && commentText.trim() && commentMutation.mutate()}
              />
              <Button
                size="icon"
                className="w-8 h-8 rounded-full flex-shrink-0"
                disabled={!commentText.trim()}
                onClick={() => commentMutation.mutate()}
              >
                <Send className="w-3 h-3" />
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}