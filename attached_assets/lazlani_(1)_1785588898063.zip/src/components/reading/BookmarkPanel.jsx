import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Bookmark, Plus, Trash2, X, StickyNote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function BookmarkPanel({ bookId, chapterId, chapterTitle, bookTitle, scrollPercent, currentUser, onClose }) {
  const [note, setNote] = useState("");
  const queryClient = useQueryClient();

  const { data: bookmarks = [] } = useQuery({
    queryKey: ["bookmarks", currentUser?.email, bookId],
    queryFn: () => base44.entities.Bookmark.filter({ user_email: currentUser.email, book_id: bookId }, "-created_date", 50),
    enabled: !!currentUser?.email,
  });

  const addMutation = useMutation({
    mutationFn: () => base44.entities.Bookmark.create({
      user_email: currentUser.email,
      book_id: bookId,
      chapter_id: chapterId,
      book_title: bookTitle || "",
      chapter_title: chapterTitle || "",
      scroll_percent: scrollPercent || 0,
      note: note.trim(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bookmarks", currentUser?.email, bookId] });
      setNote("");
      toast.success("Yer imi eklendi!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Bookmark.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bookmarks", currentUser?.email, bookId] });
      toast.success("Yer imi silindi");
    },
  });

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40" onClick={onClose}>
      <div
        className="w-full max-w-lg bg-card border-t border-border rounded-t-3xl p-5 pb-8 space-y-4 animate-in slide-in-from-bottom"
        style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 24px)", maxHeight: "70vh" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground text-sm">Yer İmleri</h3>
          </div>
          <button onClick={onClose} className="text-muted-foreground p-1"><X className="w-5 h-5" /></button>
        </div>

        {/* Add bookmark */}
        <div className="flex gap-2">
          <Input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Not ekle (isteğe bağlı)..."
            className="h-9 text-sm rounded-full flex-1"
          />
          <Button size="sm" className="rounded-full h-9" onClick={() => addMutation.mutate()} disabled={addMutation.isPending}>
            <Plus className="w-4 h-4 mr-1" /> Ekle
          </Button>
        </div>

        {/* List */}
        <div className="space-y-2 overflow-y-auto max-h-[40vh]">
          {bookmarks.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-4">Henüz yer imi yok</p>
          ) : (
            bookmarks.map((bm) => (
              <div key={bm.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                <Bookmark className="w-4 h-4 text-amber-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{bm.chapter_title}</p>
                  {bm.note && <p className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-1"><StickyNote className="w-2.5 h-2.5" /> {bm.note}</p>}
                  <p className="text-[10px] text-muted-foreground">%{bm.scroll_percent}</p>
                </div>
                <button onClick={() => deleteMutation.mutate(bm.id)} className="text-muted-foreground hover:text-destructive p-1">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}