import { useState } from "react";
import { Settings, Minus, Plus, X } from "lucide-react";

const FONTS = [
  { key: "default", label: "Varsayılan", family: "var(--font-inter)" },
  { key: "serif", label: "Serif", family: "Georgia, serif" },
  { key: "display", label: "Playfair", family: "var(--font-display)" },
  { key: "mono", label: "Mono", family: "ui-monospace, monospace" },
];

const THEMES = [
  { key: "light", label: "Gündüz", bg: "#ffffff", text: "#1a1a1a", border: "#e5e5e5" },
  { key: "sepia", label: "Sepya", bg: "#f5ead7", text: "#5b4636", border: "#d4c5a9" },
  { key: "dark", label: "Gece", bg: "#1a1a2e", text: "#d4d4d8", border: "#2d2d44" },
  { key: "amoled", label: "Siyah", bg: "#000000", text: "#e4e4e7", border: "#1a1a1a" },
];

const DEFAULTS = { font: "default", fontSize: 16, lineHeight: 1.9, theme: "light" };

function loadSettings() {
  try {
    const saved = localStorage.getItem("reading_settings");
    return saved ? { ...DEFAULTS, ...JSON.parse(saved) } : DEFAULTS;
  } catch {
    return DEFAULTS;
  }
}

function saveSettings(settings) {
  localStorage.setItem("reading_settings", JSON.stringify(settings));
}

export function useReadingSettings() {
  const [settings, setSettings] = useState(loadSettings);

  const update = (partial) => {
    setSettings((prev) => {
      const next = { ...prev, ...partial };
      saveSettings(next);
      return next;
    });
  };

  const font = FONTS.find((f) => f.key === settings.font) || FONTS[0];
  const theme = THEMES.find((t) => t.key === settings.theme) || THEMES[0];

  const contentStyle = {
    fontFamily: font.family,
    fontSize: `${settings.fontSize}px`,
    lineHeight: `${settings.lineHeight}`,
    color: theme.text,
  };

  const pageBg = theme.bg;

  return { settings, update, contentStyle, pageBg, font, theme };
}

export default function ReadingSettings({ settings, onUpdate, onClose }) {
  const currentFont = FONTS.find((f) => f.key === settings.font) || FONTS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40" onClick={onClose}>
      <div
        className="w-full max-w-lg bg-card border-t border-border rounded-t-3xl p-5 pb-8 space-y-5 animate-in slide-in-from-bottom"
        style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 24px)" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-foreground">Okuma Ayarları</h3>
          <button onClick={onClose} className="text-muted-foreground p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Font size */}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-2 block">Yazı Boyutu</label>
          <div className="flex items-center gap-4">
            <button
              onClick={() => onUpdate({ fontSize: Math.max(12, settings.fontSize - 1) })}
              className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-foreground active:scale-95"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-sm font-bold text-foreground w-8 text-center">{settings.fontSize}</span>
            <button
              onClick={() => onUpdate({ fontSize: Math.min(28, settings.fontSize + 1) })}
              className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-foreground active:scale-95"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Font family */}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-2 block">Yazı Tipi</label>
          <div className="flex gap-2">
            {FONTS.map((f) => (
              <button
                key={f.key}
                onClick={() => onUpdate({ font: f.key })}
                className={`flex-1 py-2 rounded-xl text-xs font-medium border transition-colors ${
                  settings.font === f.key
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-muted text-muted-foreground"
                }`}
                style={{ fontFamily: f.family }}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Line height */}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-2 block">Satır Aralığı</label>
          <div className="flex items-center gap-4">
            <button
              onClick={() => onUpdate({ lineHeight: Math.max(1.2, +(settings.lineHeight - 0.1).toFixed(1)) })}
              className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-foreground active:scale-95"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-sm font-bold text-foreground w-8 text-center">{settings.lineHeight.toFixed(1)}</span>
            <button
              onClick={() => onUpdate({ lineHeight: Math.min(3.0, +(settings.lineHeight + 0.1).toFixed(1)) })}
              className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-foreground active:scale-95"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Theme */}
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-2 block">Tema</label>
          <div className="flex gap-3">
            {THEMES.map((t) => (
              <button
                key={t.key}
                onClick={() => onUpdate({ theme: t.key })}
                className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all ${
                  settings.theme === t.key
                    ? "border-primary ring-2 ring-primary/30"
                    : "border-border"
                }`}
                style={{ backgroundColor: t.bg }}
              >
                <span className="text-xs font-semibold" style={{ color: t.text }}>Aa</span>
                <span className="text-[10px]" style={{ color: t.text }}>{t.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}