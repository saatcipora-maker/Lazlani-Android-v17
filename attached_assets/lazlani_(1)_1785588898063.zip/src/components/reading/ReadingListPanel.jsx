import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { List, Plus, Check, X, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function ReadingListPanel({ bookId, currentUser, onClose }) {
  const [newListName, setNewListName] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const queryClient = useQueryClient();

  const { data: lists = [] } = useQuery({
    queryKey: ["reading-lists", currentUser?.email],
    queryFn: () => base44.entities.ReadingList.filter({ user_email: currentUser.email }, "-created_date", 50),
    enabled: !!currentUser?.email,
  });

  const createMutation = useMutation({
    mutationFn: () => base44.entities.ReadingList.create({
      user_email: currentUser.email,
      name: newListName.trim(),
      book_ids: bookId ? [bookId] : [],
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reading-lists"] });
      setNewListName("");
      setShowCreate(false);
      toast.success("Liste oluşturuldu!");
    },
  });

  const toggleBook = useMutation({
    mutationFn: async (list) => {
      const ids = list.book_ids || [];
      const newIds = ids.includes(bookId) ? ids.filter((id) => id !== bookId) : [...ids, bookId];
      return base44.entities.ReadingList.update(list.id, { book_ids: newIds });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reading-lists"] });
      toast.success("Liste güncellendi!");
    },
  });

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40" onClick={onClose}>
      <div
        className="w-full max-w-lg bg-card border-t border-border rounded-t-3xl p-5 pb-8 space-y-4 animate-in slide-in-from-bottom"
        style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 24px)", maxHeight: "70vh" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <List className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground text-sm">Okuma Listeleri</h3>
          </div>
          <button onClick={onClose} className="text-muted-foreground p-1"><X className="w-5 h-5" /></button>
        </div>

        {/* Existing lists */}
        <div className="space-y-2 overflow-y-auto max-h-[40vh]">
          {lists.map((list) => {
            const isIn = bookId && (list.book_ids || []).includes(bookId);
            return (
              <button
                key={list.id}
                onClick={() => bookId && toggleBook.mutate(list)}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors text-left"
              >
                <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-colors ${isIn ? "border-primary bg-primary" : "border-border"}`}>
                  {isIn && <Check className="w-3 h-3 text-white" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{list.name}</p>
                  <p className="text-[10px] text-muted-foreground">{(list.book_ids || []).length} kitap</p>
                </div>
              </button>
            );
          })}
          {lists.length === 0 && !showCreate && (
            <p className="text-xs text-muted-foreground text-center py-4">Henüz liste yok</p>
          )}
        </div>

        {/* Create new list */}
        {showCreate ? (
          <div className="flex gap-2">
            <Input
              value={newListName}
              onChange={(e) => setNewListName(e.target.value)}
              placeholder="Liste adı..."
              className="h-9 text-sm rounded-full flex-1"
              autoFocus
            />
            <Button size="sm" className="rounded-full h-9" disabled={!newListName.trim()} onClick={() => createMutation.mutate()}>
              <Check className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="outline" className="rounded-full h-9" onClick={() => setShowCreate(false)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <Button variant="outline" className="w-full rounded-full" onClick={() => setShowCreate(true)}>
            <Plus className="w-4 h-4 mr-1" /> Yeni Liste Oluştur
          </Button>
        )}
      </div>
    </div>
  );
}