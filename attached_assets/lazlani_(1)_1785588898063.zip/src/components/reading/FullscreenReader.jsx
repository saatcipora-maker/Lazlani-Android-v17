import { useState, useEffect, useCallback, useRef } from "react";
import { X, Settings, ChevronLeft, ChevronRight } from "lucide-react";
import ReadingSettings, { useReadingSettings } from "./ReadingSettings";
import sanitizeHtml from "@/lib/sanitizeHtml";

export default function FullscreenReader({ chapter, book, prevChapter, nextChapter, onClose, onNavigate }) {
  const [showUI, setShowUI] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [scrollPercent, setScrollPercent] = useState(0);
  const hideTimer = useRef(null);
  const scrollRef = useRef(null);
  const { settings, update: updateSettings, contentStyle, pageBg } = useReadingSettings();

  // Auto-hide UI after 3s
  useEffect(() => {
    if (showUI && !showSettings) {
      hideTimer.current = setTimeout(() => setShowUI(false), 4000);
    }
    return () => clearTimeout(hideTimer.current);
  }, [showUI, showSettings]);

  // Lock body scroll
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  const handleContentTap = (e) => {
    // Don't toggle when tapping settings or buttons
    if (e.target.closest("[data-no-toggle]")) return;
    setShowUI((prev) => !prev);
  };

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const percent = el.scrollHeight - el.clientHeight > 0
      ? Math.round((el.scrollTop / (el.scrollHeight - el.clientHeight)) * 100)
      : 0;
    setScrollPercent(percent);
  }, []);

  if (!chapter) return null;

  return (
    <div
      className="fixed inset-0 z-[200] flex flex-col transition-colors duration-300"
      style={{ backgroundColor: pageBg }}
    >
      {/* Progress bar — always visible */}
      <div className="absolute top-0 left-0 right-0 h-[3px] z-[210]" style={{ backgroundColor: `${pageBg}80` }}>
        <div
          className="h-full bg-primary transition-all duration-150 ease-out"
          style={{ width: `${scrollPercent}%` }}
        />
      </div>

      {/* Top bar — toggleable */}
      <div
        data-no-toggle
        className={`absolute top-0 left-0 right-0 z-[210] transition-all duration-300 ${
          showUI ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-full pointer-events-none"
        }`}
        style={{ backgroundColor: `${pageBg}ee`, paddingTop: "env(safe-area-inset-top)" }}
      >
        <div className="flex items-center gap-3 px-4 py-3 border-b" style={{ borderColor: contentStyle.color + "20" }}>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center transition-colors"
            style={{ backgroundColor: contentStyle.color + "15", color: contentStyle.color }}
          >
            <X className="w-5 h-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] truncate" style={{ color: contentStyle.color + "80" }}>{book?.title}</p>
            <p className="text-sm font-semibold truncate" style={{ color: contentStyle.color }}>{chapter.title}</p>
          </div>
          <button
            onClick={() => setShowSettings(true)}
            className="w-9 h-9 rounded-full flex items-center justify-center transition-colors"
            style={{ backgroundColor: contentStyle.color + "15", color: contentStyle.color }}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content area */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-6 pt-20 pb-24"
        onClick={handleContentTap}
        onScroll={handleScroll}
      >
        <div className="max-w-2xl mx-auto">
          <h2 className="font-display text-xl font-bold mb-6" style={{ color: contentStyle.color }}>
            {chapter.title}
          </h2>
          {chapter.content && chapter.content.includes("<") ? (
            <div
              className="prose prose-sm max-w-none"
              style={contentStyle}
              dangerouslySetInnerHTML={{ __html: sanitizeHtml(chapter.content) }}
            />
          ) : (
            <div className="whitespace-pre-wrap" style={contentStyle}>
              {chapter.content}
            </div>
          )}
        </div>
      </div>

      {/* Bottom bar — toggleable */}
      <div
        data-no-toggle
        className={`absolute bottom-0 left-0 right-0 z-[210] transition-all duration-300 ${
          showUI ? "opacity-100 translate-y-0" : "opacity-0 translate-y-full pointer-events-none"
        }`}
        style={{
          backgroundColor: `${pageBg}ee`,
          paddingBottom: "env(safe-area-inset-bottom)",
        }}
      >
        <div className="flex items-center justify-between px-4 py-3 gap-3 border-t" style={{ borderColor: contentStyle.color + "20" }}>
          {prevChapter ? (
            <button
              onClick={() => onNavigate(prevChapter.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-full text-sm font-medium border transition-colors"
              style={{ borderColor: contentStyle.color + "30", color: contentStyle.color }}
            >
              <ChevronLeft className="w-4 h-4" />
              Önceki
            </button>
          ) : (
            <div className="flex-1" />
          )}
          <span className="text-xs font-medium px-3" style={{ color: contentStyle.color + "60" }}>
            %{scrollPercent}
          </span>
          {nextChapter ? (
            <button
              onClick={() => onNavigate(nextChapter.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-full text-sm font-medium transition-colors"
              style={{ backgroundColor: contentStyle.color + "15", color: contentStyle.color }}
            >
              Sonraki
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <div className="flex-1" />
          )}
        </div>
      </div>

      {/* Settings panel */}
      {showSettings && (
        <ReadingSettings settings={settings} onUpdate={updateSettings} onClose={() => setShowSettings(false)} />
      )}
    </div>
  );
}