import GoogleIcon from "@/components/GoogleIcon";
import { base44 } from "@/api/base44Client";

export default function ContinueWithGoogle({ redirectTo = "/" }) {
  const handleClick = () => {
    localStorage.setItem("base44_login_provider", "google");
    base44.auth.loginWithProvider("google", redirectTo);
  };

  return (
    <button
      onClick={handleClick}
      type="button"
      className="w-full h-12 rounded-2xl flex items-center justify-center gap-3 text-sm font-semibold text-foreground glass-card active:scale-[0.97] transition-transform"
    >
      <GoogleIcon className="w-5 h-5" />
      Continue with Google
    </button>
  );
}