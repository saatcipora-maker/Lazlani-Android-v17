import { useState, useEffect, useCallback, useRef } from "react";
import { ArrowLeft, Loader2, WifiOff, RefreshCw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

const CHAT_URL = "https://organizations.minnit.chat/178740399438712/c/lazlani?embedmobile&app";

export default function YazarSohbeti({ onBack }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const iframeRef = useRef(null);

  const goBack = useCallback(() => {
    if (onBack) {
      onBack();
    } else {
      navigate("/", { replace: true });
    }
  }, [onBack, navigate]);

  // Android back button handler
  useEffect(() => {
    const handlePopState = (e) => {
      e.preventDefault();
      window.history.pushState(null, "", window.location.href);
      goBack();
    };

    window.history.pushState(null, "", window.location.href);
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, [goBack]);

  const handleLoad = useCallback(() => {
    setLoading(false);
    setError(false);
  }, []);

  const handleError = useCallback(() => {
    setLoading(false);
    setError(true);
  }, []);

  const handleRetry = useCallback(() => {
    setLoading(true);
    setError(false);
  }, []);

  return (
    <div
      className="fixed inset-0 z-[100] bg-background flex flex-col"
      style={{ width: "100vw", height: "100dvh" }}>
      
      {/* Sticky header — safe area aware, with back button for iOS iframe exit */}
      <div
        className="flex-shrink-0 flex items-center gap-3 px-3 safe-top"
        style={{
          height: "52px",
          background: "rgba(30,12,45,0.85)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          borderBottom: "1px solid rgba(200,140,255,0.08)",
        }}
      >
        <button
          onClick={goBack}
          className="w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-transform flex-shrink-0"
          style={{ background: "rgba(255,255,255,0.06)" }}
          aria-label="Geri"
        >
          <ArrowLeft className="w-4.5 h-4.5 text-foreground" />
        </button>
        <span className="text-sm font-heading font-bold text-foreground">Yazar Sohbeti</span>
      </div>
      










      

      {/* Chat area — fills remaining space */}
      <div className="flex-1 relative overflow-hidden">
        {/* Loading overlay */}
        {loading && !error &&
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background z-10 gap-3">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <p className="text-sm text-muted-foreground">Sohbet yükleniyor...</p>
          </div>
        }

        {/* Error overlay */}
        {error &&
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background z-10 gap-4 px-6">
            <WifiOff className="w-12 h-12 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground text-center">
              Bağlantı kurulamadı. İnternet bağlantınızı kontrol edin.
            </p>
            <Button onClick={handleRetry} variant="outline" className="rounded-full gap-2">
              <RefreshCw className="w-4 h-4" />
              Tekrar Dene
            </Button>
          </div>
        }

        {/* Minnit chat iframe */}
        {!error &&
        <iframe
          ref={iframeRef}
          key={loading ? "retry" : "stable"}
          src={CHAT_URL}
          onLoad={handleLoad}
          onError={handleError}
          title="Yazar Sohbeti"
          className="border-0 block pb-40"
          style={{ width: "100%", height: "100%" }}
          allow="microphone; camera; clipboard-write"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
          referrerPolicy="no-referrer" />

        }
      </div>
    </div>);

}