import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function GroupChat() {
  const { data: appSettings = [] } = useQuery({
    queryKey: ["app-settings"],
    queryFn: () => base44.entities.AppSettings.list("-created_date", 50),
  });
  const chatUrl = appSettings.find((s) => s.key === "group_chat_url")?.value || "";

  return (
    <div
      className="fixed bg-white"
      style={{
        top: "calc(env(safe-area-inset-top) + 56px)",
        left: 0,
        right: 0,
        bottom: "calc(env(safe-area-inset-bottom) + 60px)",
        zIndex: 30,
      }}
    >
      <iframe
        src={chatUrl}
        style={{ width: "100%", height: "100%", border: "none" }}
        allow="microphone; camera"
        title="Grup Sohbeti"
      />
    </div>
  );
}