import { useState, useRef, useCallback } from "react";
import { Loader2 } from "lucide-react";

export default function PullToRefresh({ onRefresh, children, className = "", scrollContainerRef }) {
  const [pulling, setPulling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [pullY, setPullY] = useState(0);
  const startY = useRef(null);
  const THRESHOLD = 64;

  const isAtTop = useCallback(() => {
    if (scrollContainerRef?.current) {
      return scrollContainerRef.current.scrollTop === 0;
    }
    const main = document.querySelector('main');
    if (main) return main.scrollTop === 0;
    return window.scrollY === 0;
  }, [scrollContainerRef]);

  const onTouchStart = useCallback((e) => {
    if (isAtTop()) {
      startY.current = e.touches[0].clientY;
    }
  }, [isAtTop]);

  const onTouchMove = useCallback((e) => {
    if (startY.current === null || refreshing) return;
    const dy = Math.max(0, e.touches[0].clientY - startY.current);
    if (dy > 5) {
      setPulling(true);
      setPullY(Math.min(dy * 0.45, THRESHOLD));
    }
  }, [refreshing]);

  const onTouchEnd = useCallback(async () => {
    if (!pulling) return;
    if (pullY >= THRESHOLD * 0.8) {
      setRefreshing(true);
      setPullY(THRESHOLD * 0.7);
      await onRefresh();
      setRefreshing(false);
    }
    setPulling(false);
    setPullY(0);
    startY.current = null;
  }, [pulling, pullY, onRefresh]);

  const label = refreshing
    ? "Yenileniyor..."
    : pullY >= THRESHOLD * 0.8
      ? "Bırakın"
      : pullY > 0
        ? "Yenilemek için çekin"
        : null;

  return (
    <div
      className={`relative ${className}`}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Pull indicator */}
      <div
        className="flex flex-col items-center justify-center transition-all duration-200 overflow-hidden gap-1"
        style={{ height: pullY }}
      >
        <Loader2
          className={`w-5 h-5 text-primary ${refreshing ? "animate-spin" : ""}`}
          style={{ transform: `rotate(${(pullY / THRESHOLD) * 360}deg)`, opacity: pullY > 10 ? 1 : 0 }}
        />
        {label && (
          <span className="text-xs text-muted-foreground text-center" style={{ opacity: pullY > 10 ? 1 : 0 }}>
            {label}
          </span>
        )}
      </div>
      {children}
    </div>
  );
}