/**
 * Online indicator — disabled globally for privacy.
 * Returns null so no user sees others' online/offline status.
 */
export default function OnlineIndicator() {
  return null;
}