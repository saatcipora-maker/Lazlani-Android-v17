import { useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import { BottomSheet } from "@/components/ui/bottom-sheet";
import { cn } from "@/lib/utils";

/**
 * NativeSelect — a mobile-friendly replacement for <select> and Radix Select.
 * Opens the existing BottomSheet component for option selection.
 *
 * Props:
 *   value        — current value
 *   onChange     — (value) => void
 *   options      — [{ value, label }]
 *   placeholder  — string
 *   title        — BottomSheet header title
 *   className    — extra classes for the trigger button
 *   disabled     — boolean
 */
export default function NativeSelect({
  value,
  onChange,
  options = [],
  placeholder = "Seçiniz",
  title = "Seçiniz",
  className,
  disabled = false,
}) {
  const [open, setOpen] = useState(false);

  const selected = options.find((o) => o.value === value);

  const handleSelect = (optValue) => {
    onChange(optValue);
    setOpen(false);
  };

  return (
    <>
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen(true)}
        className={cn(
          "flex items-center justify-between w-full h-9 rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm",
          "text-left transition-colors hover:bg-accent focus:outline-none focus:ring-1 focus:ring-ring",
          "disabled:cursor-not-allowed disabled:opacity-50",
          !selected && "text-muted-foreground",
          className
        )}
      >
        <span className="truncate">{selected ? selected.label : placeholder}</span>
        <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0 ml-2" />
      </button>

      <BottomSheet isOpen={open} onClose={() => setOpen(false)} title={title}>
        <div className="space-y-1 pb-2">
          {options.map((opt) => (
            <button
              key={opt.value}
              type="button"
              onClick={() => handleSelect(opt.value)}
              className={cn(
                "w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm transition-colors",
                opt.value === value
                  ? "bg-primary/10 text-primary font-semibold"
                  : "text-foreground hover:bg-muted"
              )}
            >
              <span>{opt.label}</span>
              {opt.value === value && <Check className="w-4 h-4" />}
            </button>
          ))}
        </div>
      </BottomSheet>
    </>
  );
}