import * as React from "react";
import { useEffect } from "react";
import { X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

const BottomSheet = React.forwardRef(
  ({ children, isOpen, onClose, title, className, ...props }, ref) => {
    useEffect(() => {
      if (isOpen) {
        document.body.style.overflow = "hidden";
      } else {
        document.body.style.overflow = "unset";
      }
      return () => {
        document.body.style.overflow = "unset";
      };
    }, [isOpen]);

    return (
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="fixed inset-0 z-40 bg-black/50"
              style={{
                top: "calc(env(safe-area-inset-top))",
                paddingBottom: "env(safe-area-inset-bottom)",
              }}
            />

            {/* Sheet */}
            <motion.div
              ref={ref}
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className={cn(
                "fixed inset-x-0 bottom-0 z-50 bg-background rounded-t-3xl shadow-lg",
                "max-h-[90vh] overflow-y-auto",
                className
              )}
              style={{
                paddingBottom: "env(safe-area-inset-bottom)",
              }}
              {...props}
            >
              {/* Handle bar */}
              <div className="flex justify-center pt-2 pb-2 sticky top-0 bg-background rounded-t-3xl">
                <div className="w-12 h-1 bg-muted rounded-full" />
              </div>

              {/* Header with title and close button */}
              {title && (
                <div className="flex items-center justify-between px-4 py-3 border-b border-border sticky top-6 bg-background">
                  <h2 className="text-lg font-semibold text-foreground">{title}</h2>
                  <button
                    onClick={onClose}
                    className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-colors text-foreground"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}

              {/* Content */}
              <div className="px-4 py-4 pb-8">{children}</div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    );
  }
);

BottomSheet.displayName = "BottomSheet";

const BottomSheetTrigger = React.forwardRef(({ onClick, children }, ref) => (
  <button ref={ref} onClick={onClick}>
    {children}
  </button>
));

BottomSheetTrigger.displayName = "BottomSheetTrigger";

export { BottomSheet, BottomSheetTrigger };