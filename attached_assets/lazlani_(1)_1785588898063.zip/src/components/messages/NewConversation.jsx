import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Search } from "lucide-react";
import MessageAvatar from "./MessageAvatar";

export default function NewConversation({ currentUser, onlineMap = {}, onSelect, onClose }) {
  const [search, setSearch] = useState("");

  const { data: allUsers = [], isLoading } = useQuery({
    queryKey: ["all-users"],
    queryFn: () => base44.entities.User.list("-created_date", 200)
  });

  const filtered = allUsers
    .filter((u) => u.email !== currentUser?.email)
    .filter((u) => {
      if (!search.trim()) return true;
      return (
        (u.full_name || "").toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase())
      );
    });

  return (
    <div className="fixed inset-0 z-50 bg-background flex flex-col" style={{ paddingTop: "env(safe-area-inset-top)" }}>
      <div className="flex items-center gap-3 px-3 py-2.5 border-b border-border/40 bg-card/95 backdrop-blur-xl flex-shrink-0">
        <button onClick={onClose} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted text-foreground">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="font-bold text-base text-foreground">Yeni Sohbet</span>
      </div>

      <div className="px-4 py-3 flex-shrink-0">
        <div className="flex items-center gap-2 bg-muted/80 rounded-2xl px-4 h-11">
          <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <input
            autoFocus
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="İsim veya e-posta ara..."
            className="flex-1 bg-transparent outline-none border-0 text-sm"
            style={{ fontSize: "16px" }}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto divide-y divide-border/30">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground text-sm">Kullanıcı bulunamadı</div>
        ) : (
          filtered.map((u) => (
            <button
              key={u.email}
              onClick={() => onSelect({ email: u.email, name: u.full_name || u.email })}
              className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-muted/50 active:bg-muted transition-colors text-left"
            >
              <MessageAvatar name={u.full_name || u.email} avatarUrl={u.avatar_url} />
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-sm text-foreground">{u.full_name || u.email}</p>
                <p className="text-xs text-muted-foreground truncate mt-0.5">{u.email}</p>
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
}