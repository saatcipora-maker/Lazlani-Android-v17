import { format } from "date-fns";
import { Check, CheckCheck, FileText } from "lucide-react";
import VoiceMessage from "./VoiceMessage";

export default function MessageBubble({ message, isMine, onImageClick }) {
  const bubbleBg = "bg-white shadow-sm";
  const bubbleText = isMine ? "#111111" : "#111111";

  const isVoice = message.message_type === "voice" && message.voice_url;
  const isFile = message.message_type === "file" && message.file_url;
  const isImage = message.image_url;

  return (
    <div className={`flex ${isMine ? "justify-end" : "justify-start"} mb-1.5`}>
      {!isMine && (
        <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0 mr-2 mt-auto mb-1 text-[10px] font-bold text-primary">
          {(message.sender_name || message.sender_email)[0]?.toUpperCase()}
        </div>
      )}
      <div className={`max-w-[78%] flex flex-col ${isMine ? "items-end" : "items-start"}`}>
        {isImage && (
          <img
            src={message.image_url}
            alt=""
            className="rounded-2xl max-w-full max-h-56 object-cover cursor-pointer mb-1 shadow-sm"
            onClick={() => onImageClick?.(message.image_url)}
          />
        )}

        {isVoice && (
          <div className={`px-4 py-3 rounded-2xl ${bubbleBg} ${isMine ? "rounded-br-sm" : "rounded-bl-sm"}`} style={{ border: "1px solid rgba(0,0,0,0.08)" }}>
            <VoiceMessage url={message.voice_url} duration={message.voice_duration} isMine={isMine} />
            <div className={`flex items-center gap-1 mt-1 ${isMine ? "justify-end" : "justify-start"}`}>
              <span className={`text-[10px] ${isMine ? "opacity-70" : "opacity-50"}`}>
                {message.created_date ? format(new Date(message.created_date), "HH:mm") : ""}
              </span>
              {isMine && (
                message.is_read
                  ? <CheckCheck className="w-3.5 h-3.5 text-blue-300" />
                  : <Check className="w-3.5 h-3.5 opacity-60" />
              )}
            </div>
          </div>
        )}

        {isFile && (
          <a
            href={message.file_url}
            target="_blank"
            rel="noopener noreferrer"
            className={`px-4 py-3 rounded-2xl flex items-center gap-3 ${bubbleBg} ${isMine ? "rounded-br-sm" : "rounded-bl-sm"}`}
            style={{ border: "1px solid rgba(0,0,0,0.08)" }}
          >
            <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-primary/10">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate" style={{ color: "#111111" }}>{message.file_name || "Dosya"}</p>
              <div className={`flex items-center gap-1 mt-0.5`}>
                <span className={`text-[10px] ${isMine ? "opacity-70" : "opacity-50"}`}>
                  {message.created_date ? format(new Date(message.created_date), "HH:mm") : ""}
                </span>
                {isMine && (
                  message.is_read
                    ? <CheckCheck className="w-3.5 h-3.5 text-blue-300" />
                    : <Check className="w-3.5 h-3.5 opacity-60" />
                )}
              </div>
            </div>
          </a>
        )}

        {!isVoice && !isFile && message.content && (
          <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${bubbleBg} ${isMine ? "rounded-br-sm" : "rounded-bl-sm"}`} style={{ border: "1px solid rgba(0,0,0,0.08)", color: bubbleText }}>
            <p className="whitespace-pre-wrap break-words">{message.content}</p>
            <div className={`flex items-center gap-1 mt-1 ${isMine ? "justify-end" : "justify-start"}`}>
              <span className={`text-[10px] ${isMine ? "opacity-70" : "opacity-50"}`}>
                {message.created_date ? format(new Date(message.created_date), "HH:mm") : ""}
              </span>
              {isMine && (
                message.is_read
                  ? <CheckCheck className="w-3.5 h-3.5 text-blue-300" />
                  : <Check className="w-3.5 h-3.5 opacity-60" />
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}