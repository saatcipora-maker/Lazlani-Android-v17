import { useState, useRef } from "react";
import { Mic, Square, Send, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function VoiceRecorder({ onSend }) {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [uploading, setUploading] = useState(false);
  const mediaRecorder = useRef(null);
  const chunks = useRef([]);
  const timer = useRef(null);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
    chunks.current = [];
    recorder.ondataavailable = (e) => chunks.current.push(e.data);
    recorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      clearInterval(timer.current);
      const blob = new Blob(chunks.current, { type: "audio/webm" });
      const file = new File([blob], "voice.webm", { type: "audio/webm" });
      setUploading(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploading(false);
      onSend(file_url, duration);
      setDuration(0);
    };
    mediaRecorder.current = recorder;
    recorder.start();
    setRecording(true);
    setDuration(0);
    timer.current = setInterval(() => setDuration((d) => d + 1), 1000);
  };

  const stopRecording = () => {
    if (mediaRecorder.current?.state === "recording") {
      mediaRecorder.current.stop();
      setRecording(false);
    }
  };

  const formatTime = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  if (uploading) {
    return (
      <div className="flex items-center gap-2 px-3 py-2">
        <Loader2 className="w-5 h-5 animate-spin text-primary" />
        <span className="text-xs text-muted-foreground">Gönderiliyor...</span>
      </div>
    );
  }

  if (recording) {
    return (
      <div className="flex items-center gap-3 flex-1">
        <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
        <span className="text-sm font-mono text-foreground">{formatTime(duration)}</span>
        <div className="flex-1" />
        <button
          onClick={stopRecording}
          className="w-11 h-11 rounded-full bg-primary flex items-center justify-center text-primary-foreground shadow-md active:scale-95 transition-transform"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={startRecording}
      className="w-10 h-10 flex items-center justify-center text-muted-foreground hover:text-primary transition-colors flex-shrink-0"
    >
      <Mic className="w-5 h-5" />
    </button>
  );
}