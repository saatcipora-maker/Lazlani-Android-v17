import OnlineIndicator from "@/components/ui/OnlineIndicator";

export default function MessageAvatar({ name, avatarUrl, online, size = "md" }) {
  const sz = size === "lg" ? "w-14 h-14 text-lg" : size === "sm" ? "w-9 h-9 text-xs" : "w-11 h-11 text-sm";
  return (
    <div className={`relative ${sz} rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0 overflow-hidden border-2 border-primary/10`}>
      {avatarUrl ? (
        <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
      ) : (
        <span className="font-bold text-primary">{(name || "?")[0].toUpperCase()}</span>
      )}
      {typeof online === "boolean" && <OnlineIndicator online={online} size={size === "lg" ? "md" : "sm"} />}
    </div>
  );
}