import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, MessageCircle, X, Phone, MoreVertical } from "lucide-react";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import MessageAvatar from "./MessageAvatar";
import MessageBubble from "./MessageBubble";
import ChatInput from "./ChatInput";
import TypingIndicator from "./TypingIndicator";

function makeConversationId(a, b) {
  return [a, b].sort().join("__");
}

function FullscreenImage({ url, onClose }) {
  return (
    <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center" onClick={onClose}>
      <button className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center text-white bg-white/10 rounded-full" onClick={onClose}>
        <X className="w-5 h-5" />
      </button>
      <img src={url} alt="" className="max-w-full max-h-full object-contain rounded-lg" />
    </div>
  );
}

export default function ChatView({ currentUser, activeConv, onBack, onlineMap = {} }) {
  const [fullscreenImg, setFullscreenImg] = useState(null);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();
  const typingTimeout = useRef(null);

  const convId = makeConversationId(currentUser.email, activeConv.email);

  const { data: messages = [] } = useQuery({
    queryKey: ["conv-messages", convId],
    queryFn: async () => {
      const [sent, received] = await Promise.all([
        base44.entities.Message.filter({ sender_email: currentUser.email, conversation_id: convId }, "-created_date", 200),
        base44.entities.Message.filter({ receiver_email: currentUser.email, conversation_id: convId }, "-created_date", 200)
      ]);
      return [...sent, ...received].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    },
    staleTime: Infinity
  });

  useEffect(() => {
    const unsub = base44.entities.Message.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["conv-messages", convId] });
    });
    return unsub;
  }, [convId]);

  // Mark unread messages as read
  useEffect(() => {
    const unread = messages.filter((m) => m.receiver_email === currentUser.email && !m.is_read);
    unread.forEach((m) => base44.entities.Message.update(m.id, { is_read: true }));
    if (unread.length > 0) queryClient.invalidateQueries({ queryKey: ["messages"] });
  }, [messages.length]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const sendMutation = useMutation({
    mutationFn: (msgData) =>
      base44.entities.Message.create({
        sender_email: currentUser.email,
        sender_name: currentUser.full_name,
        receiver_email: activeConv.email,
        receiver_name: activeConv.name,
        conversation_id: convId,
        is_read: false,
        ...msgData
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["conv-messages", convId] });
      queryClient.invalidateQueries({ queryKey: ["messages"] });
    }
  });

  const handleSend = (msgData) => {
    sendMutation.mutate(msgData);
  };

  const handleTyping = () => {
    clearTimeout(typingTimeout.current);
    setIsTyping(true);
    typingTimeout.current = setTimeout(() => setIsTyping(false), 2000);
  };

  // Group messages by date
  const grouped = [];
  let lastDate = null;
  messages.forEach((m) => {
    const d = m.created_date ? format(new Date(m.created_date), "d MMMM yyyy", { locale: tr }) : null;
    if (d && d !== lastDate) {
      grouped.push({ type: "date", label: d });
      lastDate = d;
    }
    grouped.push({ type: "msg", msg: m });
  });

  return (
    <>
      {fullscreenImg && <FullscreenImage url={fullscreenImg} onClose={() => setFullscreenImg(null)} />}
      <div className="fixed inset-0 z-50 flex flex-col bg-background" style={{ paddingTop: "env(safe-area-inset-top)" }}>
        {/* Header */}
        <div className="flex items-center gap-3 px-3 py-2.5 flex-shrink-0 border-b border-border/40 bg-card/95 backdrop-blur-xl">
          <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-colors text-foreground flex-shrink-0">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <MessageAvatar name={activeConv.name} size="sm" />
          <div className="min-w-0 flex-1">
            <p className="font-bold text-[15px] truncate text-foreground">{activeConv.name}</p>
            <p className="text-[11px] text-muted-foreground">
              {onlineMap[activeConv.email] ? <span className="text-green-400">Çevrimiçi</span> : "Çevrimdışı"}
            </p>
          </div>
        </div>

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto px-3 py-3 bg-muted/20">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full py-16 text-center">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <MessageCircle className="w-9 h-9 text-primary/40" />
              </div>
              <p className="text-foreground font-semibold text-base mb-1">Sohbet başlasın!</p>
              <p className="text-xs text-muted-foreground">{activeConv.name} ile ilk mesajı gönderin</p>
            </div>
          )}

          {grouped.map((item, idx) => {
            if (item.type === "date") {
              return (
                <div key={`date-${idx}`} className="flex items-center gap-3 my-4">
                  <div className="flex-1 h-px bg-border/50" />
                  <span className="text-[11px] text-muted-foreground font-medium bg-muted px-3 py-1 rounded-full">{item.label}</span>
                  <div className="flex-1 h-px bg-border/50" />
                </div>
              );
            }
            const m = item.msg;
            return (
              <MessageBubble
                key={m.id}
                message={m}
                isMine={m.sender_email === currentUser.email}
                onImageClick={setFullscreenImg}
              />
            );
          })}

          {isTyping && <TypingIndicator name={activeConv.name} />}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <ChatInput onSend={handleSend} onTyping={handleTyping} />
      </div>
    </>
  );
}