import { useState } from "react";
import { Search, Plus, MessageCircle } from "lucide-react";
import { format, isToday, isYesterday } from "date-fns";
import { tr } from "date-fns/locale";
import MessageAvatar from "./MessageAvatar";
import OnlineUsersStrip from "./OnlineUsersStrip";

function formatMsgTime(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  if (isToday(d)) return format(d, "HH:mm", { locale: tr });
  if (isYesterday(d)) return "Dün";
  return format(d, "dd MMM", { locale: tr });
}

export default function ConversationList({ conversations, onSelect, onNewChat, onlineMap = {} }) {
  const [search, setSearch] = useState("");

  const filtered = search.trim()
    ? conversations.filter((c) => (c.name || "").toLowerCase().includes(search.toLowerCase()))
    : conversations;

  const totalUnread = conversations.reduce((sum, c) => sum + (c.unreadCount || 0), 0);

  return (
    <div className="flex flex-col min-h-full">
      {/* Header area */}
      <div className="px-4 pt-3 pb-2 space-y-3">
        {/* Search bar */}
        <div className="flex items-center gap-2 glass-card rounded-2xl px-4 h-11">
          <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Sohbet ara..."
            className="flex-1 bg-transparent outline-none border-0 text-sm text-foreground placeholder:text-muted-foreground"
            style={{ fontSize: "16px" }}
          />
        </div>
      </div>

      {/* Online users strip */}
      <OnlineUsersStrip onlineMap={onlineMap} onSelect={onSelect} />

      {/* FAB */}
      <button
        onClick={onNewChat}
        className="fixed bottom-24 right-5 z-30 w-14 h-14 rounded-full shadow-lg flex items-center justify-center active:scale-95 transition-transform"
        style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))", boxShadow: "0 6px 24px rgba(130,60,210,0.35), 0 3px 12px rgba(240,140,60,0.15)" }}
        aria-label="Yeni sohbet"
      >
        <Plus className="w-6 h-6 text-white" />
      </button>

      {/* Conversation list */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center px-8">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mb-4" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.1), rgba(240,140,60,0.05))" }}>
            <MessageCircle className="w-9 h-9 text-primary/40" />
          </div>
          <p className="text-foreground font-semibold text-base mb-1">
            {search ? "Sonuç bulunamadı" : "Henüz sohbet yok"}
          </p>
          <p className="text-muted-foreground text-sm mb-6">
            {search ? "Farklı bir isim deneyin" : "Birisiyle konuşmaya başlayın"}
          </p>
          {!search && (
            <button
              onClick={onNewChat}
              className="flex items-center gap-2 text-primary-foreground px-6 py-3 rounded-full text-sm font-semibold shadow-md active:scale-95 transition-all"
              style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}
            >
              <Plus className="w-4 h-4" />
              Yeni Sohbet
            </button>
          )}
        </div>
      ) : (
        <div className="divide-y divide-border/20">
          {filtered.map((c) => {
            const lastMsgPreview = c.lastMsgType === "voice" ? "🎤 Sesli mesaj"
              : c.lastMsgType === "file" ? "📎 Dosya"
              : c.lastMsgType === "image" ? "📷 Fotoğraf"
              : c.lastMsg || "";

            const isOnline = onlineMap[c.email];

            return (
              <button
                key={c.email}
                onClick={() => onSelect(c)}
                className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-muted/30 active:bg-muted/50 transition-colors text-left"
              >
                <div className="relative flex-shrink-0">
                  <MessageAvatar name={c.name} />
                  {isOnline && (
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-background" style={{ background: "#22c55e" }} />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <p className={`font-semibold text-sm truncate ${c.unreadCount > 0 ? "text-foreground" : "text-foreground/80"}`}>{c.name}</p>
                    <span className={`text-[11px] flex-shrink-0 ml-2 ${c.unreadCount > 0 ? "text-accent font-semibold" : "text-muted-foreground"}`}>
                      {formatMsgTime(c.lastDate)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-0.5">
                    <p className={`text-xs truncate flex-1 ${c.unreadCount > 0 ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                      {lastMsgPreview}
                    </p>
                    {c.unreadCount > 0 && (
                      <span className="ml-2 min-w-[20px] h-5 rounded-full flex items-center justify-center px-1.5 flex-shrink-0"
                        style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
                        <span className="text-[10px] font-bold text-white">{c.unreadCount > 99 ? "99+" : c.unreadCount}</span>
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}