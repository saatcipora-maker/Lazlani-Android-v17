import { useState, useRef } from "react";
import { Send, Image, Paperclip, X, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import VoiceRecorder from "./VoiceRecorder";

export default function ChatInput({ onSend, onTyping }) {
  const [text, setText] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [attachedFile, setAttachedFile] = useState(null);
  const [sending, setSending] = useState(false);
  const inputRef = useRef(null);
  const imageInputRef = useRef(null);
  const fileInputRef = useRef(null);

  const handleTextChange = (e) => {
    setText(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
    onTyping?.();
  };

  const handleSendText = async () => {
    if (!text.trim() && !imageFile && !attachedFile) return;
    setSending(true);

    let image_url = "";
    let file_url = "";
    let file_name = "";
    let message_type = "text";

    if (imageFile) {
      const res = await base44.integrations.Core.UploadFile({ file: imageFile });
      image_url = res.file_url;
      message_type = "image";
    }
    if (attachedFile) {
      const res = await base44.integrations.Core.UploadFile({ file: attachedFile });
      file_url = res.file_url;
      file_name = attachedFile.name;
      message_type = "file";
    }

    onSend({ content: text.trim(), image_url, file_url, file_name, message_type });
    setText("");
    setImageFile(null);
    setImagePreview(null);
    setAttachedFile(null);
    setSending(false);
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
    }
  };

  const handleVoiceSend = (voice_url, voice_duration) => {
    onSend({ content: "", voice_url, voice_duration, message_type: "voice" });
  };

  const hasContent = text.trim() || imageFile || attachedFile;

  return (
    <div className="bg-card/95 backdrop-blur-sm border-t border-border/50 flex-shrink-0" style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 8px)" }}>
      {/* Preview strip */}
      {(imagePreview || attachedFile) && (
        <div className="px-4 pt-2 flex items-center gap-2">
          {imagePreview && (
            <div className="relative">
              <img src={imagePreview} alt="" className="h-16 w-16 object-cover rounded-xl" />
              <button
                onClick={() => { setImageFile(null); setImagePreview(null); }}
                className="absolute -top-1.5 -right-1.5 bg-destructive w-5 h-5 rounded-full flex items-center justify-center text-white shadow"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          {attachedFile && (
            <div className="flex items-center gap-2 bg-muted rounded-xl px-3 py-2">
              <Paperclip className="w-4 h-4 text-primary" />
              <span className="text-xs truncate max-w-[150px]">{attachedFile.name}</span>
              <button onClick={() => setAttachedFile(null)}>
                <X className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            </div>
          )}
        </div>
      )}

      <div className="flex items-end gap-1.5 px-3 py-2">
        <input ref={imageInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => {
          const file = e.target.files[0];
          if (!file) return;
          setImageFile(file);
          setImagePreview(URL.createObjectURL(file));
          e.target.value = "";
        }} />
        <input ref={fileInputRef} type="file" className="hidden" onChange={(e) => {
          const file = e.target.files[0];
          if (!file) return;
          setAttachedFile(file);
          e.target.value = "";
        }} />

        <button onClick={() => imageInputRef.current?.click()} className="w-10 h-10 flex items-center justify-center text-muted-foreground hover:text-primary transition-colors flex-shrink-0">
          <Image className="w-5 h-5" />
        </button>
        <button onClick={() => fileInputRef.current?.click()} className="w-10 h-10 flex items-center justify-center text-muted-foreground hover:text-primary transition-colors flex-shrink-0">
          <Paperclip className="w-5 h-5" />
        </button>

        <div className="flex-1 bg-muted/80 rounded-2xl px-4 py-2.5 min-h-[44px] flex items-center">
          <textarea
            ref={inputRef}
            value={text}
            onChange={handleTextChange}
            placeholder="Mesajınız..."
            rows={1}
            className="w-full bg-transparent outline-none border-0 resize-none text-sm text-foreground placeholder:text-muted-foreground leading-relaxed"
            style={{ fontSize: "16px", maxHeight: "120px" }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendText();
              }
            }}
          />
        </div>

        {hasContent ? (
          <button
            onClick={handleSendText}
            disabled={sending}
            className="w-11 h-11 rounded-full bg-primary flex items-center justify-center text-primary-foreground disabled:opacity-40 flex-shrink-0 shadow-md active:scale-95 transition-all"
          >
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        ) : (
          <VoiceRecorder onSend={handleVoiceSend} />
        )}
      </div>
    </div>
  );
}