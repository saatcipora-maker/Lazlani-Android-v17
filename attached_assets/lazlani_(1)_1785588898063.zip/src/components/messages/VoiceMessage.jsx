import { useState, useRef } from "react";
import { Play, Pause } from "lucide-react";

export default function VoiceMessage({ url, duration, isMine }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef(null);

  const toggle = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio(url);
      audioRef.current.addEventListener("timeupdate", () => {
        setProgress((audioRef.current.currentTime / audioRef.current.duration) * 100 || 0);
      });
      audioRef.current.addEventListener("ended", () => {
        setPlaying(false);
        setProgress(0);
      });
    }
    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setPlaying(!playing);
  };

  const formatTime = (s) => {
    if (!s) return "0:00";
    return `${Math.floor(s / 60)}:${String(Math.round(s) % 60).padStart(2, "0")}`;
  };

  return (
    <div className="flex items-center gap-2.5 min-w-[180px]">
      <button
        onClick={toggle}
        className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${
          isMine ? "bg-white/20" : "bg-primary/10"
        }`}
      >
        {playing ? (
          <Pause className={`w-4 h-4 ${isMine ? "text-white" : "text-primary"}`} />
        ) : (
          <Play className={`w-4 h-4 ${isMine ? "text-white" : "text-primary"}`} />
        )}
      </button>
      <div className="flex-1 flex flex-col gap-1">
        <div className="h-1 rounded-full bg-black/10 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${isMine ? "bg-white/60" : "bg-primary/60"}`}
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className={`text-[10px] ${isMine ? "text-white/70" : "text-muted-foreground"}`}>
          {formatTime(duration)}
        </span>
      </div>
    </div>
  );
}