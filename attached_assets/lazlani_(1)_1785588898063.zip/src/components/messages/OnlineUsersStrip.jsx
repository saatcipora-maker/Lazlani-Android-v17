import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

export default function OnlineUsersStrip({ onlineMap = {}, onSelect }) {
  const { user } = useAuth();

  const { data: users = [] } = useQuery({
    queryKey: ["online-strip-users"],
    queryFn: () => base44.entities.User.list("-created_date", 50),
    staleTime: 60000,
  });

  const onlineUsers = users.filter(u => u.email !== user?.email && onlineMap[u.email]);

  if (onlineUsers.length === 0) return null;

  return (
    <div className="px-4 pb-2">
      <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Çevrimiçi</p>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
        {onlineUsers.map(u => (
          <button
            key={u.email}
            onClick={() => onSelect({ email: u.email, name: u.full_name || u.email })}
            className="flex flex-col items-center gap-1 flex-shrink-0 active:scale-95 transition-transform"
            style={{ minWidth: "56px", minHeight: "auto" }}
          >
            <div className="relative">
              <div className="w-12 h-12 rounded-full flex items-center justify-center overflow-hidden" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.15), rgba(240,140,60,0.08))", border: "2px solid rgba(130,60,210,0.2)" }}>
                {u.avatar_url ? (
                  <img src={u.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm font-bold text-primary">{(u.full_name || u.email)[0]?.toUpperCase()}</span>
                )}
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-background" style={{ background: "#22c55e" }} />
            </div>
            <span className="text-[10px] text-foreground/70 truncate w-full text-center">{(u.full_name || u.email).split(" ")[0]}</span>
          </button>
        ))}
      </div>
    </div>
  );
}