import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Trophy, Medal, X, Crown } from "lucide-react";
import { useState, useEffect } from "react";

const MEDALS = ["🥇", "🥈", "🥉"];

export default function TournamentLeaderboard({ tournament, onClose }) {
  const [timeLeft, setTimeLeft] = useState("");

  const { data: scores = [] } = useQuery({
    queryKey: ["tournament-scores", tournament.id],
    queryFn: () => base44.entities.TournamentScore.filter({ tournament_id: tournament.id }, "-score", 50),
    refetchInterval: 3000,
  });

  // Real-time subscribe
  useEffect(() => {
    const unsub = base44.entities.TournamentScore.subscribe(() => {});
    return unsub;
  }, []);

  useEffect(() => {
    if (tournament.status !== "active") return;
    const tick = () => {
      const end = new Date(tournament.end_time).getTime();
      const diff = Math.max(0, end - Date.now());
      if (diff <= 0) {
        setTimeLeft("Bitti!");
        return;
      }
      const m = Math.floor(diff / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTimeLeft(`${m}:${s.toString().padStart(2, "0")}`);
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => clearInterval(iv);
  }, [tournament]);

  const isFinished = tournament.status === "finished";

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60" onClick={onClose}>
      <div
        className="w-full max-w-md max-h-[80vh] bg-gradient-to-b from-gray-900 to-gray-800 rounded-t-3xl sm:rounded-3xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-amber-600 to-orange-500 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-white" />
            <div>
              <h2 className="text-white font-bold text-base">{tournament.title}</h2>
              <p className="text-white/80 text-xs">
                {isFinished ? "Turnuva sona erdi" : `Kalan: ${timeLeft}`}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Winner highlight */}
        {isFinished && tournament.winner_name && (
          <div className="mx-4 mt-3 p-3 rounded-xl bg-gradient-to-r from-yellow-500/20 to-amber-500/20 border border-yellow-500/30 flex items-center gap-3">
            <Crown className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-yellow-400 text-xs font-semibold">🎉 Kazanan</p>
              <p className="text-white font-bold">{tournament.winner_name}</p>
              <p className="text-yellow-300/80 text-xs">{tournament.winner_score} puan</p>
            </div>
          </div>
        )}

        {/* Scores */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {scores.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">Henüz katılımcı yok</p>
          ) : (
            scores.map((s, i) => (
              <div
                key={s.id}
                className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                  i === 0 ? "bg-yellow-500/20 border border-yellow-500/30" :
                  i === 1 ? "bg-gray-500/20 border border-gray-500/30" :
                  i === 2 ? "bg-amber-700/20 border border-amber-700/30" :
                  "bg-white/5 border border-white/10"
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-lg flex-shrink-0">
                  {i < 3 ? MEDALS[i] : <span className="text-gray-500 text-sm font-bold">{i + 1}</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-semibold text-sm truncate">{s.user_name || s.user_email?.split("@")[0]}</p>
                  <p className="text-gray-400 text-[11px]">{s.matches_completed} eşleşme • x{s.best_combo} kombo</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-amber-400 font-bold text-lg">{s.score}</p>
                  <p className="text-gray-500 text-[10px]">puan</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}