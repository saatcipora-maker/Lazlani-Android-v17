import { useState, useEffect } from "react";
import { Trophy, Clock, Users, Play } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TournamentBanner({ tournament, currentUser, onJoin, onView }) {
  const [timeLeft, setTimeLeft] = useState("");

  useEffect(() => {
    if (tournament.status !== "active") return;
    const tick = () => {
      const end = new Date(tournament.end_time).getTime();
      const diff = Math.max(0, end - Date.now());
      const m = Math.floor(diff / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTimeLeft(`${m}:${s.toString().padStart(2, "0")}`);
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => clearInterval(iv);
  }, [tournament]);

  if (tournament.status === "finished") return null;

  return (
    <div className="mx-2 mb-2 p-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg animate-pulse-slow">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Trophy className="w-5 h-5 flex-shrink-0" />
          <div className="min-w-0">
            <p className="font-bold text-sm truncate">{tournament.title}</p>
            <div className="flex items-center gap-2 text-xs opacity-90">
              {tournament.status === "active" && (
                <>
                  <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" />{timeLeft}</span>
                  <span className="flex items-center gap-0.5"><Users className="w-3 h-3" />{tournament.participant_count}</span>
                </>
              )}
              {tournament.status === "waiting" && <span>Başlamayı bekliyor...</span>}
            </div>
          </div>
        </div>
        <div className="flex gap-1.5 flex-shrink-0">
          <Button
            size="sm"
            onClick={onView}
            className="h-8 bg-white/20 hover:bg-white/30 text-white text-xs"
          >
            Skor
          </Button>
          {tournament.status === "active" && (
            <Button
              size="sm"
              onClick={onJoin}
              className="h-8 bg-white text-orange-600 hover:bg-white/90 text-xs font-bold"
            >
              <Play className="w-3 h-3 mr-1" />Katıl
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}