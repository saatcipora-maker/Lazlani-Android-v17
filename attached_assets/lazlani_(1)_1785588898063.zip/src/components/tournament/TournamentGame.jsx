import { useState, useEffect, useCallback } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { generateChapter, getComboMultiplier } from "@/lib/gameData";
import GameBoard from "@/components/game/GameBoard";
import { motion } from "framer-motion";
import { ArrowLeft, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TournamentGame({ tournament, currentUser, onClose }) {
  const [chapter, setChapter] = useState(null);
  const [totalScore, setTotalScore] = useState(0);
  const [totalMatches, setTotalMatches] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [roundCount, setRoundCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const queryClient = useQueryClient();

  // Get existing score entry
  const { data: existingScores = [] } = useQuery({
    queryKey: ["my-tournament-score", tournament.id, currentUser?.email],
    queryFn: () => base44.entities.TournamentScore.filter({ tournament_id: tournament.id, user_email: currentUser.email }),
    enabled: !!currentUser?.email,
  });

  const scoreEntry = existingScores[0];

  // Load accumulated score
  useEffect(() => {
    if (scoreEntry) {
      setTotalScore(scoreEntry.score || 0);
      setTotalMatches(scoreEntry.matches_completed || 0);
      setBestCombo(scoreEntry.best_combo || 0);
    }
  }, [scoreEntry]);

  // Generate chapter
  useEffect(() => {
    setChapter(generateChapter(tournament.chapter_num));
  }, [tournament.chapter_num, roundCount]);

  // Check if tournament ended
  useEffect(() => {
    const check = () => {
      const end = new Date(tournament.end_time).getTime();
      if (Date.now() >= end) {
        setFinished(true);
      }
    };
    check();
    const iv = setInterval(check, 2000);
    return () => clearInterval(iv);
  }, [tournament.end_time]);

  const updateScore = useMutation({
    mutationFn: async (data) => {
      if (scoreEntry) {
        return base44.entities.TournamentScore.update(scoreEntry.id, data);
      } else {
        // Also increment participant count
        await base44.entities.Tournament.update(tournament.id, {
          participant_count: (tournament.participant_count || 0) + 1,
        });
        return base44.entities.TournamentScore.create({
          tournament_id: tournament.id,
          user_email: currentUser.email,
          user_name: currentUser.full_name || currentUser.email.split("@")[0],
          ...data,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-tournament-score", tournament.id] });
      queryClient.invalidateQueries({ queryKey: ["tournament-scores", tournament.id] });
    },
  });

  const handleMatchComplete = useCallback(({ combo, multiplier }) => {
    if (finished) return;
    const roundScore = (chapter.matchCount * 10 + combo * 5) * multiplier;
    const newTotal = totalScore + roundScore;
    const newMatches = totalMatches + chapter.matchCount;
    const newBestCombo = Math.max(bestCombo, combo);

    setTotalScore(newTotal);
    setTotalMatches(newMatches);
    setBestCombo(newBestCombo);

    updateScore.mutate({
      score: newTotal,
      matches_completed: newMatches,
      best_combo: newBestCombo,
    });

    // Auto restart next round after brief delay
    setTimeout(() => {
      if (!finished) setRoundCount((r) => r + 1);
    }, 1200);
  }, [chapter, totalScore, totalMatches, bestCombo, finished]);

  const handleGameOver = useCallback(() => {
    // Just restart the round
    if (!finished) {
      setTimeout(() => setRoundCount((r) => r + 1), 800);
    }
  }, [finished]);

  if (!chapter) return null;

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-green-900 to-emerald-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-black/30 flex-shrink-0">
        <button onClick={onClose} className="flex items-center gap-1 text-white/80 text-sm" style={{ minWidth: "auto" }}>
          <ArrowLeft className="w-4 h-4" />
          Çık
        </button>
        <div className="flex items-center gap-2">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span className="text-amber-400 font-bold text-lg">{totalScore}</span>
          <span className="text-white/50 text-xs">puan</span>
        </div>
        <TournamentTimer endTime={tournament.end_time} onEnd={() => setFinished(true)} />
      </div>

      {finished ? (
        <div className="flex-1 flex flex-col items-center justify-center gap-4 px-6">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-6xl">🏆</motion.div>
          <h2 className="text-white text-2xl font-black">Süre Doldu!</h2>
          <p className="text-white/70 text-center">Toplam skorun: <span className="text-amber-400 font-bold">{totalScore}</span> puan</p>
          <p className="text-white/50 text-sm">{totalMatches} eşleşme • x{bestCombo} en iyi kombo</p>
          <Button onClick={onClose} className="mt-4 bg-amber-500 hover:bg-amber-600 text-white font-bold">
            Sonuçlara Bak
          </Button>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto flex flex-col items-center py-4 px-3">
          <GameBoard
            chapter={chapter}
            profile={{}}
            onMatchComplete={handleMatchComplete}
            onGameOver={handleGameOver}
            onUsepower={() => {}}
          />
        </div>
      )}
    </div>
  );
}

function TournamentTimer({ endTime, onEnd }) {
  const [left, setLeft] = useState("");

  useEffect(() => {
    const tick = () => {
      const diff = Math.max(0, new Date(endTime).getTime() - Date.now());
      if (diff <= 0) {
        setLeft("0:00");
        onEnd?.();
        return;
      }
      const m = Math.floor(diff / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setLeft(`${m}:${s.toString().padStart(2, "0")}`);
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => clearInterval(iv);
  }, [endTime]);

  const diff = new Date(endTime).getTime() - Date.now();
  const urgent = diff < 30000 && diff > 0;

  return (
    <div className={`px-2 py-1 rounded-lg text-sm font-bold ${urgent ? "bg-red-500 text-white animate-pulse" : "bg-white/20 text-white"}`}>
      ⏱ {left}
    </div>
  );
}