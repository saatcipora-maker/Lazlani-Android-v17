import { useState } from "react";
import { Trophy, X, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import NativeSelect from "@/components/ui/native-select";

export default function StartTournamentModal({ onStart, onClose }) {
  const [title, setTitle] = useState("Kuş Eşleştirme Turnuvası");
  const [duration, setDuration] = useState("5");
  const [chapter, setChapter] = useState("5");

  const handleSubmit = () => {
    if (!title.trim()) return;
    onStart({
      title: title.trim(),
      duration_minutes: parseInt(duration),
      chapter_num: parseInt(chapter),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4" onClick={onClose}>
      <div className="w-full max-w-sm bg-white rounded-2xl p-5 space-y-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <h2 className="font-bold text-lg text-gray-900">Turnuva Başlat</h2>
          </div>
          <button onClick={onClose} className="w-11 h-11 rounded-full hover:bg-gray-100 flex items-center justify-center">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-600 mb-1 block">Turnuva Adı</label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Turnuva adı..." />
          </div>

          <div>
            <label className="text-xs font-medium text-gray-600 mb-1 block">Süre</label>
            <NativeSelect
              value={duration}
              onChange={setDuration}
              title="Süre Seç"
              placeholder="Süre"
              options={[
                { value: "3", label: "3 dakika" },
                { value: "5", label: "5 dakika" },
                { value: "10", label: "10 dakika" },
                { value: "15", label: "15 dakika" },
              ]}
            />
          </div>

          <div>
            <label className="text-xs font-medium text-gray-600 mb-1 block">Zorluk (Bölüm)</label>
            <NativeSelect
              value={chapter}
              onChange={setChapter}
              title="Zorluk Seç"
              placeholder="Zorluk"
              options={[
                { value: "3", label: "Kolay (Bölüm 3)" },
                { value: "5", label: "Orta (Bölüm 5)" },
                { value: "8", label: "Zor (Bölüm 8)" },
                { value: "12", label: "Çok Zor (Bölüm 12)" },
              ]}
            />
          </div>
        </div>

        <Button onClick={handleSubmit} className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold">
          <Zap className="w-4 h-4 mr-2" />
          Turnuvayı Başlat!
        </Button>
      </div>
    </div>
  );
}