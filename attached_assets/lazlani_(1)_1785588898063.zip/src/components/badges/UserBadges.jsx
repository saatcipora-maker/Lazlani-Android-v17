import { PenTool, BookOpen, Crown, Award, Star, Sparkles } from "lucide-react";

/**
 * Displays user badge pills. Takes manual badges (from User entity)
 * and auto badges (from useAutoBadges).
 */
export default function UserBadges({ manualBadges = {}, autoBadges = {}, size = "sm" }) {
  const badges = [];

  // Manual badges (admin-granted)
  if (manualBadges.has_ozel_badge) {
    badges.push({ key: "ozel", label: "Özel", icon: Sparkles, colors: "text-purple-700 bg-purple-100 border-purple-300" });
  }
  if (manualBadges.has_vip) {
    badges.push({ key: "vip", label: "VIP", icon: Crown, colors: "text-blue-700 bg-blue-100 border-blue-300" });
  }
  if (manualBadges.has_author_badge) {
    badges.push({ key: "author_badge", label: "Yazar ✓", icon: Award, colors: "text-primary bg-primary/10 border-primary/30" });
  }
  if (manualBadges.has_magazin_badge) {
    badges.push({ key: "magazin", label: "Magazin", icon: Star, colors: "text-[#9C2A2A] bg-red-50 border-red-200" });
  }

  // Auto badges (activity-based)
  if (autoBadges.is_author && !manualBadges.has_author_badge) {
    badges.push({ key: "auto_author", label: "Yazar", icon: PenTool, colors: "text-emerald-700 bg-emerald-50 border-emerald-200" });
  }
  if (autoBadges.is_active_reader) {
    badges.push({ key: "active_reader", label: "Okur", icon: BookOpen, colors: "text-amber-700 bg-amber-50 border-amber-200" });
  }

  if (badges.length === 0) return null;

  const textSize = size === "xs" ? "text-[11px]" : "text-[11px]";
  const iconSize = size === "xs" ? "w-2.5 h-2.5" : "w-3 h-3";
  const padding = size === "xs" ? "px-1.5 py-0" : "px-2 py-0.5";

  return (
    <span className="inline-flex items-center gap-1 flex-wrap">
      {badges.map((b) => (
        <span
          key={b.key}
          className={`inline-flex items-center gap-0.5 ${textSize} font-bold ${b.colors} border ${padding} rounded-full`}
        >
          <b.icon className={iconSize} />
          {b.label}
        </span>
      ))}
    </span>
  );
}