import { useRef, useMemo, lazy, Suspense } from "react";

const ReactQuill = lazy(() => import("react-quill"));

const TOOLBAR_OPTIONS = [
  [{ header: [1, 2, 3, false] }],
  ["bold", "italic", "underline", "strike"],
  [{ list: "ordered" }, { list: "bullet" }],
  [{ align: [] }],
  ["blockquote", "link"],
  [{ color: [] }, { background: [] }],
  ["clean"],
];

const FORMATS = [
  "header",
  "bold", "italic", "underline", "strike",
  "list", "bullet",
  "align",
  "blockquote", "link",
  "color", "background",
  "clean",
];

export default function RichTextEditor({ value, onChange, placeholder, className = "" }) {
  const quillRef = useRef(null);

  const modules = useMemo(() => ({
    toolbar: TOOLBAR_OPTIONS,
  }), []);

  return (
    <div className={`rich-editor ${className}`}>
      <Suspense fallback={<div className="h-[200px] flex items-center justify-center text-sm text-muted-foreground">Editör yükleniyor...</div>}>
        <ReactQuill
          ref={quillRef}
          theme="snow"
          value={value}
          onChange={onChange}
          modules={modules}
          formats={FORMATS}
          placeholder={placeholder}
        />
      </Suspense>
    </div>
  );
}