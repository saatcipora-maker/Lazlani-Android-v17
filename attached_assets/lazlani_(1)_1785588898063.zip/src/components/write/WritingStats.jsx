import { useMemo } from "react";
import { Type, Hash, Clock } from "lucide-react";

export default function WritingStats({ content }) {
  const stats = useMemo(() => {
    const text = content
      ? content
          .replace(/<[^>]*>/g, " ")
          .replace(/&nbsp;/g, " ")
          .replace(/&[a-z]+;/g, " ")
          .trim()
      : "";
    const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
    const chars = text.length;
    const readingTime = words > 0 ? Math.max(1, Math.ceil(words / 200)) : 0;
    return { words, chars, readingTime };
  }, [content]);

  return (
    <div className="flex items-center gap-4 px-3 py-2 rounded-xl glass-card text-xs text-muted-foreground">
      <span className="flex items-center gap-1.5">
        <Type className="w-3.5 h-3.5 text-primary" />
        <span className="font-semibold text-foreground">{stats.words.toLocaleString("tr-TR")}</span> kelime
      </span>
      <span className="flex items-center gap-1.5">
        <Hash className="w-3.5 h-3.5 text-primary" />
        <span className="font-semibold text-foreground">{stats.chars.toLocaleString("tr-TR")}</span> karakter
      </span>
      <span className="flex items-center gap-1.5">
        <Clock className="w-3.5 h-3.5 text-primary" />
        ~<span className="font-semibold text-foreground">{stats.readingTime}</span> dk okuma
      </span>
    </div>
  );
}