import { useState, useEffect, useRef, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Save, Eye, Upload, X, Maximize2, CheckCircle2, Clock } from "lucide-react";
import { toast } from "sonner";
import RichTextEditor from "./RichTextEditor";
import WritingStats from "./WritingStats";
import sanitizeHtml from "@/lib/sanitizeHtml";

export default function ChapterForm({ bookId, chapter, nextOrder, onSuccess, bookTitle, currentUser }) {
  const [form, setForm] = useState({
    title: chapter?.title || "",
    content: chapter?.content || "",
    status: chapter?.status || "taslak",
    image_url: chapter?.image_url || "",
    scheduled_date: chapter?.scheduled_date || "",
  });
  const [showSchedule, setShowSchedule] = useState(!!chapter?.scheduled_date);
  const [uploading, setUploading] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [autosaveStatus, setAutosaveStatus] = useState(null); // null | "saving" | "saved"
  const autosaveTimerRef = useRef(null);
  const lastSavedRef = useRef(JSON.stringify({ title: form.title, content: form.content }));
  const queryClient = useQueryClient();

  // Autosave: save as draft every 15 seconds if content changed
  const autosave = useCallback(async () => {
    if (!chapter) return; // only autosave existing chapters
    const current = JSON.stringify({ title: form.title, content: form.content });
    if (current === lastSavedRef.current) return;
    setAutosaveStatus("saving");
    await base44.entities.Chapter.update(chapter.id, {
      title: form.title,
      content: form.content,
    });
    lastSavedRef.current = current;
    setAutosaveStatus("saved");
    setTimeout(() => setAutosaveStatus(null), 2000);
  }, [chapter, form.title, form.content]);

  useEffect(() => {
    if (!chapter) return;
    clearTimeout(autosaveTimerRef.current);
    autosaveTimerRef.current = setTimeout(autosave, 15000);
    return () => clearTimeout(autosaveTimerRef.current);
  }, [form.title, form.content, autosave]);

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((prev) => ({ ...prev, image_url: file_url }));
    setUploading(false);
  };

  const saveMutation = useMutation({
    mutationFn: async (publishStatus) => {
      const data = { ...form, status: publishStatus };
      if (chapter) {
        return base44.entities.Chapter.update(chapter.id, data);
      } else {
        const savedChapter = await base44.entities.Chapter.create({
          ...data,
          book_id: bookId,
          order: nextOrder,
        });
        if (publishStatus === "yayinda" && currentUser) {
          // Notify followers + saved book users
          const [follows, savedBooks] = await Promise.all([
            base44.entities.Follow.filter({ following_email: currentUser.email }, "-created_date", 500),
            base44.entities.SavedBook.filter({ book_id: bookId }, "-created_date", 500),
          ]);
          const recipientSet = new Set();
          [...follows.map(f => f.follower_email), ...savedBooks.map(s => s.user_email)]
            .filter(email => email !== currentUser.email)
            .forEach(email => recipientSet.add(email));
          
          await Promise.all(
            [...recipientSet].map((email) =>
              base44.entities.Notification.create({
                receiver_email: email,
                sender_name: currentUser.full_name,
                sender_email: currentUser.email,
                type: "new_chapter",
                message: `"${bookTitle || "Kitap"}" adlı kitaba yeni bölüm eklendi: "${form.title}"`,
                book_id: bookId,
                is_read: false,
              })
            )
          );
        }
        return savedChapter;
      }
    },
    onMutate: async (publishStatus) => {
      await queryClient.cancelQueries({ queryKey: ["chapters", bookId] });
      const prevChapters = queryClient.getQueryData(["chapters", bookId]) || [];
      if (chapter) {
        queryClient.setQueryData(["chapters", bookId], prevChapters.map(c => c.id === chapter.id ? { ...c, ...form, status: publishStatus } : c));
      } else {
        queryClient.setQueryData(["chapters", bookId], [...prevChapters, { ...form, id: "__temp__", status: publishStatus }]);
      }
      return { prevChapters };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prevChapters) queryClient.setQueryData(["chapters", bookId], ctx.prevChapters);
      toast.error("Hata: Bölüm kaydedilemedi");
    },
    onSettled: (data, error, publishStatus) => {
      queryClient.invalidateQueries({ queryKey: ["chapters", bookId] });
      queryClient.invalidateQueries({ queryKey: ["scheduled-chapters", bookId] });
      if (!error) {
        const msg = publishStatus === "yayinda" ? "Bölüm yayınlandı" :
          publishStatus === "zamanlanmis" ? "Bölüm zamanlandı!" : "Taslağa kaydedildi";
        toast.success(msg);
        onSuccess?.();
      }
    },
  });

  const handleSave = async (publishStatus) => {
    if (!form.title.trim() || !form.content.trim()) {
      toast.error("Başlık ve içerik gerekli");
      return;
    }
    if (publishStatus === "zamanlanmis" && !form.scheduled_date) {
      toast.error("Lütfen bir yayın tarihi seçin");
      return;
    }
    if (publishStatus === "zamanlanmis" && new Date(form.scheduled_date) <= new Date()) {
      toast.error("Yayın tarihi gelecekte olmalıdır");
      return;
    }
    saveMutation.mutate(publishStatus);
  };

  return (
    <>
      {/* Fullscreen editor overlay - keyboard friendly */}
      {fullscreen && (
        <div
          className="fixed inset-0 z-50 bg-background flex flex-col"
          style={{ paddingTop: "env(safe-area-inset-top)", paddingBottom: "env(safe-area-inset-bottom)" }}
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-border flex-shrink-0">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{form.title || "İçerik"}</p>
              {autosaveStatus === "saving" && (
                <span className="text-[10px] text-muted-foreground flex items-center gap-1 flex-shrink-0">
                  <Loader2 className="w-3 h-3 animate-spin" />
                </span>
              )}
              {autosaveStatus === "saved" && (
                <span className="text-[10px] text-green-600 flex items-center gap-1 flex-shrink-0">
                  <CheckCircle2 className="w-3 h-3" />
                </span>
              )}
            </div>
            <div className="flex gap-2 ml-2">
              <Button size="sm" variant="outline" className="rounded-full h-8 text-xs px-3" onClick={() => { setFullscreen(false); handleSave("taslak"); }} disabled={saveMutation.isPending}>
                <Save className="w-3 h-3 mr-1" /> Kaydet
              </Button>
              <Button size="sm" className="rounded-full h-8 text-xs px-3" onClick={() => { setFullscreen(false); handleSave("yayinda"); }} disabled={saveMutation.isPending}>
                <Eye className="w-3 h-3 mr-1" /> Yayınla
              </Button>
              <button onClick={() => setFullscreen(false)} className="text-muted-foreground p-1 ml-1">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            <RichTextEditor
              value={form.content}
              onChange={(val) => setForm((prev) => ({ ...prev, content: val }))}
              placeholder="Bölüm içeriğinizi buraya yazın..."
              className="h-full [&_.ql-container]:border-0 [&_.ql-editor]:min-h-[300px] [&_.ql-editor]:text-base [&_.ql-editor]:leading-8 [&_.ql-toolbar]:border-x-0 [&_.ql-toolbar]:border-t-0"
            />
          </div>
        </div>
      )}

      {/* Preview overlay */}
      {showPreview && (
        <div
          className="fixed inset-0 z-50 bg-background flex flex-col"
          style={{ paddingTop: "env(safe-area-inset-top)", paddingBottom: "env(safe-area-inset-bottom)" }}
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-border flex-shrink-0">
            <p className="text-sm font-semibold text-foreground">Önizleme</p>
            <button onClick={() => setShowPreview(false)} className="text-muted-foreground p-1" style={{ minHeight: "auto", minWidth: "auto" }}>
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-5 py-6">
            <h2 className="font-display text-xl font-bold mb-6 text-foreground">{form.title || "Başlıksız"}</h2>
            {form.content ? (
              <div
                className="prose prose-sm max-w-none text-foreground"
                dangerouslySetInnerHTML={{ __html: sanitizeHtml(form.content) }}
              />
            ) : (
              <p className="text-muted-foreground text-sm">Henüz içerik yok</p>
            )}
          </div>
        </div>
      )}

      <div className="space-y-4">
        {/* Chapter image upload - horizontal banner */}
        <div>
          <Label className="text-xs">Bölüm Görseli (yatay)</Label>
          <div className="mt-1">
            {form.image_url ? (
              <div className="relative">
                <img src={form.image_url} alt="bölüm görseli" className="w-full h-28 object-cover rounded-xl" />
                <button
                  onClick={() => setForm((prev) => ({ ...prev, image_url: "" }))}
                  className="absolute top-2 right-2 bg-black/50 rounded-full p-1 text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <label className="flex items-center gap-2 w-full h-16 border border-dashed border-border rounded-xl cursor-pointer hover:bg-muted/50 justify-center text-muted-foreground text-xs transition-colors">
                <Upload className="w-4 h-4" />
                {uploading ? "Yükleniyor..." : "Yatay görsel ekle"}
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
            )}
          </div>
        </div>

        <div>
          <Label>Bölüm Başlığı</Label>
          <Input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Bölüm 1: Başlangıç"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <Label>İçerik</Label>
            <div className="flex items-center gap-3">
              {autosaveStatus === "saving" && (
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" /> Kaydediliyor...
                </span>
              )}
              {autosaveStatus === "saved" && (
                <span className="text-[10px] text-green-600 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Kaydedildi
                </span>
              )}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setShowPreview(true)}
                  className="text-xs text-primary flex items-center gap-1 hover:underline"
                >
                  <Eye className="w-3 h-3" />
                  Önizle
                </button>
                <button
                  type="button"
                  onClick={() => setFullscreen(true)}
                  className="text-xs text-primary flex items-center gap-1 hover:underline"
                >
                  <Maximize2 className="w-3 h-3" />
                  Tam ekran
                </button>
              </div>
            </div>
          </div>
          <RichTextEditor
            value={form.content}
            onChange={(val) => setForm((prev) => ({ ...prev, content: val }))}
            placeholder="Bölüm içeriğinizi buraya yazın..."
            className="[&_.ql-editor]:min-h-[180px]"
          />
          <WritingStats content={form.content} />
        </div>

        {/* Schedule option */}
        <div className="border border-border rounded-xl p-3 space-y-2">
          <button
            type="button"
            onClick={() => setShowSchedule(!showSchedule)}
            className="flex items-center gap-2 text-sm font-medium text-foreground w-full"
            style={{ minHeight: "auto", minWidth: "auto" }}
          >
            <Clock className="w-4 h-4 text-primary" />
            <span>İleri Tarihte Yayınla</span>
            <span className={`ml-auto text-xs transition-colors ${showSchedule ? "text-primary" : "text-muted-foreground"}`}>
              {showSchedule ? "Açık" : "Kapalı"}
            </span>
          </button>
          {showSchedule && (
            <div className="pt-1">
              <Label className="text-xs text-muted-foreground">Yayın Tarihi & Saati</Label>
              <Input
                type="datetime-local"
                value={form.scheduled_date ? form.scheduled_date.slice(0, 16) : ""}
                onChange={(e) => setForm({ ...form, scheduled_date: e.target.value ? new Date(e.target.value).toISOString() : "" })}
                min={new Date().toISOString().slice(0, 16)}
                className="mt-1"
              />
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            className="flex-1 rounded-full"
            disabled={saveMutation.isPending}
            onClick={() => handleSave("taslak")}
          >
            {saveMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            <Save className="w-4 h-4 mr-1" />
            Taslağa Kaydet
          </Button>
          {showSchedule && form.scheduled_date ? (
            <Button
              type="button"
              className="flex-1 rounded-full bg-orange-500 hover:bg-orange-600"
              disabled={saveMutation.isPending}
              onClick={() => handleSave("zamanlanmis")}
            >
              {saveMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              <Clock className="w-4 h-4 mr-1" />
              Zamanla
            </Button>
          ) : (
            <Button
              type="button"
              className="flex-1 rounded-full"
              disabled={saveMutation.isPending}
              onClick={() => handleSave("yayinda")}
            >
              {saveMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              <Eye className="w-4 h-4 mr-1" />
              Yayınla
            </Button>
          )}
        </div>
      </div>
    </>
  );
}