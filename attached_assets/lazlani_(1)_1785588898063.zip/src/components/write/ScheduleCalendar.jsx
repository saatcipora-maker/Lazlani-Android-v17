import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Calendar, Clock, BookOpen, X, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, addMonths, subMonths, isToday } from "date-fns";
import { tr } from "date-fns/locale";
import { toast } from "sonner";

const DAY_NAMES = ["Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pz"];

export default function ScheduleCalendar({ bookId, bookTitle }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState(null);
  const queryClient = useQueryClient();

  const { data: chapters = [] } = useQuery({
    queryKey: ["scheduled-chapters", bookId],
    queryFn: () => base44.entities.Chapter.filter({ book_id: bookId, status: "zamanlanmis" }, "scheduled_date", 100),
    enabled: !!bookId,
  });

  const cancelMutation = useMutation({
    mutationFn: (chapterId) => base44.entities.Chapter.update(chapterId, { status: "taslak", scheduled_date: "" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["scheduled-chapters", bookId] });
      queryClient.invalidateQueries({ queryKey: ["chapters", bookId] });
      toast.success("Zamanlama iptal edildi, bölüm taslağa alındı");
    },
  });

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Pad start to align with Monday
  const startDayOfWeek = (monthStart.getDay() + 6) % 7; // Monday = 0
  const paddedDays = Array(startDayOfWeek).fill(null).concat(days);

  const getChaptersForDay = (day) => {
    if (!day) return [];
    return chapters.filter((ch) => ch.scheduled_date && isSameDay(new Date(ch.scheduled_date), day));
  };

  const selectedChapters = selectedDay ? getChaptersForDay(selectedDay) : [];

  return (
    <div className="mt-6">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-4 h-4 text-primary" />
        <h3 className="font-semibold text-foreground text-sm">Taslak Takvimi</h3>
        {chapters.length > 0 && (
          <Badge variant="secondary" className="text-[10px]">{chapters.length} zamanlanmış</Badge>
        )}
      </div>

      {chapters.length === 0 ? (
        <div className="text-center py-8 bg-card border border-border rounded-xl">
          <Clock className="w-10 h-10 text-muted-foreground/20 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Zamanlanmış bölüm yok</p>
          <p className="text-xs text-muted-foreground mt-1">Bölüm düzenlerken "Zamanla" seçeneğini kullanın</p>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          {/* Month navigation */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} className="w-10 h-10 flex items-center justify-center text-muted-foreground hover:text-foreground">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-sm font-semibold text-foreground">
              {format(currentMonth, "MMMM yyyy", { locale: tr })}
            </span>
            <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="w-10 h-10 flex items-center justify-center text-muted-foreground hover:text-foreground">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Day names */}
          <div className="grid grid-cols-7 border-b border-border">
            {DAY_NAMES.map((d) => (
              <div key={d} className="text-center text-[10px] font-medium text-muted-foreground py-2">{d}</div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7">
            {paddedDays.map((day, i) => {
              const dayChapters = getChaptersForDay(day);
              const hasScheduled = dayChapters.length > 0;
              const isSelected = selectedDay && day && isSameDay(day, selectedDay);

              return (
                <button
                  key={i}
                  onClick={() => day && setSelectedDay(isSelected ? null : day)}
                  disabled={!day}
                  className={`aspect-square flex flex-col items-center justify-center text-xs relative transition-colors ${
                    !day ? "" :
                    isSelected ? "bg-primary/10 text-primary font-bold" :
                    isToday(day) ? "bg-accent font-semibold text-foreground" :
                    "text-foreground hover:bg-muted"
                  }`}
                  
                >
                  {day && (
                    <>
                      <span>{format(day, "d")}</span>
                      {hasScheduled && (
                        <span className="absolute bottom-1 w-1.5 h-1.5 rounded-full bg-primary" />
                      )}
                    </>
                  )}
                </button>
              );
            })}
          </div>

          {/* Selected day detail */}
          {selectedDay && (
            <div className="border-t border-border px-4 py-3 space-y-2">
              <p className="text-xs font-medium text-muted-foreground">
                {format(selectedDay, "d MMMM yyyy, EEEE", { locale: tr })}
              </p>
              {selectedChapters.length === 0 ? (
                <p className="text-xs text-muted-foreground">Bu gün için zamanlanmış bölüm yok</p>
              ) : (
                selectedChapters.map((ch) => (
                  <div key={ch.id} className="flex items-center gap-2 p-2 rounded-lg bg-muted">
                    <BookOpen className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{ch.title}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {ch.scheduled_date ? format(new Date(ch.scheduled_date), "HH:mm", { locale: tr }) : ""}
                      </p>
                    </div>
                    <button
                      onClick={() => cancelMutation.mutate(ch.id)}
                      className="p-1 text-destructive hover:bg-destructive/10 rounded"
                      title="Zamanlamayı iptal et"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}