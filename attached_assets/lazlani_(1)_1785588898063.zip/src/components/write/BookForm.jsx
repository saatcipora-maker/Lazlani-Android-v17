import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import NativeSelect from "@/components/ui/native-select";
import { Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import { containsProfanity } from "@/utils/profanityFilter";

const categories = [
  { value: "roman", label: "Roman" },
  { value: "romantik", label: "Romantik" },
  { value: "ormantik", label: "Ormantik" },
  { value: "fantastik", label: "Fantastik" },
  { value: "bilim_kurgu", label: "Bilim Kurgu" },
  { value: "bilim_kurgu_genc", label: "Bilim Kurgu Genç" },
  { value: "kurgu_genc", label: "Kurgu Genç" },
  { value: "edebiyat", label: "Edebiyat" },
  { value: "gerilim", label: "Gerilim / Polisiye" },
  { value: "dram", label: "Dram" },
  { value: "genc_yetiskin", label: "Genç Yetişkin" },
  { value: "macera", label: "Macera" },
  { value: "korku", label: "Korku" },
  { value: "mafya", label: "Mafya" },
  { value: "tarih", label: "Tarih" },
  { value: "klasik", label: "Klasik" },
  { value: "siir", label: "Şiir" },
  { value: "mizah", label: "Mizah / Komedi" },
  { value: "psikoloji", label: "Psikoloji" },
  { value: "kisisel_gelisim", label: "Kişisel Gelişim" },
  { value: "biyografi", label: "Biyografi / Anı" },
  { value: "felsefe", label: "Felsefe" },
  { value: "cocuk", label: "Çocuk" },
  { value: "din_maneviyat", label: "Din / Maneviyat" },
  { value: "erotik", label: "Erotik" },
  { value: "diger", label: "Diğer" },
];

export default function BookForm({ user, book, onSuccess }) {
  const [form, setForm] = useState({
    title: book?.title || "",
    description: book?.description || "",
    category: book?.category || "roman",
    cover_image: book?.cover_image || "",
  });
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const handleCoverUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((prev) => ({ ...prev, cover_image: file_url }));
    setUploading(false);
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (book) {
        return base44.entities.Book.update(book.id, form);
      } else {
        return base44.entities.Book.create({
          ...form,
          author_name: user?.full_name || "Anonim",
          author_email: user?.email,
          status: "taslak",
          is_recommended: false,
          recommendation_status: "none",
          read_count: 0,
          like_count: 0,
        });
      }
    },
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ["myBooks"] });
      const prevBooks = queryClient.getQueryData(["myBooks", user?.email]) || [];
      if (book) {
        queryClient.setQueryData(["myBooks", user?.email], prevBooks.map(b => b.id === book.id ? { ...b, ...form } : b));
      } else {
        queryClient.setQueryData(["myBooks", user?.email], [...prevBooks, { ...form, id: "__temp__" }]);
      }
      return { prevBooks };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prevBooks) queryClient.setQueryData(["myBooks", user?.email], ctx.prevBooks);
      toast.error("Hata: Değişiklik kaydedilemedi");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myBooks"] });
      toast.success(book ? "Kitap güncellendi" : "Kitap oluşturuldu");
      onSuccess?.();
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) {
      toast.error("Kitap başlığı gerekli");
      return;
    }
    
    // Küfür kontrolü
    if (containsProfanity(form.title) || containsProfanity(form.description)) {
      try {
        await base44.functions.invoke('checkProfanity', {
          content: form.title + " " + form.description,
          type: "book"
        });
      } catch (err) {
        // İçerik bloklanmış
        return;
      }
    }
    
    saveMutation.mutate();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Kitap Başlığı</Label>
        <Input
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          placeholder="Kitabınızın adı"
        />
      </div>

      <div>
        <Label>Açıklama</Label>
        <Textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Kısa bir açıklama yazın..."
          className="h-24"
        />
      </div>

      <div>
        <Label>Kategori</Label>
        <NativeSelect
          value={form.category}
          onChange={(v) => setForm({ ...form, category: v })}
          options={categories}
          title="Kategori Seç"
          placeholder="Kategori seçin"
        />
      </div>

      <div>
        <Label>Kapak Resmi</Label>
        <div className="mt-1">
          {form.cover_image && (
            <img
              src={form.cover_image}
              alt="Kapak"
              className="w-24 h-32 object-cover rounded-lg mb-2"
            />
          )}
          <label className="inline-flex items-center gap-2 px-3 py-2 bg-accent rounded-lg cursor-pointer text-sm text-accent-foreground hover:bg-accent/80 transition-colors">
            <Upload className="w-4 h-4" />
            {uploading ? "Yükleniyor..." : "Resim Seç"}
            <input type="file" accept="image/*" className="hidden" onChange={handleCoverUpload} />
          </label>
        </div>
      </div>

      <Button type="submit" className="w-full rounded-full" disabled={saveMutation.isPending || !form.category}>
        {saveMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
        {book ? "Güncelle" : "Oluştur"}
      </Button>
      {!form.category && (
        <p className="text-xs text-destructive text-center -mt-2">Kategori seçimi zorunludur</p>
      )}
    </form>
  );
}