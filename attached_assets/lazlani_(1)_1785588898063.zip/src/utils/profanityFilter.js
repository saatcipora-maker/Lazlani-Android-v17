// Türkçe küfür ve hakaret filtresi — yalnızca gerçek küfürler
const PROFANITY_LIST = [
  "orospu", "piç", "siktir", "siktirgit", "sikeyim", "sikerim", "sikik",
  "amk", "amına", "amını", "ananı", "ananızı",
  "fahişe", "sürtük", "kaltak", "kahpe",
  "göt", "götünü", "götün",
  "yarrak", "yarrağ", "yarak",
  "dalyarak", "dallama",
  "pezevenk", "gavat", "ibne",
  "gerizekalı", "mal", "salak", "aptal", "dangalak", "gerzek",
  "haysiyetsiz", "şerefsiz", "namussuz",
  "bok", "boktan", "pislik",
  "puşt", "köpek herif",
  "lan seni", "seni gidi",
  "aq", "mk", "mq", "amq",
  "s2m", "s2k", "s1k",
];

// Normalize Turkish characters and leet speak
const normalize = (text) =>
  text
    .toLowerCase()
    .replace(/ı/g, "i")
    .replace(/ö/g, "o")
    .replace(/ü/g, "u")
    .replace(/ş/g, "s")
    .replace(/ç/g, "c")
    .replace(/ğ/g, "g")
    .replace(/1/g, "i")
    .replace(/3/g, "e")
    .replace(/0/g, "o")
    .replace(/4/g, "a")
    .replace(/\$/g, "s")
    .replace(/[_.!@#*\-]/g, "");

export const containsProfanity = (text) => {
  if (!text) return false;
  const normalized = normalize(text);
  return PROFANITY_LIST.some((word) => normalized.includes(normalize(word)));
};

export const filterProfanity = (text) => {
  if (!text) return text;
  let filtered = text;
  const lowerText = text.toLowerCase();
  PROFANITY_LIST.forEach((word) => {
    const idx = lowerText.indexOf(word.toLowerCase());
    if (idx !== -1) {
      filtered = filtered.slice(0, idx) + "*".repeat(word.length) + filtered.slice(idx + word.length);
    }
  });
  return filtered;
};