import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { Suspense, lazy } from 'react';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider } from '@/lib/AuthContext';
import { NavigationProvider } from '@/lib/NavigationContext';
import { BadgeProvider } from '@/lib/BadgeContext';
import ProtectedRoute from '@/components/ProtectedRoute';
import AppLayout from '@/components/layout/AppLayout';

// Auth pages
const Login = lazy(() => import('@/pages/Login'));
const Register = lazy(() => import('@/pages/Register'));
const ForgotPassword = lazy(() => import('@/pages/ForgotPassword'));
const ResetPassword = lazy(() => import('@/pages/ResetPassword'));

const Home = lazy(() => import('@/pages/Home'));
const BookDetail = lazy(() => import('@/pages/BookDetail'));
const ReadChapter = lazy(() => import('@/pages/ReadChapter'));
const WriteBook = lazy(() => import('@/pages/WriteBook'));
const EditBook = lazy(() => import('@/pages/EditBook'));
const Profile = lazy(() => import('@/pages/Profile'));
const Search = lazy(() => import('@/pages/Search'));
const Library = lazy(() => import('@/pages/Library'));
const MyRecommendations = lazy(() => import('@/pages/MyRecommendations'));
const Notifications = lazy(() => import('@/pages/Notifications'));
const Messages = lazy(() => import('@/pages/Messages'));
const MessagesChat = lazy(() => import('@/pages/MessagesChat'));
const MessagesNew = lazy(() => import('@/pages/MessagesNew'));
const UserProfile = lazy(() => import('@/pages/UserProfile'));
const Drafts = lazy(() => import('@/pages/Drafts'));
const AdminPanel = lazy(() => import('@/pages/AdminPanel'));
const Cart = lazy(() => import('@/pages/Cart'));
const Chat = lazy(() => import('@/pages/Chat'));
const GroupChat = lazy(() => import('@/pages/GroupChat'));
const Favorites = lazy(() => import('@/pages/Favorites'));
const Community = lazy(() => import('@/pages/Community'));

const BirdMatch = lazy(() => import('@/pages/BirdMatch'));
const MatchGame = lazy(() => import('@/pages/MatchGame'));
const Subscriptions = lazy(() => import('@/pages/Subscriptions'));

const PageLoader = () => (
  <div className="fixed inset-0 flex flex-col items-center justify-center bg-background gap-4">
    <h1 className="font-heading text-2xl font-bold tracking-wider text-foreground">LAZLANİ</h1>
    <div className="w-7 h-7 border-3 border-muted border-t-primary rounded-full animate-spin"></div>
  </div>
);

const AuthenticatedApp = () => {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* Public auth routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        {/* Protected app routes */}
        <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
          <Route element={<AppLayout />}>
            <Route path="/" element={<Home />} />
            <Route path="/library" element={<Library />} />
            <Route path="/write" element={<WriteBook />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/messages" element={<Messages />}>
              <Route path="chat/:email" element={<MessagesChat />} />
              <Route path="new" element={<MessagesNew />} />
            </Route>
            <Route path="/profile" element={<Profile />} />
            <Route path="/search" element={<Search />} />
            <Route path="/my-recommendations" element={<MyRecommendations />} />
            <Route path="/book/:id" element={<BookDetail />} />
            <Route path="/read/:bookId/:chapterId" element={<ReadChapter />} />
            <Route path="/edit-book/:id" element={<EditBook />} />
            <Route path="/user/:email" element={<UserProfile />} />
            <Route path="/drafts" element={<Drafts />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/group-chat" element={<GroupChat />} />
            <Route path="/favorites" element={<Favorites />} />
            <Route path="/community" element={<Community />} />
            <Route path="/bird-match" element={<BirdMatch />} />
            <Route path="/game" element={<MatchGame />} />
            <Route path="/subscriptions" element={<Subscriptions />} />
          </Route>
        </Route>
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </Suspense>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <BadgeProvider>
          <NavigationProvider>
            <Router>
              <AuthenticatedApp />
            </Router>
          </NavigationProvider>
        </BadgeProvider>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App