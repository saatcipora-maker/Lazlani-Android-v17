import { useEffect } from "react";
import { useNavigate, Outlet } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useOnlineUsers } from "@/hooks/useOnlineStatus";
import ConversationList from "@/components/messages/ConversationList";

function makeConversationId(a, b) {
  return [a, b].sort().join("__");
}

export default function Messages() {
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const onlineMap = useOnlineUsers();
  const queryClient = useQueryClient();

  // Handle deep-link ?to=email&name=Name → redirect to chat route
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const to = params.get("to");
    const name = params.get("name");
    if (to) {
      navigate(
        `/messages/chat/${encodeURIComponent(to)}${name ? `?name=${encodeURIComponent(name)}` : ""}`,
        { replace: true }
      );
    }
  }, []);

  const { data: allMessages = [] } = useQuery({
    queryKey: ["messages", currentUser?.email],
    queryFn: async () => {
      const [sent, received] = await Promise.all([
        base44.entities.Message.filter({ sender_email: currentUser.email }, "-created_date", 200),
        base44.entities.Message.filter({ receiver_email: currentUser.email }, "-created_date", 200)
      ]);
      return [...sent, ...received];
    },
    enabled: !!currentUser?.email,
    staleTime: Infinity
  });

  useEffect(() => {
    if (!currentUser?.email) return;
    const unsub = base44.entities.Message.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["messages", currentUser.email] });
    });
    return unsub;
  }, [currentUser?.email]);

  // Build conversations
  const convMap = {};
  allMessages.forEach((m) => {
    if (!currentUser?.email) return;
    const otherEmail = m.sender_email === currentUser.email ? m.receiver_email : m.sender_email;
    const otherName = m.sender_email === currentUser.email ? m.receiver_name : m.sender_name;
    const cid = makeConversationId(currentUser.email, otherEmail);
    const isUnread = m.receiver_email === currentUser.email && !m.is_read;

    if (!convMap[cid]) {
      convMap[cid] = {
        email: otherEmail,
        name: otherName || otherEmail,
        lastMsg: m.content || "",
        lastMsgType: m.message_type || "text",
        lastDate: m.created_date,
        unreadCount: isUnread ? 1 : 0
      };
    } else {
      if (new Date(m.created_date) > new Date(convMap[cid].lastDate)) {
        convMap[cid].lastMsg = m.content || "";
        convMap[cid].lastMsgType = m.message_type || "text";
        convMap[cid].lastDate = m.created_date;
      }
      if (isUnread) convMap[cid].unreadCount++;
    }
  });
  const conversations = Object.values(convMap).sort((a, b) => new Date(b.lastDate) - new Date(a.lastDate));

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const handleSelectConv = (c) => {
    navigate(`/messages/chat/${encodeURIComponent(c.email)}?name=${encodeURIComponent(c.name || c.email)}`);
  };

  return (
    <>
      <ConversationList
        conversations={conversations}
        onSelect={handleSelectConv}
        onNewChat={() => navigate("/messages/new")}
        onlineMap={onlineMap}
      />
      <Outlet />
    </>
  );
}