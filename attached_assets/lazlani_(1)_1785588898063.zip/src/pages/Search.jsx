import { useState, useRef, useEffect, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PullToRefresh from "@/components/ui/PullToRefresh";
import { Input } from "@/components/ui/input";
import { Search as SearchIcon, X, BookOpen, User, Filter, TrendingUp, Star, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import BookCard from "@/components/books/BookCard";
import { Badge } from "@/components/ui/badge";

function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

const categoryLabels = {
  roman: "Roman", romantik: "Romantik", ormantik: "Ormantik", fantastik: "Fantastik",
  bilim_kurgu: "Bilim Kurgu", bilim_kurgu_genc: "Bilim Kurgu (Genç)", kurgu_genc: "Kurgu (Genç)",
  edebiyat: "Edebiyat", gerilim: "Gerilim", dram: "Dram", genc_yetiskin: "Genç Yetişkin",
  macera: "Macera", korku: "Korku", mafya: "Mafya", tarih: "Tarih", klasik: "Klasik",
  siir: "Şiir", mizah: "Mizah", psikoloji: "Psikoloji", kisisel_gelisim: "Kişisel Gelişim",
  biyografi: "Biyografi", felsefe: "Felsefe", cocuk: "Çocuk", din_maneviyat: "Din & Maneviyat",
  erotik: "Erotik", diger: "Diğer",
};

export default function Search() {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const inputRef = useRef(null);
  const queryClient = useQueryClient();

  const handleRefresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["books", "search-all"] }),
      queryClient.invalidateQueries({ queryKey: ["users", "search-all"] }),
    ]);
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const q = params.get("q");
    if (q) setQuery(q);
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  const debouncedQuery = useDebounce(query, 300);
  const q = debouncedQuery.trim().toLowerCase();
  const shouldSearch = q.length >= 2 || !!selectedCategory;

  // Explore data — lightweight, loads on mount for the discovery UI
  const { data: exploreBooks = [] } = useQuery({
    queryKey: ["books", "explore"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-read_count", 20),
    staleTime: 60000,
  });

  const { data: exploreUsers = [] } = useQuery({
    queryKey: ["users", "explore"],
    queryFn: () => base44.entities.User.list("-created_date", 20),
    staleTime: 60000,
  });

  // Full search data — only fetched when user has typed 2+ chars or selected a category
  const { data: books = [], isLoading: booksLoading } = useQuery({
    queryKey: ["books", "search-all"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-read_count", 200),
    enabled: shouldSearch,
  });

  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["users", "search-all"],
    queryFn: () => base44.entities.User.list("-created_date", 200),
    enabled: q.length >= 2,
  });

  // Keşfet verileri — from lightweight explore queries
  const trendBooks = exploreBooks.slice(0, 9);
  const newBooks = useMemo(() => [...exploreBooks].sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 9), [exploreBooks]);
  const topUsers = exploreUsers.filter(u => u.full_name).slice(0, 10);

  const filteredBooks = books.filter((b) => {
    const matchesCategory = !selectedCategory || b.category === selectedCategory;
    const matchesQuery = !q || 
      b.title?.toLowerCase().includes(q) ||
      b.author_name?.toLowerCase().includes(q) ||
      (categoryLabels[b.category] || b.category || "").toLowerCase().includes(q);
    return matchesCategory && matchesQuery;
  });

  const filteredUsers = !q ? [] : users.filter(
    (u) =>
      u.full_name?.toLowerCase().includes(q) ||
      u.email?.toLowerCase().includes(q)
  );

  const showBooks = q || selectedCategory;
  const hasResults = (showBooks && filteredBooks.length > 0) || filteredUsers.length > 0;

  return (
    <PullToRefresh onRefresh={handleRefresh} className="flex flex-col bg-background" style={{ minHeight: "calc(100svh - 64px - 64px)" }}>
      {/* Search Header */}
      <div className="sticky top-14 z-30 bg-background/95 backdrop-blur-sm border-b border-border/40 px-4 pt-4 pb-3">
        <h1 className="text-lg font-bold text-foreground mb-3">🔍 Keşfet</h1>
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Kitap, yazar veya kullanıcı ara..."
            className="pl-9 pr-9 rounded-full bg-muted border-0 h-11 text-sm"
          />
          {query && (
            <button
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              onClick={() => setQuery("")}
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-4 pb-24">
        {/* Category filter chips */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Filter className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-xs font-medium text-muted-foreground">Kategori</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {selectedCategory && (
              <button
                onClick={() => setSelectedCategory(null)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-destructive/10 text-destructive font-medium flex items-center gap-1"
              >
                <X className="w-3 h-3" /> Temizle
              </button>
            )}
            {Object.entries(categoryLabels).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setSelectedCategory(selectedCategory === key ? null : key)}
                className={`text-[11px] px-2.5 py-1 rounded-full font-medium transition-colors ${
                  selectedCategory === key
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-accent"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Keşfet - no query and no category */}
        {!shouldSearch && (
          <div className="space-y-6">
            {/* Trend Kitaplar */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-4 h-4 text-orange-500" />
                <h2 className="text-sm font-semibold text-foreground">Trend Kitaplar</h2>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {trendBooks.map((book) => (
                  <BookCard key={book.id} book={book} size="small" />
                ))}
              </div>
            </div>

            {/* Yeni Yayınlananlar */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Yeni Yayınlananlar</h2>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {newBooks.map((book) => (
                  <BookCard key={book.id} book={book} size="small" />
                ))}
              </div>
            </div>

            {/* Aktif Kullanıcılar */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Star className="w-4 h-4 text-yellow-500" />
                <h2 className="text-sm font-semibold text-foreground">Kullanıcılar</h2>
              </div>
              <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
                {topUsers.map((u) => (
                  <Link
                    key={u.id}
                    to={`/user/${encodeURIComponent(u.email)}`}
                    className="flex flex-col items-center gap-1.5 min-w-[72px]"
                  >
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden border-2 border-primary/20">
                      {u.avatar_url ? (
                        <img src={u.avatar_url} alt={u.full_name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-lg font-bold text-primary">{u.full_name?.[0]?.toUpperCase()}</span>
                      )}
                    </div>
                    <span className="text-[11px] font-medium text-foreground text-center line-clamp-1 w-full">{u.full_name}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* No results */}
        {shouldSearch && !booksLoading && !usersLoading && !hasResults && (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <BookOpen className="w-12 h-12 text-muted-foreground/30 mb-3" />
            <p className="text-sm font-medium text-muted-foreground">Sonuç bulunamadı</p>
            <p className="text-xs text-muted-foreground mt-1">
              {query ? `"${query}" için eşleşme yok` : "Bu kategoride kitap bulunamadı"}
            </p>
          </div>
        )}

        {/* Books section */}
        {showBooks && filteredBooks.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="w-4 h-4 text-primary" />
              <h2 className="text-sm font-semibold text-foreground">Kitaplar</h2>
              <span className="text-xs text-muted-foreground">({filteredBooks.length})</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {filteredBooks.map((book) => (
                <BookCard key={book.id} book={book} size="small" />
              ))}
            </div>
          </div>
        )}

        {/* Users section */}
        {q && filteredUsers.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <User className="w-4 h-4 text-primary" />
              <h2 className="text-sm font-semibold text-foreground">Kullanıcılar</h2>
              <span className="text-xs text-muted-foreground">({filteredUsers.length})</span>
            </div>
            <div className="space-y-2">
              {filteredUsers.map((u) => (
                <Link
                  key={u.id}
                  to={`/user/${encodeURIComponent(u.email)}`}
                  className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border hover:border-primary/40 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {u.avatar_url ? (
                      <img src={u.avatar_url} alt={u.full_name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-sm font-bold text-primary">
                        {u.full_name?.[0]?.toUpperCase() || "?"}
                      </span>
                    )}
                  </div>
                  <span className="text-sm font-medium text-foreground">
                    {u.full_name || u.email}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </PullToRefresh>
  );
}