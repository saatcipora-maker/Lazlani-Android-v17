import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Clock, CheckCircle, XCircle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

export default function MyRecommendations() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: books = [] } = useQuery({
    queryKey: ["myBooks-recommendations", currentUser?.email],
    queryFn: () =>
      base44.entities.Book.filter({ author_email: currentUser.email }, "-created_date", 50),
    enabled: !!currentUser?.email,
  });

  const recommendedBooks = books.filter((b) => b.recommendation_status !== "none");

  const statusConfig = {
    pending: { icon: Clock, label: "Beklemede", color: "bg-yellow-100 text-yellow-800" },
    approved: { icon: CheckCircle, label: "Onaylandı", color: "bg-green-100 text-green-800" },
    rejected: { icon: XCircle, label: "Reddedildi", color: "bg-red-100 text-red-800" },
  };

  return (
    <div className="px-4 py-4">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="text-muted-foreground">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold text-foreground">Önerilerim</h1>
      </div>

      {recommendedBooks.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">
          Henüz bir öneriniz yok. Kitaplarınızın detay sayfasından "Öner" butonuna basarak kitabınızı ana sayfada yayınlanması için önerebilirsiniz.
        </div>
      ) : (
        <div className="space-y-3">
          {recommendedBooks.map((book) => {
            const config = statusConfig[book.recommendation_status];
            const Icon = config?.icon;
            return (
              <Link
                key={book.id}
                to={`/book/${book.id}`}
                className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border"
              >
                <div className="w-12 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-primary/10">
                  {book.cover_image ? (
                    <img src={book.cover_image} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs font-bold text-primary">
                      {book.title?.[0]}
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{book.title}</p>
                  <Badge className={`text-[10px] mt-1 ${config?.color}`}>
                    {Icon && <Icon className="w-3 h-3 mr-1" />}
                    {config?.label}
                  </Badge>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}