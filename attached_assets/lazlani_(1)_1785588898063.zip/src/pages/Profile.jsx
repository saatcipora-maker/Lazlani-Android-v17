import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { LogOut, ShieldCheck, Plus, Star, Crown, BookOpen, Eye, Heart, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";
import PullToRefresh from "@/components/ui/PullToRefresh";
import FollowListModal from "@/components/profile/FollowListModal";
import BadgeRequestPanel from "@/components/profile/BadgeRequestPanel";
import DeleteAccountDialog from "@/components/profile/DeleteAccountDialog";
import { BottomSheet } from "@/components/ui/bottom-sheet";
import ProfileHeader from "@/components/profile/ProfileHeader";
import HorizontalBookList from "@/components/books/HorizontalBookList";
import BultenTab from "@/components/bulten/BultenTab";
import MagazinTab from "@/components/magazin/MagazinTab";
import PremiumCard from "@/components/profile/PremiumCard";
import { useAuth } from "@/lib/AuthContext";

const TABS = [
  { id: "kitaplar", label: "Kitaplar", icon: BookOpen },
  { id: "bulten", label: "Bülten", icon: MessageCircle },
  { id: "mansetler", label: "Dergi", icon: Eye },
];

export default function Profile() {
  const { user: currentUser, setUser: setCurrentUser } = useAuth();
  const [activeTab, setActiveTab] = useState("kitaplar");
  const [followModal, setFollowModal] = useState(null);
  const [showBadgePanel, setShowBadgePanel] = useState(false);
  const queryClient = useQueryClient();

  const { data: myBooks = [], isLoading: isLoadingBooks } = useQuery({
    queryKey: ["myBooks", currentUser?.email],
    queryFn: () => base44.entities.Book.filter({ author_email: currentUser.email, status: "yayinda" }, "-created_date", 20),
    enabled: !!currentUser?.email,
    staleTime: 2 * 60 * 1000,
  });

  const { data: followers = [] } = useQuery({
    queryKey: ["followers", currentUser?.email],
    queryFn: () => base44.entities.Follow.filter({ following_email: currentUser.email }, "-created_date", 100),
    enabled: !!currentUser?.email,
    staleTime: 2 * 60 * 1000,
  });

  const { data: following = [] } = useQuery({
    queryKey: ["following", currentUser?.email],
    queryFn: () => base44.entities.Follow.filter({ follower_email: currentUser.email }, "-created_date", 100),
    enabled: !!currentUser?.email,
    staleTime: 2 * 60 * 1000,
  });

  const { data: premiumMembership } = useQuery({
    queryKey: ["premium-membership", currentUser?.email],
    queryFn: async () => {
      const results = await base44.entities.PremiumMembership.filter({ user_email: currentUser.email }, "-created_date", 1);
      return results[0] || null;
    },
    enabled: !!currentUser?.email,
    staleTime: 60000,
  });

  const isAdmin = currentUser?.role === "admin";
  const totalReads = myBooks.reduce((s, b) => s + (b.read_count || 0), 0);
  const totalLikes = myBooks.reduce((s, b) => s + (b.like_count || 0), 0);

  const handleRefresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["myBooks", currentUser?.email] }),
      queryClient.invalidateQueries({ queryKey: ["followers", currentUser?.email] }),
      queryClient.invalidateQueries({ queryKey: ["following", currentUser?.email] }),
      queryClient.invalidateQueries({ queryKey: ["premium-membership", currentUser?.email] }),
    ]);
  };

  return (
    <PullToRefresh onRefresh={handleRefresh} className="pb-8 min-h-screen">
      {/* Header */}
      <ProfileHeader
        currentUser={currentUser}
        followers={followers.length}
        following={following.length}
        myBooks={myBooks}
        onFollowersClick={() => setFollowModal("followers")}
        onFollowingClick={() => setFollowModal("following")}
        onBadgesClick={() => setShowBadgePanel(true)}
        premiumStatus={premiumMembership?.status}
      />

      {/* Stats Cards */}
      <div className="px-4 mb-4 grid grid-cols-3 gap-2">
        <div className="rounded-2xl p-3 text-center glass-card">
          <Eye className="w-4 h-4 text-primary mx-auto mb-1" />
          <p className="text-base font-bold text-foreground">{totalReads}</p>
          <p className="text-[9px] text-muted-foreground">Okunma</p>
        </div>
        <div className="rounded-2xl p-3 text-center glass-card">
          <Heart className="w-4 h-4 text-pink-400 mx-auto mb-1" />
          <p className="text-base font-bold text-foreground">{totalLikes}</p>
          <p className="text-[9px] text-muted-foreground">Beğeni</p>
        </div>
        <div className="rounded-2xl p-3 text-center glass-card">
          <BookOpen className="w-4 h-4 text-accent mx-auto mb-1" />
          <p className="text-base font-bold text-foreground">{myBooks.length}</p>
          <p className="text-[9px] text-muted-foreground">Kitap</p>
        </div>
      </div>

      {/* Premium Card */}
      <PremiumCard currentUser={currentUser} />

      {/* Quick Actions */}
      <div className="px-4 mb-4 flex gap-2">
        {isAdmin && (
          <Link
            to="/admin"
            className="flex-1 flex items-center gap-2.5 p-3.5 rounded-2xl active:scale-[0.98] transition-transform glass-card"
          >
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
              <ShieldCheck className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-foreground">Yönetici Paneli</p>
              <p className="text-[10px] text-muted-foreground">İçerik & kullanıcı yönetimi</p>
            </div>
          </Link>
        )}
        <Link
          to="/favorites"
          className="flex items-center gap-2 p-3.5 rounded-2xl glass-card active:scale-[0.98] transition-transform"
        >
          <Star className="w-4 h-4 text-accent" />
          <span className="text-xs font-medium">Favoriler</span>
        </Link>
      </div>

      {/* Tabs */}
      <div className="px-4 mt-1 mb-4">
        <div className="flex rounded-xl p-1" style={{ background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}>
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-2.5 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === tab.id
                  ? "text-foreground shadow-sm"
                  : "text-muted-foreground"
              }`}
              style={activeTab === tab.id ? {
                background: "linear-gradient(135deg, rgba(50,20,72,0.7), rgba(35,16,28,0.5))",
                border: "1px solid rgba(180,100,240,0.1)"
              } : {}}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div>
        {activeTab === "kitaplar" && (
          <div>
            {isLoadingBooks ? (
              <div className="px-4 py-8 text-center text-muted-foreground text-sm">Yükleniyor...</div>
            ) : myBooks.length === 0 ? (
              <div className="px-4 py-12 text-center">
                <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "linear-gradient(135deg, rgba(130,60,210,0.15), rgba(240,140,60,0.08))" }}>
                  <Plus className="w-7 h-7 text-primary" />
                </div>
                <p className="text-muted-foreground text-sm mb-1">Henüz kitap yok</p>
                <p className="text-muted-foreground/60 text-xs mb-4">İlk eserini oluşturmaya başla!</p>
                <Link
                  to="/write"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold text-white active:scale-95 transition-transform"
                  style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))", boxShadow: "0 4px 16px rgba(130,60,210,0.3)" }}
                >
                  <Plus className="w-4 h-4" />
                  Kitap Oluştur
                </Link>
              </div>
            ) : (
              <HorizontalBookList books={myBooks} />
            )}
          </div>
        )}

        {activeTab === "bulten" && <BultenTab />}
        {activeTab === "mansetler" && <MagazinTab />}
      </div>

      {/* Account Actions */}
      <div className="px-4 mt-8 space-y-2 pb-4">
        <button
          onClick={() => base44.auth.logout("/")}
          className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl text-foreground text-sm font-medium active:scale-[0.98] transition-all glass-card"
          style={{ minHeight: "48px" }}
        >
          <LogOut className="w-4 h-4" />
          Çıkış Yap
        </button>
        <DeleteAccountDialog />
      </div>

      {/* Follow Modals */}
      <FollowListModal
        isOpen={followModal === "followers"}
        title="Beni Takip Edenler"
        list={followers}
        nameKey="follower_name"
        onClose={() => setFollowModal(null)}
      />
      <FollowListModal
        isOpen={followModal === "following"}
        title="Takip Ettiklerim"
        list={following}
        nameKey="following_name"
        onClose={() => setFollowModal(null)}
      />

      {/* Badge Panel */}
      <BottomSheet isOpen={showBadgePanel} onClose={() => setShowBadgePanel(false)} title="Rozetler & Özellikler">
        <BadgeRequestPanel currentUser={currentUser} myBooks={myBooks} />
      </BottomSheet>
    </PullToRefresh>
  );
}