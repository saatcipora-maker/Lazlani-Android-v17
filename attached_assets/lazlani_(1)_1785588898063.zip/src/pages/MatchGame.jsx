import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion, AnimatePresence } from "framer-motion";
import { Gamepad2, Trophy, Play, ArrowLeft, Sparkles, ChevronRight } from "lucide-react";
import MatchBoard from "@/components/match3/MatchBoard";
import MatchLeaderboard from "@/components/match3/MatchLeaderboard";
import MatchBadges from "@/components/match3/MatchBadges";
import MatchShareButton from "@/components/match3/MatchShareButton";

export default function MatchGame() {
  const [view, setView] = useState("menu"); // menu | playing | leaderboard
  const [levelUpInfo, setLevelUpInfo] = useState(null);
  const [movesOut, setMovesOut] = useState(false);
  const queryClient = useQueryClient();

  const { data: currentUser } = useQuery({
    queryKey: ["current-user"],
    queryFn: () => base44.auth.me(),
  });

  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ["game-profile", currentUser?.email],
    queryFn: () => base44.entities.GameProfile.filter({ user_email: currentUser.email }),
    enabled: !!currentUser?.email,
  });

  const profile = profiles[0];

  const createProfile = useMutation({
    mutationFn: () =>
      base44.entities.GameProfile.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email.split("@")[0],
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["game-profile"] }),
  });

  useEffect(() => {
    if (currentUser?.email && !isLoading && profiles.length === 0) {
      createProfile.mutate();
    }
  }, [currentUser, isLoading, profiles.length]);

  // Daily / weekly / monthly resets
  useEffect(() => {
    if (!profile) return;
    const today = new Date().toISOString().slice(0, 10);
    const now = new Date();
    const weekKey = getWeekKey(now);
    const monthKey = now.toISOString().slice(0, 7);

    const updates = {};
    if (profile.daily_reset_date !== today) {
      updates.daily_bombs = 3;
      updates.daily_score = 0;
      updates.daily_reset_date = today;
    }
    if (profile.score_reset_weekly !== weekKey) {
      updates.weekly_score = 0;
      updates.score_reset_weekly = weekKey;
    }
    if (profile.score_reset_monthly !== monthKey) {
      updates.monthly_score = 0;
      updates.score_reset_monthly = monthKey;
    }
    if (Object.keys(updates).length > 0) {
      base44.entities.GameProfile.update(profile.id, updates).then(() =>
        queryClient.invalidateQueries({ queryKey: ["game-profile"] })
      );
    }
  }, [profile]);

  const updateProfile = useMutation({
    mutationFn: (data) => base44.entities.GameProfile.update(profile.id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["game-profile"] }),
  });

  const handleScoreGain = (amount) => {
    if (!profile) return;
    updateProfile.mutate({
      total_score: (profile.total_score || 0) + amount,
      daily_score: (profile.daily_score || 0) + amount,
      weekly_score: (profile.weekly_score || 0) + amount,
      monthly_score: (profile.monthly_score || 0) + amount,
    });
  };

  const handleLevelComplete = (sessionScore, oldLevel) => {
    setLevelUpInfo({ oldLevel, newLevel: oldLevel + 1, bonus: 50 });
    updateProfile.mutate({
      match_level: oldLevel + 1,
      total_score: (profile.total_score || 0) + 50,
      daily_score: (profile.daily_score || 0) + 50,
      weekly_score: (profile.weekly_score || 0) + 50,
      monthly_score: (profile.monthly_score || 0) + 50,
    });
  };

  const handleUseBomb = () => {
    if (!profile) return;
    updateProfile.mutate({ daily_bombs: Math.max(0, (profile.daily_bombs ?? 3) - 1) });
  };

  const handleMovesOut = () => {
    setMovesOut(true);
  };

  if (!currentUser || isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="w-7 h-7 border-2 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-0 flex-1 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 flex-shrink-0" style={{ borderBottom: "1px solid rgba(200,140,255,0.06)" }}>
        {view !== "menu" ? (
          <button onClick={() => setView("menu")} className="w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-transform" style={{ background: "rgba(255,255,255,0.04)" }}>
            <ArrowLeft className="w-4.5 h-4.5 text-muted-foreground" />
          </button>
        ) : (
          <div className="w-9" />
        )}
        <div className="flex items-center gap-2">
          <Gamepad2 className="w-4.5 h-4.5 text-primary" />
          <h1 className="text-sm font-heading font-bold text-foreground">Renk Patlatma</h1>
        </div>
        <div className="w-9" />
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-hide px-4 py-4">
        <AnimatePresence mode="wait">
          {view === "menu" && (
            <motion.div key="menu" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center gap-4 pt-4">
              {/* Hero */}
              <div className="w-20 h-20 rounded-3xl flex items-center justify-center gold-glow mb-1" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(300,50%,48%), hsl(24,85%,55%))" }}>
                <Gamepad2 className="w-10 h-10 text-white" />
              </div>
              <div className="text-center">
                <h2 className="font-heading text-2xl font-bold text-gold-gradient">Renk Patlatma</h2>
                <p className="text-xs text-muted-foreground mt-1">Eşleştir, patlat, yarış!</p>
              </div>

              {/* Stats */}
              {profile && (
                <div className="w-full max-w-sm grid grid-cols-3 gap-2 mt-2">
                  <div className="glass-card rounded-2xl px-2 py-3 text-center">
                    <p className="text-[9px] text-muted-foreground">Seviye</p>
                    <p className="text-xl font-heading font-bold text-primary">{profile.match_level || 1}</p>
                  </div>
                  <div className="glass-card rounded-2xl px-2 py-3 text-center">
                    <p className="text-[9px] text-muted-foreground">Toplam Puan</p>
                    <p className="text-xl font-heading font-bold text-accent">{profile.total_score || 0}</p>
                  </div>
                  <div className="glass-card rounded-2xl px-2 py-3 text-center">
                    <p className="text-[9px] text-muted-foreground">Bombalar</p>
                    <p className="text-xl font-heading font-bold text-foreground">{profile.daily_bombs ?? 3}</p>
                  </div>
                </div>
              )}

              {/* Play button */}
              <button
                onClick={() => { setMovesOut(false); setView("playing"); }}
                className="w-full max-w-sm h-14 rounded-2xl flex items-center justify-center gap-2 text-base font-bold text-white transition-all active:scale-[0.97] mt-2"
                style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))", boxShadow: "0 4px 20px rgba(130,60,210,0.35)" }}
              >
                <Play className="w-5 h-5" fill="currentColor" />
                Oyna
              </button>

              {/* Leaderboard button */}
              <button
                onClick={() => setView("leaderboard")}
                className="w-full max-w-sm h-12 rounded-2xl flex items-center justify-between px-4 text-sm font-semibold text-foreground glass-card active:scale-[0.97] transition-transform"
              >
                <span className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-accent" />
                  Liderlik Tablosu
                </span>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>

              {/* Share button */}
              {profile && <MatchShareButton profile={profile} />}

              {/* Achievements */}
              {profile && (
                <div className="w-full max-w-sm glass-card rounded-2xl p-4 mt-2 space-y-3">
                  <p className="text-xs font-bold text-foreground flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5 text-accent" />
                    Başarımlar
                  </p>
                  <MatchBadges totalScore={profile.total_score || 0} />
                </div>
              )}

              {/* How to play */}
              <div className="w-full max-w-sm glass-card rounded-2xl p-4 mt-2 space-y-2">
                <p className="text-xs font-bold text-foreground flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-accent" />
                  Nasıl Oynanır
                </p>
                <ul className="text-[11px] text-muted-foreground space-y-1.5 leading-relaxed">
                  <li>• Aynı renkten 3+ kutuyu yan yana getirerek patlat</li>
                  <li>• 4 veya 5 eşleşme daha çok puan verir</li>
                  <li>• Zincirleme patlamalar puan çarpanı kazandırır</li>
                  <li>• Çikolatalı Bomba tüm aynı renk kutuları patlatır (günde 3 hak)</li>
                  <li>• Hedef puana ulaşınca seviye atla, +50 bonus kazan</li>
                </ul>
              </div>
            </motion.div>
          )}

          {view === "playing" && profile && (
            <motion.div key="playing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center">
              <MatchBoard
                profile={profile}
                onScoreGain={handleScoreGain}
                onLevelComplete={handleLevelComplete}
                onUseBomb={handleUseBomb}
                onMovesOut={handleMovesOut}
              />
            </motion.div>
          )}

          {view === "leaderboard" && (
            <motion.div key="lb" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <MatchLeaderboard currentUserEmail={currentUser.email} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Level up modal */}
      <AnimatePresence>
        {levelUpInfo && (
          <LevelUpModal info={levelUpInfo} onClose={() => { setLevelUpInfo(null); setMovesOut(false); setView("playing"); }} />
        )}
      </AnimatePresence>

      {/* Moves out modal */}
      <AnimatePresence>
        {movesOut && !levelUpInfo && (
          <MovesOutModal onRetry={() => { setMovesOut(false); setView("menu"); setTimeout(() => setView("playing"), 50); }} onClose={() => { setMovesOut(false); setView("menu"); }} />
        )}
      </AnimatePresence>
    </div>
  );
}

function getWeekKey(date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - d.getDay());
  return d.toISOString().slice(0, 10);
}

function LevelUpModal({ info, onClose }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-sm p-6" onClick={onClose}>
      <motion.div initial={{ scale: 0.5, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.5, opacity: 0 }} transition={{ type: "spring", damping: 20 }} className="glass-card rounded-3xl p-8 max-w-xs w-full text-center" style={{ border: "1px solid rgba(245,158,11,0.3)" }} onClick={e => e.stopPropagation()}>
        <motion.div initial={{ rotate: -10 }} animate={{ rotate: [0, -10, 10, 0] }} transition={{ repeat: Infinity, duration: 2 }} className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: "linear-gradient(135deg, #f59e0b, #fbbf24)", boxShadow: "0 0 30px rgba(245,158,11,0.5)" }}>
          <Sparkles className="w-8 h-8 text-white" />
        </motion.div>
        <h2 className="font-heading text-2xl font-bold text-gold-gradient mb-1">Seviye Atladın!</h2>
        <p className="text-sm text-muted-foreground mb-4">Seviye {info.oldLevel} → {info.newLevel}</p>
        <div className="glass-card rounded-2xl py-3 mb-4">
          <p className="text-xs text-muted-foreground">Bonus Puan</p>
          <p className="text-2xl font-bold text-accent">+{info.bonus}</p>
        </div>
        <button onClick={onClose} className="w-full h-12 rounded-2xl text-white font-bold text-sm" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
          Devam Et
        </button>
      </motion.div>
    </motion.div>
  );
}

function MovesOutModal({ onRetry, onClose }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-sm p-6" onClick={onClose}>
      <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} exit={{ scale: 0.5 }} className="glass-card rounded-3xl p-8 max-w-xs w-full text-center" onClick={e => e.stopPropagation()}>
        <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: "rgba(239,68,68,0.15)" }}>
          <Gamepad2 className="w-8 h-8 text-red-400" />
        </div>
        <h2 className="font-heading text-xl font-bold text-foreground mb-1">Hamleler Bitti!</h2>
        <p className="text-sm text-muted-foreground mb-4">Tekrar denemek ister misin?</p>
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 h-12 rounded-2xl text-sm font-semibold text-muted-foreground glass-card">Menü</button>
          <button onClick={onRetry} className="flex-1 h-12 rounded-2xl text-white font-bold text-sm" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>Tekrar Dene</button>
        </div>
      </motion.div>
    </motion.div>
  );
}