import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { ArrowLeft, Users, BookOpen, CheckCircle2, Clock, ShieldCheck, XCircle, Settings, Star, Ban, Award, ShoppingBag, Bell, LayoutDashboard, Download, CreditCard, Wifi, BarChart3, Package, Crown, MessageCircle, Sparkles, Mail, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import AdminStats from "@/components/admin/AdminStats";
import AdminUserList from "@/components/admin/AdminUserList";
import AdminBadgeRequests from "@/components/admin/AdminBadgeRequests";
import AdminSubscriptions from "@/components/admin/AdminSubscriptions";
import AdminSubscriptionRequests from "@/components/admin/AdminSubscriptionRequests";
import AdminLiveUsers from "@/components/admin/AdminLiveUsers";
import AdminActiveStats from "@/components/admin/AdminActiveStats";
import AdminPremium from "@/components/admin/AdminPremium";
import AdminCommunity from "@/components/admin/AdminCommunity";
import AdminFeaturedBooks from "@/components/admin/AdminFeaturedBooks";
import AdminUserEmails from "@/components/admin/AdminUserEmails";
import AdminBulkEmail from "@/components/admin/AdminBulkEmail";

const tabs = [
  { id: "overview", label: "Özet", icon: LayoutDashboard },
  { id: "live", label: "Canlı", icon: Wifi },
  { id: "activity", label: "Aktivite", icon: BarChart3 },
  { id: "requests", label: "İstekler", icon: Bell },
  { id: "subscriptions", label: "Abonelik", icon: Package },
  { id: "sub-requests", label: "Başvurular", icon: CreditCard },
  { id: "reports", label: "Şikayetler", icon: Ban },
  { id: "users", label: "Üyeler", icon: Users },
  { id: "user-emails", label: "E-posta Yönet", icon: Mail },
  { id: "bulk-email", label: "E-posta Gönder", icon: Send },
  { id: "featured", label: "Vitrin", icon: Sparkles },
  { id: "books", label: "Tüm Kitaplar", icon: BookOpen },
  { id: "completed", label: "Kitap Onayı", icon: Clock },
  { id: "approved", label: "Onaylananlar", icon: CheckCircle2 },
  { id: "carts", label: "Sepet", icon: ShoppingBag },
  { id: "premium", label: "Premium", icon: Star },
  { id: "community", label: "Topluluk", icon: MessageCircle },
  { id: "settings", label: "Ayarlar", icon: Settings },
];

export default function AdminPanel() {
  const { user: currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  useEffect(() => {
    if (currentUser && currentUser.role !== "admin") navigate("/");
  }, [currentUser]);

  const { data: allUsers = [], isLoading: loadingUsers } = useQuery({
    queryKey: ["admin", "users"],
    queryFn: () => base44.entities.User.list("-created_date", 200),
    enabled: !!currentUser,
    staleTime: 2 * 60 * 1000,
  });

  const { data: allBooks = [], isLoading: loadingBooks } = useQuery({
    queryKey: ["admin", "books"],
    queryFn: () => base44.entities.Book.list("-created_date", 200),
    enabled: !!currentUser,
    staleTime: 2 * 60 * 1000,
  });

  const { data: onlineUsers = [] } = useQuery({
    queryKey: ["admin", "online"],
    queryFn: () => base44.entities.OnlineUser.list("-last_seen", 100),
    enabled: !!currentUser,
    refetchInterval: 15000,
  });

  // Real-time online subscription
  useEffect(() => {
    const unsub = base44.entities.OnlineUser.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["admin", "online"] });
    });
    return unsub;
  }, []);

  const activeOnlineCount = onlineUsers.filter((u) => u.last_seen && (Date.now() - new Date(u.last_seen).getTime()) < 5 * 60 * 1000).length;

  const completedBooks = allBooks.filter((b) => b.completion_status === "tamamlandi");
  const approvedBooks = allBooks.filter((b) => b.completion_status === "onaylandi");
  const pendingRecommendations = allBooks.filter((b) => b.recommendation_status === "pending");
  const pendingFeatureRequests = allBooks.filter((b) => b.feature_status === "pending");

  const approveMutation = useMutation({
    mutationFn: (bookId) => base44.entities.Book.update(bookId, { completion_status: "onaylandi", is_approved: true }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "books"] }); toast.success("Kitap onaylandı!"); },
  });

  const rejectMutation = useMutation({
    mutationFn: (bookId) => base44.entities.Book.update(bookId, { completion_status: "reddedildi" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "books"] }); toast.success("Kitap reddedildi"); },
  });

  const approveRecommendMutation = useMutation({
    mutationFn: (bookId) => base44.entities.Book.update(bookId, { recommendation_status: "approved", is_recommended: true }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "books"] }); toast.success("Öneri onaylandı!"); },
  });

  const { data: appSettings = [] } = useQuery({
    queryKey: ["app-settings"],
    queryFn: () => base44.entities.AppSettings.list("-created_date", 50),
    enabled: !!currentUser,
  });

  const getSetting = (key, fallback) => appSettings.find((s) => s.key === key)?.value || fallback;

  const [authorPrice, setAuthorPrice] = useState("");
  const [vipPrice, setVipPrice] = useState("");
  const [ozelPrice, setOzelPrice] = useState("");
  const [kitapPrice, setKitapPrice] = useState("");
  const [oneCikarPrice, setOneCikarPrice] = useState("");
  const [magazinPrice, setMagazinPrice] = useState("");

  useEffect(() => {
    setAuthorPrice(getSetting("yazarlik_rozeti_price", "99"));
    setVipPrice(getSetting("vip_uyelik_price", "199"));
    setOzelPrice(getSetting("ozel_rozeti_price", "149"));
    setKitapPrice(getSetting("kitap_rozeti_price", "79"));
    setOneCikarPrice(getSetting("one_cikar_rozeti_price", "49"));
    setMagazinPrice(getSetting("magazin_rozeti_price", "89"));
  }, [appSettings]);

  const saveSetting = async (key, value) => {
    const existing = appSettings.find((s) => s.key === key);
    if (existing) await base44.entities.AppSettings.update(existing.id, { value });
    else await base44.entities.AppSettings.create({ key, value });
    queryClient.invalidateQueries({ queryKey: ["app-settings"] });
    toast.success("Fiyat güncellendi!");
  };

  const { data: allBadgeRequests = [] } = useQuery({
    queryKey: ["admin", "badge-requests"],
    queryFn: () => base44.entities.BadgeRequest.list("-created_date", 200),
    enabled: !!currentUser,
  });
  const pendingRequests = allBadgeRequests.filter((r) => r.status === "pending");

  const { data: allReports = [] } = useQuery({
    queryKey: ["admin", "reports"],
    queryFn: () => base44.entities.AdminReport.list("-created_date", 200),
    enabled: !!currentUser,
  });
  const pendingReports = allReports.filter((r) => r.status === "pending");

  const { data: subRequests = [] } = useQuery({
    queryKey: ["admin", "subscription-requests"],
    queryFn: () => base44.entities.SubscriptionRequest.list("-created_date", 200),
    enabled: !!currentUser,
  });
  const pendingSubRequests = subRequests.filter((r) => r.status === "pending").length;

  const { data: premiumRequests = [] } = useQuery({
    queryKey: ["admin", "premium-memberships"],
    queryFn: () => base44.entities.PremiumMembership.list("-created_date", 200),
    enabled: !!currentUser,
  });
  const pendingPremium = premiumRequests.filter((r) => r.status === "pending").length;

  const exportReportsCSV = () => {
    const headers = ["Tarih","Kullanıcı","Email","İhlal Türü","Neden","Durum","Otomatik"];
    const rows = allReports.map((r) => [
      r.created_date ? new Date(r.created_date).toLocaleDateString("tr-TR") : "",
      r.reported_user_name || "", r.reported_user_email || "", r.violation_type || "",
      (r.reason || "").replace(/[\n\r,]/g, " "), r.status || "", r.auto_report ? "Evet" : "Hayır",
    ]);
    const csv = "\uFEFF" + [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `sikayetler_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    toast.success("CSV indirildi!");
  };

  const reviewReportMutation = useMutation({
    mutationFn: async ({ reportId, action, banDays }) => {
      await base44.entities.AdminReport.update(reportId, { status: action === "ban" ? "banned" : "dismissed" });
      if (action === "ban") {
        const report = allReports.find((r) => r.id === reportId);
        const ban_until = banDays === 0 ? "permanent" : new Date(Date.now() + banDays * 86400000).toISOString();
        const users = await base44.entities.User.filter({ email: report.reported_user_email }, "-created_date", 1);
        if (users[0]) await base44.entities.User.update(users[0].id, { is_banned: true, ban_until });
      }
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin"] }); toast.success("Şikayet işlendi!"); },
  });

  const { data: allCartItems = [] } = useQuery({
    queryKey: ["admin", "carts"],
    queryFn: () => base44.entities.CartItem.list("-created_date", 200),
    enabled: !!currentUser,
  });

  const approveAllCartsMutation = useMutation({
    mutationFn: () => Promise.all(allCartItems.map((item) => base44.entities.CartItem.update(item.id, { is_approved: true, price: 0 }))),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin", "carts"] }); toast.success("Tüm sepetler onaylandı!"); },
  });

  if (!currentUser) return null;

  return (
   <div className="px-4 py-4 pb-8">
     {/* Header */}
     <div className="flex items-center gap-3 mb-5">
       <Link to="/profile" className="text-muted-foreground" aria-label="Geri">
         <ArrowLeft className="w-5 h-5" />
       </Link>
       <div className="flex items-center gap-2">
         <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(24,85%,55%))" }}>
           <ShieldCheck className="w-4 h-4 text-white" />
         </div>
         <h1 className="text-xl font-heading font-bold text-foreground">Yönetici Paneli</h1>
       </div>
       {/* Live indicator */}
       <div className="ml-auto flex items-center gap-1.5 px-2.5 py-1.5 rounded-full" style={{ background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)" }}>
         <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
         <span className="text-[10px] font-bold text-green-400">{activeOnlineCount}</span>
       </div>
     </div>

     {/* Tabs */}
     <div className="flex gap-1 overflow-x-auto scrollbar-hide mb-5 rounded-2xl p-1" style={{ background: "rgba(38,18,55,0.4)", border: "1px solid rgba(200,140,255,0.06)" }}>
        {tabs.map((t) => {
          const hasBadge = (t.id === "sub-requests" && pendingSubRequests > 0) || (t.id === "requests" && pendingRequests.length > 0) || (t.id === "reports" && pendingReports.length > 0) || (t.id === "premium" && pendingPremium > 0) || (t.id === "featured" && pendingFeatureRequests.length > 0);
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all flex-shrink-0 ${
                activeTab === t.id ? "text-foreground shadow-sm" : "text-muted-foreground"
              }`}
              style={activeTab === t.id ? { background: "linear-gradient(135deg, rgba(50,20,72,0.7), rgba(35,16,28,0.5))", border: "1px solid rgba(180,100,240,0.1)" } : {}}
            >
              <t.icon className="w-3.5 h-3.5" />
              {t.label}
              {hasBadge && <span className="w-1.5 h-1.5 rounded-full bg-red-500 absolute top-1 right-1" />}
            </button>
          );
        })}
      </div>

      {/* Overview */}
      {activeTab === "overview" && (
        <div className="space-y-5">
          <AdminStats allUsers={allUsers} allBooks={allBooks} onlineCount={activeOnlineCount} />

          {/* Quick action cards */}
          <div className="grid grid-cols-2 gap-2.5">
            <button onClick={() => setActiveTab("live")} className="glass-card rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
              <Wifi className="w-5 h-5 text-green-400 mb-1" />
              <p className="text-2xl font-black text-foreground">{activeOnlineCount}</p>
              <p className="text-xs text-muted-foreground font-medium">Anlık Aktif</p>
            </button>
            <button onClick={() => setActiveTab("premium")} className="glass-card rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
              <Crown className="w-5 h-5 text-primary mb-1" />
              <p className="text-2xl font-black text-foreground">{pendingPremium}</p>
              <p className="text-xs text-muted-foreground font-medium">Premium Başvuru</p>
            </button>
            <button onClick={() => setActiveTab("sub-requests")} className="glass-card rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
              <CreditCard className="w-5 h-5 text-blue-400 mb-1" />
              <p className="text-2xl font-black text-foreground">{pendingSubRequests}</p>
              <p className="text-xs text-muted-foreground font-medium">Abonelik Talebi</p>
            </button>
            <button onClick={() => setActiveTab("reports")} className="glass-card rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
              <Ban className="w-5 h-5 text-red-400 mb-1" />
              <p className="text-2xl font-black text-foreground">{pendingReports.length}</p>
              <p className="text-xs text-muted-foreground font-medium">Bekleyen Şikayet</p>
            </button>
            <button onClick={() => setActiveTab("requests")} className="glass-card rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
              <Bell className="w-5 h-5 text-yellow-400 mb-1" />
              <p className="text-2xl font-black text-foreground">{pendingRequests.length}</p>
              <p className="text-xs text-muted-foreground font-medium">Bekleyen İstek</p>
            </button>
            <button onClick={() => setActiveTab("completed")} className="glass-card rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
              <Clock className="w-5 h-5 text-accent mb-1" />
              <p className="text-2xl font-black text-foreground">{completedBooks.length}</p>
              <p className="text-xs text-muted-foreground font-medium">Kitap Onayı</p>
            </button>
          </div>
        </div>
      )}

      {/* Live Users */}
      {activeTab === "live" && <AdminLiveUsers />}

      {/* Activity Stats */}
      {activeTab === "activity" && <AdminActiveStats />}

      {/* Reports */}
      {activeTab === "reports" && (
        <div className="space-y-3">
          <div className="flex justify-end mb-2">
            <Button size="sm" variant="outline" className="rounded-full text-xs gap-1.5" onClick={exportReportsCSV} disabled={allReports.length === 0}>
              <Download className="w-3.5 h-3.5" /> CSV İndir ({allReports.length})
            </Button>
          </div>
          {pendingReports.length === 0 ? (
            <div className="text-center py-12"><Ban className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Şikayet yok</p></div>
          ) : pendingReports.map((report) => (
            <div key={report.id} className="p-4 rounded-2xl bg-red-50 border border-red-200">
              <div className="mb-3">
                <p className="text-sm font-semibold text-foreground">{report.reported_user_name}</p>
                <p className="text-xs text-muted-foreground">{report.reported_user_email}</p>
                <p className="text-sm font-medium text-red-700 mt-1">{report.violation_type === "profanity" ? "Uygunsuz Dil" : report.violation_type}</p>
                <p className="text-xs text-muted-foreground mt-1">{report.reason}</p>
              </div>
              <div className="flex gap-2 mb-2">
                <Button size="sm" variant="outline" className="flex-1 rounded-full text-xs h-8 text-green-600 border-green-300" onClick={() => reviewReportMutation.mutate({ reportId: report.id, action: "dismiss" })}>Kapat</Button>
                <Button size="sm" className="flex-1 rounded-full text-xs h-8 bg-red-600 hover:bg-red-700" onClick={() => reviewReportMutation.mutate({ reportId: report.id, action: "ban", banDays: 0 })}>Süresiz Ban</Button>
              </div>
              <div className="flex flex-wrap gap-1">
                {[1, 7, 30].map((days) => (
                  <button key={days} onClick={() => reviewReportMutation.mutate({ reportId: report.id, action: "ban", banDays: days })}
                    className="text-[10px] px-2 py-1 rounded-full bg-orange-100 border border-orange-300 text-orange-700 hover:bg-orange-200">{days} gün ban</button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Badge Requests */}
      {activeTab === "requests" && <AdminBadgeRequests allBadgeRequests={allBadgeRequests} />}

      {/* Subscription Plans Management */}
      {activeTab === "subscriptions" && <AdminSubscriptions />}

      {/* Subscription Requests */}
      {activeTab === "sub-requests" && <AdminSubscriptionRequests />}

      {/* Users */}
      {activeTab === "users" && <AdminUserList allUsers={allUsers} isLoading={loadingUsers} />}

      {/* User Email Management */}
      {activeTab === "user-emails" && <AdminUserEmails allUsers={allUsers} isLoading={loadingUsers} />}

      {/* Bulk Email Sending */}
      {activeTab === "bulk-email" && <AdminBulkEmail allUsers={allUsers} />}

      {/* Featured Books */}
      {activeTab === "featured" && <AdminFeaturedBooks />}

      {/* All Books */}
      {activeTab === "books" && (
        <div className="space-y-2">
          {pendingRecommendations.length > 0 && (
            <div className="mb-3">
              <p className="text-xs font-semibold text-orange-600 mb-2">Öneri Bekleyen ({pendingRecommendations.length})</p>
              {pendingRecommendations.map((b) => (
                <div key={b.id} className="flex items-center gap-3 p-3 rounded-2xl bg-orange-50 border border-orange-200 mb-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{b.title}</p>
                    <p className="text-xs text-muted-foreground">{b.author_name}</p>
                  </div>
                  <Button size="sm" className="rounded-full text-xs h-7" onClick={() => approveRecommendMutation.mutate(b.id)}>Onayla</Button>
                </div>
              ))}
            </div>
          )}
          {loadingBooks ? [1,2,3].map((i) => <Skeleton key={i} className="h-14 rounded-xl" />) : allBooks.map((b) => (
            <div key={b.id} className="flex items-center gap-3 p-3 rounded-2xl bg-card border border-border">
              <div className="w-10 h-14 rounded-xl overflow-hidden flex-shrink-0 bg-primary/10">
                {b.cover_image && <img src={b.cover_image} alt="" className="w-full h-full object-cover" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{b.title}</p>
                <p className="text-xs text-muted-foreground truncate">{b.author_name}</p>
              </div>
              <Badge variant={b.status === "yayinda" ? "default" : "secondary"} className="text-[9px]">
                {b.status === "yayinda" ? "Yayında" : "Taslak"}
              </Badge>
            </div>
          ))}
        </div>
      )}

      {/* Completed */}
      {activeTab === "completed" && (
        <div className="space-y-3">
          {completedBooks.length === 0 ? (
            <div className="text-center py-12"><Clock className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Onay bekleyen kitap yok</p></div>
          ) : completedBooks.map((b) => (
            <div key={b.id} className="p-3 rounded-2xl bg-card border border-border">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-14 rounded-xl overflow-hidden flex-shrink-0 bg-primary/10">
                  {b.cover_image && <img src={b.cover_image} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{b.title}</p>
                  <p className="text-xs text-muted-foreground">{b.author_name}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" className="flex-1 rounded-full text-xs h-8 bg-green-600 hover:bg-green-700" onClick={() => approveMutation.mutate(b.id)}>Onayla</Button>
                <Button size="sm" variant="outline" className="flex-1 rounded-full text-xs h-8 text-destructive" onClick={() => rejectMutation.mutate(b.id)}>Reddet</Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Carts */}
      {activeTab === "carts" && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">{allCartItems.length} ürün</p>
            <Button size="sm" className="rounded-full bg-green-600 text-white text-xs" onClick={() => approveAllCartsMutation.mutate()} disabled={allCartItems.length === 0}>
              <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Hepsini Onayla
            </Button>
          </div>
          {allCartItems.length === 0 ? (
            <div className="text-center py-12"><ShoppingBag className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Sepet boş</p></div>
          ) : allCartItems.map((item) => (
            <div key={item.id} className={`flex items-center gap-3 p-3 rounded-2xl border ${item.is_approved ? "bg-green-50 border-green-200" : "bg-card border-border"}`}>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{item.product_name}</p>
                <p className="text-xs text-muted-foreground truncate">{item.user_email}</p>
              </div>
              <span className="text-xs font-bold text-primary">₺{item.price}</span>
            </div>
          ))}
        </div>
      )}

      {/* Approved */}
      {activeTab === "approved" && (
        <div className="space-y-2">
          {approvedBooks.length === 0 ? (
            <div className="text-center py-12"><CheckCircle2 className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Onaylanan kitap yok</p></div>
          ) : approvedBooks.map((b) => (
            <div key={b.id} className="flex items-center gap-3 p-3 rounded-2xl bg-green-50 border border-green-200">
              <div className="w-10 h-14 rounded-xl overflow-hidden flex-shrink-0 bg-primary/10">
                {b.cover_image && <img src={b.cover_image} alt="" className="w-full h-full object-cover" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{b.title}</p>
                <p className="text-xs text-muted-foreground">{b.author_name}</p>
              </div>
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
            </div>
          ))}
        </div>
      )}

      {/* Premium Management */}
      {activeTab === "premium" && <AdminPremium />}

      {/* Community Management */}
      {activeTab === "community" && <AdminCommunity />}

      {/* Settings */}
      {activeTab === "settings" && (
        <div className="space-y-4">
          <h3 className="font-semibold">Rozet Fiyatları</h3>
          <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
            {[
              { label: "Özel Rozeti (₺)", value: ozelPrice, setter: setOzelPrice, key: "ozel_rozeti_price" },
              { label: "Kitap Rozeti (₺)", value: kitapPrice, setter: setKitapPrice, key: "kitap_rozeti_price" },
              { label: "Öne Çıkar Rozeti (₺)", value: oneCikarPrice, setter: setOneCikarPrice, key: "one_cikar_rozeti_price" },
              { label: "Magazin Rozeti (₺)", value: magazinPrice, setter: setMagazinPrice, key: "magazin_rozeti_price" },
              { label: "Yazarlık Rozeti (₺)", value: authorPrice, setter: setAuthorPrice, key: "yazarlik_rozeti_price" },
              { label: "VIP Rozeti (₺)", value: vipPrice, setter: setVipPrice, key: "vip_uyelik_price" },
            ].map((item) => (
              <div key={item.key}>
                <label className="text-xs font-medium text-muted-foreground">{item.label}</label>
                <div className="flex gap-2 mt-1">
                  <Input value={item.value} onChange={(e) => item.setter(e.target.value)} type="number" className="h-9 text-sm" />
                  <Button size="sm" className="rounded-xl" onClick={() => saveSetting(item.key, item.value)}>Kaydet</Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}