import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Bell, BookOpen, UserPlus, MessageCircle, Heart, Send, Info, CheckCheck } from "lucide-react";
import { Link } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";
import { toast } from "sonner";
import PullToRefresh from "@/components/ui/PullToRefresh";

const typeConfig = {
  new_book: { icon: BookOpen, color: "bg-primary/10 text-primary" },
  new_chapter: { icon: BookOpen, color: "bg-blue-50 text-blue-600" },
  follow: { icon: UserPlus, color: "bg-green-50 text-green-600" },
  comment_reply: { icon: MessageCircle, color: "bg-purple-50 text-purple-600" },
  comment_like: { icon: Heart, color: "bg-pink-50 text-pink-600" },
  new_message: { icon: Send, color: "bg-accent/10 text-accent" },
  system: { icon: Info, color: "bg-muted text-muted-foreground" },
};

export default function Notifications() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const [activeFilter, setActiveFilter] = useState("all");

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["notifications", currentUser?.email],
    queryFn: () =>
      base44.entities.Notification.filter(
        { receiver_email: currentUser.email },
        "-created_date",
        50
      ),
    enabled: !!currentUser?.email,
    refetchInterval: 30000,
  });

  const markReadMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.update(id, { is_read: true }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  const handleNotifClick = (notif) => {
    if (!notif.is_read) markReadMutation.mutate(notif.id);
  };

  const unreadNotifs = notifications.filter((n) => !n.is_read);

  const markAllRead = async () => {
    const batch = unreadNotifs.slice(0, 50);
    await Promise.all(batch.map((n) => base44.entities.Notification.update(n.id, { is_read: true })));
    queryClient.invalidateQueries({ queryKey: ["notifications"] });
    toast.success("Tüm bildirimler okundu olarak işaretlendi");
  };

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["notifications"] });
  };

  const filtered = activeFilter === "all"
    ? notifications
    : activeFilter === "unread"
    ? unreadNotifs
    : notifications.filter((n) => n.type === activeFilter);

  const filters = [
    { id: "all", label: "Tümü" },
    { id: "unread", label: `Okunmamış (${unreadNotifs.length})` },
    { id: "new_chapter", label: "Bölümler" },
    { id: "follow", label: "Takip" },
    { id: "system", label: "Sistem" },
  ];

  return (
    <PullToRefresh onRefresh={handleRefresh} className="px-4 py-5">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold text-foreground">Bildirimler</h1>
        {unreadNotifs.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-primary gap-1 h-8 rounded-full"
            onClick={markAllRead}
          >
            <CheckCheck className="w-3.5 h-3.5" />
            Tümünü Oku
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-1.5 overflow-x-auto scrollbar-hide mb-4 pb-0.5">
        {filters.map((f) => (
          <button
            key={f.id}
            onClick={() => setActiveFilter(f.id)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
              activeFilter === f.id
                ? "bg-foreground text-background"
                : "bg-muted text-muted-foreground"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-[72px] rounded-2xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-3">
            <Bell className="w-7 h-7 text-muted-foreground/40" />
          </div>
          <p className="text-muted-foreground text-sm">
            {activeFilter === "unread" ? "Okunmamış bildiriminiz yok" : "Henüz bildiriminiz yok"}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((notif) => {
            const config = typeConfig[notif.type] || typeConfig.system;
            const Icon = config.icon;
            const linkTo = notif.book_id
              ? `/book/${notif.book_id}`
              : notif.type === "new_message" && notif.sender_email
              ? `/messages?to=${encodeURIComponent(notif.sender_email)}&name=${encodeURIComponent(notif.sender_name || "")}`
              : notif.type === "follow" && notif.sender_email
              ? `/user/${encodeURIComponent(notif.sender_email)}`
              : null;

            const inner = (
              <div
                className={`flex items-start gap-3 p-3.5 rounded-2xl border transition-all active:scale-[0.98] ${
                  notif.is_read
                    ? "bg-card border-border/50"
                    : "bg-primary/5 border-primary/20 shadow-sm"
                }`}
                onClick={() => handleNotifClick(notif)}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${config.color}`}>
                  <Icon className="w-4.5 h-4.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm leading-snug ${notif.is_read ? "text-foreground/80" : "text-foreground font-medium"}`}>
                    {notif.message}
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-1.5">
                    {formatDistanceToNow(new Date(notif.created_date), { addSuffix: true, locale: tr })}
                  </p>
                </div>
                {!notif.is_read && (
                  <div className="w-2.5 h-2.5 rounded-full bg-primary mt-1.5 flex-shrink-0 shadow-sm shadow-primary/30" />
                )}
              </div>
            );

            return (
              <div key={notif.id}>
                {linkTo ? <Link to={linkTo}>{inner}</Link> : inner}
              </div>
            );
          })}
        </div>
      )}
    </PullToRefresh>
  );
}