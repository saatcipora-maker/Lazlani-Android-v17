import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Messages from "./Messages";

// "Sohbet" sekmesine tıklandığında doğrudan özel mesajlaşma ekranını göster
export default function Chat() {
  return <Messages />;
}