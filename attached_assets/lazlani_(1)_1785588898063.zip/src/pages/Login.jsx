import { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Loader2, Mail, Lock, Eye, EyeOff, ArrowLeft } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import ContinueWithGoogle from "@/components/auth/ContinueWithGoogle";

export default function Login() {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  const [showLogin, setShowLogin] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-background gap-4">
        <h1 className="font-heading text-2xl font-bold tracking-wider text-foreground">LAZLANİ</h1>
        <Loader2 className="w-7 h-7 animate-spin text-primary" />
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  const handleEmailLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      localStorage.setItem('base44_login_provider', 'email');
      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = "/";
    } catch (err) {
      setError(err.message || "Giriş başarısız. E-posta ve şifrenizi kontrol edin.");
    } finally {
      setLoading(false);
    }
  };

  // Welcome screen — shown first when not authenticated
  if (!showLogin) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-background overflow-y-auto py-8">
        <div className="absolute top-[-20%] left-[-10%] w-[60vw] h-[60vw] rounded-full opacity-[0.07] pointer-events-none" style={{ background: "radial-gradient(circle, hsl(270,60%,56%), transparent 70%)" }} />
        <div className="absolute bottom-[-15%] right-[-10%] w-[50vw] h-[50vw] rounded-full opacity-[0.05] pointer-events-none" style={{ background: "radial-gradient(circle, hsl(24,85%,55%), transparent 70%)" }} />

        <div className="relative z-10 w-full max-w-sm px-8 flex flex-col items-center">
          <div className="mb-3">
            <div className="w-20 h-20 rounded-3xl flex items-center justify-center gold-glow" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(300,50%,48%), hsl(24,85%,55%))", boxShadow: "0 8px 32px rgba(130,60,210,0.3), 0 4px 16px rgba(240,140,60,0.15)" }}>
              <span className="text-3xl font-heading font-bold text-white tracking-wider">L</span>
            </div>
          </div>

          <h1 className="font-heading text-3xl font-bold tracking-wider text-gold-gradient mb-1">LAZLANİ</h1>
          <p className="text-muted-foreground text-sm mb-10">Oku, Yaz, Keşfet</p>

          <div className="w-full flex flex-col gap-3">
            <Button onClick={() => setShowLogin(true)} className="w-full h-12 font-semibold text-base">
              Giriş Yap
            </Button>
            <Link to="/register">
              <Button variant="outline" className="w-full h-12 font-semibold text-base">
                Kayıt Ol
              </Button>
            </Link>
            <ContinueWithGoogle />
          </div>

          <p className="text-[11px] text-muted-foreground/60 text-center mt-10 leading-relaxed px-4">
            Devam ederek Gizlilik Politikası ve Kullanım Koşullarını kabul etmiş olursunuz.
          </p>
        </div>
      </div>
    );
  }

  // Login form
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-background overflow-y-auto py-8">
      <div className="absolute top-[-20%] left-[-10%] w-[60vw] h-[60vw] rounded-full opacity-[0.07] pointer-events-none" style={{ background: "radial-gradient(circle, hsl(270,60%,56%), transparent 70%)" }} />
      <div className="absolute bottom-[-15%] right-[-10%] w-[50vw] h-[50vw] rounded-full opacity-[0.05] pointer-events-none" style={{ background: "radial-gradient(circle, hsl(24,85%,55%), transparent 70%)" }} />

      <div className="relative z-10 w-full max-w-sm px-8 flex flex-col items-center">
        <button onClick={() => setShowLogin(false)} className="self-start mb-4 w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-transform" style={{ background: "rgba(255,255,255,0.04)" }} aria-label="Geri">
          <ArrowLeft className="w-4.5 h-4.5 text-muted-foreground" />
        </button>

        <div className="mb-3">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center gold-glow" style={{ background: "linear-gradient(135deg, hsl(270,60%,56%), hsl(300,50%,48%), hsl(24,85%,55%))", boxShadow: "0 8px 32px rgba(130,60,210,0.3), 0 4px 16px rgba(240,140,60,0.15)" }}>
            <span className="text-2xl font-heading font-bold text-white tracking-wider">L</span>
          </div>
        </div>

        <h1 className="font-heading text-2xl font-bold tracking-wider text-gold-gradient mb-1">LAZLANİ</h1>
        <p className="text-muted-foreground text-sm mb-6">Tekrar hoş geldin</p>

        <div className="w-full mb-4">
          <ContinueWithGoogle />
        </div>

        <div className="relative w-full mb-4">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div>
          <div className="relative flex justify-center text-xs"><span className="bg-background px-3 text-muted-foreground">veya</span></div>
        </div>

        <form onSubmit={handleEmailLogin} className="w-full space-y-3">
          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm text-center">{error}</div>
          )}
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input type="email" placeholder="E-posta adresi" value={email} onChange={(e) => setEmail(e.target.value)} className="pl-10 h-12" required />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input type={showPassword ? "text" : "password"} placeholder="Şifre" value={password} onChange={(e) => setPassword(e.target.value)} className="pl-10 h-12 pr-10" required />
            <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center justify-center text-muted-foreground" style={{ minHeight: "unset", minWidth: "unset", height: "40px", width: "40px" }}>
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <Button type="submit" className="w-full h-12 font-semibold text-base" disabled={loading}>
            {loading ? (<><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Giriş yapılıyor...</>) : "Giriş Yap"}
          </Button>
        </form>

        <div className="w-full flex justify-between mt-4 text-xs">
          <Link to="/forgot-password" className="text-muted-foreground hover:text-foreground">Şifremi unuttum</Link>
          <Link to="/register" className="text-primary font-medium hover:underline">Hesap oluştur</Link>
        </div>

        <p className="text-[11px] text-muted-foreground/60 text-center mt-8 leading-relaxed px-4">
          Devam ederek Gizlilik Politikası ve Kullanım Koşullarını kabul etmiş olursunuz.
        </p>
      </div>
    </div>
  );
}