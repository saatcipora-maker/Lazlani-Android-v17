import { useState, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Skeleton } from "@/components/ui/skeleton";
import { Flame, Sparkles, Clock, Crown, Eye, Gem, Heart, TrendingUp, Star, Zap, BookOpen } from "lucide-react";

import CategoryTabs from "@/components/home/CategoryTabs";
import LuxuryHero from "@/components/home/LuxuryHero";
import FeaturedCarousel from "@/components/home/FeaturedCarousel";
import LuxuryAuthorCard from "@/components/home/LuxuryAuthorCard";
import LuxurySectionHeader from "@/components/books/LuxurySectionHeader";
import LuxuryBookList from "@/components/books/LuxuryBookList";
import PopularCategories from "@/components/home/PopularCategories";

import BultenTab from "@/components/bulten/BultenTab";
import MagazinTab from "@/components/magazin/MagazinTab";
import YazarSohbeti from "@/components/chat/YazarSohbeti";
import OzelTab from "@/components/exclusive/OzelTab";
import PullToRefresh from "@/components/ui/PullToRefresh";
import { useAuth } from "@/lib/AuthContext";

export default function Home() {

  const [activeTab, setActiveTab] = useState("kitaplar");
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["books"] });
    await queryClient.invalidateQueries({ queryKey: ["featured-books"] });
    await queryClient.invalidateQueries({ queryKey: ["bulten-posts"] });
    await queryClient.invalidateQueries({ queryKey: ["magazin-posts"] });
  };

  const { data: recommendedBooks = [], isLoading: lr } = useQuery({
    queryKey: ["books", "recommended"],
    queryFn: () => base44.entities.Book.filter({ is_recommended: true, status: "yayinda" }, "-created_date", 10),
    staleTime: 3 * 60 * 1000,
    placeholderData: (prev) => prev,
  });

  const { data: popularBooks = [], isLoading: lp } = useQuery({
    queryKey: ["books", "popular"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-read_count", 12),
    staleTime: 3 * 60 * 1000,
    placeholderData: (prev) => prev,
  });

  const { data: allBooks = [], isLoading: la } = useQuery({
    queryKey: ["books", "all"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-created_date", 20),
    staleTime: 3 * 60 * 1000,
    placeholderData: (prev) => prev,
  });

  const { data: trendBooks = [], isLoading: lt } = useQuery({
    queryKey: ["books", "trending"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-like_count", 12),
    staleTime: 3 * 60 * 1000,
    placeholderData: (prev) => prev,
  });

  const weeklyAuthor = useMemo(() => {
    if (allBooks.length === 0) return null;
    const map = {};
    allBooks.forEach(b => {
      if (!b.author_email) return;
      if (!map[b.author_email]) {
        map[b.author_email] = { email: b.author_email, full_name: b.author_name, avatar_url: b.author_avatar, count: 0, reads: 0 };
      }
      map[b.author_email].count++;
      map[b.author_email].reads += (b.read_count || 0);
    });
    return Object.values(map).sort((a, b) => b.reads - a.reads)[0] || null;
  }, [allBooks]);

  const hiddenGems = useMemo(() => {
    return allBooks.filter(b => (b.read_count || 0) < 10).slice(0, 10);
  }, [allBooks]);

  if (activeTab === "yazar") {
    return <YazarSohbeti onBack={() => setActiveTab("kitaplar")} />;
  }

  return (
    <PullToRefresh onRefresh={handleRefresh} className="min-h-screen">
      <CategoryTabs activeTab={activeTab} onTabChange={setActiveTab} />

      {activeTab === "kitaplar" && (
        <div className="pb-10">
          <FeaturedCarousel />
          <LuxuryHero />

          <div className="space-y-7 mt-1">
            {/* Devam Ettiklerin — like reference */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.05s" }}>
              <LuxurySectionHeader
                title="Devam Ettiklerin"
                subtitle="Kaldığın Yerden"
                icon={<BookOpen className="w-4 h-4 text-primary" />}
                linkTo="/library"
              />
              {lp ? <ShimmerRow /> : (
                <LuxuryBookList books={popularBooks.slice(0, 6)} size="medium" showInfo />
              )}
            </section>

            {/* Sana Özel Öneriler */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
              <LuxurySectionHeader
                title="Sana Özel Öneriler"
                subtitle="AI Destekli"
                icon={<Zap className="w-4 h-4 text-yellow-400" />}
                linkTo="/search"
              />
              {lr ? <ShimmerRow size="large" /> : (
                <LuxuryBookList books={recommendedBooks} size="large" showInfo />
              )}
            </section>

            {/* Popüler Kategoriler */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.15s" }}>
              <LuxurySectionHeader
                title="Popüler Kategoriler"
                subtitle="Keşfet"
                icon={<Sparkles className="w-4 h-4 text-primary" />}
                linkTo="/search"
              />
              <PopularCategories />
            </section>

            {/* Haftanın Yazarı */}
            {weeklyAuthor && (
              <section className="animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
                <LuxuryAuthorCard author={weeklyAuthor} bookCount={weeklyAuthor.count} readCount={weeklyAuthor.reads} />
              </section>
            )}

            {/* Trend İçerikler */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.25s" }}>
              <LuxurySectionHeader
                title="Trend İçerikler"
                subtitle="Yükselen"
                icon={<Flame className="w-4 h-4 text-orange-400" />}
                linkTo="/search"
              />
              {lt ? <ShimmerRow size="large" /> : (
                <LuxuryBookList books={trendBooks} size="large" showInfo showRanks />
              )}
            </section>

            {/* Editör Seçimi */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
              <LuxurySectionHeader
                title="Editör Seçimi"
                subtitle="Özenle Seçildi"
                icon={<Star className="w-4 h-4 text-primary" />}
                linkTo="/search"
              />
              {lr ? <ShimmerRow size="featured" /> : (
                <LuxuryBookList books={recommendedBooks} size="featured" />
              )}
            </section>

            {/* En Çok Okunanlar */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.35s" }}>
              <LuxurySectionHeader
                title="En Çok Okunanlar"
                subtitle="Popüler"
                icon={<Eye className="w-4 h-4 text-primary" />}
                linkTo="/search"
              />
              {lp ? <ShimmerRow /> : (
                <LuxuryBookList books={popularBooks} size="medium" showInfo />
              )}
            </section>

            {/* En Çok Beğenilenler */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
              <LuxurySectionHeader
                title="En Çok Beğenilenler"
                subtitle="Favoriler"
                icon={<Heart className="w-4 h-4 text-pink-400" />}
                linkTo="/search"
              />
              {lt ? <ShimmerRow /> : (
                <LuxuryBookList books={trendBooks} size="medium" showRanks showInfo />
              )}
            </section>

            {/* Yeni Eklenenler */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.45s" }}>
              <LuxurySectionHeader
                title="Yeni Eklenenler"
                subtitle="Taze"
                icon={<Clock className="w-4 h-4 text-primary" />}
                linkTo="/search"
              />
              {la ? <ShimmerRow /> : (
                <LuxuryBookList books={allBooks} size="medium" />
              )}
            </section>

            {/* Gizli Hazineler */}
            {hiddenGems.length > 0 && (
              <section className="animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
                <LuxurySectionHeader
                  title="Gizli Hazineler"
                  subtitle="Keşfedilmemiş"
                  icon={<Gem className="w-4 h-4 text-purple-400" />}
                  linkTo="/search"
                />
                <LuxuryBookList books={hiddenGems} size="large" showInfo />
              </section>
            )}

            {/* Premium Yazarlar */}
            <section className="animate-fade-in-up" style={{ animationDelay: "0.55s" }}>
              <LuxurySectionHeader
                title="Premium Yazarlar"
                subtitle="En İyiler"
                icon={<Crown className="w-4 h-4 text-primary" />}
                linkTo="/search"
              />
              {lp ? <ShimmerRow /> : (
                <LuxuryBookList books={popularBooks.slice(0, 8)} size="medium" showInfo />
              )}
            </section>
          </div>
        </div>
      )}

      {activeTab === "magazin" && <MagazinTab />}
      {activeTab === "ozel" && <OzelTab />}
      {activeTab === "bultenler" && <BultenTab />}
    </PullToRefresh>
  );
}

function ShimmerRow({ size = "medium" }) {
  const h = size === "featured" ? "h-[220px]" : size === "large" ? "h-[202px]" : "h-[178px]";
  return (
    <div className="flex gap-3.5 px-5">
      {[1, 2, 3].map(i => (
        <Skeleton key={i} className={`w-[130px] ${h} rounded-[18px] flex-shrink-0`} style={{ background: "rgba(40,18,65,0.4)" }} />
      ))}
    </div>
  );
}