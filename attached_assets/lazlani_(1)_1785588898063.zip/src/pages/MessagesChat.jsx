import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { useOnlineUsers } from "@/hooks/useOnlineStatus";
import ChatView from "@/components/messages/ChatView";

export default function MessagesChat() {
  const { email } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const onlineMap = useOnlineUsers();

  const name = searchParams.get("name") || email;
  const activeConv = { email, name };

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <ChatView
      currentUser={currentUser}
      activeConv={activeConv}
      onBack={() => navigate(-1)}
      onlineMap={onlineMap}
    />
  );
}