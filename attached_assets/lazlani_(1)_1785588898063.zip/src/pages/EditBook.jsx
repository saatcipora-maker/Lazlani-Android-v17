import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit, Eye, EyeOff, Save, BookOpen, Clock, BarChart3 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import BookForm from "@/components/write/BookForm";
import ChapterForm from "@/components/write/ChapterForm";
import ScheduleCalendar from "@/components/write/ScheduleCalendar";
import { toast } from "sonner";
import { format } from "date-fns";
import { tr } from "date-fns/locale";

export default function EditBook() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [showEditBook, setShowEditBook] = useState(false);
  const [showNewChapter, setShowNewChapter] = useState(false);
  const [editingChapter, setEditingChapter] = useState(null);

  const { user: currentUser } = useAuth();

  const { data: book, isLoading } = useQuery({
    queryKey: ["book", id],
    queryFn: () => base44.entities.Book.filter({ id }, "-created_date", 1).then((r) => r[0]),
  });

  const { data: chapters = [], isLoading: loadingChapters } = useQuery({
    queryKey: ["chapters", id],
    queryFn: () => base44.entities.Chapter.filter({ book_id: id }, "order", 100),
    enabled: !!id,
  });

  const publishMutation = useMutation({
    mutationFn: () => base44.entities.Book.update(id, { status: "yayinda" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      toast.success("Kitap yayınlandı!");
    },
  });

  const unpublishMutation = useMutation({
    mutationFn: () => base44.entities.Book.update(id, { status: "taslak" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      toast.success("Kitap taslağa alındı");
    },
  });

  const deleteChapterMutation = useMutation({
    mutationFn: (chapterId) => base44.entities.Chapter.delete(chapterId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["chapters", id] }),
  });

  const saveAllAsDraftMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Book.update(id, { status: "taslak" });
      await Promise.all(
        chapters.filter((c) => c.status !== "taslak").map((c) =>
          base44.entities.Chapter.update(c.id, { status: "taslak" })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      queryClient.invalidateQueries({ queryKey: ["chapters", id] });
      toast.success("Tümü taslağa kaydedildi");
    },
  });

  const publishAllMutation = useMutation({
    mutationFn: async () => {
      if (chapters.length === 0) throw new Error("En az 1 bölüm gerekli");
      if (!book.cover_image) throw new Error("Kapak fotoğrafı gerekli");
      await base44.entities.Book.update(id, { status: "yayinda" });
      await Promise.all(
        chapters.filter((c) => c.status === "taslak").map((c) =>
          base44.entities.Chapter.update(c.id, { status: "yayinda" })
        )
      );
      // Notify followers
      const follows = await base44.entities.Follow.filter({ following_email: currentUser.email }, "-created_date", 200);
      if (follows.length > 0) {
        await Promise.all(
          follows.map((f) =>
            base44.entities.Notification.create({
              receiver_email: f.follower_email,
              sender_name: currentUser.full_name,
              type: "new_book",
              message: `${currentUser.full_name} yeni bir kitap yayınladı: "${book.title}"`,
              book_id: id,
              is_read: false,
            })
          )
        );
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      queryClient.invalidateQueries({ queryKey: ["chapters", id] });
      toast.success("Kitap ve tüm bölümler yayınlandı!");
    },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading) {
    return (
      <div className="p-4 space-y-3">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-20 w-full rounded-xl" />
      </div>
    );
  }

  if (!book) {
    return <div className="p-4 pt-8 text-center text-muted-foreground">Kitap bulunamadı</div>;
  }

  return (
    <div className="px-4 py-4">
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <div className="flex-1 min-w-0">
          <h1 className="font-bold text-foreground truncate">{book.title}</h1>
          <Badge variant={book.status === "yayinda" ? "default" : "secondary"} className="text-[10px] mt-1">
            {book.status === "yayinda" ? "Yayında" : "Taslak"}
          </Badge>
        </div>
      </div>

      {/* Actions */}
      <div className="space-y-2 mb-6">
        <div className="flex gap-2">
          <Dialog open={showEditBook} onOpenChange={setShowEditBook}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="rounded-full flex-1">
                <Edit className="w-3 h-3 mr-1" />
                Düzenle
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Kitabı Düzenle</DialogTitle>
              </DialogHeader>
              <BookForm
                user={currentUser}
                book={book}
                onSuccess={() => {
                  setShowEditBook(false);
                  queryClient.invalidateQueries({ queryKey: ["book", id] });
                }}
              />
            </DialogContent>
          </Dialog>

          {book.status === "taslak" ? (
            <Button
              size="sm"
              className="rounded-full flex-1"
              onClick={() => publishMutation.mutate()}
            >
              <Eye className="w-3 h-3 mr-1" />
              Yayınla
            </Button>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="rounded-full flex-1"
              onClick={() => unpublishMutation.mutate()}
            >
              <EyeOff className="w-3 h-3 mr-1" />
              Taslağa Al
            </Button>
          )}
        </div>

        {/* Save / Publish All */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="rounded-full flex-1 text-xs border-orange-300 text-orange-600 hover:bg-orange-50"
            onClick={() => saveAllAsDraftMutation.mutate()}
            disabled={saveAllAsDraftMutation.isPending}
          >
            <Save className="w-3 h-3 mr-1" />
            Tümünü Taslağa Kaydet
          </Button>
          <Button
            size="sm"
            className="rounded-full flex-1 text-xs bg-primary"
            onClick={() => publishAllMutation.mutate()}
            disabled={publishAllMutation.isPending}
          >
            <BookOpen className="w-3 h-3 mr-1" />
            Kitabı Kaydet & Yayınla
          </Button>
        </div>
      </div>

      {/* Writing Stats */}
      {chapters.length > 0 && (
        <div className="mb-6 p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Yazım İstatistikleri</h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center">
              <p className="text-lg font-bold text-foreground">{chapters.length}</p>
              <p className="text-[10px] text-muted-foreground">Bölüm</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-foreground">
                {chapters.reduce((sum, c) => sum + (c.content ? c.content.replace(/<[^>]*>/g, "").split(/\s+/).filter(Boolean).length : 0), 0).toLocaleString("tr-TR")}
              </p>
              <p className="text-[10px] text-muted-foreground">Kelime</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-foreground">
                {chapters.filter((c) => c.status === "yayinda").length}
              </p>
              <p className="text-[10px] text-muted-foreground">Yayında</p>
            </div>
          </div>
        </div>
      )}

      {/* Chapters */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-foreground">Bölümler</h2>
        <Dialog open={showNewChapter} onOpenChange={setShowNewChapter}>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline" className="rounded-full">
              <Plus className="w-3 h-3 mr-1" />
              Yeni Bölüm
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Yeni Bölüm</DialogTitle>
            </DialogHeader>
            <ChapterForm
              bookId={id}
              nextOrder={chapters.length + 1}
              bookTitle={book?.title}
              currentUser={currentUser}
              onSuccess={() => {
                setShowNewChapter(false);
                queryClient.invalidateQueries({ queryKey: ["chapters", id] });
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {loadingChapters ? (
        <div className="space-y-2">
          {[1, 2].map((i) => (
            <Skeleton key={i} className="h-14 rounded-xl" />
          ))}
        </div>
      ) : chapters.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground text-sm">
          Henüz bölüm yok. İlk bölümünüzü ekleyin!
        </div>
      ) : (
        <div className="space-y-2">
          {chapters.map((chapter, idx) => (
            <div
              key={chapter.id}
              className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border"
            >
              <span className="w-6 h-6 rounded bg-accent flex items-center justify-center text-xs font-bold text-accent-foreground flex-shrink-0">
                {idx + 1}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{chapter.title}</p>
                <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                  <Badge
                    variant={chapter.status === "yayinda" ? "default" : chapter.status === "zamanlanmis" ? "outline" : "secondary"}
                    className={`text-[11px] ${chapter.status === "zamanlanmis" ? "border-orange-400 text-orange-600" : ""}`}
                  >
                    {chapter.status === "yayinda" ? "Yayında" : chapter.status === "zamanlanmis" ? "Zamanlanmış" : "Taslak"}
                  </Badge>
                  {chapter.status === "zamanlanmis" && chapter.scheduled_date && (
                    <span className="text-[11px] text-orange-500 flex items-center gap-0.5">
                      <Clock className="w-2.5 h-2.5" />
                      {format(new Date(chapter.scheduled_date), "d MMM HH:mm", { locale: tr })}
                    </span>
                  )}
                </div>
              </div>
              <Dialog
                open={editingChapter?.id === chapter.id}
                onOpenChange={(open) => !open && setEditingChapter(null)}
              >
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setEditingChapter(chapter)}
                    aria-label="Bölümü düzenle"
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Bölümü Düzenle</DialogTitle>
                  </DialogHeader>
                  <ChapterForm
                    bookId={id}
                    chapter={editingChapter}
                    nextOrder={idx + 1}
                    bookTitle={book?.title}
                    currentUser={currentUser}
                    onSuccess={() => {
                      setEditingChapter(null);
                      queryClient.invalidateQueries({ queryKey: ["chapters", id] });
                    }}
                  />
                </DialogContent>
              </Dialog>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive"
                onClick={() => deleteChapterMutation.mutate(chapter.id)}
                aria-label="Bölümü sil"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          ))}
          {/* Add new chapter after last */}
          <Dialog open={showNewChapter} onOpenChange={setShowNewChapter}>
            <DialogTrigger asChild>
              <button className="w-full py-3 border-2 border-dashed border-border rounded-xl text-sm text-muted-foreground hover:border-primary/40 hover:text-primary transition-colors flex items-center justify-center gap-2 mt-1">
                <Plus className="w-4 h-4" />
                Yeni Bölüm Ekle
              </button>
            </DialogTrigger>
          </Dialog>
        </div>
      )}

      {/* Schedule Calendar */}
      <ScheduleCalendar bookId={id} bookTitle={book?.title} />
    </div>
  );
}