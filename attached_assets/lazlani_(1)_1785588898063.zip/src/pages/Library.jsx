import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router-dom";
import { BookOpen, Bookmark, Eye, Heart, ChevronRight } from "lucide-react";
import NativeSelect from "@/components/ui/native-select";
import PullToRefresh from "@/components/ui/PullToRefresh";

const categoryLabels = {
  roman: "Roman", romantik: "Romantik", ormantik: "Ormantik", fantastik: "Fantastik",
  bilim_kurgu: "Bilim Kurgu", bilim_kurgu_genc: "Bilim Kurgu (Genç)", kurgu_genc: "Kurgu (Genç)",
  edebiyat: "Edebiyat", gerilim: "Gerilim", dram: "Dram", genc_yetiskin: "Genç Yetişkin",
  macera: "Macera", korku: "Korku", mafya: "Mafya", tarih: "Tarih", klasik: "Klasik",
  siir: "Şiir", mizah: "Mizah", psikoloji: "Psikoloji", kisisel_gelisim: "Kişisel Gelişim",
  biyografi: "Biyografi", felsefe: "Felsefe", cocuk: "Çocuk", din_maneviyat: "Din & Maneviyat",
  erotik: "Erotik", diger: "Diğer",
};

function BookRow({ book }) {
  return (
    <Link
      to={`/book/${book.id || book.book_id}`}
      className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors">
      
      <div className="w-14 h-20 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
        {book.cover_image ?
        <img src={book.cover_image} alt={book.title} className="w-full h-full object-cover" /> :

        <div className="w-full h-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-primary/50" />
          </div>
        }
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm text-foreground truncate">{book.title}</p>
        <p className="text-xs text-muted-foreground mt-0.5 truncate">{book.author_name}</p>
        {book.category &&
        <span className="inline-block mt-1.5 text-[10px] bg-accent text-accent-foreground px-2 py-0.5 rounded-full">
            {book.category}
          </span>
        }
      </div>
    </Link>);

}

export default function Library() {
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: savedBooks = [], isLoading: loadingSaved } = useQuery({
    queryKey: ["saved-books-library", currentUser?.email],
    queryFn: async () => {
      const saved = await base44.entities.SavedBook.filter(
        { user_email: currentUser.email },
        "-created_date",
        50
      );
      const bookIds = saved.map((s) => s.book_id).filter(Boolean);
      if (bookIds.length === 0) return [];
      const allBooks = await base44.entities.Book.filter(
        { id: { $in: bookIds } },
        "-created_date",
        50
      );
      return allBooks;
    },
    enabled: !!currentUser?.email
  });

  const { data: readHistory = [], isLoading: loadingHistory } = useQuery({
    queryKey: ["read-history", currentUser?.email],
    queryFn: async () => {
      const history = await base44.entities.ReadHistory.filter(
        { user_email: currentUser.email },
        "-updated_date",
        50
      );
      const bookIds = history.map((h) => h.book_id).filter(Boolean);
      if (bookIds.length === 0) return [];
      const allBooks = await base44.entities.Book.filter(
        { id: { $in: bookIds } },
        "-created_date",
        50
      );
      return allBooks;
    },
    enabled: !!currentUser?.email
  });

  const filterByCategory = (books) => {
    if (!selectedCategory) return books;
    return books.filter((b) => b.category === selectedCategory);
  };

  const filteredSaved = filterByCategory(savedBooks);
  const filteredHistory = filterByCategory(readHistory);

  const handleRefresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["saved-books-library"] }),
      queryClient.invalidateQueries({ queryKey: ["read-history"] }),
    ]);
  };

  return (
    <PullToRefresh onRefresh={handleRefresh} className="py-4 px-4 space-y-6 pb-8">
      {/* Kategori Filtresi */}
      <div className="flex items-center gap-2">
        <NativeSelect
          value={selectedCategory || ""}
          onChange={(val) => val === "" ? setSelectedCategory(null) : setSelectedCategory(val)}
          title="Kategori Seç"
          placeholder="Kategori"
          options={[
            { value: "", label: "🗑 Filtreyi Temizle" },
            ...Object.entries(categoryLabels).map(([key, label]) => ({ value: key, label }))
          ]}
        />
      </div>

      {/* Favorilerim link */}
      <Link
        to="/favorites"
        className="flex items-center justify-between p-4 rounded-xl bg-card border border-border hover:border-red-300 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center">
            <Heart className="w-5 h-5 text-red-500" />
          </div>
          <div>
            <p className="font-semibold text-sm text-foreground">Favorilerim</p>
            <p className="text-xs text-muted-foreground">Beğendiğiniz kitaplar</p>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground" />
      </Link>

      {/* Saved Books */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Bookmark className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-foreground">Kaydettiklerim</h2>
          <span className="text-xs text-muted-foreground">({filteredSaved.length})</span>
        </div>
        {loadingSaved ?
        <div className="space-y-3">
            {[1, 2].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
          </div> :
        filteredSaved.length === 0 ?
        <p className="text-sm text-muted-foreground py-4 text-center">
          {selectedCategory ? "Bu kategoride kaydedilen kitap yok" : "Henüz kaydedilen kitap yok"}
        </p> :

        <div className="space-y-2">
            {filteredSaved.map((book) => <BookRow key={book.id} book={book} />)}
          </div>
        }
      </div>

      {/* Read History */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Eye className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-foreground">Okuduklarım</h2>
          <span className="text-xs text-muted-foreground">({filteredHistory.length})</span>
        </div>
        {loadingHistory ?
        <div className="space-y-3">
            {[1, 2].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
          </div> :
        filteredHistory.length === 0 ?
        <p className="text-sm text-muted-foreground py-4 text-center">
          {selectedCategory ? "Bu kategoride okunan kitap yok" : "Henüz okunmuş kitap yok"}
        </p> :

        <div className="space-y-2">
            {filteredHistory.map((book) => <BookRow key={book.id} book={book} />)}
          </div>
        }
      </div>
    </PullToRefresh>);

}