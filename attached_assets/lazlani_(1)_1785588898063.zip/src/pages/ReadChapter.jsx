import { useState, useEffect, useCallback, useRef } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, ChevronLeft, ChevronRight, Heart, MessageCircle, Send, Settings, Maximize2, Bookmark, List, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import CommentItem from "@/components/comments/CommentItem";
import ReadingSettings, { useReadingSettings } from "@/components/reading/ReadingSettings";
import sanitizeHtml from "@/lib/sanitizeHtml";
import FullscreenReader from "@/components/reading/FullscreenReader";
import BookmarkPanel from "@/components/reading/BookmarkPanel";
import ReadingListPanel from "@/components/reading/ReadingListPanel";
import { trackChapterRead } from "@/lib/bookStats";

export default function ReadChapter() {
  const { bookId, chapterId } = useParams();
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [showFullscreen, setShowFullscreen] = useState(false);
  const [scrollPercent, setScrollPercent] = useState(0);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [showReadingList, setShowReadingList] = useState(false);
  const readHistoryRef = useRef(null);
  const saveTimerRef = useRef(null);
  const restoredRef = useRef(false);
  const { settings, update: updateSettings, contentStyle, pageBg } = useReadingSettings();
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  // Track unique chapter read (1 read per user per chapter)
  useEffect(() => {
    if (!currentUser?.email || !chapterId || !bookId) return;
    trackChapterRead(currentUser.email, chapterId, bookId).then((isNew) => {
      if (isNew) queryClient.invalidateQueries({ queryKey: ["chapter-reads", chapterId] });
    });
  }, [currentUser?.email, chapterId, bookId]);

  // Track read history & restore scroll position
  useEffect(() => {
    if (!currentUser?.email || !bookId) return;
    restoredRef.current = false;
    base44.entities.ReadHistory.filter({ user_email: currentUser.email, book_id: bookId }, "-created_date", 1)
      .then(async (existing) => {
        if (existing.length > 0) {
          readHistoryRef.current = existing[0];
          await base44.entities.ReadHistory.update(existing[0].id, { last_chapter_id: chapterId });
          // Restore scroll position if same chapter
          if (existing[0].last_chapter_id === chapterId && existing[0].scroll_percent > 0 && !restoredRef.current) {
            restoredRef.current = true;
            setTimeout(() => {
              const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
              window.scrollTo({ top: (existing[0].scroll_percent / 100) * maxScroll, behavior: "smooth" });
            }, 300);
          }
        } else {
          const bookData = await base44.entities.Book.filter({ id: bookId }, "-created_date", 1).then(r => r[0]);
          const created = await base44.entities.ReadHistory.create({
            user_email: currentUser.email,
            book_id: bookId,
            book_title: bookData?.title || "",
            last_chapter_id: chapterId,
            scroll_percent: 0,
          });
          readHistoryRef.current = created;
        }
      })
      .catch(() => {});
  }, [currentUser?.email, bookId, chapterId]);

  // Scroll progress tracker
  const handleScroll = useCallback(() => {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
    const percent = scrollHeight > 0 ? Math.min(100, Math.round((scrollTop / scrollHeight) * 100)) : 0;
    setScrollPercent(percent);

    // Debounced save to DB
    if (readHistoryRef.current) {
      clearTimeout(saveTimerRef.current);
      saveTimerRef.current = setTimeout(() => {
        base44.entities.ReadHistory.update(readHistoryRef.current.id, { scroll_percent: percent }).catch(() => {});
      }, 2000);
    }
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      // Save on unmount
      if (readHistoryRef.current && scrollPercent > 0) {
        base44.entities.ReadHistory.update(readHistoryRef.current.id, { scroll_percent: scrollPercent }).catch(() => {});
      }
      clearTimeout(saveTimerRef.current);
    };
  }, [handleScroll]);

  const { data: chapter, isLoading } = useQuery({
    queryKey: ["chapter", chapterId],
    queryFn: () =>
      base44.entities.Chapter.filter({ id: chapterId }, "-created_date", 1).then((r) => r[0]),
  });

  const { data: allChapters = [] } = useQuery({
    queryKey: ["chapters", bookId],
    queryFn: () =>
      base44.entities.Chapter.filter({ book_id: bookId, status: "yayinda" }, "order", 50),
    enabled: !!bookId,
  });

  const { data: book } = useQuery({
    queryKey: ["book", bookId],
    queryFn: () =>
      base44.entities.Book.filter({ id: bookId }, "-created_date", 1).then((r) => r[0]),
  });

  const { data: likes = [] } = useQuery({
    queryKey: ["chapter-likes", chapterId],
    queryFn: () => base44.entities.ChapterLike.filter({ chapter_id: chapterId }, "-created_date", 500),
    enabled: !!chapterId,
  });

  const { data: chapterReads = [] } = useQuery({
    queryKey: ["chapter-reads", chapterId],
    queryFn: () => base44.entities.ChapterRead.filter({ chapter_id: chapterId }, "-created_date", 500),
    enabled: !!chapterId,
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["chapter-comments", chapterId],
    queryFn: () => base44.entities.ChapterComment.filter({ chapter_id: chapterId }, "created_date", 100),
    enabled: !!chapterId,
  });

  // Real-time subscribe
  useEffect(() => {
    const unsubLikes = base44.entities.ChapterLike.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["chapter-likes", chapterId] });
    });
    const unsubComments = base44.entities.ChapterComment.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["chapter-comments", chapterId] });
    });
    const unsubReads = base44.entities.ChapterRead.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["chapter-reads", chapterId] });
    });
    return () => { unsubLikes(); unsubComments(); unsubReads(); };
  }, [chapterId]);

  const isLiked = likes.some((l) => l.user_email === currentUser?.email);

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (isLiked) {
        const myLike = likes.find((l) => l.user_email === currentUser.email);
        await base44.entities.ChapterLike.delete(myLike.id);
      } else {
        await base44.entities.ChapterLike.create({ chapter_id: chapterId, user_email: currentUser.email });
      }
    },
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ["chapter-likes", chapterId] });
      const prev = queryClient.getQueryData(["chapter-likes", chapterId]) || [];
      if (isLiked) {
        queryClient.setQueryData(["chapter-likes", chapterId], prev.filter(l => l.user_email !== currentUser?.email));
      } else {
        queryClient.setQueryData(["chapter-likes", chapterId], [...prev, { user_email: currentUser?.email, chapter_id: chapterId, id: "__optimistic__" }]);
      }
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(["chapter-likes", chapterId], ctx.prev);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["chapter-likes", chapterId] }),
  });

  const commentMutation = useMutation({
    mutationFn: () =>
      base44.entities.ChapterComment.create({
        chapter_id: chapterId,
        user_email: currentUser.email,
        user_name: currentUser.full_name,
        content: commentText.trim(),
      }),
    onSuccess: () => {
      setCommentText("");
      queryClient.invalidateQueries({ queryKey: ["chapter-comments", chapterId] });
    },
  });

  if (isLoading) {
    return (
      <div className="p-4 space-y-4">
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
      </div>
    );
  }

  if (!chapter) {
    return (
      <div className="p-4 pt-8 text-center text-muted-foreground">Bölüm bulunamadı</div>
    );
  }

  const currentIdx = allChapters.findIndex((c) => c.id === chapterId);
  const prevChapter = currentIdx > 0 ? allChapters[currentIdx - 1] : null;
  const nextChapter = currentIdx < allChapters.length - 1 ? allChapters[currentIdx + 1] : null;

  return (
    <div className="pb-8" style={{ backgroundColor: pageBg }}>
      {/* Fullscreen reader */}
      {showFullscreen && (
        <FullscreenReader
          chapter={chapter}
          book={book}
          prevChapter={prevChapter}
          nextChapter={nextChapter}
          onClose={() => setShowFullscreen(false)}
          onNavigate={(id) => {
            setShowFullscreen(false);
            window.location.href = `/read/${bookId}/${id}`;
          }}
        />
      )}

      {/* Reading settings panel */}
      {showSettings && (
        <ReadingSettings settings={settings} onUpdate={updateSettings} onClose={() => setShowSettings(false)} />
      )}

      {/* Progress bar */}
      <div className="sticky top-0 z-40 h-[3px] w-full" style={{ backgroundColor: `${pageBg}80` }}>
        <div
          className="h-full bg-primary transition-all duration-150 ease-out"
          style={{ width: `${scrollPercent}%` }}
        />
      </div>

      {/* Header */}
      <div className="sticky top-[3px] z-30 backdrop-blur-lg border-b border-border/50 px-4 py-3" style={{ backgroundColor: `${pageBg}ee` }}>
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="text-muted-foreground" aria-label="Kitaba dön">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="text-xs text-muted-foreground truncate">{book?.title}</p>
            <p className="text-sm font-medium truncate" style={{ color: contentStyle.color }}>{chapter.title}</p>
          </div>
          <button
            onClick={() => setShowBookmarks(true)}
            className="w-8 h-8 rounded-full bg-muted/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            aria-label="Yer imleri"
          >
            <Bookmark className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowReadingList(true)}
            className="w-8 h-8 rounded-full bg-muted/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            aria-label="Okuma listesi"
          >
            <List className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowFullscreen(true)}
            className="w-8 h-8 rounded-full bg-muted/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            aria-label="Tam ekran"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="w-8 h-8 rounded-full bg-muted/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            aria-label="Okuma ayarları"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Chapter image */}
      {chapter.image_url && (
        <div className="w-full h-40 overflow-hidden">
          <img src={chapter.image_url} alt={chapter.title} className="w-full h-full object-cover" />
        </div>
      )}

      {/* Content */}
      <div className="px-5 py-6">
        <h2 className="font-display text-xl font-bold mb-6" style={{ color: contentStyle.color }}>
          {chapter.title}
        </h2>
        {chapter.content && chapter.content.includes("<") ? (
          <div
            className="prose prose-sm max-w-none"
            style={contentStyle}
            dangerouslySetInnerHTML={{ __html: sanitizeHtml(chapter.content) }}
          />
        ) : (
          <div className="whitespace-pre-wrap" style={contentStyle}>
            {chapter.content}
          </div>
        )}
      </div>

      {/* Like & Comment bar */}
      <div className="mx-4 mb-4 p-4 bg-card border border-border rounded-2xl">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Eye className="w-5 h-5" />
            <span>{chapterReads.length}</span>
          </div>
          <button
            onClick={() => currentUser && likeMutation.mutate()}
            className={`flex items-center gap-2 text-sm font-medium transition-colors ${isLiked ? "text-red-500" : "text-muted-foreground hover:text-red-400"}`}
          >
            <Heart className={`w-5 h-5 ${isLiked ? "fill-current" : ""}`} />
            <span>{likes.length}</span>
          </button>
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            <span>{comments.length > 0 ? comments.length : "Yorumlar"}</span>
          </button>
        </div>

        {showComments && (
          <div className="mt-4 space-y-3">
            {comments.map((c) => (
              <CommentItem
                key={c.id}
                comment={c}
                currentUser={currentUser}
                entityName="ChapterComment"
                queryKey={["chapter-comments", chapterId]}
              />
            ))}
            {currentUser && (
              <div className="flex gap-2 pt-1">
                <Input
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Yorum yaz..."
                  className="rounded-full text-xs h-8 bg-muted border-0"
                  onKeyDown={(e) => e.key === "Enter" && commentText.trim() && commentMutation.mutate()}
                />
                <Button
                  size="icon"
                  className="w-8 h-8 rounded-full flex-shrink-0"
                  disabled={!commentText.trim()}
                  onClick={() => commentMutation.mutate()}
                >
                  <Send className="w-3 h-3" />
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bookmark Panel */}
      {showBookmarks && currentUser && (
        <BookmarkPanel
          bookId={bookId}
          chapterId={chapterId}
          chapterTitle={chapter.title}
          bookTitle={book?.title}
          scrollPercent={scrollPercent}
          currentUser={currentUser}
          onClose={() => setShowBookmarks(false)}
        />
      )}

      {/* Reading List Panel */}
      {showReadingList && currentUser && (
        <ReadingListPanel
          bookId={bookId}
          currentUser={currentUser}
          onClose={() => setShowReadingList(false)}
        />
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between px-4 pt-2 pb-4 border-t border-border gap-3">
        {prevChapter ? (
          <Link to={`/read/${bookId}/${prevChapter.id}`} className="flex-1">
            <Button variant="outline" className="rounded-full w-full min-h-[48px]">
              <ChevronLeft className="w-4 h-4 mr-1" />
              Önceki
            </Button>
          </Link>
        ) : (
          <div className="flex-1" />
        )}
        {nextChapter ? (
          <Link to={`/read/${bookId}/${nextChapter.id}`} className="flex-1">
            <Button className="rounded-full w-full min-h-[48px]">
              Sonraki
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        ) : (
          <div className="flex-1" />
        )}
      </div>
    </div>
  );
}