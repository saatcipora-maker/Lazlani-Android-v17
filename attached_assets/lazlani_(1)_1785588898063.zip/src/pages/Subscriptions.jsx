import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Link } from "react-router-dom";
import { ArrowLeft, CheckCircle2, Clock, Loader2, Package, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function Subscriptions() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["subscription-plans"],
    queryFn: () => base44.entities.SubscriptionPlan.filter({ is_active: true }, "sort_order", 50),
  });

  const { data: myRequests = [] } = useQuery({
    queryKey: ["my-subscription-requests", currentUser?.email],
    queryFn: () => base44.entities.SubscriptionRequest.filter({ user_email: currentUser.email }, "-created_date", 20),
    enabled: !!currentUser?.email,
  });

  const applyMutation = useMutation({
    mutationFn: async (plan) => {
      await base44.entities.SubscriptionRequest.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name || "",
        plan_id: plan.id,
        plan_name: plan.name,
        price: plan.price,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-subscription-requests"] });
      toast.success("Başvurunuz alındı! Yönetici onayından sonra aboneliğiniz aktif olacak.");
    },
  });

  const hasPendingRequest = (planId) => myRequests.some((r) => r.plan_id === planId && r.status === "pending");
  const hasApprovedRequest = (planId) => myRequests.some((r) => r.plan_id === planId && r.status === "approved");

  return (
    <div className="px-4 py-4 pb-8">
      <div className="flex items-center gap-3 mb-5">
        <Link to="/profile" className="text-muted-foreground" aria-label="Geri">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex items-center gap-2">
          <Package className="w-5 h-5 text-primary" />
          <h1 className="text-xl font-bold text-foreground">Abonelik Paketleri</h1>
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-5">Premium özelliklere erişmek için bir paket seçin. Başvurunuz onaylandığında aboneliğiniz hemen aktif olur.</p>

      {isLoading ? (
        <div className="space-y-3">{[1,2,3].map((i) => <div key={i} className="h-44 rounded-2xl bg-muted animate-pulse" />)}</div>
      ) : plans.length === 0 ? (
        <div className="text-center py-16">
          <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Henüz aktif abonelik paketi bulunmuyor</p>
        </div>
      ) : (
        <div className="space-y-4">
          {plans.map((plan) => {
            const features = (plan.features || "").split("\n").filter(Boolean);
            const isPending = hasPendingRequest(plan.id);
            const isApproved = hasApprovedRequest(plan.id);
            return (
              <div key={plan.id} className="rounded-2xl border border-border overflow-hidden bg-card">
                {/* Header */}
                <div className="p-5 pb-3" style={{ borderBottom: `2px solid ${plan.color || '#f59e0b'}20` }}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${plan.color || '#f59e0b'}15` }}>
                        <Sparkles className="w-5 h-5" style={{ color: plan.color || '#f59e0b' }} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{plan.name}</h3>
                        {plan.description && <p className="text-xs text-muted-foreground mt-0.5">{plan.description}</p>}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-black" style={{ color: plan.color || '#f59e0b' }}>₺{plan.price}</p>
                      <p className="text-[10px] text-muted-foreground">{plan.duration_days || 30} gün</p>
                    </div>
                  </div>
                </div>

                {/* Features */}
                {features.length > 0 && (
                  <div className="px-5 py-3 space-y-1.5">
                    {features.map((f, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                        <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" style={{ color: plan.color || '#f59e0b' }} />
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Action */}
                <div className="px-5 pb-5 pt-2">
                  {isApproved ? (
                    <div className="flex items-center justify-center gap-2 py-2.5 rounded-full bg-green-50 border border-green-200 text-green-700 text-sm font-medium">
                      <CheckCircle2 className="w-4 h-4" /> Aktif Abonelik
                    </div>
                  ) : isPending ? (
                    <div className="flex items-center justify-center gap-2 py-2.5 rounded-full bg-amber-50 border border-amber-200 text-amber-700 text-sm font-medium">
                      <Clock className="w-4 h-4" /> Onay Bekleniyor
                    </div>
                  ) : (
                    <Button
                      className="w-full rounded-full font-semibold"
                      style={{ backgroundColor: plan.color || '#f59e0b' }}
                      onClick={() => applyMutation.mutate(plan)}
                      disabled={applyMutation.isPending}
                    >
                      {applyMutation.isPending ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : null}
                      Başvur
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* My requests history */}
      {myRequests.length > 0 && (
        <div className="mt-8">
          <h3 className="text-sm font-semibold text-foreground mb-3">Başvuru Geçmişim</h3>
          <div className="space-y-2">
            {myRequests.map((req) => (
              <div key={req.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/50 border border-border">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{req.plan_name}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {req.created_date ? new Date(req.created_date).toLocaleDateString("tr-TR") : ""}
                  </p>
                </div>
                <Badge variant={req.status === "approved" ? "default" : req.status === "rejected" ? "destructive" : "secondary"} className="text-[10px]">
                  {req.status === "approved" ? "Onaylandı" : req.status === "rejected" ? "Reddedildi" : "Bekliyor"}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}