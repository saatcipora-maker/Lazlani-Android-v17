import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { UserPlus, UserCheck, MessageCircle, ArrowLeft, Share2, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import HorizontalBookList from "@/components/books/HorizontalBookList";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import FollowListModal from "@/components/profile/FollowListModal";
import { useOptimisticUpdate } from "@/hooks/useOptimisticUpdate";
import UserBadges from "@/components/badges/UserBadges";
import { useBadgeContext } from "@/lib/BadgeContext";
import { useAuth } from "@/lib/AuthContext";

export default function UserProfile() {
  const { email } = useParams();
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState("kitaplar");
  const queryClient = useQueryClient();

  const decodedEmail = decodeURIComponent(email);
  const { autoBadgeMap } = useBadgeContext();
  const autoBadges = autoBadgeMap[decodedEmail] || { is_author: false, is_active_reader: false };

  const { data: profileUser } = useQuery({
    queryKey: ["user-profile-data", decodedEmail],
    queryFn: async () => {
      const users = await base44.entities.User.filter({ email: decodedEmail }, "-created_date", 1);
      return users[0] || null;
    },
  });

  const { data: userBooks = [], isLoading } = useQuery({
    queryKey: ["userBooks", decodedEmail],
    queryFn: () =>
      base44.entities.Book.filter({ author_email: decodedEmail, status: "yayinda" }, "-created_date", 20),
  });

  const { data: followers = [] } = useQuery({
    queryKey: ["followers", decodedEmail],
    queryFn: () => base44.entities.Follow.filter({ following_email: decodedEmail }, "-created_date", 100),
  });

  const { data: following = [] } = useQuery({
    queryKey: ["followingOf", decodedEmail],
    queryFn: () => base44.entities.Follow.filter({ follower_email: decodedEmail }, "-created_date", 100),
  });

  const { data: myFollowing = [] } = useQuery({
    queryKey: ["following", currentUser?.email],
    queryFn: () => base44.entities.Follow.filter({ follower_email: currentUser.email }, "-created_date", 100),
    enabled: !!currentUser?.email,
  });

  const isFollowing = myFollowing.some((f) => f.following_email === decodedEmail);
  const { optimisticFollow, rollback } = useOptimisticUpdate();
  const followRecord = myFollowing.find((f) => f.following_email === decodedEmail);

  const followMutation = useMutation({
    mutationFn: () =>
      base44.entities.Follow.create({
        follower_email: currentUser.email,
        follower_name: currentUser.full_name,
        following_email: decodedEmail,
        following_name: userBooks[0]?.author_name || decodedEmail,
      }),
    onMutate: () => {
      const prevFollowing = optimisticFollow({
        userId: decodedEmail,
        queryKey: ["following", currentUser?.email],
        isFollowing: false,
      });
      const prevFollowers = queryClient.getQueryData(["followers", decodedEmail]) || [];
      queryClient.setQueryData(["followers", decodedEmail], [...prevFollowers, { id: "__optimistic__" }]);
      return { prevFollowing, prevFollowers };
    },
    onError: (_err, _vars, ctx) => {
      rollback(["following", currentUser?.email], ctx?.prevFollowing);
      if (ctx?.prevFollowers) queryClient.setQueryData(["followers", decodedEmail], ctx.prevFollowers);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["following"] });
      queryClient.invalidateQueries({ queryKey: ["followers"] });
      toast.success("Takip edildi!");
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: () => base44.entities.Follow.delete(followRecord.id),
    onMutate: () => {
      const prevFollowing = optimisticFollow({
        userId: decodedEmail,
        queryKey: ["following", currentUser?.email],
        isFollowing: true,
      });
      const prevFollowers = queryClient.getQueryData(["followers", decodedEmail]) || [];
      queryClient.setQueryData(["followers", decodedEmail], prevFollowers.slice(0, -1));
      return { prevFollowing, prevFollowers };
    },
    onError: (_err, _vars, ctx) => {
      rollback(["following", currentUser?.email], ctx?.prevFollowing);
      if (ctx?.prevFollowers) queryClient.setQueryData(["followers", decodedEmail], ctx.prevFollowers);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["following"] });
      queryClient.invalidateQueries({ queryKey: ["followers"] });
      toast.success("Takipten çıkıldı");
    },
  });







  const rawName = profileUser?.display_name || userBooks[0]?.author_name || decodedEmail.split("@")[0];
  const authorName = profileUser?.display_nickname && profileUser?.nickname ? profileUser.nickname : profileUser?.hide_real_name && profileUser?.nickname ? profileUser.nickname : rawName;
  const username = decodedEmail.split("@")[0];
  const isOwnProfile = currentUser?.email === decodedEmail;
  const [followModal, setFollowModal] = useState(null);


  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <button onClick={() => navigate(-1)} className="text-foreground p-1" aria-label="Geri dön">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-4">
          <button className="text-foreground p-1" aria-label="Paylaş">
            <Share2 className="w-5 h-5" />
          </button>
          {isOwnProfile && (
            <Link to="/profile" className="text-foreground p-1">
              <Pencil className="w-5 h-5" />
            </Link>
          )}
        </div>
      </div>

      {/* Cover Photo */}
      <div className="relative h-40 bg-gradient-to-br from-primary/30 via-primary/10 to-accent/20 overflow-hidden">
        {profileUser?.cover_url && (
          <img src={profileUser.cover_url} alt="kapak" className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
      </div>

      {/* Avatar + name */}
      <div className="px-5 -mt-12 pb-5">
        <div className="flex items-end justify-between mb-4">
          <div className="w-24 h-24 rounded-full bg-card flex items-center justify-center border-4 border-background overflow-hidden shadow-xl ring-2 ring-primary/20">
            {profileUser?.avatar_url ? (
              <img src={profileUser.avatar_url} alt="profil" className="w-full h-full object-cover" />
            ) : (
              <span className="text-3xl font-bold text-primary">
                {authorName[0]?.toUpperCase() || "?"}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 mb-1 flex-wrap">
          <h1 className="text-xl font-bold text-foreground">{profileUser?.display_name || authorName}</h1>
          <UserBadges
            manualBadges={{
              has_ozel_badge: profileUser?.has_ozel_badge,
              has_vip: profileUser?.has_vip,
              has_author_badge: profileUser?.has_author_badge,
              has_magazin_badge: profileUser?.has_magazin_badge,
            }}
            autoBadges={autoBadges}
          />
        </div>
        {profileUser?.nickname && profileUser?.display_nickname && (
          <p className="text-xs text-muted-foreground mb-1">Takma Ad: {profileUser.nickname}</p>
        )}
        {!profileUser?.hide_email && (
          <p className="text-xs text-muted-foreground mb-3">@{username}</p>
        )}
        {profileUser?.hide_email && (
          <p className="text-xs text-muted-foreground mb-3">@{username}</p>
        )}

        {profileUser?.bio && (
          <p className="text-sm text-foreground/80 leading-relaxed mb-3">{profileUser.bio}</p>
        )}

        {/* Social links */}
        {(profileUser?.social_twitter || profileUser?.social_instagram || profileUser?.social_wattpad || profileUser?.website) && (
          <div className="flex flex-wrap gap-2 mb-4">
            {profileUser?.social_twitter && <span className="px-2.5 py-1 rounded-full bg-muted text-[10px] font-medium text-foreground">X: {profileUser.social_twitter}</span>}
            {profileUser?.social_instagram && <span className="px-2.5 py-1 rounded-full bg-muted text-[10px] font-medium text-foreground">IG: {profileUser.social_instagram}</span>}
            {profileUser?.social_wattpad && <span className="px-2.5 py-1 rounded-full bg-muted text-[10px] font-medium text-foreground">WP: {profileUser.social_wattpad}</span>}
            {profileUser?.website && <span className="px-2.5 py-1 rounded-full bg-muted text-[10px] font-medium text-foreground">🌐 {profileUser.website}</span>}
          </div>
        )}

        {profileUser?.location && !profileUser?.hide_location && (
          <p className="text-xs text-muted-foreground mb-3">📍 {profileUser.location}</p>
        )}

        {/* Stats Row */}
        <div className="flex items-center gap-1 bg-card rounded-2xl border border-border p-1">
          <button onClick={() => setFollowModal("followers")} className="flex-1 py-3 rounded-xl hover:bg-muted transition-colors text-center">
            <span className="text-lg font-bold text-foreground block">{followers.length}</span>
            <p className="text-[11px] text-muted-foreground font-medium">Takipçi</p>
          </button>
          <div className="w-px h-8 bg-border" />
          <button onClick={() => setFollowModal("following")} className="flex-1 py-3 rounded-xl hover:bg-muted transition-colors text-center">
            <span className="text-lg font-bold text-foreground block">{following.length}</span>
            <p className="text-[11px] text-muted-foreground font-medium">Takip</p>
          </button>
          <div className="w-px h-8 bg-border" />
          <div className="flex-1 py-3 rounded-xl text-center">
            <span className="text-lg font-bold text-foreground block">{userBooks.length}</span>
            <p className="text-[11px] text-muted-foreground font-medium">Kitap</p>
          </div>
        </div>
      </div>

      <FollowListModal
        isOpen={followModal === "followers"}
        title="Takipçiler"
        list={followers}
        nameKey="follower_name"
        onClose={() => setFollowModal(null)}
      />
      <FollowListModal
        isOpen={followModal === "following"}
        title="Takip Edilenler"
        list={following}
        nameKey="following_name"
        onClose={() => setFollowModal(null)}
      />

      {/* Follow / Message buttons */}
      {!isOwnProfile && (
        <div className="flex gap-2 justify-center px-4 mb-2">
          <Button
            variant={isFollowing ? "outline" : "default"}
            className="rounded-full flex-1 max-w-[160px]"
            onClick={() => isFollowing ? unfollowMutation.mutate() : followMutation.mutate()}
            disabled={followMutation.isPending || unfollowMutation.isPending}
          >
            {isFollowing ? (
              <><UserCheck className="w-4 h-4 mr-1" />Takip Ediliyor</>
            ) : (
              <><UserPlus className="w-4 h-4 mr-1" />Takip Et</>
            )}
          </Button>
          <Button
            variant="outline"
            className="rounded-full flex-1 max-w-[160px]"
            onClick={() => navigate(`/messages?to=${decodedEmail}&name=${authorName}`)}
          >
            <MessageCircle className="w-4 h-4 mr-1" />
            Mesaj
          </Button>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-border mt-2">
        <div className="flex px-4">
          {["kitaplar", "oduller"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
                activeTab === tab ? "text-primary" : "text-muted-foreground"
              }`}
            >
              {tab === "kitaplar" ? "Kitaplar" : "Rozetler"}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div className="pt-4">
        {activeTab === "kitaplar" && (
          isLoading ? (
            <div className="flex gap-3 px-4">
              {[1, 2].map((i) => (
                <Skeleton key={i} className="w-40 h-56 rounded-xl flex-shrink-0" />
              ))}
            </div>
          ) : (
            <HorizontalBookList books={userBooks} />
          )
        )}

        {activeTab === "oduller" && (
          <p className="text-center text-muted-foreground text-sm py-12">Henüz ödül yok</p>
        )}
      </div>
    </div>
  );
}