import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { useOnlineUsers } from "@/hooks/useOnlineStatus";
import NewConversation from "@/components/messages/NewConversation";

export default function MessagesNew() {
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const onlineMap = useOnlineUsers();

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <NewConversation
      currentUser={currentUser}
      onlineMap={onlineMap}
      onSelect={(conv) =>
        navigate(
          `/messages/chat/${encodeURIComponent(conv.email)}?name=${encodeURIComponent(conv.name || conv.email)}`,
          { replace: true }
        )
      }
      onClose={() => navigate(-1)}
    />
  );
}