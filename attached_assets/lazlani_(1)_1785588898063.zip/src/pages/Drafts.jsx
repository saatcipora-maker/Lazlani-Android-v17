import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, BookOpen, Edit, Eye, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function Drafts() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: draftBooks = [], isLoading } = useQuery({
    queryKey: ["draftBooks", currentUser?.email],
    queryFn: () =>
      base44.entities.Book.filter(
        { author_email: currentUser.email, status: "taslak" },
        "-created_date",
        50
      ),
    enabled: !!currentUser?.email,
  });

  // For each draft book, we need chapter counts — fetch all user books' chapters
  const { data: allChapters = [] } = useQuery({
    queryKey: ["allMyChapters", currentUser?.email],
    queryFn: async () => {
      const allBooks = await base44.entities.Book.filter({ author_email: currentUser.email }, "-created_date", 50);
      const bookIds = allBooks.map((b) => b.id);
      const chaptersArr = await Promise.all(
        bookIds.map((bid) => base44.entities.Chapter.filter({ book_id: bid }, "order", 100))
      );
      return chaptersArr.flat();
    },
    enabled: !!currentUser?.email,
  });

  const publishMutation = useMutation({
    mutationFn: async (book) => {
      const chapters = allChapters.filter((c) => c.book_id === book.id);
      if (chapters.length === 0) throw new Error("En az 1 bölüm gerekli");
      if (!book.cover_image) throw new Error("Kapak fotoğrafı gerekli");
      if (!book.category) throw new Error("Kategori seçimi gerekli");
      // Publish book and all its chapters
      await base44.entities.Book.update(book.id, { status: "yayinda" });
      await Promise.all(
        chapters
          .filter((c) => c.status === "taslak")
          .map((c) => base44.entities.Chapter.update(c.id, { status: "yayinda" }))
      );
      // Notify followers
      const follows = await base44.entities.Follow.filter({ following_email: currentUser.email }, "-created_date", 200);
      if (follows.length > 0) {
        await Promise.all(
          follows.map((f) =>
            base44.entities.Notification.create({
              receiver_email: f.follower_email,
              sender_name: currentUser.full_name,
              type: "new_book",
              message: `${currentUser.full_name} yeni bir kitap yayınladı: "${book.title}"`,
              book_id: book.id,
              is_read: false,
            })
          )
        );
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["draftBooks"] });
      queryClient.invalidateQueries({ queryKey: ["myBooks"] });
      queryClient.invalidateQueries({ queryKey: ["books"] });
      toast.success("Kitap yayınlandı! Takipçilerinize bildirim gönderildi.");
    },
    onError: (err) => {
      toast.error(err.message || "Yayınlama başarısız");
    },
  });

  const getChapterCount = (bookId) => allChapters.filter((c) => c.book_id === bookId).length;

  const getWarnings = (book) => {
    const warnings = [];
    const chCount = getChapterCount(book.id);
    if (chCount === 0) warnings.push("Bölüm yok");
    if (!book.cover_image) warnings.push("Kapak yok");
    if (!book.category) warnings.push("Kategori yok");
    return warnings;
  };

  return (
    <div className="px-4 py-4">
      <div className="flex items-center gap-3 mb-6">
        <Link to="/profile" className="text-muted-foreground">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-xl font-bold text-foreground">Taslaklarım</h1>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      ) : draftBooks.length === 0 ? (
        <div className="text-center py-16">
          <BookOpen className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">Henüz taslak kitabınız yok</p>
          <Button size="sm" className="mt-4 rounded-full" onClick={() => navigate("/write")}>
            Yeni Kitap Oluştur
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {draftBooks.map((book) => {
            const chapterCount = getChapterCount(book.id);
            const warnings = getWarnings(book);
            const canPublish = warnings.length === 0;

            return (
              <div key={book.id} className="rounded-xl bg-card border border-border p-3">
                <div className="flex items-start gap-3">
                  {/* Cover */}
                  <div className="w-16 h-22 rounded-lg overflow-hidden flex-shrink-0 bg-gradient-to-br from-primary/40 to-primary/20">
                    {book.cover_image ? (
                      <img src={book.cover_image} alt={book.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <BookOpen className="w-5 h-5 text-primary/50" />
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm text-foreground truncate">{book.title}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {chapterCount} bölüm · {book.category || "Kategori yok"}
                    </p>

                    {/* Warnings */}
                    {warnings.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {warnings.map((w) => (
                          <span key={w} className="inline-flex items-center gap-0.5 text-[10px] text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded-full">
                            <AlertCircle className="w-2.5 h-2.5" />
                            {w}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex gap-2 mt-2.5">
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-full text-xs h-7 px-3"
                        onClick={() => navigate(`/edit-book/${book.id}`)}
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Düzenle
                      </Button>
                      <Button
                        size="sm"
                        className="rounded-full text-xs h-7 px-3"
                        disabled={!canPublish || publishMutation.isPending}
                        onClick={() => publishMutation.mutate(book)}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        {canPublish ? "Yayınla" : "Eksik var"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}