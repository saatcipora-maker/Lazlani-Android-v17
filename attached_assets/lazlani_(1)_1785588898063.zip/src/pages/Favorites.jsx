import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Heart, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import { useFavorites } from "@/hooks/useFavorites";
import PullToRefresh from "@/components/ui/PullToRefresh";

function FavoriteRow({ book }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const fav = isFavorite(book.id);

  return (
    <div className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border">
      <Link to={`/book/${book.id}`} className="flex items-center gap-3 flex-1 min-w-0">
        <div className="w-14 h-20 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
          {book.cover_image ? (
            <img src={book.cover_image} alt={book.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary/50" />
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm text-foreground truncate">{book.title}</p>
          <p className="text-xs text-muted-foreground mt-0.5 truncate">{book.author_name}</p>
          {book.category && (
            <span className="inline-block mt-1.5 text-[10px] bg-accent text-accent-foreground px-2 py-0.5 rounded-full">
              {book.category}
            </span>
          )}
        </div>
      </Link>
      <button
        onClick={() => toggleFavorite.mutate({ bookId: book.id, bookTitle: book.title })}
        className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 hover:bg-muted transition-colors"
      >
        <Heart className={`w-5 h-5 ${fav ? "fill-red-500 text-red-500" : "text-muted-foreground"}`} />
      </button>
    </div>
  );
}

export default function Favorites() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["favorite-books-page", user?.email] });
  };

  const { data: favoriteBooks = [], isLoading } = useQuery({
    queryKey: ["favorite-books-page", user?.email],
    queryFn: async () => {
      const favs = await base44.entities.FavoriteBook.filter(
        { user_email: user.email },
        "-created_date",
        100
      );
      const bookIds = favs.map((f) => f.book_id).filter(Boolean);
      if (bookIds.length === 0) return [];
      const allBooks = await base44.entities.Book.filter(
        { id: { $in: bookIds } },
        "-created_date",
        100
      );
      return allBooks;
    },
    enabled: !!user?.email,
  });

  return (
    <PullToRefresh onRefresh={handleRefresh} className="py-4 px-4 space-y-4 pb-8">
      <div className="flex items-center gap-2">
        <Heart className="w-5 h-5 text-red-500" />
        <h1 className="text-lg font-bold text-foreground">Favorilerim</h1>
        <span className="text-xs text-muted-foreground">({favoriteBooks.length})</span>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
      ) : favoriteBooks.length === 0 ? (
        <div className="text-center py-16">
          <Heart className="w-12 h-12 text-muted-foreground/20 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm font-medium">Henüz favori kitabınız yok</p>
          <p className="text-xs text-muted-foreground mt-1">
            Kitap kartlarındaki kalp ikonuna tıklayarak favorilerinize ekleyin
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {favoriteBooks.map((book) => (
            <FavoriteRow key={book.id} book={book} />
          ))}
        </div>
      )}
    </PullToRefresh>
  );
}