import { useState, useEffect, useRef } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, BookOpen, Heart, Star, Eye, ChevronRight, CheckCircle2, Flag, Bookmark, BookmarkCheck, MessageCircle, X, List, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Skeleton } from "@/components/ui/skeleton";
import SimilarBooks from "@/components/bookdetail/SimilarBooks";
import BookComments from "@/components/bookdetail/BookComments";
import BookReviews from "@/components/bookdetail/BookReviews";
import PullToRefresh from "@/components/ui/PullToRefresh";
import ChapterDiscussion from "@/components/bookdetail/ChapterDiscussion";
import DownloadBookButton from "@/components/bookdetail/DownloadBookButton";
import ShareButtons from "@/components/bookdetail/ShareButtons";
import ReadingListPanel from "@/components/reading/ReadingListPanel";
import BookStatsBar from "@/components/books/BookStatsBar";
import { recalcLibraryCount } from "@/lib/bookStats";
import { format } from "date-fns";
import { tr } from "date-fns/locale";

const categoryLabels = {
  roman: "Roman", fantastik: "Fantastik", bilim_kurgu: "Bilim Kurgu",
  gerilim: "Gerilim / Polisiye", romantik: "Romantik", korku: "Korku",
  macera: "Macera", tarih: "Tarih", klasik: "Klasik", dram: "Dram",
  genc_yetiskin: "Genç Yetişkin", diger: "Diğer",
};

export default function BookDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [currentUser, setCurrentUser] = useState(null);
  const [showFinishConfirm, setShowFinishConfirm] = useState(false);
  const [showCoverStats, setShowCoverStats] = useState(false);
  const [showReadingList, setShowReadingList] = useState(false);
  const readCountIncrmented = useRef(false);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: book, isLoading } = useQuery({
    queryKey: ["book", id],
    queryFn: () => base44.entities.Book.filter({ id }, "-created_date", 1).then((r) => r[0]),
  });

  // Real-time book updates
  useEffect(() => {
    const unsub = base44.entities.Book.subscribe((event) => {
      if (event.id === id) {
        queryClient.invalidateQueries({ queryKey: ["book", id] });
      }
    });
    return unsub;
  }, [id]);

  // Increment read count only once per unique user
  useEffect(() => {
    if (!book || !currentUser?.email || readCountIncrmented.current) return;
    readCountIncrmented.current = true;
    base44.entities.ReadHistory.filter({ user_email: currentUser.email, book_id: id }, "-created_date", 1)
      .then((existing) => {
        if (existing.length === 0) {
          // First time this user reads this book — increment count
          base44.entities.Book.update(id, { read_count: (book.read_count || 0) + 1 }).catch(() => {});
        }
      })
      .catch(() => {});
  }, [book, currentUser?.email]);

  const { data: chapters = [] } = useQuery({
    queryKey: ["chapters", id],
    queryFn: () => base44.entities.Chapter.filter({ book_id: id, status: "yayinda" }, "order", 50),
    enabled: !!id,
  });

  // Fetch all comments (book-level + per-chapter) in a single batch query
  const chapterIds = chapters.map((c) => c.id);
  const { data: allChapterComments = [] } = useQuery({
    queryKey: ["all-chapter-comments", id, chapterIds.join(",")],
    queryFn: () => base44.entities.ChapterComment.filter(
      { chapter_id: { $in: [...chapterIds, `book_${id}`] } },
      "-created_date",
      500
    ),
    enabled: chapterIds.length > 0,
  });

  // Also keep book-level comments query for when there are no chapters yet
  const { data: bookComments = [] } = useQuery({
    queryKey: ["book-comments-count", id],
    queryFn: () => base44.entities.ChapterComment.filter({ chapter_id: `book_${id}` }, "-created_date", 200),
    enabled: !!id && chapterIds.length === 0,
  });

  // Build a map of chapter_id -> comment count
  const chapterCommentCountMap = {};
  allChapterComments.forEach((c) => {
    if (c.chapter_id && c.chapter_id !== `book_${id}`) {
      chapterCommentCountMap[c.chapter_id] = (chapterCommentCountMap[c.chapter_id] || 0) + 1;
    }
  });

  const bookLevelComments = chapterIds.length > 0
    ? allChapterComments.filter(c => c.chapter_id === `book_${id}`).length
    : bookComments.length;
  const chapterLevelComments = allChapterComments.filter(c => c.chapter_id !== `book_${id}`).length;
  const totalCommentCount = bookLevelComments + chapterLevelComments;

  // Real-time book-level likes (unique per user)
  const { data: bookLikes = [] } = useQuery({
    queryKey: ["book-likes", id],
    queryFn: () => base44.entities.BookLike.filter({ book_id: id }, "-created_date", 500),
    enabled: !!id,
  });

  // Real-time unique reads (unique per user per chapter)
  const { data: chapterReads = [] } = useQuery({
    queryKey: ["book-reads", id],
    queryFn: () => base44.entities.ChapterRead.filter({ book_id: id }, "-created_date", 500),
    enabled: !!id,
  });

  const totalLikeCount = bookLikes.length;
  const totalReadCount = chapterReads.length;
  const isBookLiked = bookLikes.some((l) => l.user_email === currentUser?.email);

  useEffect(() => {
    const unsub1 = base44.entities.ChapterComment.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["book-comments-count", id] });
      queryClient.invalidateQueries({ queryKey: ["all-chapter-comments", id] });
    });
    const unsub2 = base44.entities.BookLike.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["book-likes", id] });
    });
    const unsub3 = base44.entities.ChapterRead.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["book-reads", id] });
    });
    const unsub4 = base44.entities.BookReview.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["book-reviews", id] });
    });
    return () => { unsub1(); unsub2(); unsub3(); unsub4(); };
  }, [id]);

  const recommendMutation = useMutation({
    mutationFn: () => base44.entities.Book.update(id, { recommendation_status: "pending" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      toast.success("Kitabınız öneri için gönderildi!");
    },
  });

  const featureMutation = useMutation({
    mutationFn: () => base44.entities.Book.update(id, { feature_status: "pending" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      toast.success("Kitabınız öne çıkarma için gönderildi! Yönetici onayından sonra vitrinde görünecek.");
    },
  });

  const bookLikeMutation = useMutation({
    mutationFn: async () => {
      if (isBookLiked) {
        const myLike = bookLikes.find((l) => l.user_email === currentUser.email);
        if (myLike) await base44.entities.BookLike.delete(myLike.id);
      } else {
        await base44.entities.BookLike.create({
          book_id: id,
          user_email: currentUser.email,
          user_name: currentUser.full_name || "",
        });
      }
    },
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ["book-likes", id] });
      const prev = queryClient.getQueryData(["book-likes", id]) || [];
      if (isBookLiked) {
        queryClient.setQueryData(["book-likes", id], prev.filter((l) => l.user_email !== currentUser?.email));
      } else {
        queryClient.setQueryData(["book-likes", id], [...prev, { user_email: currentUser?.email, book_id: id, id: "__optimistic__" }]);
      }
      return { prev };
    },
    onError: (_e, _v, ctx) => { if (ctx?.prev) queryClient.setQueryData(["book-likes", id], ctx.prev); },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["book-likes", id] }),
  });

  const { data: savedBooks = [] } = useQuery({
    queryKey: ["saved-books", currentUser?.email, id],
    queryFn: () => base44.entities.SavedBook.filter({ user_email: currentUser.email, book_id: id }, "-created_date", 1),
    enabled: !!currentUser?.email,
  });

  const isSaved = savedBooks.length > 0;

  // Fetch library count (how many users saved this book)
  const { data: libraryCount = 0 } = useQuery({
    queryKey: ["library-count", id],
    queryFn: () => base44.entities.SavedBook.filter({ book_id: id }, "-created_date", 500).then((r) => r.length),
    enabled: !!id,
  });

  // Sync computed stats to Book entity so cards can display them
  useEffect(() => {
    if (!book || !id) return;
    if ((book.like_count || 0) !== totalLikeCount) {
      base44.entities.Book.update(id, { like_count: totalLikeCount }).catch(() => {});
    }
  }, [totalLikeCount, book?.like_count, id]);

  useEffect(() => {
    if (!book || !id) return;
    if ((book.read_count || 0) !== totalReadCount) {
      base44.entities.Book.update(id, { read_count: totalReadCount }).catch(() => {});
    }
  }, [totalReadCount, book?.read_count, id]);

  useEffect(() => {
    if (!book || !id) return;
    if ((book.comment_count || 0) !== totalCommentCount) {
      base44.entities.Book.update(id, { comment_count: totalCommentCount }).catch(() => {});
    }
  }, [totalCommentCount, book?.comment_count, id]);

  useEffect(() => {
    if (!book || !id || libraryCount === 0) return;
    if ((book.library_count || 0) !== libraryCount) {
      base44.entities.Book.update(id, { library_count: libraryCount }).catch(() => {});
    }
  }, [libraryCount, book?.library_count, id]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (isSaved) {
        await base44.entities.SavedBook.delete(savedBooks[0].id);
      } else {
        await base44.entities.SavedBook.create({ user_email: currentUser.email, book_id: id, book_title: book.title });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["saved-books", currentUser?.email, id] });
      queryClient.invalidateQueries({ queryKey: ["library-count", id] });
      recalcLibraryCount(id);
      toast.success(isSaved ? "Kaydedilenlerden çıkarıldı" : "Kitap kaydedildi!");
    },
  });

  const finishMutation = useMutation({
    mutationFn: () => base44.entities.Book.update(id, { completion_status: "tamamlandi" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      setShowFinishConfirm(false);
      toast.success("Kitabınız tamamlandı olarak işaretlendi ve yönetici onayına gönderildi!");
    },
  });

  if (isLoading) {
    return (
      <div className="p-4 space-y-4">
        <Skeleton className="w-full h-72 rounded-xl" />
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-4 w-32" />
      </div>
    );
  }

  if (!book) {
    return <div className="p-4 pt-8 text-center text-muted-foreground">Kitap bulunamadı</div>;
  }

  const isOwner = currentUser?.email === book.author_email;
  const canRecommend = isOwner && book.recommendation_status === "none";
  const canFinish = isOwner && book.status === "yayinda" && chapters.length > 0
    && (!book.completion_status || book.completion_status === "devam_ediyor");

  const handleRefresh = async () => {
    await Promise.all([
    queryClient.invalidateQueries({ queryKey: ["book", id] }),
    queryClient.invalidateQueries({ queryKey: ["chapters", id] }),
    queryClient.invalidateQueries({ queryKey: ["book-comments-count", id] }),
    queryClient.invalidateQueries({ queryKey: ["all-chapter-comments", id] }),
    queryClient.invalidateQueries({ queryKey: ["book-likes", id] }),
    queryClient.invalidateQueries({ queryKey: ["book-reads", id] }),
    queryClient.invalidateQueries({ queryKey: ["library-count", id] }),
    ]);
  };

  return (
    <PullToRefresh onRefresh={handleRefresh} className="pb-8">
      {/* Cover */}
      <div className="relative h-80 w-full cursor-pointer" onClick={() => setShowCoverStats(true)}>
        {book.cover_image ? (
          <img src={book.cover_image} alt={book.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/60 to-primary/20 flex items-center justify-center">
            <BookOpen className="w-16 h-16 text-primary-foreground/50" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        <button
          onClick={(e) => { e.stopPropagation(); navigate(-1); }}
          className="absolute top-4 left-4 w-9 h-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center text-white"
          aria-label="Geri"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        {/* Approved stamp on cover */}
        {book.is_approved && (
          <div className="absolute top-4 right-4 bg-green-500 text-white text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 shadow-lg">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Onaylandı
          </div>
        )}
      </div>

      {/* Cover Stats Popup */}
      {showCoverStats && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={() => setShowCoverStats(false)}>
          <div className="bg-card border border-border rounded-2xl p-6 mx-6 w-full max-w-sm shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">{book.title}</h3>
              <button onClick={() => setShowCoverStats(false)} className="text-muted-foreground hover:text-foreground" aria-label="Kapat">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="flex flex-col items-center gap-1 p-3 rounded-xl bg-muted">
                <Eye className="w-5 h-5 text-primary" />
                <span className="text-xl font-bold text-foreground">{totalReadCount}</span>
                <span className="text-[10px] text-muted-foreground">Okuma</span>
              </div>
              <div className="flex flex-col items-center gap-1 p-3 rounded-xl bg-muted">
                <Heart className="w-5 h-5 text-red-500" />
                <span className="text-xl font-bold text-foreground">{totalLikeCount}</span>
                <span className="text-[10px] text-muted-foreground">Beğeni</span>
              </div>
              <div className="flex flex-col items-center gap-1 p-3 rounded-xl bg-muted">
                <MessageCircle className="w-5 h-5 text-blue-500" />
                <span className="text-xl font-bold text-foreground">{totalCommentCount}</span>
                <span className="text-[10px] text-muted-foreground">Yorum</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Info */}
      <div className="px-4 -mt-16 relative z-10">
        <h1 className="font-display text-2xl font-bold text-foreground">{book.title}</h1>
        <Link to={`/user/${encodeURIComponent(book.author_email)}`} className="text-sm text-primary mt-1 inline-block hover:underline">
          {book.author_name}
        </Link>

        <div className="flex flex-wrap items-center gap-2 mt-3">
          {book.category && (
            <Badge variant="secondary" className="text-xs">
              {categoryLabels[book.category] || book.category}
            </Badge>
          )}
          {book.is_approved && (
            <Badge className="text-xs bg-green-100 text-green-700 border-green-200 border">
              ✓ Onaylanmış
            </Badge>
          )}
          {book.completion_status === "tamamlandi" && (
            <Badge variant="outline" className="text-xs border-orange-300 text-orange-600">
              ⏳ Onay Bekliyor
            </Badge>
          )}
          {book.created_date && (
            <span className="text-[11px] text-muted-foreground">
              📅 {format(new Date(book.created_date), "dd MMM yyyy", { locale: tr })}
            </span>
          )}
        </div>

        <BookStatsBar book={book} totalReads={totalReadCount} totalLikes={totalLikeCount} totalComments={totalCommentCount} libraryCount={libraryCount} />

        {/* Action buttons */}
        <div className="flex flex-wrap gap-2 mt-4">
          {chapters.length > 0 && (
            <Link to={`/read/${id}/${chapters[0].id}`} className="flex-1 min-w-[120px]">
              <Button className="w-full rounded-full font-semibold">
                <BookOpen className="w-4 h-4 mr-2" />
                Okumaya Başla
              </Button>
            </Link>
          )}
          {currentUser && !isOwner && (
            <Button
              variant="outline"
              className={`rounded-full ${isBookLiked ? "border-red-500 text-red-500 bg-red-500/5" : ""}`}
              onClick={() => bookLikeMutation.mutate()}
              disabled={bookLikeMutation.isPending}
            >
              <Heart className={`w-4 h-4 mr-1 ${isBookLiked ? "fill-current" : ""}`} />
              {isBookLiked ? "Beğenildi" : "Beğen"}
            </Button>
          )}
          {currentUser && !isOwner && (
            <Button
              variant="outline"
              className={`rounded-full ${isSaved ? "border-primary text-primary bg-primary/5" : ""}`}
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending}
            >
              {isSaved ? <BookmarkCheck className="w-4 h-4 mr-1" /> : <Bookmark className="w-4 h-4 mr-1" />}
              {isSaved ? "Kaydedildi" : "Kaydet"}
            </Button>
          )}
          {chapters.length > 0 && (
            <DownloadBookButton bookId={id} bookTitle={book.title} />
          )}
          {currentUser && (
            <Button
              variant="outline"
              className="rounded-full"
              onClick={() => setShowReadingList(true)}
            >
              <List className="w-4 h-4 mr-1" />
              Listeye Ekle
            </Button>
          )}
          <ShareButtons book={book} />
          {canRecommend && (
            <Button
              variant="outline"
              className="rounded-full border-primary text-primary hover:bg-primary hover:text-primary-foreground"
              onClick={() => recommendMutation.mutate()}
              disabled={recommendMutation.isPending}
            >
              <Star className="w-4 h-4 mr-1" />
              Öner
            </Button>
          )}
          {isOwner && book.feature_status === "none" && (
            <Button
              variant="outline"
              className="rounded-full border-accent text-accent hover:bg-accent hover:text-accent-foreground"
              onClick={() => featureMutation.mutate()}
              disabled={featureMutation.isPending}
            >
              <Sparkles className="w-4 h-4 mr-1" />
              Öne Çıkar
            </Button>
          )}
          {book.feature_status === "pending" && isOwner && (
            <Badge variant="secondary" className="flex items-center h-9 px-3">Vitrin Beklemede</Badge>
          )}
          {book.feature_status === "approved" && isOwner && (
            <Badge className="flex items-center h-9 px-3 bg-accent/10 text-accent">Vitrinde ✓</Badge>
          )}
          {canFinish && !showFinishConfirm && (
            <Button
              variant="outline"
              className="rounded-full border-orange-400 text-orange-600 hover:bg-orange-50"
              onClick={() => setShowFinishConfirm(true)}
            >
              <Flag className="w-4 h-4 mr-1" />
              Bitti
            </Button>
          )}
          {book.recommendation_status === "pending" && isOwner && (
            <Badge variant="secondary" className="flex items-center h-9 px-3">Öneri Beklemede</Badge>
          )}
          {book.recommendation_status === "approved" && isOwner && (
            <Badge className="flex items-center h-9 px-3 bg-primary/10 text-primary">Önerildi ✓</Badge>
          )}
        </div>

        {/* Finish confirm */}
        {showFinishConfirm && (
          <div className="mt-3 p-4 rounded-xl bg-orange-50 border border-orange-200">
            <p className="text-sm font-semibold text-orange-800 mb-1">Kitabı tamamlamak istiyor musunuz?</p>
            <p className="text-xs text-orange-600 mb-3">Bu işlem geri alınamaz. Kitap yönetici onayına gönderilecek.</p>
            <div className="flex gap-2">
              <Button
                size="sm"
                className="rounded-full flex-1 bg-orange-500 hover:bg-orange-600"
                onClick={() => finishMutation.mutate()}
                disabled={finishMutation.isPending}
              >
                Onayla
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="rounded-full flex-1"
                onClick={() => setShowFinishConfirm(false)}
              >
                Vazgeç
              </Button>
            </div>
          </div>
        )}

        {book.description && (
          <p className="text-sm text-muted-foreground mt-5 leading-relaxed">{book.description}</p>
        )}

        {/* Chapters */}
        <div className="mt-6">
          <h3 className="font-semibold text-foreground mb-3">Bölümler ({chapters.length})</h3>
          <div className="space-y-2">
            {chapters.map((chapter, idx) => (
              <Link
                key={chapter.id}
                to={`/read/${id}/${chapter.id}`}
                className="flex items-center justify-between p-3 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center text-xs font-bold text-accent-foreground">
                    {idx + 1}
                  </span>
                  <span className="text-sm font-medium text-foreground">{chapter.title}</span>
                </div>
                <div className="flex items-center gap-2">
                  {chapterCommentCountMap[chapter.id] > 0 && (
                    <span className="flex items-center gap-0.5 text-xs text-muted-foreground">
                      <MessageCircle className="w-3 h-3" />
                      {chapterCommentCountMap[chapter.id]}
                    </span>
                  )}
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </Link>
            ))}
            {chapters.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">Henüz bölüm eklenmemiş</p>
            )}
          </div>
        </div>

        {/* Chapter Discussions */}
        <ChapterDiscussion chapters={chapters} bookId={id} currentUser={currentUser} />

        {/* Similar Books */}
        <SimilarBooks category={book.category} currentBookId={id} />

        {/* Reviews with rating */}
        <BookReviews bookId={id} currentUser={currentUser} />

        {/* Comments */}
        <BookComments bookId={id} currentUser={currentUser} />

      </div>

      {/* Reading List Panel */}
      {showReadingList && currentUser && (
        <ReadingListPanel
          bookId={id}
          currentUser={currentUser}
          onClose={() => setShowReadingList(false)}
        />
      )}
    </PullToRefresh>
  );
}