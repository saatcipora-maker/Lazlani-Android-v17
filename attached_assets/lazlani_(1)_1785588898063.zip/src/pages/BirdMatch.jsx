import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { generateChapter, getRank } from "@/lib/gameData";
import { AnimatePresence, motion } from "framer-motion";

import GameHUD from "@/components/game/GameHUD";
import GameMenu from "@/components/game/GameMenu";
import ChapterSelect from "@/components/game/ChapterSelect";
import GameBoard from "@/components/game/GameBoard";
import DailyQuests from "@/components/game/DailyQuests";
import Leaderboard from "@/components/game/Leaderboard";
import EggHatchery from "@/components/game/EggHatchery";
import BirdCollection from "@/components/game/BirdCollection";
import GameOverModal from "@/components/game/GameOverModal";
import ChapterCompleteModal from "@/components/game/ChapterCompleteModal";

export default function BirdMatch() {
  const [view, setView] = useState("menu");
  const [activeChapter, setActiveChapter] = useState(null);
  const [gameResult, setGameResult] = useState(null); // "win" | "lose_time" | "lose_moves"
  const [chapterReward, setChapterReward] = useState(null);
  const queryClient = useQueryClient();

  // Get current user
  const { data: currentUser } = useQuery({
    queryKey: ["current-user-game"],
    queryFn: () => base44.auth.me(),
  });

  // Get or create game profile
  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ["game-profile", currentUser?.email],
    queryFn: () => base44.entities.GameProfile.filter({ user_email: currentUser.email }),
    enabled: !!currentUser?.email,
  });

  const profile = profiles[0];

  // Create profile if doesn't exist
  const createProfile = useMutation({
    mutationFn: () =>
      base44.entities.GameProfile.create({
        user_email: currentUser.email,
        user_name: currentUser.full_name || currentUser.email.split("@")[0],
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["game-profile"] }),
  });

  useEffect(() => {
    if (currentUser?.email && !isLoading && profiles.length === 0) {
      createProfile.mutate();
    }
  }, [currentUser, isLoading, profiles.length]);

  // Reset daily quests if new day
  useEffect(() => {
    if (!profile) return;
    const today = new Date().toISOString().slice(0, 10);
    if (profile.daily_reset_date !== today) {
      base44.entities.GameProfile.update(profile.id, {
        daily_matches: 0,
        daily_chapters: 0,
        daily_coins_earned: 0,
        daily_special_bird: 0,
        daily_reset_date: today,
      });
      queryClient.invalidateQueries({ queryKey: ["game-profile"] });
    }
  }, [profile]);

  const updateProfile = useMutation({
    mutationFn: (data) => base44.entities.GameProfile.update(profile.id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["game-profile"] }),
  });

  const handleStartChapter = (chapter) => {
    setActiveChapter(chapter);
    setGameResult(null);
    setChapterReward(null);
    setView("playing");
  };

  const handleMatchComplete = ({ combo, multiplier }) => {
    if (!activeChapter || !profile) return;
    const coins = activeChapter.coinReward * multiplier;
    const xp = activeChapter.xpReward * multiplier;
    const newXp = (profile.xp || 0) + xp;
    const newLevel = Math.floor(newXp / 200) + 1;
    const newRank = getRank(newXp);
    const newChapter = Math.max(profile.current_chapter || 1, activeChapter.num + 1);

    setChapterReward({ coins, xp, combo, multiplier });
    setGameResult("win");

    updateProfile.mutate({
      coins: (profile.coins || 0) + coins,
      xp: newXp,
      level: newLevel,
      rank: newRank.id,
      current_chapter: newChapter,
      total_matches: (profile.total_matches || 0) + activeChapter.matchCount,
      best_combo: Math.max(profile.best_combo || 0, combo),
      daily_matches: (profile.daily_matches || 0) + activeChapter.matchCount,
      daily_chapters: (profile.daily_chapters || 0) + 1,
      daily_coins_earned: (profile.daily_coins_earned || 0) + coins,
    });
  };

  const handleGameOver = (reason) => {
    setGameResult(reason === "time" ? "lose_time" : "lose_moves");
  };

  const handleUsePower = (powerKey) => {
    if (!profile) return;
    const current = profile[powerKey] || 0;
    if (current > 0) {
      updateProfile.mutate({ [powerKey]: current - 1 });
    }
  };

  const handleHatchEgg = (rarity, birdKey) => {
    if (!profile) return;
    const eggField = `eggs_${rarity}`;
    const currentEggs = profile[eggField] || 0;
    const owned = [...(profile.owned_birds || [])];
    if (!owned.includes(birdKey)) {
      owned.push(birdKey);
    }
    updateProfile.mutate({
      [eggField]: Math.max(0, currentEggs - 1),
      owned_birds: owned,
      daily_special_bird: (profile.daily_special_bird || 0) + 1,
    });
  };

  const handleCloseResult = () => {
    setGameResult(null);
    setChapterReward(null);
    setView("chapters");
  };

  const zone = activeChapter?.zone;

  if (!currentUser || isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gradient-to-b from-green-900 to-emerald-800">
        <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className={`flex flex-col h-full bg-gradient-to-b ${
      view === "playing" && zone ? zone.bg : "from-green-900 to-emerald-800"
    } overflow-hidden`}>
      <GameHUD profile={profile} view={view} onChangeView={setView} />

      <div className="flex-1 overflow-y-auto px-3 py-4 relative">
        <AnimatePresence mode="wait">
          {view === "menu" && (
            <motion.div key="menu" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <GameMenu profile={profile} onChangeView={setView} />
            </motion.div>
          )}
          {view === "chapters" && (
            <motion.div key="chapters" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ChapterSelect currentChapter={profile?.current_chapter || 1} onSelect={handleStartChapter} />
            </motion.div>
          )}
          {view === "playing" && activeChapter && (
            <motion.div key="playing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center">
              <GameBoard
                chapter={activeChapter}
                profile={profile}
                onMatchComplete={handleMatchComplete}
                onGameOver={handleGameOver}
                onUsepower={handleUsePower}
              />
            </motion.div>
          )}
          {view === "daily" && (
            <motion.div key="daily" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <DailyQuests profile={profile} />
            </motion.div>
          )}
          {view === "leaderboard" && (
            <motion.div key="lb" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <Leaderboard />
            </motion.div>
          )}
          {view === "eggs" && (
            <motion.div key="eggs" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <EggHatchery profile={profile} onHatch={handleHatchEgg} />
            </motion.div>
          )}
          {view === "collection" && (
            <motion.div key="col" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <BirdCollection profile={profile} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Modals */}
      {gameResult === "win" && chapterReward && (
        <ChapterCompleteModal reward={chapterReward} chapter={activeChapter} onClose={handleCloseResult} />
      )}
      {(gameResult === "lose_time" || gameResult === "lose_moves") && (
        <GameOverModal reason={gameResult} onRetry={() => { setGameResult(null); setActiveChapter({ ...activeChapter }); }} onClose={handleCloseResult} />
      )}
    </div>
  );
}