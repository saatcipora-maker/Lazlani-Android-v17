import { useState, useCallback } from "react";
import { ArrowLeft, ScrollText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { useCommunityPresence } from "@/components/community/CommunityPresenceTracker";
import NicknameGate from "@/components/community/NicknameGate";
import CommunityChat from "@/components/community/CommunityChat";
import OnlinePanel from "@/components/community/OnlinePanel";
import UserActionSheet from "@/components/community/UserActionSheet";
import CommunityRules from "@/components/community/CommunityRules";

export default function Community() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.role === "admin";
  const [nickname, setNickname] = useState(null);
  const [showOnlinePanel, setShowOnlinePanel] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  const { activeUsers, getUserRole } = useCommunityPresence(nickname);

  const existingNicknames = activeUsers.
  filter((u) => u.user_email !== user?.email).
  map((u) => u.user_name).
  filter(Boolean);

  const handleEnter = useCallback((name) => {
    setNickname(name);
  }, []);

  const handleUserTap = (u) => {
    if (isAdmin) setSelectedUser(u);
  };

  // Show nickname gate if not entered (admin bypasses)
  if (!nickname) {
    return (
      <NicknameGate
        onEnter={handleEnter}
        existingNicknames={existingNicknames}
        isAdmin={isAdmin}
        adminName={isAdmin ? user?.full_name || user?.email?.split("@")[0] : null} />);


  }

  return (
    <div className="flex flex-col overflow-hidden" style={{ height: "calc(100svh - 80px)", paddingTop: "env(safe-area-inset-top)" }}>
      {/* Header */}
      <div className="flex items-center justify-between flex-shrink-0 pr-1 ml-1"
      style={{ background: "rgba(30,12,45,0.7)", borderBottom: "1px solid rgba(200,140,255,0.06)", backdropFilter: "blur(20px)" }}>
        <div className="flex items-center gap-2.5">
          <button onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-transform"
          style={{ background: "rgba(255,255,255,0.04)" }}>
            <ArrowLeft className="w-4.5 h-4.5 text-muted-foreground" />
          </button>
          <div>
            <h1 className="text-sm font-heading font-bold text-foreground leading-tight">Topluluk Odası</h1>
            <p className="text-[9px] text-muted-foreground">{nickname} olarak katıldınız</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Rules button */}
          <button
            onClick={() => setShowRules(true)}
            className="w-8 h-8 rounded-full flex items-center justify-center active:scale-90 transition-transform"
            style={{ background: "rgba(130,60,210,0.08)", border: "1px solid rgba(130,60,210,0.12)" }}>
            <ScrollText className="w-3.5 h-3.5 text-primary" />
          </button>

          {/* Online count */}
          <button
            onClick={() => setShowOnlinePanel(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full active:scale-95 transition-transform"
            style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.15)" }}>
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] font-bold text-green-400">Çevrimiçi ({activeUsers.length + 1})</span>
          </button>
        </div>
      </div>

      {/* Chat */}
      <CommunityChat getUserRole={getUserRole} nickname={nickname} />

      {/* Online panel */}
      <OnlinePanel
        open={showOnlinePanel}
        onClose={() => setShowOnlinePanel(false)}
        activeUsers={activeUsers}
        onUserTap={handleUserTap} />
      

      {/* Community rules */}
      <CommunityRules open={showRules} onClose={() => setShowRules(false)} />

      {/* Admin user action sheet */}
      {selectedUser &&
      <UserActionSheet
        targetUser={selectedUser}
        userRole={getUserRole(selectedUser.user_email)}
        onClose={() => setSelectedUser(null)} />

      }
    </div>);

}