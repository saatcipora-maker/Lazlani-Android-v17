import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Plus, BookOpen, Edit, Trash2, ChevronRight, FileText, Eye } from "lucide-react";
import { Link } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import BookForm from "@/components/write/BookForm";
import { toast } from "sonner";

const statusLabels = { taslak: "Taslak", yayinda: "Yayında" };
const statusColors = { taslak: "secondary", yayinda: "default" };

export default function WriteBook() {
  const { user: currentUser } = useAuth();
  const [showNewBook, setShowNewBook] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const queryClient = useQueryClient();

  const { data: myBooks = [], isLoading } = useQuery({
    queryKey: ["myBooks", currentUser?.email],
    queryFn: () =>
      base44.entities.Book.filter({ author_email: currentUser.email }, "-created_date", 50),
    enabled: !!currentUser?.email,
  });

  const deleteMutation = useMutation({
    mutationFn: (bookId) => base44.entities.Book.delete(bookId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myBooks"] });
      toast.success("Kitap silindi");
    },
  });

  const filteredBooks = myBooks.filter((b) => {
    if (activeTab === "draft") return b.status === "taslak";
    if (activeTab === "published") return b.status === "yayinda";
    return true;
  });

  const draftCount = myBooks.filter((b) => b.status === "taslak").length;
  const pubCount = myBooks.filter((b) => b.status === "yayinda").length;

  return (
    <div className="flex flex-col h-full animate-fade-in-up">
      {/* Header */}
      <div className="px-4 pt-5 pb-3 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-heading font-bold text-foreground">Kitaplarım</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{myBooks.length} eser · Yaratıcı yolculuğun</p>
        </div>
        <Dialog open={showNewBook} onOpenChange={setShowNewBook}>
          <DialogTrigger asChild>
            <Button size="sm" className="rounded-full gap-1.5 shadow-lg shadow-primary/20">
              <Plus className="w-4 h-4" />
              Yeni Kitap
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Yeni Kitap Oluştur</DialogTitle>
            </DialogHeader>
            <BookForm
              user={currentUser}
              onSuccess={() => {
                setShowNewBook(false);
                queryClient.invalidateQueries({ queryKey: ["myBooks"] });
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Tab filter */}
      <div className="flex gap-2 px-4 mb-4">
        {[
          { id: "all", label: `Tümü (${myBooks.length})` },
          { id: "draft", label: `Taslak (${draftCount})` },
          { id: "published", label: `Yayında (${pubCount})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3.5 py-2 rounded-full text-xs font-medium transition-all ${
              activeTab === tab.id
                ? "bg-foreground text-background shadow-sm"
                : "glass-card text-muted-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Shortcut to Drafts page */}
      {draftCount > 0 && activeTab !== "published" && (
        <Link to="/drafts" className="mx-4 mb-3">
          <div className="flex items-center gap-3 p-3.5 rounded-2xl gold-glass active:scale-[0.98] transition-transform">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(240,160,80,0.15)" }}>
              <FileText className="w-4 h-4 text-accent" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-foreground">{draftCount} taslak kitabınız var</p>
              <p className="text-[10px] text-muted-foreground">Tamamlayıp yayınlamak için tıklayın</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </div>
        </Link>
      )}

      {/* Book list */}
      <div className="flex-1 overflow-y-auto px-4 pb-6">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 rounded-2xl" />
            ))}
          </div>
        ) : filteredBooks.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full glass-card flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-7 h-7 text-muted-foreground/40" />
            </div>
            <p className="text-foreground text-sm mb-1 font-medium">
              {activeTab === "draft" ? "Taslak kitabınız yok" : activeTab === "published" ? "Yayınlanan kitabınız yok" : "Henüz kitabınız yok"}
            </p>
            <p className="text-muted-foreground/60 text-xs">İlk eserinizi oluşturmaya başlayın</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredBooks.map((book) => (
              <div
                key={book.id}
                className="flex items-center gap-3.5 p-3.5 rounded-2xl glass-card hover:border-primary/20 transition-all active:scale-[0.98] premium-card"
              >
                {/* Cover */}
                <div className="w-16 h-22 rounded-xl overflow-hidden flex-shrink-0 shadow-md">
                  {book.cover_image ? (
                    <img src={book.cover_image} alt={book.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, hsl(270,55%,50%), hsl(24,80%,50%))" }}>
                      <BookOpen className="w-5 h-5 text-white/50" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm text-foreground truncate">{book.title}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                    {book.description || "Açıklama yok"}
                  </p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={statusColors[book.status]} className="text-[10px]">
                      {statusLabels[book.status]}
                    </Badge>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-1.5">
                  <Link to={`/edit-book/${book.id}`}>
                    <Button variant="outline" size="sm" className="rounded-full h-8 w-8 p-[6px]" aria-label="Kitabı düzenle">
                      <Edit className="w-3.5 h-3.5" />
                    </Button>
                  </Link>
                  {book.status === "taslak" && (
                    <Link to="/drafts">
                      <Button size="sm" className="rounded-full h-8 w-8 p-[6px]" aria-label="Taslakları görüntüle">
                        <Eye className="w-3.5 h-3.5" />
                      </Button>
                    </Link>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="rounded-full h-8 w-8 p-[6px] text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={() => deleteMutation.mutate(book.id)}
                    aria-label="Kitabı sil"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}