import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Link } from "react-router-dom";
import { ArrowLeft, ShoppingCart, Trash2, CreditCard, Star, Award, Zap, Copy, CheckCircle2, Crown, BookOpen, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

// IBAN bilgileri AppSettings'den çekilir

export default function Cart() {
  const { user: currentUser } = useAuth();
  const [payingItemId, setPayingItemId] = useState(null);
  const [paidItemId, setPaidItemId] = useState(null);
  const queryClient = useQueryClient();

  const { data: appSettings = [] } = useQuery({
    queryKey: ["app-settings"],
    queryFn: () => base44.entities.AppSettings.list("-created_date", 50),
  });

  const getSetting = (key, fallback) => {
    const s = appSettings.find((s) => s.key === key);
    return s ? s.value : fallback;
  };

  const IBAN_INFO = {
    iban: getSetting("iban", ""),
    bank: getSetting("iban_bank", ""),
    name: getSetting("iban_name", ""),
    desc: getSetting("iban_desc", "Ödeme açıklamasına kullanıcı adınızı ve ürün adını yazınız."),
  };

  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ["cart", currentUser?.email],
    queryFn: () => base44.entities.CartItem.filter({ user_email: currentUser.email }, "-created_date", 50),
    enabled: !!currentUser?.email,
  });

  const addMutation = useMutation({
    mutationFn: (product) =>
      base44.entities.CartItem.create({
        user_email: currentUser.email,
        product_name: product.name,
        product_type: product.id,
        price: product.price,
        quantity: 1,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] });
      toast.success("Sepete eklendi!");
    },
  });

  const removeMutation = useMutation({
    mutationFn: (id) => base44.entities.CartItem.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["cart"] }),
  });

  const total = cartItems.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0);

  return (
    <div className="px-4 py-4 pb-8">
      <div className="flex items-center gap-3 mb-5">
        <Link to="/profile" className="text-muted-foreground">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex items-center gap-2">
          <ShoppingCart className="w-5 h-5 text-primary" />
          <h1 className="text-xl font-bold text-foreground">Alışveriş Sepeti</h1>
        </div>
      </div>

      {/* Badge products */}
      <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Rozetler & Abonelikler</p>
      <div className="space-y-2 mb-5">
        {[
          { id: "ozel_rozeti", name: "Özel Rozeti", icon: Sparkles, desc: "Özel bölümüne video paylaşma hakkı", priceKey: "ozel_rozeti_price", fallback: "149" },
          { id: "kitap_rozeti", name: "Kitap Rozeti", icon: BookOpen, desc: "Kitap yazarı özel rozeti", priceKey: "kitap_rozeti_price", fallback: "79" },
          { id: "one_cikarma", name: "Öne Çıkar Rozeti", icon: Zap, desc: "Kitaplarınızı öne çıkarın", priceKey: "one_cikar_rozeti_price", fallback: "49" },
          { id: "magazin_rozeti", name: "Magazin Rozeti", icon: Star, desc: "Magazin yazarı rozeti", priceKey: "magazin_rozeti_price", fallback: "89" },
          { id: "yazar_rozeti", name: "Yazarlık Rozeti", icon: Award, desc: "Profilinizde yazar rozeti", priceKey: "yazarlik_rozeti_price", fallback: "99" },
          { id: "vip_uyelik", name: "VIP Rozeti", icon: Crown, desc: "VIP üyelik ile premium özellikler", priceKey: "vip_uyelik_price", fallback: "199" },
        ].map((p) => {
          const Icon = p.icon;
          const price = parseFloat(getSetting(p.priceKey, p.fallback));
          const inCart = cartItems.some((c) => c.product_type === p.id);
          return (
            <div key={p.id} className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Icon className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.desc}</p>
              </div>
              <div className="flex flex-col items-end gap-1.5">
                <span className="text-sm font-bold text-primary">₺{price}</span>
                <Button
                  size="sm"
                  variant={inCart ? "secondary" : "outline"}
                  className="rounded-full text-xs h-7 px-3"
                  disabled={inCart || addMutation.isPending}
                  onClick={() => !inCart && addMutation.mutate({ ...p, price })}
                >
                  {inCart ? "Sepette ✓" : "Ekle"}
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Cart */}
      <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Sepetim</p>
      {isLoading ? (
        <Skeleton className="h-20 rounded-xl" />
      ) : cartItems.length === 0 ? (
        <div className="text-center py-10 border border-dashed border-border rounded-xl">
          <ShoppingCart className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Sepetiniz boş</p>
        </div>
      ) : (
        <div className="space-y-2">
          {cartItems.map((item) => (
            <div key={item.id} className="rounded-xl bg-card border border-border overflow-hidden">
              <div className="flex items-center gap-3 p-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{item.product_name}</p>
                  <p className="text-xs text-primary font-semibold">₺{item.price}</p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-full text-xs h-7 px-3"
                  onClick={() => setPayingItemId(payingItemId === item.id ? null : item.id)}
                >
                  <CreditCard className="w-3 h-3 mr-1" />
                  Ödeme Yap
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive"
                  onClick={() => removeMutation.mutate(item.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              {/* IBAN bilgileri */}
              {payingItemId === item.id && (
                <div className="border-t border-border bg-muted/50 px-4 py-3 space-y-2">
                  <p className="text-xs font-semibold text-foreground mb-1">Havale / EFT Bilgileri</p>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <p><span className="font-medium text-foreground">Banka:</span> {IBAN_INFO.bank}</p>
                    <div className="flex items-center gap-2">
                      <span><span className="font-medium text-foreground">IBAN:</span> {IBAN_INFO.iban}</span>
                      <button onClick={() => { navigator.clipboard.writeText(IBAN_INFO.iban); toast.success("IBAN kopyalandı!"); }} className="text-primary">
                        <Copy className="w-3 h-3" />
                      </button>
                    </div>
                    <p><span className="font-medium text-foreground">Ad:</span> {IBAN_INFO.name}</p>
                    <p className="text-[11px] text-amber-600">{IBAN_INFO.desc}</p>
                  </div>
                  {paidItemId === item.id ? (
                    <div className="flex items-center gap-2 text-green-600 text-xs font-semibold pt-1">
                      <CheckCircle2 className="w-4 h-4" />
                      Ödeme bildiriminiz alındı, inceleniyor.
                    </div>
                  ) : (
                    <Button
                      size="sm"
                      className="w-full rounded-full mt-2 bg-green-600 hover:bg-green-700 text-white text-xs"
                      onClick={() => { setPaidItemId(item.id); toast.success("Ödeme bildiriminiz alındı!"); }}
                    >
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Ödemeyi Yaptım, Onayla
                    </Button>
                  )}
                </div>
              )}
            </div>
          ))}

          <div className="mt-4 p-4 rounded-xl bg-primary/5 border border-primary/20">
            <div className="flex justify-between items-center">
              <span className="font-semibold text-foreground">Toplam</span>
              <span className="text-xl font-bold text-primary">₺{total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}