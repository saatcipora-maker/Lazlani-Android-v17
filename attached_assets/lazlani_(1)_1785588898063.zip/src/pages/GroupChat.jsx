import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Menu, Users, Settings, Hash, X, Ban, Tv, UserPlus, Shield, Lock, ListOrdered, Paintbrush, UserCircle, Rocket, Bot, Terminal, Megaphone } from "lucide-react";



const SETTINGS_SECTIONS = [
  {
    title: "Sohbet Bilgileri",
    desc: "Sohbet odanız hakkında genel bilgiler",
    icon: Menu,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Sohbet Görünümü",
    desc: "Sohbet odanızın görünümünü ve işlevselliğini özelleştirin",
    icon: Paintbrush,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Misafirler",
    desc: "Misafirler (kayıtlı olmayan kullanıcılar) için ayarları yönetin",
    icon: Users,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Güçlendirir",
    desc: "Bu sohbet odasının Boosting'i nasıl teşvik edeceğini yönetin",
    icon: Rocket,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Kullanıcı Kişiselleştirmesi",
    desc: "Takma adlar, renklendirme ve daha fazlası için seçenekler",
    icon: UserCircle,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Ölçülülük",
    desc: "Sohbetinizin denetimi ve yönetimi için ayarları düzenleyin",
    icon: Shield,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Güvenlik ve Gizlilik",
    desc: "Parola korumalarını, CAPTCHA ayarlarını ve daha fazlasını yönetin",
    icon: Lock,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Sıralama Listesi",
    desc: "Sıralanmış kullanıcıların listesini görüntüleyin ve düzenleyin",
    icon: ListOrdered,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Yasaklı Liste",
    desc: "Yasaklı kullanıcılar listesini görüntüleyin ve değiştirin",
    icon: Ban,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Kanallar",
    desc: "Kullanıcıları kanallara ayırarak sohbeti ve moderasyonu kolaylaştırın",
    icon: Hash,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Arkadaşlar ve Engelleme",
    desc: "Kullanıcılarınızın arkadaş eklemesine ve diğer kullanıcıları engellemesine izin verin",
    icon: UserPlus,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Gelişmiş",
    desc: "Sohbetiniz için çeşitli gelişmiş seçenekler",
    icon: Settings,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Bot Ayarları - Genel",
    desc: "Botu açın veya kapatın, takma adı ve fotoğrafı değiştirin",
    icon: Bot,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Komutanlıklar için Minimum Rütbeler",
    desc: "Hangi rütbelerin hangi bot komutunu kullanmasına izin verildiğini değiştirin",
    icon: Terminal,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Güncel Şarkıyı Duyurun",
    desc: "Botu, sohbet radyosunda yeni bir şarkı çalmaya başladığında mesaj gönderecek şekilde yapılandırın",
    icon: Megaphone,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
];

function SettingsPanel({ onClose }) {
  return (
    <div className="fixed inset-0 z-[60] bg-background flex flex-col" style={{ paddingTop: "env(safe-area-inset-top)" }}>
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card flex-shrink-0">
        <button onClick={onClose} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted text-foreground">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="font-bold text-base text-foreground">Sohbet Ayarları</span>
      </div>
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="px-4 py-4 space-y-4">
          {SETTINGS_SECTIONS.map((s) => {
            const Icon = s.icon;
            return (
              <div
                key={s.title}
                className="flex flex-col items-center text-center py-5 px-4 bg-card rounded-2xl border border-border"
              >
                <div className={`w-14 h-14 rounded-full ${s.bg} flex items-center justify-center mb-3`}>
                  <Icon className={`w-7 h-7 ${s.color}`} />
                </div>
                <h3 className="font-bold text-base text-foreground">{s.title}</h3>
                <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{s.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default function GroupChat() {
  const navigate = useNavigate();
  const [showSettings, setShowSettings] = useState(false);
  const [currentRoom, setCurrentRoom] = useState("Ana Salon");
  const [showRoomDropdown, setShowRoomDropdown] = useState(false);
  const [showMembers, setShowMembers] = useState(false);

  const { data: appSettings = [] } = useQuery({
    queryKey: ["app-settings"],
    queryFn: () => base44.entities.AppSettings.list("-created_date", 50),
  });
  const chatUrl = appSettings.find((s) => s.key === "minnit_chat_url")?.value || "";

  const rooms = ["Ana Salon", "Genel Sohbet", "Oyun", "Müzik", "Edebiyat"];

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#e8eef1]" style={{ paddingTop: "env(safe-area-inset-top)", paddingBottom: "env(safe-area-inset-bottom)", paddingLeft: "env(safe-area-inset-left, 0px)", paddingRight: "env(safe-area-inset-right, 0px)" }}>
      {/* Settings panel */}
      {showSettings && <SettingsPanel onClose={() => setShowSettings(false)} />}

      {/* Members panel */}
      {showMembers && (
        <div className="fixed inset-0 z-[60] bg-background flex flex-col" style={{ paddingTop: "env(safe-area-inset-top)" }}>
          <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card flex-shrink-0">
            <button onClick={() => setShowMembers(false)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted text-foreground">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <span className="font-bold text-base text-foreground">Çevrimiçi Üyeler</span>
          </div>
          <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">
            Üye listesi sohbet içinden görüntülenebilir
          </div>
        </div>
      )}

      {/* Room selector dropdown */}
      {showRoomDropdown && (
        <div className="fixed inset-0 z-[60] bg-black/40" onClick={() => setShowRoomDropdown(false)}>
          <div
            className="absolute top-14 left-1/2 -translate-x-1/2 bg-card border border-border rounded-2xl shadow-xl w-64 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
            style={{ marginTop: "env(safe-area-inset-top)" }}
          >
            <div className="px-4 py-3 border-b border-border">
              <p className="font-semibold text-sm text-foreground">Oda Seç</p>
            </div>
            {rooms.map((room) => (
              <button
                key={room}
                onClick={() => { setCurrentRoom(room); setShowRoomDropdown(false); }}
                className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                  currentRoom === room ? "bg-blue-50 text-blue-600 font-semibold" : "text-foreground hover:bg-muted"
                }`}
              >
                <Hash className="w-3.5 h-3.5 inline mr-2 opacity-50" />
                {room}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Top header bar - like screenshot 1 */}
      <div className="flex items-center justify-between px-2 py-2 bg-[#f0f4f8] border-b border-[#d8dfe6] flex-shrink-0">
        {/* Left icons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 flex items-center justify-center rounded-full text-[#5b6b7d] hover:bg-white/60"
          >
            <Menu className="w-5 h-5" />
          </button>
          <button
            onClick={() => setShowMembers(true)}
            className="w-10 h-10 flex items-center justify-center rounded-full text-[#5b6b7d] hover:bg-white/60"
          >
            <Users className="w-5 h-5" />
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="w-10 h-10 flex items-center justify-center rounded-full text-[#5b6b7d] hover:bg-white/60"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        {/* Room name */}
        <button
          onClick={() => setShowRoomDropdown(true)}
          className="bg-white border border-[#c8d1da] rounded-full px-4 py-1.5 text-sm font-semibold text-[#3a4a5c] flex items-center gap-1 shadow-sm"
        >
          {currentRoom}
          <span className="text-[10px] ml-1">▼</span>
        </button>

        {/* Right icons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowMembers(true)}
            className="w-10 h-10 flex items-center justify-center rounded-full text-[#5b6b7d] hover:bg-white/60"
          >
            <Users className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Minnit Chat iframe */}
      <iframe
        src={chatUrl}
        style={{
          border: "none",
          width: "100%",
          height: "100%",
          display: "block",
          flex: 1,
        }}
        allowTransparency={true}
        data-minnitchatembed="1"
        allow="microphone; camera"
        title="Grup Sohbeti"
      />
    </div>
  );
}