import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { toast } from "sonner";

export function useFavorites() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: favorites = [] } = useQuery({
    queryKey: ["favorites", user?.email],
    queryFn: () => base44.entities.FavoriteBook.filter({ user_email: user.email }, "-created_date", 500),
    enabled: !!user?.email,
    staleTime: 30000,
  });

  const isFavorite = (bookId) => favorites.some((f) => f.book_id === bookId);

  const toggleFavorite = useMutation({
    mutationFn: async ({ bookId, bookTitle }) => {
      const existing = favorites.find((f) => f.book_id === bookId);
      if (existing) {
        await base44.entities.FavoriteBook.delete(existing.id);
      } else {
        await base44.entities.FavoriteBook.create({
          user_email: user.email,
          book_id: bookId,
          book_title: bookTitle,
        });
      }
    },
    onMutate: async ({ bookId }) => {
      await queryClient.cancelQueries({ queryKey: ["favorites", user?.email] });
      const prev = queryClient.getQueryData(["favorites", user?.email]) || [];
      const existing = prev.find((f) => f.book_id === bookId);
      if (existing) {
        queryClient.setQueryData(["favorites", user?.email], prev.filter((f) => f.book_id !== bookId));
      } else {
        queryClient.setQueryData(["favorites", user?.email], [...prev, { book_id: bookId, user_email: user?.email, id: "__temp__" }]);
      }
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(["favorites", user?.email], ctx.prev);
      toast.error("Hata oluştu");
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["favorites", user?.email] });
    },
  });

  return { favorites, isFavorite, toggleFavorite };
}