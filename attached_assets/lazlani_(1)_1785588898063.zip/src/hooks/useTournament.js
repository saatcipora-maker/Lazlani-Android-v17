import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useEffect } from "react";

export function useTournament(activeRoom) {
  const queryClient = useQueryClient();

  // Get active tournament for this room
  const { data: tournaments = [] } = useQuery({
    queryKey: ["active-tournament", activeRoom],
    queryFn: async () => {
      const active = await base44.entities.Tournament.filter(
        { room_id: activeRoom, status: "active" },
        "-created_date",
        1
      );
      if (active.length > 0) return active;
      // Also check waiting
      const waiting = await base44.entities.Tournament.filter(
        { room_id: activeRoom, status: "waiting" },
        "-created_date",
        1
      );
      return waiting;
    },
    enabled: !!activeRoom,
    refetchInterval: 5000,
  });

  // Subscribe to tournament changes
  useEffect(() => {
    const unsub = base44.entities.Tournament.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["active-tournament", activeRoom] });
    });
    return unsub;
  }, [activeRoom]);

  const activeTournament = tournaments[0] || null;

  // Auto-finish expired tournaments
  useEffect(() => {
    if (!activeTournament || activeTournament.status !== "active") return;
    const end = new Date(activeTournament.end_time).getTime();
    const remaining = end - Date.now();
    if (remaining <= 0) {
      finishTournament(activeTournament);
      return;
    }
    const timer = setTimeout(() => finishTournament(activeTournament), remaining + 1000);
    return () => clearTimeout(timer);
  }, [activeTournament?.id, activeTournament?.status]);

  const finishTournament = async (t) => {
    if (t.status === "finished") return;
    // Get top scorer
    const scores = await base44.entities.TournamentScore.filter(
      { tournament_id: t.id },
      "-score",
      1
    );
    const winner = scores[0];
    await base44.entities.Tournament.update(t.id, {
      status: "finished",
      winner_email: winner?.user_email || "",
      winner_name: winner?.user_name || "",
      winner_score: winner?.score || 0,
    });
    queryClient.invalidateQueries({ queryKey: ["active-tournament", activeRoom] });
  };

  const startTournament = useMutation({
    mutationFn: async ({ title, duration_minutes, chapter_num, currentUser }) => {
      const now = new Date();
      const end = new Date(now.getTime() + duration_minutes * 60000);
      return base44.entities.Tournament.create({
        room_id: activeRoom,
        title,
        status: "active",
        started_by: currentUser.email,
        started_by_name: currentUser.full_name || currentUser.email.split("@")[0],
        chapter_num,
        duration_minutes,
        start_time: now.toISOString(),
        end_time: end.toISOString(),
        participant_count: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["active-tournament", activeRoom] });
    },
  });

  return { activeTournament, startTournament };
}