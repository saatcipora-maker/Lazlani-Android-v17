import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

/**
 * Hook to preserve navigation stack independently for each bottom tab
 * Allows users to navigate within a tab and return to their last position
 */
export function useNavigationStack(tabId) {
  const location = useLocation();
  const stackRef = useRef({});

  useEffect(() => {
    // Initialize stack for each tab if not exists
    if (!stackRef.current[tabId]) {
      stackRef.current[tabId] = [];
    }

    // Get current stack for this tab
    const currentStack = stackRef.current[tabId];

    // If we're at the root of this tab, clear the stack
    const isTabRoot = location.pathname === `/${tabId}` || location.pathname === '/';

    if (isTabRoot) {
      currentStack.length = 0;
    } else {
      // Add current path to stack
      if (currentStack[currentStack.length - 1] !== location.pathname) {
        currentStack.push(location.pathname);
      }
    }
  }, [location.pathname, tabId]);

  const getStackLength = () => {
    return stackRef.current[tabId]?.length || 0;
  };

  const getPreviousPath = () => {
    const stack = stackRef.current[tabId];
    return stack && stack.length > 0 ? stack[stack.length - 1] : null;
  };

  return {
    stackLength: getStackLength(),
    previousPath: getPreviousPath(),
  };
}