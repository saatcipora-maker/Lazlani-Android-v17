import { useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';

/**
 * Reusable hook for optimistic UI updates on likes, comments, and follows
 * Provides immediate feedback while maintaining data consistency
 */
export function useOptimisticUpdate() {
  const queryClient = useQueryClient();

  const optimisticLike = useCallback(({ entityId, queryKey, userId, isLiked }) => {
    // Cancel ongoing queries
    queryClient.cancelQueries({ queryKey });

    // Get previous data
    const previousData = queryClient.getQueryData(queryKey);

    // Update cache optimistically
    queryClient.setQueryData(queryKey, (old) => {
      if (Array.isArray(old)) {
        return old.map((item) =>
          item.id === entityId
            ? {
                ...item,
                like_count: isLiked ? item.like_count - 1 : item.like_count + 1,
              }
            : item
        );
      }
      return old;
    });

    return previousData;
  }, [queryClient]);

  const optimisticComment = useCallback(({ entityId, queryKey, newComment }) => {
    queryClient.cancelQueries({ queryKey });
    const previousData = queryClient.getQueryData(queryKey);

    queryClient.setQueryData(queryKey, (old) => {
      if (Array.isArray(old)) {
        return [
          ...old,
          {
            ...newComment,
            id: '__temp__',
            created_date: new Date().toISOString(),
          },
        ];
      }
      return old;
    });

    return previousData;
  }, [queryClient]);

  const optimisticFollow = useCallback(({ userId, queryKey, isFollowing }) => {
    queryClient.cancelQueries({ queryKey });
    const previousData = queryClient.getQueryData(queryKey);

    // Update follow status immediately
    queryClient.setQueryData(queryKey, (old) => (isFollowing ? false : true));

    return previousData;
  }, [queryClient]);

  const rollback = useCallback((queryKey, previousData) => {
    if (previousData !== undefined) {
      queryClient.setQueryData(queryKey, previousData);
    }
  }, [queryClient]);

  return {
    optimisticLike,
    optimisticComment,
    optimisticFollow,
    rollback,
  };
}