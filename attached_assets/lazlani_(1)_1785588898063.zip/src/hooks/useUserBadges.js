import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

/**
 * Returns a map of email → { has_magazin_badge, has_vip, has_author_badge }
 * for quick badge color lookups.
 */
export function useUserBadges() {
  const { data: users = [] } = useQuery({
    queryKey: ["all-users-badges"],
    queryFn: () => base44.entities.User.list("-created_date", 200),
    staleTime: 5 * 60 * 1000,
  });

  const badgeMap = {};
  users.forEach((u) => {
    badgeMap[u.email] = {
      has_magazin_badge: !!u.has_magazin_badge,
      has_vip: !!u.has_vip,
      has_author_badge: !!u.has_author_badge,
    };
  });

  return badgeMap;
}

export function getBadgeNameClass(email, badgeMap) {
  const u = badgeMap[email];
  if (!u) return "";
  if (u.has_magazin_badge) return "text-[#9C2A2A]";
  if (u.has_vip) return "text-blue-700";
  return "";
}

export function getBadgeTextClass(email, badgeMap) {
  const u = badgeMap[email];
  if (!u) return "";
  if (u.has_magazin_badge) return "text-[#9C2A2A]";
  if (u.has_vip) return "text-blue-700";
  return "";
}