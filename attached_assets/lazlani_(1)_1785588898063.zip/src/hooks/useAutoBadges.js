import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

/**
 * Returns auto-detected badges for a given user email:
 * - is_author: has at least 1 published book
 * - is_active_reader: has read at least 5 books
 */
export function useAutoBadges(email) {
  const { data: books = [] } = useQuery({
    queryKey: ["auto-badge-books", email],
    queryFn: () => base44.entities.Book.filter({ author_email: email, status: "yayinda" }, "-created_date", 1),
    enabled: !!email,
    staleTime: 60000,
  });

  const { data: readHistory = [] } = useQuery({
    queryKey: ["auto-badge-reads", email],
    queryFn: () => base44.entities.ReadHistory.filter({ user_email: email }, "-created_date", 100),
    enabled: !!email,
    staleTime: 60000,
  });

  return {
    is_author: books.length > 0,
    is_active_reader: readHistory.length >= 5,
  };
}

/**
 * Bulk version: fetches all published books and read histories
 * to build a map of email -> { is_author, is_active_reader }
 */
export function useAutoBadgesBulk() {
  const { data: allBooks = [] } = useQuery({
    queryKey: ["auto-badge-all-books"],
    queryFn: () => base44.entities.Book.filter({ status: "yayinda" }, "-created_date", 500),
    staleTime: 60000,
  });

  const { data: allReads = [] } = useQuery({
    queryKey: ["auto-badge-all-reads"],
    queryFn: () => base44.entities.ReadHistory.list("-created_date", 500),
    staleTime: 60000,
  });

  const map = {};

  // Authors: anyone with a published book
  allBooks.forEach((b) => {
    if (b.author_email) {
      if (!map[b.author_email]) map[b.author_email] = { is_author: false, is_active_reader: false };
      map[b.author_email].is_author = true;
    }
  });

  // Readers: count unique books per user
  const readerCounts = {};
  allReads.forEach((r) => {
    if (!readerCounts[r.user_email]) readerCounts[r.user_email] = new Set();
    readerCounts[r.user_email].add(r.book_id);
  });

  Object.entries(readerCounts).forEach(([email, bookSet]) => {
    if (!map[email]) map[email] = { is_author: false, is_active_reader: false };
    if (bookSet.size >= 5) map[email].is_active_reader = true;
  });

  return map;
}