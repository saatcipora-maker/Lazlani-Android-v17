import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export function useDeleteAccount() {
  const [step, setStep] = useState(0);
  const [isOpen, setIsOpen] = useState(false);

  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('deleteUserAccount', {});
      return response.data;
    },
    onSuccess: () => {
      toast.success('Hesap başarıyla silindi');
      setIsOpen(false);
      setStep(0);
      base44.auth.logout('/');
    },
    onError: () => {
      toast.error('Hesap silme başarısız oldu. Lütfen support@lazlani.com adresine yazın.');
    },
  });

  const handleOpen = () => {
    setIsOpen(true);
    setStep(0);
  };

  const handleClose = () => {
    setIsOpen(false);
    setStep(0);
  };

  const handleNext = () => {
    if (step < 2) {
      setStep(step + 1);
    }
  };

  const handleConfirmDelete = () => {
    deleteAccountMutation.mutate();
  };

  return {
    isOpen,
    step,
    isPending: deleteAccountMutation.isPending,
    handleOpen,
    handleClose,
    handleNext,
    handleConfirmDelete,
  };
}