import { useState, useEffect, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";

const ONLINE_THRESHOLD_MS = 5 * 60 * 1000; // 5 minutes
const HEARTBEAT_INTERVAL_MS = 2 * 60 * 1000; // 2 minutes

/**
 * Returns true if the user was seen within the last 5 minutes.
 */
export function isUserOnline(lastSeen) {
  if (!lastSeen) return false;
  return Date.now() - new Date(lastSeen).getTime() < ONLINE_THRESHOLD_MS;
}

/**
 * Hook: heartbeat disabled for privacy — no user's online status is tracked.
 */
export function useHeartbeat() {
  // Disabled: users' online/offline status is not shared
}

/**
 * Hook: disabled for privacy — returns empty map so no user sees others' status.
 */
export function useOnlineUsers() {
  return {};
}