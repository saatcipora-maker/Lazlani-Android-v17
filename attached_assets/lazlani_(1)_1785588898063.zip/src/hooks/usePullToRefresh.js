import { useRef, useCallback } from "react";

/**
 * Attach to a scrollable container ref.
 * onRefresh should return a Promise.
 * Returns { containerRef, isRefreshing }
 */
export function usePullToRefresh(onRefresh) {
  const startY = useRef(null);
  const isRefreshing = useRef(false);

  const onTouchStart = useCallback((e) => {
    startY.current = e.touches[0].clientY;
  }, []);

  const onTouchEnd = useCallback(
    async (e) => {
      if (startY.current === null) return;
      const dy = e.changedTouches[0].clientY - startY.current;
      startY.current = null;
      if (dy > 70 && !isRefreshing.current) {
        isRefreshing.current = true;
        await onRefresh();
        isRefreshing.current = false;
      }
    },
    [onRefresh]
  );

  return { onTouchStart, onTouchEnd };
}