import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '@/data/types';
import { SAMPLE_USERS } from '@/data/sampleData';

type ProfileUpdates = Partial<Pick<User,
  'displayName' | 'bio' | 'avatarColor' | 'coverColor' | 'username' | 'avatarUrl' | 'coverUrl'
>>;

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (username: string, displayName: string, email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updateProfile: (updates: ProfileUpdates) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const STORAGE_KEY = 'lazlani_current_user';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then(v => { if (v) setUser(JSON.parse(v)); })
      .finally(() => setLoading(false));
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    const found = SAMPLE_USERS.find(u => u.email === email && u.password === password);
    if (found) {
      setUser(found);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(found));
      return true;
    }
    return false;
  };

  const register = async (
    username: string, displayName: string, email: string, password: string
  ): Promise<boolean> => {
    const newUser: User = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      username, displayName, email, password,
      bio: '',
      avatarColor: '#9B59F5',
      coverColor: '#4C1D95',
      followersCount: 0, followingCount: 0, likesReceivedCount: 0,
      booksCount: 0, storiesCount: 0, poemsCount: 0,
      isPremium: false,
      joinedAt: new Date().toISOString().split('T')[0],
    };
    setUser(newUser);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
    return true;
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem(STORAGE_KEY);
  };

  const updateProfile = async (updates: ProfileUpdates) => {
    if (!user) return;
    const updated = { ...user, ...updates };
    setUser(updated);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be inside AuthProvider');
  return ctx;
}
