import { useTheme } from '@/context/ThemeContext';

/**
 * Returns the active theme palette.
 * Theme is chosen by the user and persisted via ThemeContext → AsyncStorage.
 */
export function useColors() {
  return useTheme().colors;
}
