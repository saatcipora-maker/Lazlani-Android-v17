import React, { useRef, useState } from 'react';
import {
  ActivityIndicator, Platform, StyleSheet, Text,
  TouchableOpacity, View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

const CHAT_URL = 'https://organizations.minnit.chat/178740399438712/lazlani';

/* Web uses <iframe>, native uses WebView */
let WebView: any = null;
if (Platform.OS !== 'web') {
  try {
    WebView = require('react-native-webview').WebView;
  } catch (_) {}
}

export default function MinnitChatScreen() {
  const colors  = useColors();
  const insets  = useSafeAreaInsets();
  const router  = useRouter();
  const topPad  = Platform.OS === 'web' ? 67 : insets.top;

  const [loading,  setLoading]  = useState(true);
  const [offline,  setOffline]  = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const webRef = useRef<any>(null);

  const handleRetry = () => {
    setOffline(false);
    setLoading(true);
    setRetryKey(k => k + 1);
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* ── Header ── */}
      <LinearGradient
        colors={['#3D3468', colors.background]}
        style={[styles.header, { paddingTop: topPad + 8 }]}
      >
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={22} color="#E0D8FF" />
        </TouchableOpacity>

        <View style={styles.titleRow}>
          <View style={[styles.liveDot, { backgroundColor: offline ? '#EF4444' : '#22C55E' }]} />
          <Text style={styles.titleTxt}>LAZLANI Sohbet</Text>
        </View>

        <TouchableOpacity
          onPress={() => webRef.current?.reload?.()}
          style={styles.reloadBtn}
        >
          <Ionicons name="refresh-outline" size={20} color="#C8B8FF" />
        </TouchableOpacity>
      </LinearGradient>

      {/* ── Content ── */}
      <View style={{ flex: 1 }}>

        {/* Loading overlay */}
        {loading && !offline && (
          <View style={[styles.overlay, { backgroundColor: colors.background }]}>
            <LinearGradient
              colors={['#9B59F5', '#EC4899']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={styles.loaderIcon}
            >
              <Ionicons name="chatbubbles" size={30} color="#fff" />
            </LinearGradient>
            <ActivityIndicator size="large" color="#9B59F5" style={{ marginTop: 20 }} />
            <Text style={[styles.loadingTxt, { color: colors.mutedForeground }]}>
              Sohbet yükleniyor…
            </Text>
          </View>
        )}

        {/* Offline state */}
        {offline && (
          <View style={[styles.overlay, { backgroundColor: colors.background }]}>
            <View style={[styles.offlineIcon, { backgroundColor: '#3D3468' }]}>
              <Ionicons name="wifi-outline" size={38} color="#EF4444" />
            </View>
            <Text style={[styles.offlineTitle, { color: colors.foreground }]}>
              Bağlantı Yok
            </Text>
            <Text style={[styles.offlineSub, { color: colors.mutedForeground }]}>
              İnternet bağlantını kontrol et ve tekrar dene.
            </Text>
            <TouchableOpacity onPress={handleRetry} style={styles.retryBtnWrap}>
              <LinearGradient
                colors={['#9B59F5', '#EC4899']}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                style={styles.retryBtn}
              >
                <Ionicons name="refresh" size={16} color="#fff" />
                <Text style={styles.retryTxt}>Tekrar Dene</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}

        {/* WebView — native */}
        {Platform.OS !== 'web' && WebView && (
          <WebView
            key={retryKey}
            ref={webRef}
            source={{ uri: CHAT_URL }}
            style={{ flex: 1, backgroundColor: colors.background }}
            onLoadStart={() => { setLoading(true); setOffline(false); }}
            onLoadEnd={() => setLoading(false)}
            onError={() => { setLoading(false); setOffline(true); }}
            onHttpError={() => { setLoading(false); setOffline(true); }}
            javaScriptEnabled
            domStorageEnabled
            allowsInlineMediaPlayback
            mediaPlaybackRequiresUserAction={false}
            mixedContentMode="compatibility"
            userAgent="Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
          />
        )}

        {/* Iframe — web */}
        {Platform.OS === 'web' && !offline && (
          <iframe
            key={retryKey}
            src={CHAT_URL}
            style={{
              flex: 1, width: '100%', height: '100%',
              border: 'none', display: 'block',
            } as any}
            allow="microphone; camera"
            onLoad={() => setLoading(false)}
            onError={() => { setLoading(false); setOffline(true); }}
            title="LAZLANI Sohbet"
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 16, paddingBottom: 14,
  },
  backBtn: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: 'rgba(155,89,245,0.18)',
    alignItems: 'center', justifyContent: 'center',
  },
  titleRow: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  liveDot: { width: 8, height: 8, borderRadius: 4 },
  titleTxt: {
    color: '#E0D8FF', fontFamily: 'Poppins_700Bold', fontSize: 17,
  },
  reloadBtn: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: 'rgba(155,89,245,0.18)',
    alignItems: 'center', justifyContent: 'center',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center', justifyContent: 'center',
    zIndex: 10, gap: 12,
  },
  loaderIcon: {
    width: 72, height: 72, borderRadius: 20,
    alignItems: 'center', justifyContent: 'center',
  },
  loadingTxt: {
    fontFamily: 'Poppins_500Medium', fontSize: 15, marginTop: 4,
  },
  offlineIcon: {
    width: 80, height: 80, borderRadius: 24,
    alignItems: 'center', justifyContent: 'center', marginBottom: 8,
  },
  offlineTitle: { fontFamily: 'Poppins_700Bold', fontSize: 20 },
  offlineSub: {
    fontFamily: 'Poppins_400Regular', fontSize: 14,
    textAlign: 'center', paddingHorizontal: 40, lineHeight: 22,
  },
  retryBtnWrap: { marginTop: 8, borderRadius: 24, overflow: 'hidden' },
  retryBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 28, paddingVertical: 14,
  },
  retryTxt: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 15 },
});
