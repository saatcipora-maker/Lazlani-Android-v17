import React, { useState } from 'react';
import {
  Alert, Platform, ScrollView, StyleSheet, Text, TextInput,
  TouchableOpacity, View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/context/AuthContext';

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Hata', 'Tüm alanları doldurun.');
      return;
    }
    setLoading(true);
    const ok = await login(email.trim(), password);
    setLoading(false);
    if (ok) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace('/(tabs)');
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Hatalı Giriş', 'E-posta veya şifre yanlış.\n\nDeneme: ayse@example.com / 123456');
    }
  };

  return (
    <LinearGradient
      colors={['#1A0B3B', '#0D0B24']}
      style={[styles.root, { paddingTop: topPad, paddingBottom: botPad }]}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Logo */}
        <View style={styles.logoSection}>
          <LinearGradient
            colors={['#9B59F5', '#EC4899']}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            style={styles.logoIcon}
          >
            <Ionicons name="book" size={36} color="#fff" />
          </LinearGradient>
          <Text style={styles.logoText}>LAZLANI</Text>
          <Text style={styles.logoTagline}>Edebiyatın yeni adresi</Text>
        </View>

        {/* Form */}
        <View style={styles.formCard}>
          <Text style={[styles.formTitle, { color: colors.foreground }]}>Hoş Geldin</Text>
          <Text style={[styles.formSubtitle, { color: colors.mutedForeground }]}>Hesabına giriş yap</Text>

          <View style={styles.inputGroup}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>E-posta</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.input, borderColor: colors.border }]}>
              <Ionicons name="mail-outline" size={18} color={colors.mutedForeground} />
              <TextInput
                style={[styles.input, { color: colors.foreground }]}
                placeholder="ornek@email.com"
                placeholderTextColor={colors.mutedForeground}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Şifre</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.input, borderColor: colors.border }]}>
              <Ionicons name="lock-closed-outline" size={18} color={colors.mutedForeground} />
              <TextInput
                style={[styles.input, { color: colors.foreground }]}
                placeholder="••••••••"
                placeholderTextColor={colors.mutedForeground}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPass}
              />
              <TouchableOpacity onPress={() => setShowPass(!showPass)}>
                <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={18} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity style={styles.forgotRow}>
            <Text style={[styles.forgotText, { color: colors.primary }]}>Şifremi Unuttum</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleLogin} disabled={loading} style={styles.loginBtn} activeOpacity={0.85}>
            <LinearGradient colors={['#9B59F5', '#EC4899']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.loginBtnGrad}>
              {loading ? (
                <Text style={styles.loginBtnText}>Giriş yapılıyor...</Text>
              ) : (
                <Text style={styles.loginBtnText}>Giriş Yap</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>

          {/* Demo hint */}
          <View style={[styles.demoHint, { backgroundColor: colors.card, borderRadius: 8, borderColor: colors.border }]}>
            <Ionicons name="information-circle-outline" size={14} color={colors.mutedForeground} />
            <Text style={[styles.demoText, { color: colors.mutedForeground }]}>Demo: ayse@example.com / 123456</Text>
          </View>
        </View>

        {/* Register link */}
        <View style={styles.registerRow}>
          <Text style={[styles.registerText, { color: colors.mutedForeground }]}>Hesabın yok mu?</Text>
          <TouchableOpacity onPress={() => router.push('/auth/register' as any)}>
            <Text style={[styles.registerLink, { color: colors.primary }]}>Kayıt Ol</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 24, gap: 24 },
  logoSection: { alignItems: 'center', gap: 10 },
  logoIcon: { width: 80, height: 80, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  logoText: { color: '#FFFFFF', fontFamily: 'Poppins_700Bold', fontSize: 32, letterSpacing: 4 },
  logoTagline: { color: 'rgba(255,255,255,0.5)', fontFamily: 'Poppins_400Regular', fontSize: 14 },
  formCard: { gap: 14 },
  formTitle: { fontFamily: 'Poppins_700Bold', fontSize: 24 },
  formSubtitle: { fontFamily: 'Poppins_400Regular', fontSize: 14, marginBottom: 4 },
  inputGroup: { gap: 6 },
  inputLabel: { fontFamily: 'Poppins_500Medium', fontSize: 13 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 13,
  },
  input: { flex: 1, fontFamily: 'Poppins_400Regular', fontSize: 14 },
  forgotRow: { alignItems: 'flex-end' },
  forgotText: { fontFamily: 'Poppins_500Medium', fontSize: 13 },
  loginBtn: { borderRadius: 16, overflow: 'hidden', marginTop: 4 },
  loginBtnGrad: { paddingVertical: 15, alignItems: 'center' },
  loginBtnText: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 16 },
  demoHint: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 10, borderWidth: 1 },
  demoText: { fontFamily: 'Poppins_400Regular', fontSize: 12, flex: 1 },
  registerRow: { flexDirection: 'row', justifyContent: 'center', gap: 6 },
  registerText: { fontFamily: 'Poppins_400Regular', fontSize: 14 },
  registerLink: { fontFamily: 'Poppins_700Bold', fontSize: 14 },
});
