import React, { useState } from 'react';
import {
  Alert, Linking, Modal, Platform, Pressable, ScrollView, StyleSheet, Switch,
  Text, TextInput, TouchableOpacity, View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/context/AuthContext';

type IoniconsName = React.ComponentProps<typeof Ionicons>['name'];

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, logout } = useAuth();
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const [notifLikes, setNotifLikes] = useState(true);
  const [notifComments, setNotifComments] = useState(true);
  const [notifFollows, setNotifFollows] = useState(true);
  const [notifMessages, setNotifMessages] = useState(true);
  const [dataSaver, setDataSaver] = useState(false);

  // Change password modal
  const [showPwModal, setShowPwModal] = useState(false);
  const [currentPw, setCurrentPw]   = useState('');
  const [newPw,     setNewPw]       = useState('');
  const [confirmPw, setConfirmPw]   = useState('');
  const [pwError,   setPwError]     = useState('');
  const [showCur,   setShowCur]     = useState(false);
  const [showNew,   setShowNew]     = useState(false);
  const [showConf,  setShowConf]    = useState(false);

  const handleChangePassword = () => {
    setPwError('');
    if (!currentPw) { setPwError('Mevcut şifrenizi girin.'); return; }
    if (currentPw !== '123456') { setPwError('Mevcut şifre hatalı.'); return; }
    if (newPw.length < 6) { setPwError('Yeni şifre en az 6 karakter olmalı.'); return; }
    if (newPw !== confirmPw) { setPwError('Yeni şifreler eşleşmiyor.'); return; }
    setShowPwModal(false);
    setCurrentPw(''); setNewPw(''); setConfirmPw(''); setPwError('');
    Alert.alert('Başarılı', 'Şifreniz güncellendi.');
  };

  const closePwModal = () => {
    setShowPwModal(false);
    setCurrentPw(''); setNewPw(''); setConfirmPw(''); setPwError('');
  };

  const handleLogout = () => {
    Alert.alert('Çıkış Yap', 'Hesabından çıkmak istediğine emin misin?', [
      { text: 'İptal', style: 'cancel' },
      { text: 'Çıkış Yap', style: 'destructive', onPress: logout },
    ]);
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Hesabı Sil',
      'Hesabını ve tüm verilerini kalıcı olarak silmek mi istiyorsun? Bu işlem geri alınamaz.',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Devam Et',
          style: 'destructive',
          onPress: () => {
            const url = 'https://a45bcb60-3dbf-452f-b413-d55d62733f2f-00-mn12yh0cpx6a.pike.replit.dev/api-server/delete-account';
            Linking.openURL(url).catch(() =>
              Alert.alert('Hata', 'Sayfa açılamadı. Lütfen daha sonra tekrar deneyin.')
            );
          },
        },
      ]
    );
  };

  const Section = ({ title }: { title: string }) => (
    <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>{title}</Text>
  );

  const Row = ({
    icon, label, value, onPress, danger = false,
  }: {
    icon: IoniconsName; label: string; value?: string; onPress?: () => void; danger?: boolean;
  }) => (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.row, { backgroundColor: colors.card }]}
      activeOpacity={onPress ? 0.7 : 1}
    >
      <View style={[styles.rowIcon, { backgroundColor: danger ? '#7F1D1D' : colors.secondary }]}>
        <Ionicons name={icon} size={18} color={danger ? '#EF4444' : colors.primary} />
      </View>
      <Text style={[styles.rowLabel, { color: danger ? '#EF4444' : colors.foreground }]}>{label}</Text>
      {value && <Text style={[styles.rowValue, { color: colors.mutedForeground }]}>{value}</Text>}
      {onPress && !value && (
        <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
      )}
    </TouchableOpacity>
  );

  const ToggleRow = ({
    icon, label, value, onChange,
  }: {
    icon: IoniconsName; label: string; value: boolean; onChange: (v: boolean) => void;
  }) => (
    <View style={[styles.row, { backgroundColor: colors.card }]}>
      <View style={[styles.rowIcon, { backgroundColor: colors.secondary }]}>
        <Ionicons name={icon} size={18} color={colors.primary} />
      </View>
      <Text style={[styles.rowLabel, { color: colors.foreground, flex: 1 }]}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ false: colors.border, true: '#9B59F5' }}
        thumbColor="#fff"
      />
    </View>
  );

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Ayarlar</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>

        {/* Account */}
        <Section title="HESAP" />
        <View style={[styles.card, { borderRadius: colors.radius }]}>
          <Row icon="person-outline" label="Profili Düzenle" onPress={() => router.push('/edit-profile' as any)} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <Row icon="mail-outline" label="E-posta" value={user?.email ?? ''} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <Row icon="shield-checkmark-outline" label="Şifre Değiştir" onPress={() => setShowPwModal(true)} />
        </View>

        {/* Notifications */}
        <Section title="BİLDİRİMLER" />
        <View style={[styles.card, { borderRadius: colors.radius }]}>
          <ToggleRow icon="heart-outline" label="Beğeniler" value={notifLikes} onChange={setNotifLikes} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <ToggleRow icon="chatbubble-outline" label="Yorumlar" value={notifComments} onChange={setNotifComments} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <ToggleRow icon="person-add-outline" label="Takipçiler" value={notifFollows} onChange={setNotifFollows} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <ToggleRow icon="mail-outline" label="Mesajlar" value={notifMessages} onChange={setNotifMessages} />
        </View>

        {/* Preferences */}
        <Section title="TERCİHLER" />
        <View style={[styles.card, { borderRadius: colors.radius }]}>
          <Row icon="color-palette-outline" label="Tema Seç" onPress={() => router.push('/theme' as any)} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <ToggleRow icon="cellular-outline" label="Veri Tasarrufu" value={dataSaver} onChange={setDataSaver} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <Row icon="language-outline" label="Dil" value="Türkçe" />
        </View>

        {/* About */}
        <Section title="HAKKINDA" />
        <View style={[styles.card, { borderRadius: colors.radius }]}>
          <Row icon="information-circle-outline" label="Uygulama Versiyonu" value="1.0.0" />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <Row icon="document-text-outline" label="Kullanım Koşulları" onPress={() => router.push('/terms' as any)} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <Row icon="lock-closed-outline" label="Gizlilik Politikası" onPress={() => router.push('/privacy' as any)} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <Row icon="ribbon-outline" label="Telif Hakkı" onPress={() => router.push('/copyright' as any)} />
        </View>

        {/* Support */}
        <Section title="DESTEK" />
        <View style={[styles.card, { borderRadius: colors.radius }]}>
          <Row icon="headset-outline" label="Destek ve Şikâyet" onPress={() => router.push('/support' as any)} />
          <View style={[styles.sep, { backgroundColor: colors.border }]} />
          <Row icon="chatbox-ellipses-outline" label="İletişim" onPress={() => router.push('/contact' as any)} />
        </View>

        {/* Logout */}
        <Section title="" />
        <View style={[styles.card, { borderRadius: colors.radius }]}>
          <Row icon="log-out-outline" label="Çıkış Yap" onPress={handleLogout} danger />
        </View>

        {/* Danger zone */}
        <Section title="TEHLİKELİ BÖLGE" />
        <View style={[styles.card, { borderRadius: colors.radius }]}>
          <Row icon="trash-outline" label="Hesabımı ve Verilerimi Sil" onPress={handleDeleteAccount} danger />
        </View>

        <View style={{ height: Platform.OS === 'web' ? 80 : 60 }} />
      </ScrollView>

      {/* ── Change Password Modal ── */}
      <Modal visible={showPwModal} transparent animationType="slide" onRequestClose={closePwModal}>
        <Pressable style={styles.overlay} onPress={closePwModal} />
        <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Şifre Değiştir</Text>

          {/* Current password */}
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Mevcut Şifre</Text>
          <View style={[styles.inputWrap, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Ionicons name="lock-closed-outline" size={16} color={colors.mutedForeground} />
            <TextInput
              style={[styles.input, { color: colors.foreground }]}
              secureTextEntry={!showCur}
              value={currentPw}
              onChangeText={setCurrentPw}
              placeholder="••••••••"
              placeholderTextColor={colors.mutedForeground}
            />
            <TouchableOpacity onPress={() => setShowCur(v => !v)}>
              <Ionicons name={showCur ? 'eye-off-outline' : 'eye-outline'} size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>

          {/* New password */}
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Yeni Şifre</Text>
          <View style={[styles.inputWrap, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Ionicons name="key-outline" size={16} color={colors.mutedForeground} />
            <TextInput
              style={[styles.input, { color: colors.foreground }]}
              secureTextEntry={!showNew}
              value={newPw}
              onChangeText={setNewPw}
              placeholder="En az 6 karakter"
              placeholderTextColor={colors.mutedForeground}
            />
            <TouchableOpacity onPress={() => setShowNew(v => !v)}>
              <Ionicons name={showNew ? 'eye-off-outline' : 'eye-outline'} size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>

          {/* Confirm password */}
          <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Yeni Şifre (Tekrar)</Text>
          <View style={[styles.inputWrap, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Ionicons name="key-outline" size={16} color={colors.mutedForeground} />
            <TextInput
              style={[styles.input, { color: colors.foreground }]}
              secureTextEntry={!showConf}
              value={confirmPw}
              onChangeText={setConfirmPw}
              placeholder="••••••••"
              placeholderTextColor={colors.mutedForeground}
            />
            <TouchableOpacity onPress={() => setShowConf(v => !v)}>
              <Ionicons name={showConf ? 'eye-off-outline' : 'eye-outline'} size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>

          {!!pwError && (
            <View style={styles.errorRow}>
              <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
              <Text style={styles.errorTxt}>{pwError}</Text>
            </View>
          )}

          <View style={styles.sheetBtns}>
            <TouchableOpacity onPress={closePwModal} style={[styles.sheetBtn, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.sheetBtnTxt, { color: colors.foreground }]}>İptal</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleChangePassword} style={[styles.sheetBtn, { backgroundColor: colors.primary }]}>
              <Text style={[styles.sheetBtnTxt, { color: '#fff' }]}>Güncelle</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1,
  },
  backBtn: { padding: 4 },
  title: { fontFamily: 'Poppins_700Bold', fontSize: 20 },
  content: { padding: 16, gap: 6 },
  sectionLabel: {
    fontFamily: 'Poppins_600SemiBold', fontSize: 11,
    letterSpacing: 0.8, textTransform: 'uppercase',
    marginTop: 10, marginBottom: 4, paddingHorizontal: 4,
  },
  card: { overflow: 'hidden' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 14 },
  rowIcon: { width: 34, height: 34, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  rowLabel: { flex: 1, fontFamily: 'Poppins_500Medium', fontSize: 14 },
  rowValue: { fontFamily: 'Poppins_400Regular', fontSize: 13 },
  sep: { height: 1, marginLeft: 62 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)' },
  sheet: {
    borderTopLeftRadius: 20, borderTopRightRadius: 20,
    borderTopWidth: 1, paddingHorizontal: 20, paddingBottom: 36,
  },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: 'center', marginTop: 10, marginBottom: 16 },
  sheetTitle: { fontFamily: 'Poppins_700Bold', fontSize: 18, marginBottom: 14 },
  inputLabel: { fontFamily: 'Poppins_500Medium', fontSize: 12, marginBottom: 6, marginTop: 8 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingHorizontal: 14, paddingVertical: 12, borderRadius: 10, borderWidth: 1,
  },
  input: { flex: 1, fontFamily: 'Poppins_400Regular', fontSize: 14 },
  errorRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8 },
  errorTxt: { fontFamily: 'Poppins_400Regular', fontSize: 12, color: '#EF4444', flex: 1 },
  sheetBtns: { flexDirection: 'row', gap: 10, marginTop: 20 },
  sheetBtn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  sheetBtnTxt: { fontFamily: 'Poppins_600SemiBold', fontSize: 14 },
});
