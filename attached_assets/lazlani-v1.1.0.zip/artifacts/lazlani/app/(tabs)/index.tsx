import React, { useState } from 'react';
import {
  Platform, ScrollView, StyleSheet,
  Text, TouchableOpacity, View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import UserAvatar from '@/components/UserAvatar';

/* ── Reading goal ring ──────────────────────────────────── */
function GoalRing({ pct }: { pct: number }) {
  return (
    <View style={{ width: 66, height: 66, alignItems: 'center', justifyContent: 'center' }}>
      <View style={[styles.ringOuter, { borderColor: 'rgba(255,255,255,0.15)' }]}>
        <LinearGradient
          colors={['#EF4444', '#F97316']}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={styles.ringInner}
        />
      </View>
      <View style={styles.ringCenter}>
        <Text style={styles.ringPct}>{pct}%</Text>
      </View>
    </View>
  );
}

/* ── Category tab pill ──────────────────────────────────── */
type CatTab = {
  key: string;
  icon: React.ComponentProps<typeof Ionicons>['name'];
  label: string;
  isBremil?: boolean;
};

/* ── Book categories for the main feed ─────────────────────────────── */
type BookCat = {
  genre: string;
  icon: React.ComponentProps<typeof Ionicons>['name'];
  color: string;
};
const BOOK_CATEGORIES: BookCat[] = [
  { genre: 'Roman',        icon: 'library-outline',   color: '#9B59F5' },
  { genre: 'Hikâye',       icon: 'bookmark-outline',  color: '#EC4899' },
  { genre: 'Şiir',         icon: 'flower-outline',    color: '#F59E0B' },
  { genre: 'Bilim Kurgu',  icon: 'planet-outline',    color: '#3B82F6' },
  { genre: 'Macera',       icon: 'compass-outline',   color: '#22C55E' },
];

const CAT_TABS: CatTab[] = [
  { key: 'magaza',  icon: 'storefront-outline',  label: 'Mağaza'    },
  { key: 'ozel',    icon: 'sparkles-outline',    label: 'Özel'      },
  { key: 'bulten',  icon: 'newspaper-outline',   label: 'Bültenler' },
  { key: 'dergi',   icon: 'book-outline',        label: 'Dergi'     },
  { key: 'sohbet',  icon: 'chatbubbles-outline', label: 'Sohbet'    },
  { key: 'bremil',  icon: 'star-outline',        label: 'Bremil', isBremil: true },
];

export default function HomeScreen() {
  const colors   = useColors();
  const insets   = useSafeAreaInsets();
  const router   = useRouter();
  const { user } = useAuth();
  const { books, stories, posts, togglePostLike, postLikedIds, unreadNotifCount, weeklyBookId } = useData();
  const weeklyBook = weeklyBookId ? books.find(b => b.id === weeklyBookId) : books.find(b => b.isEditorChoice);
  const topPad   = Platform.OS === 'web' ? 67 : insets.top;

  const [activeCat, setActiveCat] = useState('magaza');
  const [paused,    setPaused]    = useState(false);

  const featured = books.find(b => b.isFeatured) ?? books[0];

  const handleCatPress = (cat: CatTab) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (cat.key === 'sohbet') { router.push('/minnit-chat' as any); return; }
    if (cat.key === 'bulten') { router.push('/bulten' as any);     return; }
    if (cat.key === 'dergi')  { router.push('/dergi' as any);      return; }
    if (cat.key === 'ozel')   { router.push('/ozel' as any);       return; }
    if (cat.key === 'bremil') { router.push('/bremil' as any);     return; }
    setActiveCat(cat.key);
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>

      {/* ── Header ── */}
      <View style={[styles.header, { paddingTop: topPad + 10 }]}>
        <TouchableOpacity activeOpacity={0.8}>
          <LinearGradient
            colors={['#C2185B', '#E91E63', '#FF5722']}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.premiumBadge}
          >
            <Ionicons name="flash" size={12} color="#FFE082" />
            <Text style={styles.premiumText}>Premium</Text>
          </LinearGradient>
        </TouchableOpacity>

        <Text style={styles.logo}>LAZLANİ</Text>

        <View style={styles.headerRight}>
          <TouchableOpacity
            onPress={() => router.push('/(tabs)/discover' as any)}
            style={styles.iconBtn}
          >
            <Ionicons name="search-outline" size={22} color="#E0D8FF" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push('/notifications' as any)}
            style={styles.iconBtn}
          >
            <Ionicons name="notifications-outline" size={22} color="#E0D8FF" />
            {unreadNotifCount > 0 && <View style={styles.notifDot} />}
          </TouchableOpacity>
          <TouchableOpacity onPress={() => router.push('/(tabs)/profile' as any)}>
            <UserAvatar
              name={user?.displayName ?? 'Kullanıcı'}
              color={user?.avatarColor ?? '#9B59F5'}
              size={34}
              imageUri={user?.avatarUrl}
            />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

        {/* ── Category tabs ── */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.catRow}
        >
          {CAT_TABS.map(cat => {
            const isActive = activeCat === cat.key;
            const isBremil = cat.isBremil;

            if (isBremil) {
              return (
                <TouchableOpacity
                  key={cat.key}
                  onPress={() => handleCatPress(cat)}
                  activeOpacity={0.82}
                >
                  <View style={[
                    styles.bremilTab,
                    isActive && styles.bremilTabActive,
                    { borderColor: isActive ? '#F5C842' : 'rgba(245,200,66,0.35)' },
                  ]}>
                    <Ionicons name="star" size={12} color={isActive ? '#F5C842' : 'rgba(245,200,66,0.6)'} />
                    <Text style={[styles.bremilTxt, { color: isActive ? '#F5C842' : 'rgba(245,200,66,0.7)' }]}>
                      Bremil
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            }

            return (
              <TouchableOpacity
                key={cat.key}
                onPress={() => handleCatPress(cat)}
                activeOpacity={0.82}
              >
                {isActive ? (
                  <LinearGradient
                    colors={['#9B59F5', '#EC4899']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    style={styles.catActive}
                  >
                    <Ionicons name={cat.icon} size={14} color="#fff" />
                    <Text style={styles.catActiveTxt}>{cat.label}</Text>
                  </LinearGradient>
                ) : (
                  <View style={styles.catInactive}>
                    <Ionicons name={cat.icon} size={14} color="#C8B8FF" />
                    <Text style={styles.catInactiveTxt}>{cat.label}</Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* ── GÜNÜN KİTABI row ── */}
        <View style={styles.dayRow}>
          <View style={styles.dayBadge}>
            <Ionicons name="sparkles" size={12} color="#E0D8FF" />
            <Text style={styles.dayBadgeTxt}>GÜNÜN KİTABI</Text>
          </View>
          <TouchableOpacity
            onPress={() => setPaused(p => !p)}
            style={styles.pauseBtn}
          >
            <Ionicons name={paused ? 'play' : 'pause'} size={17} color="#E0D8FF" />
          </TouchableOpacity>
        </View>

        {/* ── Hero card ── */}
        {featured && (
          <TouchableOpacity
            onPress={() => router.push(`/book/${featured.id}` as any)}
            activeOpacity={0.92}
            style={styles.heroWrap}
          >
            <View style={[styles.heroCard, { backgroundColor: featured.coverColor }]}>
              <LinearGradient
                colors={[featured.coverColor, featured.coverColor + 'CC', '#1A0A00']}
                start={{ x: 0.3, y: 0 }} end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              <LinearGradient
                colors={['transparent', 'rgba(10,5,0,0.85)']}
                style={styles.heroOverlay}
              />
              <View style={styles.heroContent}>
                <Text style={styles.heroTitle}>{featured.title}</Text>
                <Text style={styles.heroAuthor}>{featured.authorName}</Text>
                <View style={styles.heroMeta}>
                  <View style={styles.heroBadge}>
                    <Text style={styles.heroBadgeTxt}>Kısa</Text>
                    <Ionicons name="film-outline" size={11} color="#fff" style={{ marginLeft: 4 }} />
                  </View>
                </View>
                <View style={styles.heroStats}>
                  <View style={styles.heroStat}>
                    <Ionicons name="eye-outline" size={12} color="#E0D8FF" />
                    <Text style={styles.heroStatTxt}>{featured.readCount}</Text>
                  </View>
                  <View style={styles.heroStat}>
                    <Ionicons name="heart-outline" size={12} color="#E0D8FF" />
                    <Text style={styles.heroStatTxt}>{featured.likesCount}</Text>
                  </View>
                  <View style={styles.heroStat}>
                    <Ionicons name="chatbubble-outline" size={12} color="#E0D8FF" />
                    <Text style={styles.heroStatTxt}>{featured.commentsCount}</Text>
                  </View>
                </View>
              </View>
            </View>
            <LinearGradient
              colors={['#8B5CF6', '#9B59F5', '#EC4899', '#F97316']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={styles.readBtn}
            >
              <Ionicons name="book-outline" size={17} color="#fff" />
              <Text style={styles.readBtnTxt}>Hemen Oku</Text>
            </LinearGradient>
          </TouchableOpacity>
        )}

        {/* ── Stat cards ── */}
        <View style={styles.statRow}>
          <View style={[styles.statCard, { backgroundColor: '#3A2F5A' }]}>
            <View style={styles.statCardTop}>
              <View style={[styles.statIcon, { backgroundColor: '#7F1D1D' }]}>
                <Ionicons name="book" size={17} color="#EF4444" />
              </View>
              <Text style={styles.statCardTitle}>OKUMA{'\n'}HEDEFİN</Text>
            </View>
            <View style={styles.statCardBody}>
              <GoalRing pct={75} />
              <Text style={styles.statCardTxt}>Sana özel 20 kitap hedefi hazırlandı!</Text>
            </View>
          </View>

          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() => router.push('/lazlani-ai' as any)}
            style={[styles.statCard, { backgroundColor: '#3A3020' }]}
          >
            <View style={styles.statCardTop}>
              <View style={[styles.statIcon, { backgroundColor: '#78350F' }]}>
                <Ionicons name="sparkles" size={17} color="#F59E0B" />
              </View>
              <Text style={[styles.statCardTitle, { color: '#F59E0B' }]}>LAZLANİ AI</Text>
            </View>
            <View style={{ paddingTop: 10, gap: 6 }}>
              <Text style={styles.statCardTxt}>Kitap, hikâye ve şiir önerileri için dokunun</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: '#22C55E' }} />
                <Text style={[styles.statCardTxt, { fontSize: 10, color: '#22C55E' }]}>Çevrim içi</Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>

        {/* ── Haftanın Kitabı ── */}
        {weeklyBook && (
          <>
            <View style={styles.sectionHeader}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Ionicons name="trophy" size={15} color="#F5C842" />
                <Text style={[styles.sectionTitle, { color: '#F5C842' }]}>Haftanın Kitabı</Text>
              </View>
            </View>
            <TouchableOpacity
              onPress={() => router.push(`/book/${weeklyBook.id}` as any)}
              activeOpacity={0.9}
              style={[styles.weeklyCard, { backgroundColor: colors.card, borderColor: '#F5C842' + '40' }]}
            >
              <LinearGradient colors={[weeklyBook.coverColor, weeklyBook.coverColor + '44']} style={styles.weeklyCover}>
                <Text style={styles.weeklyCoverInit}>{weeklyBook.title[0]}</Text>
                <View style={styles.weeklyBadge}>
                  <Ionicons name="trophy" size={10} color="#0A0710" />
                  <Text style={styles.weeklyBadgeTxt}>Haftanın</Text>
                </View>
              </LinearGradient>
              <View style={styles.weeklyInfo}>
                <Text style={[styles.weeklyTitle, { color: colors.foreground }]} numberOfLines={2}>{weeklyBook.title}</Text>
                <Text style={[styles.weeklyAuthor, { color: colors.mutedForeground }]}>{weeklyBook.authorName}</Text>
                <Text style={[styles.weeklyDesc, { color: colors.mutedForeground }]} numberOfLines={3}>{weeklyBook.description}</Text>
                <View style={styles.weeklyMeta}>
                  <Ionicons name="heart" size={12} color="#EC4899" />
                  <Text style={[styles.weeklyMetaTxt, { color: colors.mutedForeground }]}>{weeklyBook.likesCount}</Text>
                  <Ionicons name="chatbubble-outline" size={12} color={colors.mutedForeground} />
                  <Text style={[styles.weeklyMetaTxt, { color: colors.mutedForeground }]}>{weeklyBook.commentsCount}</Text>
                  <Ionicons name="star" size={12} color="#F59E0B" />
                  <Text style={[styles.weeklyMetaTxt, { color: colors.mutedForeground }]}>{weeklyBook.rating.toFixed(1)}</Text>
                </View>
                <LinearGradient colors={['#9B59F5', '#EC4899']} style={styles.weeklyReadBtn}>
                  <Ionicons name="book-outline" size={13} color="#fff" />
                  <Text style={styles.weeklyReadBtnTxt}>Hemen Oku</Text>
                </LinearGradient>
              </View>
            </TouchableOpacity>
          </>
        )}

        {/* ── Kategorilere göre kitaplar (max 5 kategori) ── */}
        {BOOK_CATEGORIES.map(cat => {
          const catBooks = books.filter(b => b.genre === cat.genre);
          if (catBooks.length === 0) return null;
          return (
            <View key={cat.genre}>
              <View style={styles.sectionHeader}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Ionicons name={cat.icon} size={15} color={cat.color} />
                  <Text style={styles.sectionTitle}>{cat.genre}</Text>
                </View>
                <TouchableOpacity onPress={() => router.push(`/category?genre=${encodeURIComponent(cat.genre)}` as any)}>
                  <Text style={[styles.seeAll, { color: colors.primary }]}>Tümünü Gör</Text>
                </TouchableOpacity>
              </View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hScroll}>
                {catBooks.map(book => (
                  <TouchableOpacity
                    key={book.id}
                    onPress={() => router.push(`/book/${book.id}` as any)}
                    activeOpacity={0.85}
                    style={styles.bookCard}
                  >
                    <LinearGradient colors={[book.coverColor, book.coverColor + '66', '#1A1040']} style={styles.bookCardCover}>
                      <Text style={styles.bookCardInit}>{book.title[0]}</Text>
                      {book.isEditorChoice && (
                        <View style={styles.editorChip}>
                          <Ionicons name="star" size={8} color="#F5C842" />
                        </View>
                      )}
                    </LinearGradient>
                    <View style={styles.bookCardInfo}>
                      <Text style={[styles.bookCardTitle, { color: colors.foreground }]} numberOfLines={2}>{book.title}</Text>
                      <Text style={[styles.bookCardAuthor, { color: colors.mutedForeground }]} numberOfLines={1}>{book.authorName}</Text>
                      <View style={styles.bookCardMeta}>
                        <Ionicons name="star" size={10} color="#F59E0B" />
                        <Text style={[styles.bookCardMetaTxt, { color: colors.mutedForeground }]}>{book.rating.toFixed(1)}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          );
        })}

        {/* ── Topluluk gönderileri ── */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Topluluktan</Text>
          <TouchableOpacity onPress={() => router.push('/bulten' as any)}>
            <Text style={[styles.seeAll, { color: colors.primary }]}>Tümü</Text>
          </TouchableOpacity>
        </View>
        {posts.slice(0, 2).map(post => (
          <View key={post.id} style={[styles.postCard, { backgroundColor: colors.card }]}>
            <View style={styles.postHeader}>
              <UserAvatar name={post.authorName} color={post.authorAvatarColor} size={34} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.postName, { color: colors.foreground }]}>{post.authorName}</Text>
              </View>
              <Ionicons name="ellipsis-horizontal" size={17} color={colors.mutedForeground} />
            </View>
            {post.title && (
              <Text style={[styles.postTitle, { color: colors.foreground }]}>{post.title}</Text>
            )}
            <Text style={[styles.postContent, { color: colors.foreground }]} numberOfLines={3}>{post.content}</Text>
            <View style={styles.postActions}>
              <TouchableOpacity
                onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); togglePostLike(post.id); }}
                style={styles.postAction}
              >
                <Ionicons
                  name={postLikedIds.has(post.id) ? 'heart' : 'heart-outline'}
                  size={17}
                  color={postLikedIds.has(post.id) ? '#EC4899' : colors.mutedForeground}
                />
                <Text style={[styles.postActionTxt, { color: colors.mutedForeground }]}>{post.likesCount}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.postAction} onPress={() => router.push('/bulten' as any)}>
                <Ionicons name="chatbubble-outline" size={17} color={colors.mutedForeground} />
                <Text style={[styles.postActionTxt, { color: colors.mutedForeground }]}>{post.commentsCount}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.postAction}>
                <Ionicons name="share-social-outline" size={17} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <View style={{ height: 110 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  /* Header */
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingBottom: 12, gap: 8,
  },
  premiumBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 11, paddingVertical: 6, borderRadius: 20,
  },
  premiumText: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 12 },
  logo: {
    flex: 1, textAlign: 'center',
    fontFamily: 'Poppins_700Bold', fontSize: 21,
    color: '#F5C842', letterSpacing: 2,
  },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  iconBtn: { position: 'relative', padding: 4 },
  notifDot: {
    position: 'absolute', top: 4, right: 4,
    width: 7, height: 7, borderRadius: 4, backgroundColor: '#EF4444',
  },

  /* Category tabs — refined */
  catRow: { paddingHorizontal: 16, gap: 8, paddingBottom: 4 },
  catActive: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 22,
  },
  catActiveTxt: { color: '#fff', fontFamily: 'Poppins_600SemiBold', fontSize: 13 },
  catInactive: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 12, paddingVertical: 8,
  },
  catInactiveTxt: { color: '#C8B8FF', fontFamily: 'Poppins_400Regular', fontSize: 13 },

  /* Bremil — smaller + gold */
  bremilTab: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 10, paddingVertical: 6, borderRadius: 18,
    borderWidth: 1, backgroundColor: 'rgba(245,200,66,0.06)',
  },
  bremilTabActive: { backgroundColor: 'rgba(245,200,66,0.12)' },
  bremilTxt: { fontFamily: 'Poppins_500Medium', fontSize: 11 },

  /* GÜNÜN KİTABI */
  dayRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, marginTop: 8,
  },
  dayBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(155,89,245,0.25)', paddingHorizontal: 12, paddingVertical: 7, borderRadius: 18,
  },
  dayBadgeTxt: { color: '#E0D8FF', fontFamily: 'Poppins_600SemiBold', fontSize: 12, letterSpacing: 0.5 },
  pauseBtn: {
    width: 36, height: 36, borderRadius: 11,
    backgroundColor: '#3D3468', alignItems: 'center', justifyContent: 'center',
  },

  /* Hero */
  heroWrap: { marginHorizontal: 16 },
  heroCard: { height: 220, borderRadius: 20, overflow: 'hidden', justifyContent: 'flex-end' },
  heroOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 140 },
  heroContent: { padding: 18, gap: 3 },
  heroTitle: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 25, lineHeight: 31 },
  heroAuthor: { color: 'rgba(255,255,255,0.75)', fontFamily: 'Poppins_500Medium', fontSize: 12 },
  heroMeta: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  heroBadge: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: 9, paddingVertical: 3, borderRadius: 11,
  },
  heroBadgeTxt: { color: '#fff', fontFamily: 'Poppins_500Medium', fontSize: 11 },
  heroStats: { flexDirection: 'row', gap: 12, marginTop: 6 },
  heroStat: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  heroStatTxt: { color: '#E0D8FF', fontFamily: 'Poppins_400Regular', fontSize: 11 },
  readBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    paddingVertical: 15, borderBottomLeftRadius: 20, borderBottomRightRadius: 20,
  },
  readBtnTxt: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 15 },

  /* Stat cards */
  statRow: { flexDirection: 'row', gap: 12, marginHorizontal: 16 },
  statCard: { flex: 1, borderRadius: 16, padding: 13, gap: 5 },
  statCardTop: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statIcon: { width: 34, height: 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  statCardTitle: { color: '#EF4444', fontFamily: 'Poppins_700Bold', fontSize: 11, flex: 1, lineHeight: 15 },
  statCardBody: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
  statCardTxt: { color: '#E0D8FF', fontFamily: 'Poppins_400Regular', fontSize: 11, lineHeight: 17, flex: 1 },

  /* Ring */
  ringOuter: { width: 56, height: 56, borderRadius: 28, borderWidth: 5, position: 'absolute', overflow: 'hidden' },
  ringInner: { ...StyleSheet.absoluteFillObject },
  ringCenter: { width: 46, height: 46, borderRadius: 23, backgroundColor: '#3A2F5A', alignItems: 'center', justifyContent: 'center' },
  ringPct: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 12 },

  /* Sections */
  scroll: { gap: 16, paddingTop: 6 },
  sectionHeader: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', paddingHorizontal: 16,
  },
  sectionTitle: { color: '#E0D8FF', fontFamily: 'Poppins_700Bold', fontSize: 15 },
  seeAll: { fontFamily: 'Poppins_600SemiBold', fontSize: 12 },

  /* Horizontal scroll */
  hScroll: { paddingHorizontal: 16, gap: 12 },

  /* Book card (category slider) */
  bookCard: { width: 130, borderRadius: 13, overflow: 'hidden', backgroundColor: '#3D3468' },
  bookCardCover: { width: 130, height: 160, alignItems: 'center', justifyContent: 'center' },
  bookCardInit: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 44 },
  editorChip: {
    position: 'absolute', top: 7, right: 7,
    width: 20, height: 20, borderRadius: 10,
    backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center',
  },
  bookCardInfo: { padding: 9, gap: 2 },
  bookCardTitle: { fontFamily: 'Poppins_600SemiBold', fontSize: 12, lineHeight: 17 },
  bookCardAuthor: { fontFamily: 'Poppins_400Regular', fontSize: 10 },
  bookCardMeta: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 2 },
  bookCardMetaTxt: { fontFamily: 'Poppins_400Regular', fontSize: 10 },

  /* Haftanın Kitabı */
  weeklyCard: {
    marginHorizontal: 16, borderRadius: 18, overflow: 'hidden',
    flexDirection: 'row', borderWidth: 1,
  },
  weeklyCover: { width: 120, height: 180, alignItems: 'center', justifyContent: 'center' },
  weeklyCoverInit: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 44 },
  weeklyBadge: {
    position: 'absolute', bottom: 8,
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: '#F5C842', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10,
  },
  weeklyBadgeTxt: { fontFamily: 'Poppins_700Bold', fontSize: 9, color: '#0A0710' },
  weeklyInfo: { flex: 1, padding: 13, gap: 5 },
  weeklyTitle: { fontFamily: 'Poppins_700Bold', fontSize: 16, lineHeight: 22 },
  weeklyAuthor: { fontFamily: 'Poppins_400Regular', fontSize: 12 },
  weeklyDesc: { fontFamily: 'Poppins_400Regular', fontSize: 11, lineHeight: 16 },
  weeklyMeta: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  weeklyMetaTxt: { fontFamily: 'Poppins_400Regular', fontSize: 11 },
  weeklyReadBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5,
    paddingVertical: 8, borderRadius: 10, marginTop: 4,
  },
  weeklyReadBtnTxt: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 12 },

  /* Posts */
  postCard: { marginHorizontal: 16, borderRadius: 16, padding: 13, gap: 8 },
  postHeader: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  postName: { fontFamily: 'Poppins_600SemiBold', fontSize: 13 },
  postTitle: { fontFamily: 'Poppins_700Bold', fontSize: 14 },
  postContent: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20 },
  postActions: { flexDirection: 'row', gap: 18 },
  postAction: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  postActionTxt: { fontFamily: 'Poppins_400Regular', fontSize: 12 },
});
