import React, { useState } from 'react';
import {
  Alert, Image, KeyboardAvoidingView, Platform,
  ScrollView, StyleSheet, Text, TextInput,
  TouchableOpacity, View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import UserAvatar from '@/components/UserAvatar';
import { OzelPost } from '@/data/types';

function timeAgo(iso: string) {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return 'şimdi';
  if (diff < 3600) return `${Math.floor(diff / 60)}dk`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}sa`;
  return `${Math.floor(diff / 86400)}g`;
}

function timeLeft(expiresAt: string) {
  const diff = (new Date(expiresAt).getTime() - Date.now()) / 1000;
  if (diff <= 0) return null;
  const days = Math.floor(diff / 86400);
  const hours = Math.floor((diff % 86400) / 3600);
  if (days > 0) return `${days}g ${hours}sa kaldı`;
  return `${hours}sa kaldı`;
}

export default function OzelScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { ozelPosts, addOzelPost, toggleOzelLike, ozelLikedIds, checkContent } = useData();
  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 32 : insets.bottom + 16;

  const [showCreate, setShowCreate] = useState(false);
  const [mediaType, setMediaType] = useState<'photo' | 'video'>('photo');
  const [mediaUri, setMediaUri] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const canPostPhoto = user?.canPostPhoto || user?.isAdmin;
  const canPostVideo = user?.canPostVideo || user?.isAdmin;
  const canCreate = canPostPhoto || canPostVideo;

  // Filter out expired videos (auto-delete)
  const activePosts = ozelPosts.filter(p => {
    if (p.mediaType === 'video' && p.expiresAt) {
      return new Date(p.expiresAt).getTime() > Date.now();
    }
    return true;
  });

  const pickMedia = async (type: 'photo' | 'video') => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('İzin gerekli', 'Galeriye erişim için izin vermeniz gerekiyor.'); return; }

    if (type === 'video') {
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Videos,
        videoMaxDuration: 40,
        quality: 0.8,
      });
      if (!res.canceled && res.assets[0]) {
        const dur = res.assets[0].duration ?? 0;
        if (dur > 40000) { Alert.alert('Süre Hatası', 'Video en fazla 40 saniye olabilir.'); return; }
        setMediaUri(res.assets[0].uri);
        setMediaType('video');
      }
    } else {
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.9,
      });
      if (!res.canceled && res.assets[0]) {
        setMediaUri(res.assets[0].uri);
        setMediaType('photo');
      }
    }
  };

  const handlePublish = () => {
    if (!mediaUri) { Alert.alert('Medya gerekli', 'Önce bir fotoğraf veya video seçin.'); return; }
    if (!user) return;
    if (title.trim() || description.trim()) {
      const filterResult = checkContent([title, description].join(' '));
      if (!filterResult.ok) { Alert.alert('İçerik Filtresi', filterResult.message ?? 'Uygunsuz içerik tespit edildi.'); return; }
    }

    const expiresAt = mediaType === 'video'
      ? new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      : undefined;

    const post: OzelPost = {
      id: Date.now().toString(),
      authorId: user.id,
      authorName: user.displayName,
      authorAvatarColor: user.avatarColor,
      title: title.trim() || undefined,
      description: description.trim() || undefined,
      mediaType,
      mediaUri,
      expiresAt,
      likesCount: 0,
      commentsCount: 0,
      createdAt: new Date().toISOString(),
    };
    addOzelPost(post);
    setMediaUri(null); setTitle(''); setDescription('');
    setShowCreate(false);
  };

  if (showCreate) {
    return (
      <KeyboardAvoidingView
        style={[styles.root, { backgroundColor: colors.background }]}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={topPad + 60}
      >
        <View style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={() => setShowCreate(false)} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={24} color={colors.foreground} />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Özel Paylaşım</Text>
          <TouchableOpacity onPress={handlePublish} style={[styles.pubBtn, { backgroundColor: colors.primary }]}>
            <Text style={styles.pubBtnText}>Paylaş</Text>
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={[styles.form, { paddingBottom: botPad + 60 }]} keyboardShouldPersistTaps="handled">

          {/* Media type selector */}
          <View style={styles.typeRow}>
            {canPostPhoto && (
              <TouchableOpacity onPress={() => setMediaType('photo')}
                style={[styles.typeBtn, { backgroundColor: mediaType === 'photo' ? colors.primary : colors.card, borderColor: colors.border }]}>
                <Ionicons name="image-outline" size={20} color={mediaType === 'photo' ? '#fff' : colors.mutedForeground} />
                <Text style={[styles.typeBtnText, { color: mediaType === 'photo' ? '#fff' : colors.foreground }]}>Fotoğraf</Text>
              </TouchableOpacity>
            )}
            {canPostVideo && (
              <TouchableOpacity onPress={() => setMediaType('video')}
                style={[styles.typeBtn, { backgroundColor: mediaType === 'video' ? colors.primary : colors.card, borderColor: colors.border }]}>
                <Ionicons name="videocam-outline" size={20} color={mediaType === 'video' ? '#fff' : colors.mutedForeground} />
                <Text style={[styles.typeBtnText, { color: mediaType === 'video' ? '#fff' : colors.foreground }]}>Video (maks. 40s)</Text>
              </TouchableOpacity>
            )}
          </View>

          {mediaType === 'video' && (
            <View style={[styles.infoBox, { backgroundColor: '#78350F20', borderColor: '#F59E0B40' }]}>
              <Ionicons name="time-outline" size={16} color="#F59E0B" />
              <Text style={[styles.infoText, { color: '#F59E0B' }]}>Videolar 7 gün sonra otomatik olarak silinir.</Text>
            </View>
          )}

          {/* Media picker */}
          <TouchableOpacity onPress={() => pickMedia(mediaType)} style={[styles.mediaPicker, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {mediaUri ? (
              <Image source={{ uri: mediaUri }} style={styles.mediaPreview} resizeMode="cover" />
            ) : (
              <>
                <Ionicons name={mediaType === 'video' ? 'videocam-outline' : 'image-outline'} size={36} color={colors.primary} />
                <Text style={[styles.mediaPickerText, { color: colors.primary }]}>
                  {mediaType === 'video' ? 'Video Seç (maks. 40 saniye)' : 'Fotoğraf Seç'}
                </Text>
              </>
            )}
          </TouchableOpacity>
          {mediaUri && (
            <TouchableOpacity onPress={() => pickMedia(mediaType)} style={[styles.changeMedia, { borderColor: colors.border }]}>
              <Text style={[{ fontFamily: 'Poppins_500Medium', fontSize: 13 }, { color: colors.primary }]}>Değiştir</Text>
            </TouchableOpacity>
          )}

          {/* Title */}
          <Text style={[styles.label, { color: colors.mutedForeground }]}>BAŞLIK (İSTEĞE BAĞLI)</Text>
          <TextInput value={title} onChangeText={setTitle} placeholder="Başlık ekleyin..."
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} maxLength={100} />

          <Text style={[styles.label, { color: colors.mutedForeground }]}>AÇIKLAMA (İSTEĞE BAĞLI)</Text>
          <TextInput value={description} onChangeText={setDescription} placeholder="Açıklama yazın..."
            placeholderTextColor={colors.mutedForeground} multiline textAlignVertical="top" scrollEnabled={false}
            style={[styles.textarea, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} maxLength={500} />
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 }}>
          <View style={[styles.ozelIcon, { backgroundColor: `${colors.primary}18` }]}>
            <Ionicons name="sparkles" size={18} color={colors.primary} />
          </View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Özel</Text>
        </View>
        {canCreate && (
          <TouchableOpacity onPress={() => setShowCreate(true)} style={[styles.writeBtn, { backgroundColor: `${colors.primary}18` }]}>
            <Ionicons name="add" size={20} color={colors.primary} />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={[styles.listContent, { paddingBottom: botPad }]}>
        {!canCreate && (
          <View style={[styles.infoBox, { backgroundColor: `${colors.primary}10`, borderColor: `${colors.primary}25`, marginBottom: 4 }]}>
            <Ionicons name="shield-checkmark-outline" size={16} color={colors.primary} />
            <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
              Video ve fotoğraf paylaşımı yalnızca yetkilendirilmiş kullanıcılara açıktır.
            </Text>
          </View>
        )}

        {activePosts.length === 0 ? (
          <View style={styles.emptyWrap}>
            <Ionicons name="sparkles-outline" size={48} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Henüz özel paylaşım yok</Text>
          </View>
        ) : activePosts.map(post => {
          const liked = ozelLikedIds.has(post.id);
          const exp = post.expiresAt ? timeLeft(post.expiresAt) : null;
          return (
            <View key={post.id} style={[styles.postCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {/* Media */}
              <View style={styles.mediaContainer}>
                <Image source={{ uri: post.mediaUri }} style={styles.postMedia} resizeMode="cover" />
                {post.mediaType === 'video' && (
                  <View style={styles.videoOverlay}>
                    <Ionicons name="play-circle" size={40} color="rgba(255,255,255,0.9)" />
                  </View>
                )}
                {exp && (
                  <View style={styles.expBadge}>
                    <Ionicons name="time-outline" size={11} color="#F59E0B" />
                    <Text style={styles.expText}>{exp}</Text>
                  </View>
                )}
              </View>

              <View style={styles.postBody}>
                <View style={styles.postAuthorRow}>
                  <UserAvatar name={post.authorName} color={post.authorAvatarColor} size={30} />
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.postAuthor, { color: colors.foreground }]}>{post.authorName}</Text>
                    <Text style={[styles.postTime, { color: colors.mutedForeground }]}>{timeAgo(post.createdAt)}</Text>
                  </View>
                  {post.mediaType === 'video' && <View style={[styles.videoBadge, { backgroundColor: '#EF444420' }]}><Text style={styles.videoBadgeText}>Video</Text></View>}
                </View>
                {post.title && <Text style={[styles.postTitle, { color: colors.foreground }]}>{post.title}</Text>}
                {post.description && <Text style={[styles.postDesc, { color: colors.mutedForeground }]} numberOfLines={3}>{post.description}</Text>}
                <View style={styles.postActions}>
                  <TouchableOpacity onPress={() => toggleOzelLike(post.id)} style={styles.postAction}>
                    <Ionicons name={liked ? 'heart' : 'heart-outline'} size={18} color={liked ? '#EC4899' : colors.mutedForeground} />
                    <Text style={[styles.postActionText, { color: colors.mutedForeground }]}>{post.likesCount + (liked ? 1 : 0)}</Text>
                  </TouchableOpacity>
                  <View style={styles.postAction}>
                    <Ionicons name="chatbubble-outline" size={18} color={colors.mutedForeground} />
                    <Text style={[styles.postActionText, { color: colors.mutedForeground }]}>{post.commentsCount}</Text>
                  </View>
                </View>
              </View>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingBottom: 14, borderBottomWidth: 1 },
  backBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 10 },
  headerTitle: { fontFamily: 'Poppins_700Bold', fontSize: 17 },
  ozelIcon: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  writeBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 10 },
  listContent: { padding: 16, gap: 14 },
  emptyWrap: { alignItems: 'center', paddingVertical: 60, gap: 12 },
  emptyText: { fontFamily: 'Poppins_400Regular', fontSize: 14 },
  postCard: { borderRadius: 16, borderWidth: 1, overflow: 'hidden' },
  mediaContainer: { position: 'relative' },
  postMedia: { width: '100%', height: 280 },
  videoOverlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.2)' },
  expBadge: { position: 'absolute', top: 10, right: 10, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(0,0,0,0.7)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  expText: { color: '#F59E0B', fontFamily: 'Poppins_600SemiBold', fontSize: 10 },
  postBody: { padding: 14, gap: 6 },
  postAuthorRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  postAuthor: { fontFamily: 'Poppins_600SemiBold', fontSize: 13 },
  postTime: { fontFamily: 'Poppins_400Regular', fontSize: 11 },
  videoBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  videoBadgeText: { color: '#EF4444', fontFamily: 'Poppins_600SemiBold', fontSize: 10 },
  postTitle: { fontFamily: 'Poppins_700Bold', fontSize: 15 },
  postDesc: { fontFamily: 'Poppins_400Regular', fontSize: 13, lineHeight: 20 },
  postActions: { flexDirection: 'row', gap: 16, marginTop: 4 },
  postAction: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  postActionText: { fontFamily: 'Poppins_400Regular', fontSize: 13 },
  infoBox: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, padding: 10, borderRadius: 10, borderWidth: 1 },
  infoText: { flex: 1, fontFamily: 'Poppins_400Regular', fontSize: 12, lineHeight: 18 },
  // Create form
  form: { padding: 16, gap: 12 },
  typeRow: { flexDirection: 'row', gap: 10 },
  typeBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 14, borderRadius: 12, borderWidth: 1 },
  typeBtnText: { fontFamily: 'Poppins_600SemiBold', fontSize: 13 },
  mediaPicker: { borderWidth: 1.5, borderRadius: 14, borderStyle: 'dashed', minHeight: 200, alignItems: 'center', justifyContent: 'center', gap: 10, overflow: 'hidden' },
  mediaPreview: { width: '100%', height: 220 },
  mediaPickerText: { fontFamily: 'Poppins_600SemiBold', fontSize: 14 },
  changeMedia: { alignSelf: 'center', paddingVertical: 6, paddingHorizontal: 14, borderWidth: 1, borderRadius: 8 },
  label: { fontFamily: 'Poppins_600SemiBold', fontSize: 10, letterSpacing: 1, marginTop: 4 },
  input: { borderWidth: 1, borderRadius: 12, padding: 12, fontFamily: 'Poppins_400Regular', fontSize: 14 },
  textarea: { borderWidth: 1, borderRadius: 12, padding: 12, fontFamily: 'Poppins_400Regular', fontSize: 14, minHeight: 100 },
  pubBtn: { paddingHorizontal: 18, paddingVertical: 8, borderRadius: 20 },
  pubBtnText: { color: '#fff', fontFamily: 'Poppins_700Bold', fontSize: 13 },
});
