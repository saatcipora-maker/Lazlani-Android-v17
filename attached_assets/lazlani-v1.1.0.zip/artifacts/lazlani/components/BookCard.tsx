import React from 'react';
import { Image, ImageSourcePropType, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { Book } from '@/data/types';
import StarRating from './StarRating';

interface Props {
  book: Book;
  onPress: () => void;
  imageSource?: ImageSourcePropType;
  width?: number;
}

export default function BookCard({ book, onPress, imageSource, width = 140 }: Props) {
  const colors = useColors();
  const h = width * 1.4;

  return (
    <TouchableOpacity onPress={onPress} style={[styles.container, { width }]} activeOpacity={0.85}>
      <View style={[styles.cover, { width, height: h, borderRadius: colors.radius }]}>
        {imageSource ? (
          <Image source={imageSource} style={StyleSheet.absoluteFill} resizeMode="cover" />
        ) : (
          <LinearGradient
            colors={[book.coverColor, '#0D0B24']}
            style={StyleSheet.absoluteFill}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          />
        )}
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.75)']}
          style={[StyleSheet.absoluteFill, { justifyContent: 'flex-end', padding: 10 }]}
          start={{ x: 0, y: 0.4 }}
          end={{ x: 0, y: 1 }}
        >
          <Text style={styles.coverTitle} numberOfLines={2}>{book.title}</Text>
          <Text style={styles.genre} numberOfLines={1}>{book.genre}</Text>
        </LinearGradient>
        {book.isEditorChoice && (
          <View style={[styles.badge, { backgroundColor: colors.accent }]}>
            <Ionicons name="star" size={9} color="#fff" />
          </View>
        )}
      </View>
      <Text style={[styles.author, { color: colors.mutedForeground }]} numberOfLines={1}>
        {book.authorName}
      </Text>
      <StarRating rating={book.rating} size={11} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { gap: 6 },
  cover: { overflow: 'hidden' },
  coverTitle: { color: '#FFFFFF', fontFamily: 'Poppins_700Bold', fontSize: 12, lineHeight: 16 },
  genre: { color: 'rgba(255,255,255,0.7)', fontFamily: 'Poppins_400Regular', fontSize: 10 },
  author: { fontFamily: 'Poppins_400Regular', fontSize: 11 },
  badge: {
    position: 'absolute', top: 8, right: 8, width: 20, height: 20,
    borderRadius: 10, alignItems: 'center', justifyContent: 'center',
  },
});
