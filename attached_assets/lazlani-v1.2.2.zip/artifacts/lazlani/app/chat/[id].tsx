import React, { useEffect, useRef, useState } from 'react';
import {
  FlatList, Keyboard, Platform, StyleSheet, Text, TextInput,
  TouchableOpacity, View, KeyboardAvoidingView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { Message } from '@/data/types';
import UserAvatar from '@/components/UserAvatar';

const HEADER_HEIGHT = 64;

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { conversations, messagesByConv, sendMessage } = useData();
  const [text, setText] = useState('');
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const listRef = useRef<FlatList>(null);
  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const bottomPad = insets.bottom;

  const conversation = conversations.find(c => c.id === id);
  const messages = messagesByConv[id] ?? [];

  // Klavye yüksekliğini takip et
  useEffect(() => {
    const show = Keyboard.addListener(
      Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow',
      e => {
        setKeyboardHeight(e.endCoordinates.height);
        setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
      }
    );
    const hide = Keyboard.addListener(
      Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide',
      () => setKeyboardHeight(0)
    );
    return () => { show.remove(); hide.remove(); };
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      listRef.current?.scrollToEnd({ animated: false });
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  if (!conversation || !user) return null;

  const handleSend = () => {
    if (!text.trim()) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    sendMessage(id, user.id, text.trim());
    setText('');
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 50);
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isMe = item.senderId === user.id || item.senderId === 'current';
    return (
      <View style={[styles.msgRow, isMe ? styles.msgRowMe : styles.msgRowThem]}>
        {!isMe && (
          <UserAvatar
            name={conversation.participantName}
            color={conversation.participantAvatarColor}
            size={30}
          />
        )}
        <View style={[
          styles.bubble,
          isMe
            ? { backgroundColor: colors.primary, borderBottomRightRadius: 4 }
            : { backgroundColor: colors.card, borderBottomLeftRadius: 4 },
        ]}>
          <Text style={[styles.msgText, { color: isMe ? '#fff' : colors.foreground }]}>
            {item.content}
          </Text>
          <Text style={[styles.msgTime, { color: isMe ? 'rgba(255,255,255,0.6)' : colors.mutedForeground }]}>
            {new Date(item.createdAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header — sabit üstte */}
      <View style={[styles.header, { paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <UserAvatar
          name={conversation.participantName}
          color={conversation.participantAvatarColor}
          size={38}
          showOnline={conversation.isOnline}
        />
        <View style={{ flex: 1 }}>
          <Text style={[styles.headerName, { color: colors.foreground }]}>
            {conversation.participantName}
          </Text>
          <Text style={[styles.headerStatus, { color: conversation.isOnline ? '#22C55E' : colors.mutedForeground }]}>
            {conversation.isOnline ? 'Çevrimiçi' : 'Son görülme dün'}
          </Text>
        </View>
        <TouchableOpacity>
          <Ionicons name="ellipsis-horizontal" size={22} color={colors.foreground} />
        </TouchableOpacity>
      </View>

      {/* Mesaj listesi + input kutusu */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={topPad + HEADER_HEIGHT}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={item => item.id}
          renderItem={renderMessage}
          contentContainerStyle={[
            styles.messageList,
            // Android için klavye boşluğu
            Platform.OS === 'android' && keyboardHeight > 0
              ? { paddingBottom: 8 }
              : {},
          ]}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          onLayout={() => listRef.current?.scrollToEnd({ animated: false })}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
          showsVerticalScrollIndicator={false}
        />

        {/* Input bar — her zaman altta görünür */}
        <View style={[
          styles.inputBar,
          {
            borderTopColor: colors.border,
            backgroundColor: colors.background,
            paddingBottom: Math.max(bottomPad, 12),
          },
        ]}>
          <TouchableOpacity style={styles.attachBtn}>
            <Ionicons name="image-outline" size={22} color={colors.mutedForeground} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.attachBtn}>
            <Ionicons name="attach-outline" size={22} color={colors.mutedForeground} />
          </TouchableOpacity>
          <View style={[
            styles.inputWrap,
            { backgroundColor: colors.card, borderColor: colors.border },
          ]}>
            <TextInput
              style={[styles.input, { color: colors.foreground, fontFamily: 'Poppins_400Regular' }]}
              placeholder="Mesaj yaz..."
              placeholderTextColor={colors.mutedForeground}
              value={text}
              onChangeText={setText}
              multiline
              maxLength={1000}
              returnKeyType="default"
              blurOnSubmit={false}
            />
          </View>
          <TouchableOpacity
            onPress={handleSend}
            disabled={!text.trim()}
            style={[styles.sendBtn, { opacity: text.trim() ? 1 : 0.4 }]}
          >
            <LinearGradient
              colors={['#9B59F5', '#EC4899']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.sendBtnGrad}
            >
              <Ionicons name="send" size={16} color="#fff" />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1,
  },
  backBtn: { padding: 4 },
  headerName: { fontFamily: 'Poppins_600SemiBold', fontSize: 15 },
  headerStatus: { fontFamily: 'Poppins_400Regular', fontSize: 12 },
  messageList: { padding: 16, gap: 4, flexGrow: 1, justifyContent: 'flex-end' },
  msgRow: { flexDirection: 'row', gap: 8, alignItems: 'flex-end', marginBottom: 6 },
  msgRowMe: { justifyContent: 'flex-end' },
  msgRowThem: { justifyContent: 'flex-start' },
  bubble: {
    maxWidth: '72%', borderRadius: 18,
    paddingHorizontal: 14, paddingVertical: 10,
  },
  msgText: { fontFamily: 'Poppins_400Regular', fontSize: 14, lineHeight: 20 },
  msgTime: { fontFamily: 'Poppins_400Regular', fontSize: 10, marginTop: 4, alignSelf: 'flex-end' },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 8,
    paddingHorizontal: 12, paddingTop: 10, borderTopWidth: 1,
  },
  attachBtn: { padding: 4, paddingBottom: 8 },
  inputWrap: {
    flex: 1, borderWidth: 1, borderRadius: 24,
    paddingHorizontal: 14, paddingVertical: 8,
    minHeight: 42, justifyContent: 'center',
  },
  input: { fontSize: 14, maxHeight: 120 },
  sendBtn: { width: 42, height: 42, marginBottom: 2 },
  sendBtnGrad: { flex: 1, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
});
